# 通用 MCP 作业桥

`scripts/bridge.py` 是本地 stdio MCP，不是 Ansys 官方发布的 MCP。它帮助缺少终端/文件工具的客户端提交**外部 Python SDK 脚本**，优先使用可用的官方产品 MCP。

## 六个工具

- `inventory()`：只读产品文件和包元数据，可能需要数十秒；单产品任务先用 product_info。
- `product_info(product_id)`：精确产品 ID/别名查询、接口路线和前置条件。自然语言物理问题的选路由模型完成。
- `write_script(project_dir, relative_path, code, overwrite=false)`：把脚本写入配置允许的项目目录，返回 SHA-256。
- `start_job(product_id, project_dir, relative_path, sha256)`：核对产品、路径、hash、脚本声明及 SDK，使用固定解释器启动后台 Python helper。
- `job_status(job_id)`：查看 Python helper 的退出码、状态。
- `read_job_log(job_id, ...)`：读取有界日志。具体可选参数以工具 schema 为准。

写入或运行脚本是执行用户授权的仿真工作，不需额外形式确认。调用方必须先理解脚本会操作哪个项目、哪一个会话。

前 40 行声明示例：

```python
# ansys-product: fluent
# ansys-session: dedicated-keep-open
```

会话值：`dedicated-keep-open`、`attach-existing-read-only`、`attach-existing-authorized`、`batch-owned`。声明用于防止误提交，不能替代检查代码。附着修改必须来自用户的实际任务授权，不是写一行声明就获得授权。

`start_job` 使用的 sha256 必须与 write_script 返回值一致；修改脚本后重新提交新 hash。失败时读日志再修复，不重复提交原脚本制造多个模型/会话。

## 状态含义

- `blocked_student_api`：当前配置 Student 明确禁止该产品接口。
- `blocked_missing_runtime / blocked_missing_sdk`：缺运行环境；按 product_info 的官方来源安装正确依赖。
- `blocked_no_python_route`：该产品还需适配器，不能仅改标签绕过。
- `eligible_for_script`：仅允许运行 helper，不保证 SDK 能导入、应用安装、许可有效或求解成功。
- helper 的 completed/exit0 **不等于** solver 求解或 GUI 验证通过。脚本需另外保存真实 API 状态、物理验证及原生文件证据。

## 生命周期与权限

桥只管理自己启动的 helper 和日志，不关闭 Ansys。Python 脚本应按用户意愿保留自建 GUI；不要用会自动退出的上下文管理器。如果有 batch-owned 专用后台求解会话，脚本只清理该会话。

目录检查限制工具把文件放到哪里；**Python 执行不是沙箱**，代码具有运行账户权限，可以调用 SDK 和系统功能。仅让可信本地客户端接入；不要把该 stdio 桥暴露为无认证公网服务。配置不存 API 密钥、许可证文本或 server-info 密码。

库存只读本地文件和 SDK 包元数据，不扫描许可证、不导入 SDK、不启动 Ansys。迁移后更新根目录和环境，旧的“已验证”标签仅代表历史算例证据。

Job ID 只在当前桥进程有效。持久记录位于项目 `.ansys-unified-jobs/<job-id>/job.json` 和 `output.log`，日志保留最后 1 MiB。等待 helper 完成后再退出客户端；运行中的 helper 日志管道依赖桥进程，不能把客户端退出当作正常作业结束。
