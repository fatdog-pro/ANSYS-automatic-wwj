# Mechanical 机械臂支架：静力＋六阶模态

这是 ANSYS automatic wwj 的内置 Mechanical 示例。2026-09-20 在 Student 2026 R1 / Mechanical 261 上通过官方 MCP 分阶段实测了：新建可见会话、STEP 导入、原生二次网格、静力与六阶模态求解、反力验收、六个原生 GIF 导出、保存重开数值核对。不是 Fluent 的内置结构求解器。

## 执行固定路线

代码位于 `scripts/mechanical_bracket/`，已有对照结果位于 [原生结果与录屏说明](../assets/examples/mechanical-bracket/README.md)。默认按脚本重新求解；用户只想预览时才打开已有工程。

1. 准备 Gmsh 4.15.2 / Python 环境，运行 `generate_bracket.py --out <新建的纯英文绝对工作目录>`，生成 STEP 与几何参数。
2. 检查 Mechanical MCP 状态。使用新建、可见、空白的专用 Mechanical 261 会话，Windows transport 为 `wnua`；不要清空用户已有工程。先读取本机 MCP 对应 guidelines。
3. 逐个读取 `01_import.py`、`02_setup_mesh.py` 的内容。每次通过 MCP `run_python_script` 执行前，在脚本最前面注入 `WWJ_RUN_DIR = <工作目录的 Python 字符串字面量>`。该变量必须在 Mechanical 内部定义，不能仅在外部 Python 定义。脚本不硬编码几何面 ID。
4. 用 `save_project(file_path=<工作目录>/WWJ_Robot_Bracket.mechdb)` 保存新工程。执行 `03_solve.py`，同样注入工作目录。检查 MCP 返回文本中的实际异常；不能只看外层 isError。求解设置暂用 SMP 2 核、手动初始工作区 1024 MB，finally 恢复原配置。本机两项求解约 33 秒，不包含其他阶段。
5. 执行 `04_present.py`。静态显示 200 倍变形，模态采用自动放大、归一化振型。Student 本机禁止 MP4 导出，使用允许的 GIF。原生设置为 60 帧、4 秒；实际编码为 118 帧、3.54 秒，以导出文件核对值为准。导出需要几分钟，不等于求解耗时。
6. 保存当前工程，再重开相同文件，执行 `05_verify_reopened.py`；它检查两项 Done、位移/应力/频率一致及网格质量。用有 Pillow 的外部 Python 执行 `verify_animations.py --out <工作目录>`，检查所有 GIF 的分辨率、帧数及变化。
7. 保持 Mechanical 原生窗口打开。`WWJ_Robot_Bracket.mechdb` 必须与同名 `_Mech_Files` 目录一起交付。

分阶段代码已实测；打包版本只把工作目录改为显式输入，没有独立验证另一个全自动启动包装器或豆包客户端。接收者必须验收自己的新运行。不要声称所有 Mechanical 分析均已通过。

## 验收与实质限制

本次 45075 节点、25083 实体单元；最大位移 0.0306351 mm、最大等效应力 70.9695 MPa，反力相对误差 5.35e-7。前六阶频率为 1088.959、3194.516、4345.069、5843.561、6080.027、6797.851 Hz。来源数值用于对照，不要求另一环境逐位相等。

单体线弹性钢支架，底面完全固定，轴承孔面分布合力 [2000,750,-1500] N；模态独立、无预应力。没有螺栓/轴承接触、塑性、疲劳或瞬态振动计算。模态动画数值不是物理振幅，播放时长不是实际振动周期。

Mechanical 原生质量检查未报告失败单元，但最差偏斜度 0.99277、最小单元质量 0.07718，仍属教学演示网格，未做网格收敛研究，不把峰值应力当作设计认证。求解日志 SHPP 未开启警告与 SURF154 载荷单元 material 2 提示保留在来源记录中；实体材料已读取核对。

证据：[求解结果](../assets/examples/mechanical-bracket/results.json)、[保存重开](../assets/examples/mechanical-bracket/native_reopen_verification.json)、[动画检查](../assets/examples/mechanical-bracket/animation_validation.json)。
