# 已求解飞机绕流：模型、过程与证据

作者：抖音 萌猪过河。资源目录为相对 skill 根目录的 `assets/examples/aircraft/`。这是自建通用飞机，不对应真实机型。默认按已经验证的脚本重跑完整流程，操作见 [Fluent](fluent.md)；以下数值是来源运行的对照，不是接收者的新结果。

## 已保存结果

| 项目 | 源机器实测值 |
|---|---:|
| 求解器 | Fluent 2026 R1 Student，3D 双精度，PyFluent 0.42.1 |
| 来流、迎角 | 20 m/s、5° |
| 网格 | 59,431 四面体，11,659 节点 |
| 真实迭代 | 747 |
| 全机升力 +Z | 554.092533 N |
| 全机阻力 +X | 63.034873 N |
| CL / CD | 0.4074958875 / 0.0463576930 |
| 最终连续性残差 | 9.9587147×10⁻⁵ |
| 全局质量不平衡率 | 3.2771×10⁻¹¹ % |
| 源机器保存重开 | 升力、阻力、CL、CD 回读完全一致 |

系数按主翼参考面积 **5.55 m²** 归一化，包含埋入机身部分。空气密度 1.225 kg/m³，动压 245 Pa，`CL=L/(qS)`、`CD=D/(qS)`。它们是以主翼面积归一化的整机系数。

## 几何和物理设置

- 椭球机身长 4 m、宽 0.6 m、高 0.7 m；主翼翼展 6 m、根/梢弦 1.15/0.70 m；平尾展长 2.3 m，垂尾顶部约 1.2 m。
- 翼/尾翼为闭合尾缘的对称 NACA 0012 厚度形状，经 Gmsh 4.15.2 / OpenCASCADE 合并为一个闭合实体。整机绕 +Y 旋转 +5°，机头在 −X 侧并抬高；来流 +X，升力 +Z。
- 外部盒子 x∈[−12,24]、y∈[−15,15]、z∈[−12,12] m，扣除飞机成为流体域；没有发动机、螺旋桨、起落架或自由飞行运动。
- 稳态、常密度不可压缩 RANS，SST k–ω，全湍流假设，未启用转捩；μ=1.7894×10⁻⁵ Pa·s，操作压力 101325 Pa，能量方程关闭。
- `inlet`：20 m/s、湍流强度 1%、黏度比 10；`outlet`：表压 0 Pa，回流相同湍流条件；四个外侧面 `farfield` 为 symmetry；`aircraft_wall` 光滑、静止、无滑移。
- 参考平均气动弦 0.943243 m，雷诺数约 1.291×10⁶。网格为无棱柱边界层的粗四面体，机体 CAD 与三角面离散体积相差约 1.57%。

## 已验证、供固定执行器重跑的数值阶段

1. 建立闭合飞机与外部流体几何，导出 STEP / STL 与含命名边界的 Fluent ASCII 网格；正体积、邻接和闭合性检查通过，Fluent 实际导入检查完成。
2. 设置材料、边界和力报告，Hybrid Initialization。
3. 第 1–50 步 SIMPLE，动量/k/ω一阶迎风；51 步起三者二阶迎风，压力始终二阶。
4. 第 101 步起 Coupled + 全局伪时间，初始自动 Conservative 长度/倍率 1；161 步起倍率 5。191 步起 k/ω显式松弛 0.5、AMG 精度 0.01。
5. 291 步起压力耦合 AMG 精度 0.01；391 步起精度 0.001、最多 30 个 AMG 周期。491 步起伪时间倍率回到 1；591 步起特征长度改为平均气动弦。
6. 第 747 步达到原定验收：最后一步连续性 <1e−4、速度三分量/k/ω <1e−5；最后连续 50 步 CL/CD 的范围/绝对均值均 <1%；整体质量不平衡 <0.1%。守恒、残差与系数稳定性分开判断，未改归一化或放宽残差目标。
7. 导出原生压力、流线和速度切面，保存 Case/Data；重开后四个力/系数读数完全恢复。原始残差及系数曲线已随包保存。

伪时间是稳态迭代算法，不是飞机实际飞行时间。最后 50 步的稳定性判据针对 CL/CD；不能声称这 50 步的所有残差都已低于最终阈值。原始完整判断见 `results/validation.json`。

## 文件用途

| 相对资源目录的位置 | 用途 |
|---|---|
| `results/aircraft.cas.h5`、`aircraft.dat.h5` | 可直接读取的原生网格、设置和已求解场；必须配套保留 |
| `geometry/aircraft.step`、`fluid_domain.step` | 独立飞机与流体域 CAD |
| `geometry/aircraft_surface.stl`、`aircraft_fluent.msh` | 飞机表面及已检查的体网格 |
| `results/aircraft_pressure.png`、`aircraft_streamlines.png`、`aircraft_wing_velocity.png` | Fluent 原生图形导出 |
| `results/convergence.png`、`*-history.csv` | 原始计算的收敛曲线及完整数值历史 |
| `records/progress.json`、`final_values.json`、`reopen_verification.json` | 原始求解与重开证据 |
| `results/validation.json`、`geometry/mesh_validation.json` | 数值、守恒和网格拓扑检查 |
| `expected.json`、`manifest.json` | 本机打开后的力核对基准及资产完整性清单 |
| `replay/` | 原算例实际成功执行的建模、网格、求解、显示及验证脚本，供固定执行器顺序运行 |
| `replay/requirements.txt` | 已使用过的 Python 依赖版本；可在独立环境安装 |

记录中出现的作者原始工作路径属于来源证据。重跑执行器重新生成模型/网格并初始化求解，所有新输出写到接收者的独立运行目录；源记录中的 747 步和数值不作为新运行成功的证据。精确步数可能随目标机环境变化，执行器读取本次真实残差/力历史并验收，不强行把它写成 747。仅预览工具读取旧 Case/Data，输出明确标记“未重新求解”。

重新执行同一 Gmsh/Netgen 生成路线时，网格节点和单元数也可能小幅变化；独立复跑曾生成 59,947 单元并通过全部拓扑检查。图表和验收必须读取新网格元数据，不能写死来源运行的 59,431 单元或强求升阻力逐位相同。

## 精度限制

实际壁面面积平均 y+≈857、最大≈1670；没有棱柱边界层、网格独立性研究、外域敏感性或风洞对照。近壁分辨率不足，尤其摩擦阻力、分离和尾流细节不能用于定量设计结论。本算例展示真实完整 CFD 流程，**数值收敛通过，气动精度尚未验证**。

压力云图为节点平均插值，面值统计极值约 −387.81/232.81 Pa，两者范围可不同。流线来自稳态平均速度场，不是瞬态飞行动画。

官方方法参考：[SST 外流设置](https://fluent.docs.pyansys.com/version/stable/examples/00-fluent/external_compressible_flow.html)、[伪时间控制](https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/flu_ug/flu_ug_sec_solve_pseudo.html)、[原生 Scene](https://fluent.docs.pyansys.com/version/stable/examples/00-fluent/exhaust_system_settings_api.html)、[Gmsh](https://gmsh.info/doc/texinfo/)。
