# 此版本交付验证

日期：2026-09-15。产品安装为本机 Ansys Student 2026 R1；该记录不随迁移自动成立。

## 库存

实际运行 `scripts/inventory.py`，41 条产品/应用注册项：

| 前置状态 | 数量 | 含义 |
|---|---:|---|
| eligible_for_script | 2 | Mechanical、Fluent，已有 Python SDK 元数据 |
| blocked_missing_sdk | 27 | 当前配置的环境缺相应官方 SDK；也可能缺独立产品 |
| blocked_student_api | 1 | OpticStudio Student 禁止编程接口 |
| blocked_no_python_route | 11 | 需产品原生脚本/CLI 的适配器，不能冒充已实现 |

26 项找到了候选程序文件。这可能包括共享组件或辅助程序，不能报告为 26 个已安装且可运行的独立求解器。

库存没有 SDK import、许可证签出或 Ansys 启动。完整本机库存保存在包外 `inventory-20260915.json`，仅用于本机排查。产品历史真实验证见 verified-baseline.md。

## 新代码

- `quick_validate.py`：技能格式通过；UTF-8 中文入口与 UI 元数据已检查。
- `test_bridge.py`：11 项测试，10 通过；Windows 当前账户不能创建符号链接，相关 1 项跳过。
- 实际 Python helper 成功与异常退出、错误 hash、产品/会话声明、路径穿越、缺 SDK、Student API 禁用、配置解释器、有界日志及 bundled API 路径均测试。
- FastMCP 实际 stdio 工具发现与 product_info 调用通过，6 工具可见；Mechanical 0.13.2 / Fluent 0.42.1 读取正确，zemax 别名返回 opticstudio 并阻断 Student API。
- 初版通道网格生成器已替换为三维飞机建模/网格代码及完整重跑路线。打包更新本身不等于再次执行了一轮求解。
- 独立代理使用五种真实请求做 forward-test：CFX 精确选路、Student OpticStudio API、现有 Mechanical 添加模态并保留窗口、豆包迁移边界、helper completed 的含义。均未发现严重误导；适配器扩展步骤已补充。
- 安装位置的真实 stdio 端到端检查通过：发现6工具，读取3产品状态，再通过 write_script/start_job 实际导入 Mechanical SDK，helper 正常结束并读取日志；没有启动求解器。已打开的 Mechanical 进程仍响应，工程标题正确。
- 本机适配器配置分支检查通过：缺路径阻断、存在路径仍标 configured_unverified、已知 Student API 禁用仍优先阻断。

以上桥与库存记录来自初版技能验证，不表示此后所有版本自动通过。飞机示例本身的源机求解/重开记录见 verified-baseline.md，打开器的打包验证另列下文。豆包客户端导入、其他产品求解和未授权产品的 API 仍未验证。

## 飞机固定重跑路线的打包验证

- 默认入口 `replay_fluent_aircraft.py`，原实际成功脚本按固定顺序执行，最多请求790步；当前运行独立验收，旧结果仅作参考。另有显式预览入口 `open_fluent_aircraft.py`。
- 技能格式、脚本语法、无SDK的 `--plan` 与 MCP `runpy` 入口通过；完整 manifest 校验包含46个资产，其中24个为重放脚本/依赖文件。
- 只读预检正确识别 Python3.12.14、PyFluent0.42.1、Gmsh4.15.2 与已有Fluent会话，未启动第二实例。受限工具环境曾因系统拒绝 tasklist 而停止；正常主机权限下成功识别已有进程。进程检查错误现在保留具体stderr原因。
- 独立代理在新的中文目录中实际执行复制出的几何/网格生成脚本：24.68秒，59947四面体、11734节点；CAD体积与基线一致，正体积、面邻接、壁面闭合、体积一致性通过。
- 网格计数相对源运行略有变化，因此新图表使用当前网格元数据；源机升阻力只作对照，不能要求新运行逐位相同或代替其验收。
- 日志转发器已测试关闭阶段日志后的异步write/flush，避免后台输出持有旧流导致异常。
- 本轮更新没有重新启动Ansys或再做一轮CFD求解；新入口的整个求解到重开流程尚未在本轮整轮实测。它调用的是源运行已逐段成功的代码；实际重跑必须以目标机的新记录判断成功。

<!-- fish-fsi-20260917 -->
## 2026-09-18：精细鱼固定路线与来源运行交付

本次完整入口自行启动 1 进程的专用 Fluent GUI 会话，重新生成几何和网格、从时间 0 初始化并计算 20 步、验收、保存重开及原生播放均通过。显式 attach 到已有会话的分支未在本版另做完整 20 步实测；豆包客户端未实测。 本机并行新启动尚未验证成功；本例使用单进程。

- `scripts/replay_fluent_fish.py` 实际执行新几何生成、眼面分区、时间 0 初始化、20 个物理步、独立逐步验收、所有保存步 HDF 检查、原生显示、保存重开和有限播放；[完整入口记录](../assets/examples/fish/records/replay_summary.json) 保留本次阶段与状态。
- [四项 FSI 证据](../assets/examples/fish/records/fsi_evidence.json) 与 [最终验收](../assets/examples/fish/records/validation.json) 均通过，来源文件及身份见 [精细网格记录](../assets/examples/fish/records/refined-mesh-identity.json)。
- 打包与文档发布均重新核验 `mesh-quality-0000.json`–`mesh-quality-0020.json` 全部 21 份原生质量记录及固定正交质量门槛 ≥ 0.001；汇总和 FSI 证据一致，不能仅凭 Gmsh SICN 放行。
- 生成器离线 `fluent_quality_gate` 必须通过，三个体区数量、全局最低值须与网格元数据一致，全部正交质量 > 0.001；本次离线最低值 0.00155575。此生成门槛不能替代原生质量记录。
- 随包交付精细鱼初始/最终 Case/Data、20 帧 CXA/HSF、CSV 与审计；完整中间数值场由新运行重新生成。依赖见 [requirements](../assets/examples/fish/replay/requirements.txt)，Matplotlib 仅为可选作图依赖。
- 模型是来流中的精细刚性前身规定平移和柔性尾部响应；前身无结构单元，不是全鱼弹性或自由游泳。仅柔性尾采用 Fluent standalone intrinsic FSI，流体有限体积与内置结构有限元双向耦合，没有调用 Mechanical 或 System Coupling。 未完成网格/时间步独立性和物理精度验证；屏幕画面、无限循环播放、其他 Ansys 求解器及接收者机器均不在这次验收结论内。

包内文件校验和压缩包检查应以本次打包记录为准；文档更新本身不代替打包验证。参数和实测数值统一见 [精细鱼说明](fish-fsi.md)。
<!-- /fish-fsi-20260917 -->

## 2026-09-20：Mechanical 支架静力与六阶模态

新增例程实际完成新建可见 Mechanical 261 会话、单体 STEP 建模导入、45075 节点二次网格、静力与六阶模态求解、反力平衡、六个原生 GIF 导出、保存重开数值一致性检查。两项纯求解约 33 秒。详细证据、固定脚本与限制见 [支架例程](mechanical-bracket.md)。这是新增的分阶段源机验证，不代表跨客户端、一键包装器或其他 Mechanical 分析已实测。


## 2026-09-20：全身柔性鱼快速版完整重跑

完整新入口从几何生成到 28 步 × .025 s 求解、全部验收、原生动画及重开均已实测，耗时 20.22 分钟。首尾仍未闭合，跨客户端未实测。参数见 [全身柔性鱼](fish-fullbody-fsi.md)，计时证据见 [timing.json](../assets/examples/fish-fullbody/timing.json)。


## 2026-09-21：鱼结果与对话动画导出

统一导出脚本在最终原生会话实测 42.39 秒，28 个原生 HSF 均渲染成不同帧，GIF/MP4 解码各 28 帧、2.8 秒；另输出位移和压力 PNG、CSV 原始曲线、JSON 和 Markdown。前后原生时间、报告、最终 Case/Data 哈希一致。新完整入口默认调用该步骤，并在求解前预检依赖；组合入口本次仅做参数/阶段检查，没有再次从建模起计时。原 1213 秒基线保持其原验证范围。见 [导出证据](../assets/examples/fish-fullbody/deliverables/delivery.json)。
