# 全身柔性鱼：半小时快速教学流程

作者：抖音 萌猪过河

## 当前实测

2026-09-20，Intel Core i5-12450H，Fluent Student 2026 R1，单进程。完整 `replay_halfhour_fish.py` 从新几何到求解、独立验收、原生动画、最终 Case/Data 重开耗时 **20.22 分钟**，未载入旧物理结果。此为本机一次完整实测，不保证不同电脑、版本或后台负载相同。证据见 [timing.json](../assets/examples/fish-fullbody/timing.json)。

保留 **0.70 s / 28 步 / dt=.025 s**。原生求解时保存 HSF，验收后直接整理，不再为每一帧重开 Case/Data 和重复渲染。**首尾尚未闭合**；提速通过不代表稳定周期或定量精度通过。

## 固定入口

```powershell
& $ansysPython "$skillRoot/scripts/fish_fullbody/replay_halfhour_fish.py" --fluent $fluentExe --mesh-python $meshPython --runtime-root C:/AnsysWork/runs
```

`--plan` 只读输出路线。需要 Fluent 26.1 有效许可、PyFluent 0.42.1、NumPy、h5py、Gmsh 4.15.2；网格与求解 Python 可不同。工作目录用纯英文。默认新建专用 GUI 并保留窗口。已有实例占用唯一可用许可时，先核对会话归属与保存状态，不反复盲启、不关闭未保存的用户工程。

步骤固定为：新几何和网格 → 眼面分区 → 新 Fluent / t=0 → 28 步逐步验收及原生帧 → 全部检查点独立复核 → 首尾检查 → 原生动画读取/有限播放 → 最终工程重开核对 → GIF/MP4、云图、曲线与数值摘要自动导出。不要重新摸索接口或自动回到旧长流程。默认预算 1800 s，前几步按实际耗时预测；超预算预期或失败时在检查点停止。预算检查在单步完成后进行，不是强制中断硬超时。`STOP_AFTER_STEP` 可请求在合格步骤后停止。

## 固定参数

- 轻量 20 cm 鲫鱼/鲤鱼式外形，保留圆润鱼身、眼、背鳍和分叉尾；省略鳃盖、胸鳍和臀鳍，保留鳍厚 4 mm。初始水域 13025、鱼身 6557、尾部 3988 单元，总计 23570。几何简化改变了阻力和刚度，不宣称与旧模型定量等价。
- 网格：`generate_realistic_fish.py --lightweight`，body .004 m、tail .0025、far .035、eyes .0015、gills 0；水域尺寸过渡距离 .04 m，优化 10 轮，无局部细化球，保留 Gmsh 单线程固定种子设置。SICN≥.08 和离线 Fluent OQ≥.001，仍需原生质量检查。
- dt=.025 s，动量一阶迎风，Backward Euler，结构 predictor=1；首个真正新迭代结束后用官方同步事件切换 corrector=.5，并核验事件顺序。全湿面 mesh relaxation=1，diffusion 参数=2。
- 从开始启用 methods-based 水域重网格：unified=false，调用原生 remeshing_methods() 初始化方法，skew_max=.95，仅 water 重网格；固体参考拓扑和湿面拓扑不变。
- 每步最多 100 迭代；连续性前 3 步<.005、以后<.01，速度/位移残差<1e-4，并要求原生收敛标记。原生 OQ≥.001、原生有向体积>0、结构 J>0、界面差≤1 µm、相对 ALE 质量误差<.001。不降低门槛强行接受失败。
- 固定动画色标 0–.06 m，显示位移放大关闭；若本次位移超过色标范围，停止快速导出并重新选择范围，不默默截断色标。

## 物理模型与边界

水密度 1000 kg/m³、黏度 .001 Pa·s，来流 .05 m/s；鱼身 E=.2 MPa、尾 E=2 MPa，ν=.35，固体密度 1000。头端小面 XYZ 固定，其余湿面 XYZ intrinsic FSI。鱼身 Y 向主动体积力 15000 N/m³，2 Hz、渐增时间 .15 s；空间行波使用 C_CENTROID，其参考坐标语义尚未独立确认。无重力、无 Z 主动驱动、无新增竖向泳姿约束。

这是 Fluent 内置结构有限元与流体有限体积的双向耦合，不调用 Mechanical/System Coupling，不是自由游泳。两种结构材料之间的 interior 警告保留，不能盲目切成流体壁面对而断开结构。低网格质量及教学离散限制定量用途；没有网格/时间步独立性和实验校准。

`audit_remesh.py` 依据各时刻真实水域拓扑复核；`present_fast.py` 只交付已验收 HSF 并记录来源哈希。`check_loop.py` 比较相隔 .5 s 的真实三维位置和有限差分速度，要求两侧运动、两次转向、位置差≤5%、速度差≤15%。本次闭合失败，只交付 `fullbody-process`；禁止用倒放、镜像或插值冒充实际求解周期。

开发时 dt=.05 s 在 .4 s 出现界面误差和迭代振荡，未通过验收，不是可用快速路线。旧 `replay_fullbody_cycle.py` / `continue_cycle.py` 保留历史诊断用途，半小时任务用本节新入口。`server.info` 是本机凭据，不分享。

原生结果、实际数值和打开方式见 [结果说明](../assets/examples/fish-fullbody/README.md)。本例始终属于同一个 **ANSYS automatic wwj** skill。


## 自动结果与对话动画（2026-09-21）

默认完整入口在原生验收通过后自动执行 `export_deliverables.py`，输出到本次 `solution/deliverables/`：

| 文件 | 内容 |
|---|---|
| `fish-swimming.gif`、`fish-swimming.mp4` | 全部 28 个 Fluent 原生帧，10 fps、4 倍慢放；没有插帧、倒放或位移放大 |
| `displacement-final.png` | 最终时刻原生位移云图 |
| `pressure-final.png` | 最终时刻水侧湿面静压云图，单位 Pa |
| `result-curves.png` | 鱼身/尾位移、侧向摆动、弯曲指标及 ALE 守恒误差随真实时间变化 |
| `results.csv`、`results-summary.json` | 原始逐步数值和带单位的摘要 |
| `results.md`、`delivery.json`、`frame-provenance.json` | 结果索引、导出状态、媒体校验与帧来源 |

原生 Case/Data、UDF 库和 `fullbody-process/` 仍保存在 `solution/`，保持配套文件完整。

**agent 的最终回复应直接嵌入本次生成的 GIF，并展示关键云图或结果曲线，列出主要数值、单位和验证状态，附 MP4、CSV、原生工程链接。** 支持本地媒体的客户端使用 `![鱼游动](绝对路径/fish-swimming.gif)`；不支持内嵌的客户端明确说明限制，提供可打开的文件。不要仅回复“动画已保存”。保留首尾未闭合和教学精度说明。

### 执行依赖与失败处理

- 求解 Python 还需要 `matplotlib`；本机导出实测版本 3.11.2。
- FFmpeg 需支持 GIF、palettegen/paletteuse，以及 `libopenh264` 或 `libx264`。优先发现本机 Ansys 的 `tp/ffmpeg/*/winx64/ffmpeg.exe`，其次 PATH；也可向完整入口传 `--ffmpeg <实际路径>`。脚本没有写死作者电脑盘符，不随包分发 FFmpeg。
- 完整入口在求解前检查导出依赖，为结果导出预留 120 秒预算；真实最终耗时和 `within_budget` 包含此新阶段。预算是完成步后的检查，不是硬中断保证。
- 当前 Fluent 视频菜单不可用时，已验证路线是官方 API 逐帧播放 HSF 并保存 PNG，再编码 GIF/MP4。每帧来自通过验收的 HSF，检查 SHA、解码帧数、时长和差异；前后核对原生报告及 Case/Data 哈希不变。
- 使用唯一动画序列名避免覆盖对话框。逐帧结束后恢复完整播放范围；本版本的 `player='[]'` 曾触发 Scheme 错误，使用已验证的正向单次播放恢复。
- 导出失败时保留已有求解结果，完整入口返回 `solve-validated-delivery-failed`。修复依赖后单独重跑下面的导出命令，使用新的输出目录；无需重算物理场。

```powershell
& $ansysPython "$skillRoot/scripts/fish_fullbody/export_deliverables.py" --root C:/AnsysWork/runs/fish-run-id/solution --server-info C:/AnsysWork/runs/fish-run-id/solution/server.info --fluent $fluentExe --out C:/AnsysWork/runs/fish-run-id/solution/deliverables-retry
```

命令中的 fish-run-id 需换成本次真实的纯英文目录名。`server.info` 是本机凭据，不分享。导出连接要求当前原生会话与此运行的最终时间、报告一致；不匹配时先恢复正确工程，不替换未知的未保存项目。

### 本次验证范围和计时

新导出脚本在已验收的 0.70 s 运行上独立实测 **42.39 秒**，两种媒体均为 28 帧、2.8 秒；云图、曲线、数值摘要均生成，原生报告与 Case/Data 未改变。原 **1213 秒**基线不包含本节新增导出阶段；新增组合入口尚未从建模起重新计时，不把两次测量之和宣称为一次完整实测。已检验新入口参数和阶段衔接，数值求解参数保持原已验证设置。豆包客户端执行仍需独立验证。
