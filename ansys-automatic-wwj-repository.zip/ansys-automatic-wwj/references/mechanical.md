# Mechanical：接口、热与结构

本页记录 2026-09-15 的本机历史探索：Ansys 261 Student + PyMechanical 0.13.2 + Mechanical MCP 0.2.0，WNUA。2026-09-20 新增了 [Mechanical 支架静力＋六阶模态固定路线](mechanical-bracket.md)，该例已分阶段实测；下述梁和热分析仍是历史接口记录，不能扩大新例验证范围。其他版本先查实际方法。

## 连接与显示

优先 native `ansys_mechanical` MCP：
- check_mechanical_status → read-only run_python_script 读取工程路径、Model.Analyses 和现有数据。
- 无可用会话时用 launch_mechanical：batch=false，version="261"，transport_mode="wnua"，必要时 exec_file 指定 aisol/bin/winx64/AnsysWBU.exe。
- 已有未保存工程不要清空。新演示使用新会话和唯一工程目录；attach 修改按用户指定范围执行。
- IronPython 运行脚本中有 Model、ExtAPI、Quantity；中文 .NET 字符串转 `unicode()`，数值转 int/float 再序列化。不要用 str() 转中文名称。
- MCP 外层成功不代表脚本成功。检查返回的实际错误信息、结果状态和数值；重试前读回已创建对象，避免重复分析或载荷。

结果显示（实际方法已验证）：

```python
result.Activate()
ExtAPI.Graphics.Camera.SetSpecificViewOrientation(ViewOrientationType.Iso)
ExtAPI.Graphics.Camera.SetFit()
```

export image 用 Graphics 的原生接口。用户要保持窗口时不调用 disconnect：此 MCP 的 disconnect 会退出 Mechanical。

## 已验证模型构造方法

官方示例 STEP 来源：
https://raw.githubusercontent.com/ansys/pymechanical-mcp/main/examples/cantilever_beam/beam.step

SHA-256：600cdf605343ece795648bf2e3dd1a11c54ccdb02bb059c7e8b4436c6955c725

读当前 geometry/meshing/materials 等 MCP guidelines 后构建。该模型单实体，X±100、Y±10、Z±5 mm；几何单位必须读 GeoData.Unit。不要把该几何专属尺寸当通用默认，也不要硬编码 face ID。

- ActiveUnitSystem=MechanicalUnitSystem.StandardNMM。
- GeometryImportGroup.AddGeometryImport，Import STEP，检查单实体。
- Structural Steel，读取材料 GetAsDictionary：本机 E=200GPa、nu=0.3、k=60.5W/mK。
- 按面质心 X 最小/最大建命名选择 Fixed_End_X_Min / Loaded_End_X_Max。
- Mesh.ElementSize=Quantity("2 [mm]")，生成并读回节点/单元数；此例 24,881 节点、5,000 单元，厚度 5 层。

静力：
- Model.AddStaticStructuralAnalysis()。
- AddFixedSupport 作用 xmin；AddForce 作用 xmax，以分量施加 Z=-10N。
- Solution.AddTotalDeformation、AddDirectionalDeformation(Z)、AddEquivalentStress。
- AddForceReaction 的 BoundaryConditionSelection 指向固定约束。

稳态热：
- Model.AddSteadyStateThermalAnalysis()。
- AddTemperature 的 Location 指向两端；Magnitude.Output.DiscreteValues=[Quantity("100 [C]")] / 20C。其余面未施加热边界即此模型自然绝热。
- AnalysisSettings.NodalForces=OutputControlsNodalForcesType.Yes。
- Solution.AddTemperature、AddTotalHeatFlux。
- 热反力使用 AddReactionProbe()，BoundaryConditionSelection 指向温度边界，读取 Heat.Value；不要猜 AddReactionHeatFlow。
- 静力和热作为两个独立分析时，不声称已做温度→结构耦合。

## 本机低内存求解经验

本机16GB，Fluent 与 Mechanical 同开曾导致 MAPDL 启动内存不足。先保存、确认会话所属；只有任务允许才关闭自有其他求解器。不要自动关闭用户窗口。

这个机器已验证的回退是暂改**现有默认本地求解配置**，同步 Solve(True)，finally 恢复。新建复制配置的尝试曾在本机失败，不把此经验推广成所有机器的必需流程。

```python
cfg = [c for c in ExtAPI.Application.SolveConfigurations if c.Default][0]
s = cfg.SolveProcessSettings
m = s.ManualSolverMemorySettings
saved = (bool(s.DistributeSolution), bool(s.HybridParallel),
         int(s.MaxNumberOfCores), int(s.ThreadsPerProcess),
         bool(m.Active), int(m.Workspace), int(m.Database))
try:
    s.DistributeSolution = False
    s.HybridParallel = False
    s.MaxNumberOfCores = 1
    s.ThreadsPerProcess = 1
    m.Active = True
    m.Workspace = 512
    m.Database = 128
    analysis.Solution.Solve(True)
finally:
    s.DistributeSolution, s.HybridParallel = saved[0], saved[1]
    s.MaxNumberOfCores, s.ThreadsPerProcess = saved[2], saved[3]
    m.Workspace, m.Database, m.Active = saved[5], saved[6], saved[4]
analysis.Solution.EvaluateAllResults()
assert unicode(analysis.Solution.Status) == "Done"
```

512MB 是启动 workspace 设置，不是进程总内存上限。不要在通用前置检查中 ClearGeneratedData；只在具体需要且属于本次授权重算的分析上使用。

## 保存、重开、验证

- 新文件 save_project(file_path=新路径)。已有当前工程用 save_project()，因为指定已有路径走 SaveAs 且不覆盖。
- .mechdb 必须和 *_Mech_Files 配套；单独交付 mechdb 可能丢失结果。
- 先保存再安全 open_project，重新 EvaluateAllResults，读回 Status 与结果值。重开后 MeshData 可能惰性未加载而返回0；不能据此断言原网格丢失，也不要为读取统计无故重划网格。
- 结构：反力平衡、变形方向与梁理论；热：两端热流平衡与线性温度场。具体基准见 verified-baseline.md。
- fixed-end 最大局部 von Mises 应力不是梁理论名义应力；收敛/网格研究是另外工作，未做时明确说明。

模态、谐响应、瞬态、屈曲、显式与耦合分析：按本机 Model 可用方法及专属 license 验证，不能因上述两个分析成功就声明全部已验证。
