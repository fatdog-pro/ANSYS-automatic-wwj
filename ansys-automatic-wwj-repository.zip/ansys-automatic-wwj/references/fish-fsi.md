# 精细鱼体瞬态双向流固耦合固定流程

验收日期：2026-09-18。本页及 `assets/examples/fish/` 仅对应精细鱼模型；旧简化鱼结果已由本基线替换。本次完整入口自行启动 1 进程的专用 Fluent GUI 会话，重新生成几何和网格、从时间 0 初始化并计算 20 步、验收、保存重开及原生播放均通过。显式 attach 到已有会话的分支未在本版另做完整 20 步实测；豆包客户端未实测。 本机并行新启动尚未验证成功；本例使用单进程。

## 物理模型与几何

模型是来流中的精细刚性前身规定平移和柔性尾部响应；前身无结构单元，不是全鱼弹性或自由游泳。仅柔性尾采用 Fluent standalone intrinsic FSI，流体有限体积与内置结构有限元双向耦合，没有调用 Mechanical 或 System Coupling。 前身位置由规定运动确定，水动力使柔性尾变形；尾部移动界面将解得的形状反馈给流场。

- 曲面鱼身长 0.2 m，包含分叉尾鳍、背鳍、臀鳍、成对胸鳍、浅眼部和鳃盖；外形是程序化教学模型，没有扫描或生物标定。
- 唯一弹性实体为 `soft_tail`，E = 2 MPa、ρ = 1000 kg/m³、ν = 0.35。`stiff_body` 只存在于生成阶段的源网格，导入前删除其结构单元，保留全部前身湿面几何；不输出前身 FE 应力或变形。
- 水：ρ = 1000 kg/m³、μ = 0.001 Pa·s，来流 0.05 m/s，层流；尾部为瞬态非线性弹性 intrinsic FSI。刚性前身与完整 `tail_root` 的 Y 位移同为 `1 mm × sin(2π × 2 Hz × t) × (1 − exp(−t/0.5 s))`，X/Z 位移为零。UDF 返回每个实际 dt 的位移差商，尾根用 FE 规定节点位移。
- 四个湿面为 `body_water`、`tail_water`、`fish_drive`、`fish_eyes`。body/drive/eyes 是三个单侧刚体流体壁面；仅 `tail_water`/shadow 是双向 FSI。`tail_root` 是完整 94 面、60 节点结构截面，周边与刚体接缝为 24 节点闭环。四个流体湿面都计入总水动力。
- 实际求解网格 31,668 单元、8,281 个 ASCII 有效节点：水 26,638、尾 5,030；源网格 52,595 单元中的 20,927 个前身结构单元已删除，保留单元的坐标与连通逐位不变。Fluent 创建 shadow 时可复制节点，不能把 ASCII 节点数量当原生 HDF 总节点数量。眼区 240 面。尺寸设置：body=0.003 m, tail=0.002 m, far=0.03 m, eye_ball=0.001 m, gill_pole_ball=0.00075 m。源网格最小 Gmsh SICN = 0.0891836，源三区离线 Fluent 正交质量最低 0.00155575，保留水/尾质量不降低；生成门槛 > 0.001，仍需全部原生质量检查。
- dt = 0.025 s，20 步 / 0.5 s，流动耦合算法 Coupled，每步最多 100 次内部迭代；通过原始残差及报告逐步验收，达到迭代上限不自动视为收敛。
- 本次为 1 进程；尾部 FSI 动态网格 solver stabilization 关闭，已与最终原生设置核对；配置中保留的 scale 不参与本次求解。 每个物理时间步的首个实际新迭代使用结构松弛系数 1；该轮结束后通过官方同步 `IterationEnded` 回调切换到 0.3，本步其余轮只读核对。新时间层至多出现一次上一迭代编号的边界重放事件，保持系数 1、不计作新迭代；每步仍只调用一次原生 `dual_time_iterate`。20 份 `records/structure-corrector-NNNN.json` 全部验收，并与原生残差终止编号逐步核对。 隐式网格每迭代更新，松弛系数 0.5、残差准则 1e-10。这些数值控制不改变规定的位移驱动、物理时间步或材料参数。
- 每个完成步均在推进下一步前进行独立保存场检查；20 份 `records/checkpoint-audit-NNNN.json` 与最终 `checkpoint-audit.json` 的源文件哈希和几何/界面结果一致。单步记录缺少上一步体积时，ALE 储存项诊断可为 unknown；完整汇总另行计算，不将其冒充通过或改变原验收门槛。

## 固定执行路线

入口为 `scripts/replay_fluent_fish.py`；命令和专用会话要求见 [README](../README.md#运行精细鱼体瞬态流固耦合示例)。

1. `generate_realistic_fish.py` 与 `mesh_export.py` 重新生成曲面 CAD、共形两固体区与水网格；`fluent_quality.py` 对三个体区重构默认四面体 Fluent 正交质量，全部须 > 0.001；`split_eye_zone.py` 只划分现有眼部表面，不改节点或单元连通。
2. 检查 STL 闭合、源体积/邻接及眼区身份；运行 `prepare_rigid_tail_geometry.py`，按本次源网格精确提取全部水/尾单元，新增完整 `tail_root`。保留源文件和 `source_to_active_ids.npz`，由 [mesh_identity.json](../assets/examples/fish/geometry/mesh_identity.json) 的八个相对文件/hash绑定源、活动网格、编号映射、质量和接缝证据。实际导入 `active-tail/fish_water_tail.msh`，执行原生 `mesh.quality`。
3. 按 `02`–`06` 创建水和弹性尾材料、完整尾根位移、tail 双向 FSI、body/drive/eyes 刚体 UDF；在目标环境重新编译随包 `fish_rigid_forebody_motion.c`。时间 0 初始化后创建尾部位移云图和刚体前身组合场景、十项报告及 HSF 动画。
4. 每次只推进一个物理步，保存 Case/Data 并检查残差、流量、物理时间与网格；原生质量须继续满足正交质量 ≥ 0.001，记录长宽比。失败保留本次目录并停止，不混入另一尝试的历史。
5. 全 20 步 HDF 审计、原生流场显示、最终 Case/Data 重开读值、20 帧读取/有限播放及最终验收。不得只打开随包缓存就报告完成新仿真。

## 本次证据

来源运行标识：`fish-rigid-tail-replay-20260918-153401-75cf1230`。

| 本次来源数据 | 实测值 |
|---|---:|
| 最大尾部总位移 | 0.692624 mm（步 16，0.4 s） |
| Fx / Fy 范围 | 1.57801 ～ 29.2817 / -25.0376 ～ 16.8528 mN |
| 驱动表达式与报告最大差 | 2.32241e-11 m |
| 每步末连续性 / 速度 / 结构残差最大值 | 0.00099797 / 1.1861e-06 / 1.4593e-05 |
| 最大入口出口相对流量差 | 2.07609e-05% |
| 保存步最小流体体积 / 固体 J 范围 | 8.38779e-13 m³ / 0.999519 ～ 1.00049 |
| 初始及 20 完成步原生最小正交质量 | 0.00322893（步 15；门槛 ≥ 0.001） |
| 21 次原生质量报告最大长宽比 | 71.4294 |
| 尾部流固坐标最大误差 | 2.37522e-08 m |
| 刚体表面实际/规定位置最大误差 | 1.24674e-10 m |
| 完整尾根 FE/规定驱动最大误差 | 5.69206e-19 m |
| 前身/尾根周边接缝最大误差 | 1.24674e-10 m |
| 原生重开报告量最大差 | 0 |

[最终数值验收](../assets/examples/fish/records/validation.json)、[四项 FSI 证据](../assets/examples/fish/records/fsi_evidence.json)、[实际设置](../assets/examples/fish/records/final_actual_setup.json)、[完整入口记录](../assets/examples/fish/records/replay_summary.json)、[20 步 HDF 审计](../assets/examples/fish/records/checkpoint-audit.json)。流量差是入口/出口瞬时通量差；变形域储存项的 ALE 修正单独记录为诊断，不混称相同守恒量。

原生 `mesh.quality` 的 21 份记录从 [初始网格](../assets/examples/fish/records/mesh-quality-0000.json) 至 [第 20 步](../assets/examples/fish/records/mesh-quality-0020.json) 连续保存；四项证据中的 `dynamic_mesh_quality.native_quality_history` 汇总每步值。长宽比作为诊断报告，不另声称已通过未定义的上限。

本精细鱼算例的偏斜度平滑循环固定为 **0**，同时保留扩散动态网格和双向 FSI。固定脚本通过正式设置 API 写入该控制，并在求解前恢复扩散方法；不要省略这一步。初始、20 步及最终原生重开的读回记录均随包保存。

结构松弛与隐式网格调度的原生读回记录从 [第 1 步](../assets/examples/fish/records/numerical-controls-0001.json) 至 [第 20 步](../assets/examples/fish/records/numerical-controls-0020.json) 连续保存；最终设置和四项证据中的 `numerical_schedule` 汇总本次 20 步检查。每步 predictor 设置和所有 corrector/carryover 事件均保留；发布验收重新计算事件顺序、原生时间、会话身份、系数读回及注销状态，并独立比对原生终止残差。

## 在 Fluent 中查看

配对读取 `results/fish-final.cas.h5` 与 `results/fish-final.dat.h5`，查看已有结果时不要重新初始化或推进求解。若本机 UDF 库路径不可用，应按已验证迁移记录加载正式库；不能把重新求解当成读取已有结果的必要步骤。进入 **Results → Animations → Solution Animation Playback → Edit…**，用 **Read…** 加载随包 `results/animations/fish-swim.cxa`，选择 `fish-swim`，Start Frame 1、End Frame 20、Increment 1，选 Current View 后 Play Once；需要循环时选择 Auto Repeat。全序列 HSF 必须与 CXA 同目录。

HSF 记录求解中的实际移动几何：前身是规定刚体运动，尾部是求解所得 FSI 运动。位移云图仅显示弹性尾，范围 0–4 mm，场景同时显示三个刚体表面，关闭额外后处理变形。原生有限播放已由 API 返回验证；没有用屏幕识别验收，也未把自动无限循环声称为测试完成。

原生文件、数值记录与迁移边界见 [资源说明](../assets/examples/fish/README.md)。Case 内动画路径来自源机器，迁移后显式加载相对 HSF 引用的 CXA。包内初始/最终场不能还原全部中间场；新重跑会逐步生成完整 checkpoints。

## 适用边界

本版按用户要求采用快速教学预览：较粗网格、20 步一个周期；原生低正交质量警告保留在记录中，明确采用 0.001 而非标准 0.01 的网格门槛。结果只用于流程和运动展示，不作工程定量结论。 这是层流、粗四面体网格的教学演示；局部薄鳍可能只有一层厚度单元，未做边界层膨胀、网格/时间步独立性、周期稳定或生物实验验证，不能据此预测真实鱼推进性能。原生网格质量检查覆盖初始网格及全部 20 个完成步，几何和界面检查覆盖全部保存完成步，不覆盖未保存的内部迭代。Gmsh SICN 不能替代 Fluent 原生正交质量检查，质量门槛也不等于网格独立性。刚体运动 UDF 随包提供 C 源码；新运行需用目标 Fluent 内置编译器重新编译。随包仅含本例正式库的两个 Windows DLL；已实测同机新目录、新 Fluent 261 单进程读取时自动用内置编译器重新编译未改动的 C 源码，再加载结果，时钟、十项报告、网格/流场/FE 历史及刚体状态保持一致，没有初始化或求解。这不证明跨电脑或平台兼容；跨电脑可先使用独立 CXA/HSF 观察结果。 完整 wrapper 的本机新启动专用 GUI验证不等于其他电脑、许可或软件版本已验证；显式 attach 分支未在本版另做完整实测。当前公开模块范围仍为 Fluent；后续逐步实测其他模块。
