from pathlib import Path
import argparse,json,shutil,time,types,sys
import ansys.fluent.core as pf
HELPERS=Path(__file__).resolve().parent
sys.path.insert(0,str(HELPERS))
from advance_step import advance_with_structure_corrector
from audit_remesh import audit
p=argparse.ArgumentParser(description='Continue validated full-body FSI checkpoints via official Fluent API.');p.add_argument('--server-info',type=Path,required=True);p.add_argument('--parent',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--start',type=int,required=True);p.add_argument('--end',type=int,required=True);p.add_argument('--corrector',type=float,default=.3);p.add_argument('--remesh',action='store_true');p.add_argument('--smoothing',choices=['inherit','diffusion2'],default='inherit')
a=p.parse_args();PARENT=a.parent;OUT=a.out
assert a.end>a.start and not OUT.exists();OUT.mkdir();(OUT/'animations').mkdir()
def record(n,v):(OUT/(n+'.json')).write_text(json.dumps(v,indent=2,default=str),encoding='utf-8')
assert json.loads((PARENT/'status.json').read_text('utf-8'))['completed_steps']>=a.start
for i in range(1,a.start+1):assert json.loads((PARENT/f'step-{i:04d}-audit.json').read_text('utf-8'))['passed']
for path in PARENT.iterdir():
    if path.is_dir() and path.name.startswith('libfish'):shutil.copytree(path,OUT/path.name)
    elif path.is_file() and (path.name.startswith(('initial.','fish_active')) or path.name=='fish-fullbody.msh'):shutil.copy2(path,OUT/path.name)
for i in range(1,a.start+1):
    for pattern in [f'step-{i:04d}*',f'structure-corrector-{i:04d}.json',f'mass-{i:04d}.json']:
        for path in PARENT.glob(pattern):shutil.copy2(path,OUT/path.name)
base=json.loads((PARENT/'cycle-config.json').read_text('utf-8'))
# Preserve the numerical settings actually used for each inherited time level.
for i in range(1,a.start+1):
    if not (OUT/f'step-{i:04d}-config.json').exists():record(f'step-{i:04d}-config',base)
config=dict(base);config.update(structure_corrector_under_relaxation=a.corrector,target_steps=a.end,planned_time_steps=a.end,target_time_s=a.end*.025,max_iterations_per_step=100)
record('cycle-config',config)
solver=pf.connect_to_fluent(server_info_file_name=str(a.server_info),cleanup_on_exit=False,start_watchdog=False,start_transcript=False)
s=solver.settings;solver.chdir(OUT.as_posix());s.file.read_case_data(file_name=(OUT/f'step-{a.start:04d}.cas.h5').as_posix())
assert abs(s.solution.run_calculation.transient_controls.flow_time()-a.start*.025)<1e-9
s.solution.methods.spatial_discretization.discretization_scheme['mom']='first-order-upwind'
s.setup.dynamic_mesh.options.implicit_update.relaxation_factor=1.
if a.smoothing=='radial':
    sm=s.setup.dynamic_mesh.methods.smoothing;sm.method='radial';sm.radial_settings.relative_tolerance=1e-5;sm.radial_settings.local_smoothing=False;sm.radial_settings.smooth_from_ref=True
    config['dynamic_mesh_smoothing']=sm.get_state();record('cycle-config',config)
if a.smoothing=='diffusion2':
    sm=s.setup.dynamic_mesh.methods.smoothing;sm.method='diffusion';sm.diffusion_settings.diffusion_coeff_parameter=2.0
    config['dynamic_mesh_smoothing']=sm.get_state();record('cycle-config',config)
if a.remesh:
    dm=s.setup.dynamic_mesh
    dm.methods.remeshing.enabled=True
    rm=dm.methods.remeshing.settings;rm.unified_remeshing=False
    solver.tui.define.dynamic_mesh.controls.remeshing_parameters.remeshing_methods()
    rm.cell_skew_max=.95
    record('native-remesh-methods',solver.rp_vars('dynamesh/remesh/methods'))
    dz=dm.dynamic_zones
    if not any(dz[k].zone()=='water' for k in dz.get_object_names()):
        old=set(dz.get_object_names());dz.create(zone='water');water=dz[(set(dz.get_object_names())-old).pop()];water.type='deforming'
    else:water=next(dz[k] for k in dz.get_object_names() if dz[k].zone()=='water')
    water.meshing.remeshing.enabled=True
    config['local_fluid_remeshing']=True;record('cycle-config',config);record('remeshing-setup',dm.get_state())
c=s.results.graphics.contour['fullbody-displacement'];assert c.deformation() is False;c.range_options.maximum=.04;c.display()
an=s.solution.calculation_activity.solution_animations
if 'fullbody-swim' in an.get_object_names():an.delete(name_list=['fullbody-swim'])
an.create(name='fullbody-swim',storage_dir=(OUT/'animations').as_posix(),animate_on='fullbody-displacement')
z=an['fullbody-swim'];z.frequency_of='time-step';z.frequency=1;z.storage_type='hsf';z.window_id=1;z.view='fullbody-top-oblique'
record('continuation-origin',{'parent':str(PARENT),'accepted_start_step':a.start,'loaded_start_time':a.start*.025,'structure_corrector_urf':a.corrector,'physics_changed':False,'reason':'Extend actual two-way FSI to a complete left-right motion; evaluate cycle seam using solved positions and velocities.'})
h=types.SimpleNamespace(solver=solver,settings=config,record=record)
status={'status':'running','completed_steps':a.start,'target_steps':a.end,'time_s':a.start*.025};record('status',status)
try:
    for step in range(a.start+1,a.end+1):
        t0=time.monotonic();record(f'step-{step:04d}-config',config)
        if s.file.stop_transcript.is_active():s.file.stop_transcript()
        s.file.start_transcript(file_name=(OUT/f'step-{step:04d}.trn').as_posix())
        s.solution.controls.under_relaxation['structure']=1.
        s.solution.monitor.residual.equations['continuity'].absolute_criteria=.01
        event=advance_with_structure_corrector(h,step)
        s.mesh.check();s.mesh.quality()
        s.file.write_case_data(file_name=(OUT/f'step-{step:04d}.cas.h5').as_posix())
        reports=s.solution.report_definitions.compute(report_defs=['body-y','body-max','tail-y','tail-max','mass-inlet','mass-outlet'])
        c.display();s.file.stop_transcript()
        record(f'step-{step:04d}-summary',{'elapsed_s':time.monotonic()-t0,'event_validation':event['validation'],'reports':reports})
        proof=audit(OUT,step);record(f'step-{step:04d}-audit',proof)
        assert event['validation']['passed'] and proof['passed'],proof
        mass={'passed':proof['checks']['ALE_mass_balance'],'relative_ALE_mass_error':proof['relative_ALE_mass_error'],'method':'oriented native faces, current and previous fluid mesh'};record(f'mass-{step:04d}',mass);assert mass['passed'],mass
        status.update(completed_steps=step,time_s=step*.025,last_step_elapsed_s=time.monotonic()-t0);record('status',status)
        print('ACCEPTED',step,'TIME',step*.025,'SECONDS',status['last_step_elapsed_s'],flush=True)
        if (OUT/'STOP_AFTER_STEP').exists():break
    s.file.write_case_data(file_name=(OUT/'fish-final.cas.h5').as_posix());status['status']='solved-awaiting-presentation' if status['completed_steps']==a.end else 'stopped-at-requested-boundary';record('status',status)
except BaseException as e:
    status.update(status='stopped',error=type(e).__name__+': '+str(e));record('status',status);raise


