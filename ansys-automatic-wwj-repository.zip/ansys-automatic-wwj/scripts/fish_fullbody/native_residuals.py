"""Read-only validation of native Fluent fish-FSI transcript and report history.

This program never imports an Ansys SDK or operates a solver. It writes only to
the explicitly selected output directory. Solver convergence is checked for
each completed physical time step; GUI, topology, FSI configuration and native
reopen evidence must be provided separately, otherwise their status is unknown.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sys


EQUATIONS = ["continuity", "x-velocity", "y-velocity", "z-velocity",
             "x-displace", "y-displace", "z-displace"]
REPORT_COLUMNS = ["drive-y", "tail-y-mean", "tail-y-max", "tail-y-min",
                  "tail-displacement", "force-x", "force-y", "mass-net",
                  "mass-inlet", "mass-outlet"]
EXTERNAL_EVIDENCE = ["fsi_configuration", "fluid_solid_topology",
                     "dynamic_mesh_quality", "native_reopen"]
NUMBER = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][+-]?\d+)?"
FLOW = re.compile(r"Flow\s+time\s*=\s*(%s)\s*s\s*,\s*time\s+step\s*=\s*(\d+)" % NUMBER, re.I)
CONVERGED = re.compile(r"!?\s*(\d+)\s+solution\s+is\s+converged", re.I)
ITER = re.compile(r"^\s*(\d+)\s+(.+?)\s+\d+:\d+:\d+\s+\d+\s*$")
FATAL = re.compile(r"floating[ -]point|\bFPU\b|divergence detected|diverged|negative cell volume|"
                   r"negative volume|inverted (?:cell|element)|fatal error|^\s*Error(?:\s+Object)?:", re.I)
DISPLAY_REJECTED_WRITE = "Error: api-set-var: the object cannot be edited"
DISPLAY_DEFORMATION_OBJECT = 'Error Object: "results/graphics/contour/fish-displacement/deformation-scale"'


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def number(token):
    return float(token.replace("D", "e").replace("d", "e"))


def parse_transcript(text, start_line=1):
    """Tie the final NEW iteration to its subsequent Flow-time completion line.

    Fluent prints the previous step's final row and converged marker again at
    the beginning of a new dual-time-iterate call. Those repeated rows must not
    count as convergence of the new step.
    """
    completed, issues, errors, nonfinite_rows = [], [], [], []
    unacknowledged_errors, display_events = [], []
    acknowledged_display_lines = set()
    rows, marks = [], set()
    last_completed_iteration = -1
    first_iteration_line = None
    header = None
    mesh_updates = 0
    step_mesh_updates = 0
    source_lines = text.splitlines()
    for lineno, line in enumerate(source_lines, 1):
        if lineno < start_line:
            continue
        words = line.split()
        if words and words[0] == "iter" and "continuity" in words:
            header = words[1:words.index("time/iter")] if "time/iter" in words else words[1:8]
            if header != EQUATIONS:
                issues.append({"line": lineno, "reason": "Unexpected residual columns", "columns": header})
        match = ITER.match(line)
        if match and header == EQUATIONS:
            values = match.group(2).split()
            if len(values) != len(EQUATIONS):
                issues.append({"line": lineno, "reason": "Residual row has wrong field count"})
                continue
            try:
                row = dict(zip(EQUATIONS, map(number, values)))
            except ValueError:
                issues.append({"line": lineno, "reason": "Residual row is not numeric"})
                continue
            iteration = int(match.group(1))
            if first_iteration_line is None:
                first_iteration_line = lineno
            if iteration == last_completed_iteration:
                continue  # Stale display of the preceding converged state.
            if iteration < last_completed_iteration:
                issues.append({"line": lineno, "reason": "Iteration reset; select one run using --start-line"})
            row.update(iteration=iteration, transcript_line=lineno)
            if not all(finite(row[eq]) for eq in EQUATIONS):
                nonfinite_rows.append({"line": lineno, "iteration": iteration})
            rows.append(row)
        match = CONVERGED.search(line)
        if match and int(match.group(1)) > last_completed_iteration:
            marks.add(int(match.group(1)))
        if first_iteration_line is not None and FATAL.search(line):
            error = {"line": lineno, "text": line.strip(), "raw_text": line}
            errors.append(error)  # Retain the complete runtime-error record.
            if lineno in acknowledged_display_lines:
                pass
            elif (line.strip() == DISPLAY_REJECTED_WRITE and lineno < len(source_lines)
                  and source_lines[lineno].strip() == DISPLAY_DEFORMATION_OBJECT):
                # Only this exact adjacent two-line event is recognized.
                # A solver-control path, another contour, another message,
                # or an intervening line cannot enter this narrow exception.
                acknowledged_display_lines.update({lineno, lineno + 1})
                display_events.append({
                    "start_line": lineno, "end_line": lineno + 1,
                    "raw_lines": [line, source_lines[lineno]],
                    "object_path": "results/graphics/contour/fish-displacement/deformation-scale",
                    "classification": "acknowledged_rejected_display_property_write",
                    "after_completed_step": completed[-1]["step"] if completed else None,
                    "explanation": "Fluent rejected this exact contour deformation-scale write. It is a display-property edit error, not a solver-control or convergence error. The replay source omits this setter when deformation is disabled. This classification does not itself prove that solution fields were unchanged.",
                    "excluded_from_physical_runtime_error_gate": True,
                })
            else:
                unacknowledged_errors.append(error)
        if "Updating mesh at iteration... done." in line:
            mesh_updates += 1
            step_mesh_updates += 1
        match = FLOW.search(line)
        if match:
            last = rows[-1] if rows else {}
            values_finite = all(finite(last.get(eq)) for eq in EQUATIONS)
            thresholds_met = values_finite and all(
                0 <= last[eq] < (1e-3 if eq == "continuity" else 1e-4)
                for eq in EQUATIONS)
            marker = bool(last) and last["iteration"] in marks
            item = {"step": int(match.group(2)), "flow_time_s": number(match.group(1)),
                    "final_iteration": last.get("iteration"), "iterations_observed": len(rows),
                    "flow_time_transcript_line": lineno,
                    "final_residual_transcript_line": last.get("transcript_line"),
                    **{eq: last.get(eq) for eq in EQUATIONS},
                    "converged_marker": marker, "residuals_finite": values_finite,
                    "residual_thresholds_passed": bool(thresholds_met),
                    "step_numerically_converged": bool(marker and thresholds_met),
                    "successful_iteration_mesh_update_messages": step_mesh_updates}
            completed.append(item)
            if last:
                last_completed_iteration = last["iteration"]
            rows, marks = [], set()
            step_mesh_updates = 0
    return completed, {"parse_issues": issues, "runtime_errors_after_first_iteration": errors,
                       "unacknowledged_runtime_errors_after_first_iteration": unacknowledged_errors,
                       "non_solver_display_events": display_events,
                       "non_solver_display_event_count": len(display_events),
                       "nonfinite_residual_rows": nonfinite_rows,
                       "first_iteration_line": first_iteration_line,
                       "incomplete_next_step": {"iterations_observed": len(rows),
                                                "last_residual": rows[-1] if rows else None},
                       "successful_iteration_mesh_update_messages": mesh_updates}


