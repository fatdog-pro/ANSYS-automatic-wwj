"""Measured 30-minute candidate; preserve full-body intrinsic FSI and 0.70 s."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,time,types,hashlib
from datetime import datetime
import ansys.fluent.core as pf

p=argparse.ArgumentParser();p.add_argument('--mesh',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
p.add_argument('--fluent',type=Path,required=True);p.add_argument('--steps',type=int,default=28)
p.add_argument('--budget',type=float,default=1800);p.add_argument('--helper-dir',type=Path,default=Path(__file__).parent/'replay')
p.add_argument('--dt',type=float,default=.025);p.add_argument('--corrector',type=float,default=.7)
a=p.parse_args()
assert a.mesh.is_file() and a.fluent.is_file()
assert a.steps>=1 and a.dt>0 and 0<a.corrector<=1 and a.budget>180
OUT=a.out;assert not OUT.exists();OUT.mkdir(parents=True)
script_dir=a.helper_dir.resolve();sys.path.insert(0,str(script_dir))
from advance_step import advance_with_structure_corrector
from audit_remesh import audit
started=time.monotonic()
def record(name,value):(OUT/(name+'.json')).write_text(json.dumps(value,indent=2,default=str),encoding='utf-8')
config={'dt_s':a.dt,'max_iterations_per_step':100,'flow_scheme':'Coupled',
 'structure_under_relaxation':1.,'structure_under_relaxation_after_first':1.,
 'structure_corrector_under_relaxation':a.corrector,'implicit_mesh_relaxation':1.,
 'implicit_mesh_residual_criterion':1e-10,'drive_amplitude_N_m3':15000,
 'frequency_Hz':2.,'ramp_s':.15,'body_E_Pa':2e5,'tail_E_Pa':2e6,
 'continuity_criterion':.01,'momentum_scheme':'first-order-upwind',
 'target_steps':a.steps,'local_fluid_remeshing':True,'wall_time_budget_s':a.budget,
 'profile':'half-hour-development','physics_constraints_changed':False,'animation_limit_m':.06}
record('cycle-config',config)
status={'status':'launching','completed_steps':0,'target_steps':a.steps,'time_s':0.}
record('status',status)
shutil.copytree(script_dir,OUT/'replay',ignore=shutil.ignore_patterns('__pycache__'))
shutil.copy2(a.mesh,OUT/'fish-fullbody.msh')
record('mesh-origin',{'path':str(a.mesh),'sha256':hashlib.sha256(a.mesh.read_bytes()).hexdigest(),'cached_physics_loaded':False})
try:
    solver=pf.launch_fluent(fluent_path=str(a.fluent),product_version='26.1.0',dimension=3,precision='double',processor_count=1,mode='solver',ui_mode='gui',py=False,cwd=str(OUT),start_timeout=120,cleanup_on_exit=False,start_watchdog=False)
except BaseException as exc:
    status.update(status='launch-failed',error=type(exc).__name__,elapsed_s=time.monotonic()-started)
    record('status',status);raise
solver.tui.server.write_or_reset_grpc_server_info((OUT/'server.info').as_posix())
s=solver.settings;solver.chdir(OUT.as_posix())
try:
    s.file.start_transcript(file_name=(OUT/'setup.trn').as_posix())
    s.file.read_mesh(file_name=(OUT/'fish-fullbody.msh').as_posix())
    s.setup.general.solver.time='unsteady-1st-order';s.setup.models.viscous.model='laminar'
    s.setup.models.energy.enabled=False;s.setup.models.structure.model='nonlinear-elasticity';s.setup.dynamic_mesh.enabled=True
    ns={'solver':solver,'s':s,'OUT':OUT,'run_dir':OUT.as_posix(),'replay_settings':config,'record':record,'save':record,'Path':Path,'json':json,'shutil':shutil,'script_dir':script_dir}
    for phase in ['configure_model.py','initialize.py','configure_display.py']:
        ns['__file__']=str(script_dir/phase);exec(compile((script_dir/phase).read_text('utf-8'),str(script_dir/phase),'exec'),ns)
    s.results.graphics.contour['fullbody-displacement'].range_options.maximum=config['animation_limit_m']
    s.setup.dynamic_mesh.options.implicit_update.relaxation_factor=1.
    s.solution.methods.spatial_discretization.discretization_scheme['mom']='first-order-upwind'
    sm=s.setup.dynamic_mesh.methods.smoothing;sm.method='diffusion';sm.diffusion_settings.diffusion_coeff_parameter=2.
    dm=s.setup.dynamic_mesh;dm.methods.remeshing.enabled=True
    rm=dm.methods.remeshing.settings;rm.unified_remeshing=False
    solver.tui.define.dynamic_mesh.controls.remeshing_parameters.remeshing_methods();rm.cell_skew_max=.95
    dz=dm.dynamic_zones;old=set(dz.get_object_names());dz.create(zone='water');water=dz[(set(dz.get_object_names())-old).pop()]
    water.type='deforming';water.meshing.remeshing.enabled=True
    record('native-remesh-methods',solver.rp_vars('dynamesh/remesh/methods'))
    record('numerical-setup',{'dynamic_mesh':dm.get_state(),'methods':s.solution.methods.get_state(),'config':config})
    s.mesh.check();s.mesh.quality()
    s.file.write_case_data(file_name=(OUT/'initial.cas.h5').as_posix());s.file.stop_transcript()
    setup_elapsed=time.monotonic()-started
    h=types.SimpleNamespace(solver=solver,settings=config,record=record)
    status.update(status='solving',setup_elapsed_s=setup_elapsed);record('status',status)
    timings=[]
    for step in range(1,a.steps+1):
        t0=time.monotonic()
        config['structure_corrector_under_relaxation']=a.corrector
        config['displacement_residual_criterion']=1e-4
        record('cycle-config',config);record(f'step-{step:04d}-config',config)
        s.file.start_transcript(file_name=(OUT/f'step-{step:04d}.trn').as_posix())
        s.solution.controls.under_relaxation['structure']=1.
        s.solution.monitor.residual.equations['continuity'].absolute_criteria=.005 if step<=3 else .01
        for eq in ['x-displacement','y-displacement','z-displacement']:
            s.solution.monitor.residual.equations[eq].absolute_criteria=config['displacement_residual_criterion']
        event=advance_with_structure_corrector(h,step)
        s.mesh.check();s.mesh.quality()
        s.file.write_case_data(file_name=(OUT/f'step-{step:04d}.cas.h5').as_posix())
        reports=s.solution.report_definitions.compute(report_defs=['body-y','body-max','tail-y','tail-max','mass-inlet','mass-outlet'])
        s.file.stop_transcript()
        record(f'step-{step:04d}-summary',{'elapsed_s':time.monotonic()-t0,'reports':reports,'event_validation':event['validation']})
        proof=audit(OUT,step);record(f'step-{step:04d}-audit',proof)
        assert event['validation']['passed'] and proof['passed'],proof
        frame=OUT/'animations'/f'fullbody-swim_{step-1:04d}.hsf'
        assert frame.is_file() and frame.stat().st_size>1000
        record(f'step-{step:04d}-frame',{'accepted_step':step,'time_s':step*a.dt,'hsf_sha256':hashlib.sha256(frame.read_bytes()).hexdigest(),'source':'native end-of-time-step solution animation','display_amplification':False})
        record(f'mass-{step:04d}',{'passed':proof['checks']['ALE_mass_balance'],'relative_ALE_mass_error':proof['relative_ALE_mass_error']})
        timings.append(time.monotonic()-t0)
        projected=setup_elapsed+sum(timings)+(a.steps-step)*sum(timings[-3:])/len(timings[-3:])+90
        status.update(completed_steps=step,time_s=step*a.dt,last_step_elapsed_s=timings[-1],elapsed_s=time.monotonic()-started,projected_with_presentation_s=projected)
        record('status',status);print('ACCEPTED',json.dumps(status),flush=True)
        if (OUT/'STOP_AFTER_STEP').exists() or time.monotonic()-started>a.budget-90 or (step>=6 and projected>a.budget):
            status['status']='stopped-at-budget-checkpoint';record('status',status);sys.exit(2)
    s.file.write_case_data(file_name=(OUT/'fish-final.cas.h5').as_posix())
    status['status']='presenting';record('status',status)
    with (OUT/'presentation.log').open('w',encoding='utf-8') as log:
        subprocess.run([sys.executable,str(script_dir/'present_fast.py'),str(OUT),'--steps',str(a.steps),'--server-info',str(OUT/'server.info')],stdout=log,stderr=subprocess.STDOUT,check=True)
    proof=json.loads((OUT/'native-presentation.json').read_text('utf-8'))
    status.update(status='validated-complete',elapsed_s=time.monotonic()-started,native_presentation=proof,within_30_minutes=time.monotonic()-started<=1800)
    record('status',status);print('COMPLETE',json.dumps(status),flush=True)
except BaseException as exc:
    if isinstance(exc,SystemExit):raise
    status.update(status='stopped',error=type(exc).__name__+': '+str(exc),elapsed_s=time.monotonic()-started)
    record('status',status);raise
