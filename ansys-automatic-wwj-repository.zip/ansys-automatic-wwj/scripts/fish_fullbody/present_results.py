"""Verify native reopening, play solved frames, and leave Fluent on a peak frame."""
from pathlib import Path
import json

def present(solver,root,steps,animation=None):
    from summarize_results import summarize
    proof=summarize(root,steps)
    assert proof['passed']
    s=solver.settings
    def clock():return {n:solver.scheme.eval("(rpgetvar '"+n+")") for n in ['flow-time','time-step','physical-time-step']}
    before=clock();assert before['time-step']==steps and abs(before['flow-time']-steps*.025)<1e-9
    report_names=['body-y','body-max','tail-y','tail-max','mass-inlet','mass-outlet']
    reports_before=s.solution.report_definitions.compute(report_defs=report_names)
    if not (root/'fish-delivery.cas.h5').exists():
        s.file.write_case_data(file_name=(root/'fish-delivery.cas.h5').as_posix())
    solver.chdir(root.as_posix())
    s.file.read_case_data(file_name=(root/'fish-delivery.cas.h5').as_posix())
    after=clock();reports_after=s.solution.report_definitions.compute(report_defs=report_names)
    assert before==after
    import numpy as np
    flat=lambda r:{k:v[0] for x in r for k,v in x.items()}
    r0,r1=flat(reports_before),flat(reports_after)
    assert all(np.isclose(r0[k],r1[k],rtol=1e-8,atol=1e-10) for k in r0)
    contour=s.results.graphics.contour['fullbody-displacement'];assert contour.deformation() is False
    contour.display()
    s.results.graphics.views.restore_view(view_name='fullbody-top-oblique')
    final_image=root/'fish-fullbody-final.png';s.results.graphics.picture.save_picture(file_name=final_image.as_posix())
    animation=Path(animation) if animation else root/'animations/fullbody-swim.cxa'
    p=s.results.animations.playback;p.read_animation_file(animation_file_name=animation.as_posix());p.current_animation='fullbody-swim'
    p.view_mode(view_name='current-view')
    p.play(player='>',start_frame=1,end_frame=steps,increment=1,playback_mode='play-once',speed=15)
    peak=proof['bending_peak_step'];p.play(player='>',start_frame=peak,end_frame=peak,increment=1,playback_mode='play-once',speed=15)
    s.results.graphics.picture.save_picture(file_name=(root/'fish-fullbody-peak.png').as_posix())
    assert before==clock()
    result={'passed':True,'case_data_reopened':True,'reports_match_after_reopen':True,'clock':before,'animation_frames':steps,'native_animation_path':str(animation),'peak_frame':peak,'display_amplification':False,'gui_left_open':True}
    (root/'native-presentation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return proof,result
