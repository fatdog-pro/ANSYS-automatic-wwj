"""Development fresh replay: tested component route, not yet end-to-end validated."""
from pathlib import Path
from datetime import datetime
import argparse,json,subprocess,sys,uuid

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--fluent',type=Path);p.add_argument('--mesh-python',type=Path);p.add_argument('--mesh',type=Path)
    p.add_argument('--runtime-root',type=Path);p.add_argument('--steps',type=int,default=28);p.add_argument('--plan',action='store_true')
    a=p.parse_args()
    if not 22<=a.steps<=60:p.error('--steps must be between 22 and 60; a complete visual loop is checked, never assumed')
    phases=[{'end_step':8,'route':'fresh full-body initialization and audited solve','corrector':.3},
            {'end_step':9,'smoothing':'diffusion parameter 2','corrector':.3},
            {'end_step':10,'remesh':'methods-based native defaults, skewness .95, deforming water only','corrector':.3},
            {'end_step':20,'route':'continue actual FSI; stop on any failed check','corrector':.5},
            {'end_step':a.steps,'route':'continue actual FSI; stop on any failed check','corrector':.7},
            {'route':'independent checkpoint audit, loop seam check, native render and reopen'}]
    if a.plan:
        print(json.dumps({'validation':'Development orchestrator; component restart route tested, full fresh wrapper not yet tested.','cached_physics_loaded':False,'steps':a.steps,'time_s':a.steps*.025,'phases':phases,'loop_is_not_guaranteed':True},indent=2));return
    if not a.fluent or not a.fluent.is_file():p.error('Provide the installed --fluent executable')
    if not a.runtime_root or not str(a.runtime_root).isascii():p.error('Provide an ASCII --runtime-root')
    if a.mesh is None and (a.mesh_python is None or not a.mesh_python.is_file()):p.error('Provide --mesh-python, or an exact full-body --mesh')
    if a.mesh is not None and not a.mesh.is_file():p.error('--mesh does not exist')
    here=Path(__file__).resolve().parent
    root=a.runtime_root/('fullbody-cycle-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);root.mkdir(parents=True,exist_ok=False)
    def execute(name,script,args):
        print('PHASE',name,flush=True)
        with (root/(name+'.log')).open('w',encoding='utf-8') as f:
            subprocess.run([sys.executable,str(here/script),*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)
    fresh=['--fluent',a.fluent,'--runtime-root',root/'seed','--steps',8]
    fresh+=['--mesh',a.mesh] if a.mesh else ['--mesh-python',a.mesh_python]
    execute('fresh-08','replay_fullbody_fish.py',fresh)
    candidates=list((root/'seed').glob('fish-fullbody-*'));assert len(candidates)==1
    parent=candidates[0];server=parent/'server.info';assert server.is_file()
    for start,end,name,corrector,extra in [(8,9,'diffusion-09',.3,['--smoothing','diffusion2']),(9,10,'remesh-10',.3,['--remesh']),(10,20,'cycle-20',.5,[]),(20,a.steps,'cycle',.7,[])]:
        out=root/name
        execute(name,'continue_cycle.py',['--server-info',server,'--parent',parent,'--out',out,'--start',start,'--end',end,'--corrector',corrector,*extra]);parent=out
        state=json.loads((parent/'status.json').read_text('utf-8'));assert state['completed_steps']==end
    execute('presentation','present_cycle.py',[parent,'--steps',a.steps,'--server-info',server])
    presentation=json.loads((parent/'native-presentation.json').read_text('utf-8'))
    (root/'result.json').write_text(json.dumps({'run':str(parent),'native_presentation':presentation,'validation':'This execution must be judged from its own generated records.'},indent=2),encoding='utf-8')
    print(parent,flush=True)
if __name__=='__main__':main()
