"""Audit fluid-only remeshing while preserving FE reference topology and wet faces."""
from pathlib import Path
import sys,json,re,itertools
import numpy as np
import native_fields as m
import native_residuals as v
from advance_step import check_structure_corrector_record

def indices(c,n):
    z=c['zones']['cells'][n];return np.arange(z['minId']-1,z['maxId'])
def sortrows(a):
    a=np.sort(a,axis=1);return a[np.lexsort(a.T[::-1])]
def canonical_map(ref,d):
    orig=np.unique(np.concatenate([ref['tet'][indices(ref,n)].ravel() for n in ['stiff_body','soft_tail']]))
    lookup={tuple(np.round(ref['xyz'][i],12)):int(i) for i in orig};assert len(lookup)==len(orig)
    mapped=np.array([lookup[tuple(np.round(x,12))] for x in d['reference_xyz']])
    assert np.array_equal(np.sort(mapped),orig)
    assert np.allclose(ref['xyz'][mapped],d['reference_xyz'],rtol=0,atol=1e-12)
    return mapped

def signed_volumes(c):
    p=c['xyz'][c['faces']];face_v=np.einsum('ij,ij->i',p[:,0],np.cross(p[:,1],p[:,2]))/6
    vol=np.zeros(len(c['tet']));np.add.at(vol,c['c0'],-face_v)
    mask=c['c1']>=0;np.add.at(vol,c['c1'][mask],face_v[mask])
    return vol

def wet_matches(target,source,tol=1e-6):
    buckets={}
    for i,x in enumerate(source):buckets.setdefault(tuple(np.floor(x/tol).astype(int)),[]).append(i)
    offsets=list(itertools.product([-1,0,1],repeat=3));mapped=[];errors=[]
    for x in target:
        k=np.floor(x/tol).astype(int);candidates=[]
        for off in offsets:candidates+=buckets.get(tuple(k+off),[])
        assert candidates,'No adjacent solid node within interface tolerance'
        dist=np.linalg.norm(source[candidates]-x,axis=1);valid=np.flatnonzero(dist<=tol)
        assert len(valid)==1,'Missing/ambiguous wet-node correspondence'
        mapped.append(candidates[int(valid[0])]);errors.append(float(dist[valid[0]]))
    assert len(set(mapped))==len(mapped)==len(source)
    return np.array(mapped),max(errors)

def audit(root,step):
    cfg=root/f'step-{step:04d}-config.json';cfg=cfg if cfg.exists() else root/'cycle-config.json'
    config=json.loads(cfg.read_text('utf-8'));dt=float(config['dt_s'])
    ref=m.read_case(root/'initial.cas.h5');c=m.read_case(root/f'step-{step:04d}.cas.h5');d=m.read_data(root/f'step-{step:04d}.dat.h5')
    mapped=canonical_map(ref,d);orig_id=np.full(len(c['xyz']),-1,dtype=int);orig_id[d['ids']]=mapped
    reference=c['xyz'].copy();reference[d['ids']]=d['reference_xyz']
    solved=c['xyz'].copy();solved[d['ids']]=d['reference_xyz']+d['displacement']
    checks={'fullbody_zones':set(c['zones']['cells'])=={'water','stiff_body','soft_tail'},'native_time':d['step']==step and abs(d['time_s']-step*dt)<1e-9}
    structure_cells=np.concatenate([indices(c,n) for n in ['stiff_body','soft_tail']])
    checks['all_structural_nodes']=np.array_equal(np.sort(d['ids']),np.unique(c['tet'][structure_cells]))
    checks['reference_and_solid_topology_unchanged']=all(np.array_equal(sortrows(orig_id[c['tet'][indices(c,n)]]),sortrows(ref['tet'][indices(ref,n)])) for n in ['stiff_body','soft_tail'])
    J={}
    for n in ['stiff_body','soft_tail']:
        tet=c['tet'][indices(c,n)];den=np.linalg.det(m.matrices(reference,tet));num=np.linalg.det(m.matrices(solved,tet));J[n]=float((num/den).min())
    checks['positive_structural_J']=all(j>0 for j in J.values())
    volumes=signed_volumes(c);minimum={n:float(volumes[indices(c,n)].min()) for n in c['zones']['cells']}
    checks['all_native_signed_cell_volumes_positive']=all(x>0 for x in minimum.values())
    wet={};wet_topology=True
    for name in ['body_water','fish_eyes','tail_water','fish_drive']:
        fn=m.surface_nodes(c,name);sn=m.surface_nodes(c,name+'-shadow')
        pair,error=wet_matches(c['xyz'][fn],solved[sn]);wet[name]=error
        link=orig_id.copy();link[fn]=orig_id[sn[pair]]
        z=c['zones']['faces'][name];faces=link[c['faces'][z['minId']-1:z['maxId']]]
        rz=ref['zones']['faces'][name+'-shadow'];old=ref['faces'][rz['minId']-1:rz['maxId']]
        wet_topology &= np.array_equal(sortrows(faces),sortrows(old))
    checks['wet_interfaces_match']=all(e<=1e-6 for e in wet.values());checks['wet_topology_unchanged']=bool(wet_topology)
    fixed=m.surface_nodes(c,'fish_drive-shadow');checks['fixed_head']=bool(np.max(np.linalg.norm(solved[fixed]-reference[fixed],axis=1))<1e-8)
    report={k:x[0] for r in json.loads((root/f'step-{step:04d}-summary.json').read_text('utf-8'))['reports'] for k,x in r.items()}
    comparisons=[]
    for n,surf in [('body','body_water-shadow'),('tail','tail_water-shadow')]:
        ix=m.surface_nodes(c,surf);u=solved[ix]-reference[ix]
        comparisons += [np.isclose(np.linalg.norm(u,axis=1).max(),report[n+'-max'],rtol=1e-6,atol=1e-10),np.isclose(u[:,1].mean(),report[n+'-y'],rtol=1e-6,atol=1e-10)]
    checks['native_reports_match_fields']=bool(all(comparisons))
    ix=m.surface_nodes(c,'body_water-shadow');X=reference[ix];Y=(solved-reference)[ix,1];stations=[]
    for a,b in zip([.02,.04,.06,.08,.10,.12],[.04,.06,.08,.10,.12,.14]):
        mask=(X[:,0]>=a)&(X[:,0]<b)&(abs(X[:,1])<.018)&(abs(X[:,2])<.035)
        stations.append({'x_m':(a+b)/2,'mean_y_displacement_m':float(Y[mask].mean()),'nodes':int(mask.sum())})
    sx=np.array([x['x_m'] for x in stations]);sy=np.array([x['mean_y_displacement_m'] for x in stations]);bend=float(abs(sy-np.polyval(np.polyfit(sx,sy,1),sx)).max())
    text=(root/f'step-{step:04d}.trn').read_text('utf-8',errors='replace');rows,diag=v.parse_transcript(text);last=rows[-1] if rows else {}
    threshold=.005 if step<=3 else .01
    displace_threshold=float(config.get('displacement_residual_criterion',1e-4))
    checks['residuals_and_native_convergence']=bool(last.get('converged_marker') and all(v.finite(last.get(eq)) and 0<=last[eq]<(threshold if eq=='continuity' else displace_threshold if eq.endswith('-displace') else 1e-4) for eq in v.EQUATIONS))
    last['legacy_1e3_continuity_comparison']=last.pop('residual_thresholds_passed',None)
    last['declared_continuity_threshold']=threshold
    last['step_numerically_converged']=checks['residuals_and_native_convergence']
    checks['no_native_errors']=not diag['unacknowledged_runtime_errors_after_first_iteration'] and not diag['nonfinite_residual_rows'] and not diag['parse_issues']
    q=re.findall(r'Minimum Orthogonal Quality\s*=\s*([-+\d.eE]+)',text);checks['native_mesh_quality']=bool(q) and float(q[-1])>=.001
    cfg=root/f'step-{step:04d}-config.json';cfg=cfg if cfg.exists() else root/'cycle-config.json'
    event=check_structure_corrector_record(json.loads((root/f'structure-corrector-{step:04d}.json').read_text('utf-8')),step,json.loads(cfg.read_text('utf-8')))
    checks['coupling_event_schedule']=event['passed']
    prev=m.read_case(root/(f'step-{step-1:04d}.cas.h5' if step>1 else 'initial.cas.h5'))
    V=float(volumes[indices(c,'water')].sum());Vp=float(signed_volumes(prev)[indices(prev,'water')].sum());storage=1000*(V-Vp)/dt;net=report['mass-inlet']+report['mass-outlet'];error=abs(storage-net)/abs(report['mass-inlet'])
    checks['ALE_mass_balance']=bool(np.isfinite(error) and error<.001)
    return {'passed':all(bool(x) for x in checks.values()),'checks':{k:bool(x) for k,x in checks.items()},'step':step,'time_s':d['time_s'],'minimum_orthogonal_quality':float(q[-1]) if q else None,'minimum_native_cell_volumes_m3':minimum,'minimum_structural_J':J,'interfaces_error_m':wet,'body_stations':stations,'non_affine_body_bending_peak_m':bend,'residuals':last,'relative_ALE_mass_error':error,'cell_counts':{n:len(indices(c,n)) for n in c['zones']['cells']},'node_count':len(c['xyz']),'fluid_mesh_topology_changed':len(c['tet'])!=len(ref['tet']) or not np.array_equal(c['tet'],ref['tet'])}
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--step',type=int,required=True);a=p.parse_args();r=audit(a.root,a.step);(a.root/f'step-{a.step:04d}-remesh-audit.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
