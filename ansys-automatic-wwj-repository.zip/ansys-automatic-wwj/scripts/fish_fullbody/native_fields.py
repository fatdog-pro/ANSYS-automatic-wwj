import re
import hashlib
import h5py
import numpy as np
def unique_reference_matches(reference_xyz, target_nodes, source_nodes):
    """Return source IDs; distinct arrays are never paired by array position."""
    source_nodes = np.asarray(source_nodes, dtype=int)
    assert len(source_nodes) > 0 and len(np.unique(source_nodes)) == len(source_nodes)
    source_xyz = reference_xyz[source_nodes]
    mapping = []
    for node in target_nodes:
        matches = np.flatnonzero(np.linalg.norm(source_xyz-reference_xyz[node], axis=1) < 1e-12)
        assert len(matches) == 1, "Reference vertex correspondence is missing or ambiguous"
        mapping.append(source_nodes[matches[0]])
    assert len(np.unique(mapping)) == len(mapping), "Reference correspondence must be one-to-one"
    return np.asarray(mapping, dtype=int)

def native_step_time(variables):
    step = int(re.search(r"\(time-step\s+(\d+)\)", variables).group(1))
    time = float(re.search(r"\(flow-time\s+([^\)]+)\)", variables).group(1))
    assert np.isfinite(time), "Native flow time is nonfinite"
    return step, time

def value(a):
    return int(np.asarray(a).reshape(-1)[0])

def signature(path):
    st = path.stat()
    return st.st_size, st.st_mtime_ns

def read_case(path):
    before = signature(path)
    with h5py.File(path, "r") as f:
        m = f["meshes/1"]
        assert value(m.attrs["dimension"]) == 3
        count = value(m.attrs["cellCount"])
        assert value(m["nodes/coords/1"].attrs["minId"]) == 1
        xyz = m["nodes/coords/1"][:]
        assert len(xyz) == value(m.attrs["nodeCount"])
        assert np.all(m["faces/nodes/1/nnodes"][:] == 3)
        faces = m["faces/nodes/1/nodes"][:].astype(np.int64).reshape(-1, 3) - 1
        c0 = m["faces/c0/1"][:].astype(np.int64) - 1
        c1 = np.full(len(faces), -1, dtype=np.int64)
        ds = m["faces/c1/1"]
        lo, hi = value(ds.attrs["minId"]) - 1, value(ds.attrs["maxId"])
        c1[lo:hi] = ds[:].astype(np.int64) - 1
        zones = {}
        for kind in ["cells", "faces"]:
            group = m[f"{kind}/zoneTopology"]
            names = group["name"][0].decode().split(";")
            zones[kind] = {name: {k: int(group[k][i]) for k in group if k not in {"name", "fields"}}
                           for i, name in enumerate(names)}
        assert all(z["cellType"] == 2 for z in zones["cells"].values()), "Only tetrahedra are supported"
        version = f["settings/Version"][0].decode()
    assert signature(path) == before, "Case file changed while being read"
    assert len(faces) == len(c0) and np.all((c0 >= 0) & (c0 < count))
    sets = [set() for _ in range(count)]
    adjacency = np.zeros(count, dtype=int)
    for i, face in enumerate(faces):
        for cell in (c0[i], c1[i]):
            if cell >= 0:
                assert cell < count
                sets[cell].update(map(int, face))
                adjacency[cell] += 1
    assert np.all(adjacency == 4), "Every tetrahedron must have four faces"
    assert all(len(nodes) == 4 for nodes in sets), "Every tetrahedron must have four unique vertices"
    tet = np.array([sorted(nodes) for nodes in sets], dtype=int)
    assert np.all((tet >= 0) & (tet < len(xyz))) and np.isfinite(xyz).all()
    return {"xyz": xyz, "faces": faces, "c0": c0, "c1": c1, "tet": tet,
            "zones": zones, "version": version, "signature": before}

def read_data(path):
    before = signature(path)
    with h5py.File(path, "r") as f:
        g = f["special/structure-node-data/nodes/1"]
        ids = g["elemids"][:].astype(np.int64) - 1
        assert np.all(g["ndata"][:] == 21), "Unsupported structural restart layout"
        data = g["data"][:].reshape(-1, 21)
        assert len(ids) == len(data) and len(np.unique(ids)) == len(ids)
        direct = f["special/structure-direct-data/data"][:].tolist()
        assert direct == list(range(11431, 11449)) + [11455, 11456, 11457], "Unknown Fluent 261 structural field layout"
        variables = f["settings/Data Variables"][0].decode()
        step, time = native_step_time(variables)
        stress = {}
        for name in ["XX", "YY", "ZZ", "XY", "YZ", "XZ"]:
            ds = f[f"results/1/phase-1/cells/SV_SIGMA_{name}/1"]
            stress[name] = (value(ds.attrs["minId"]) - 1, value(ds.attrs["maxId"]), ds[:])
    assert signature(path) == before, "Data file changed while being read"
    assert np.isfinite(data).all()
    return {"ids": ids, "reference_xyz": data[:, -3:], "displacement": data[:, [0, 6, 12]],
            "step": step, "time_s": time, "stress": stress, "signature": before}

def matrices(xyz, tet):
    return (xyz[tet[:, 1:]] - xyz[tet[:, 0, None]]).transpose(0, 2, 1)

def surface_nodes(case, name):
    zone = case["zones"]["faces"][name]
    return np.unique(case["faces"][zone["minId"]-1:zone["maxId"]])
