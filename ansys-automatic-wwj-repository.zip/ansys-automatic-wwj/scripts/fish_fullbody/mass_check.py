import json
import numpy as np
import native_fields as m
def check_mass(root,step):
    ref=m.read_case(root/'initial.cas.h5');prev=m.read_case(root/(f'step-{step-1:04d}.cas.h5' if step>1 else 'initial.cas.h5'));now=m.read_case(root/f'step-{step:04d}.cas.h5')
    z=ref['zones']['cells']['water'];ids=np.arange(z['minId']-1,z['maxId']);tet=ref['tet'][ids];sign=np.sign(np.linalg.det(m.matrices(ref['xyz'],tet)))
    vol=lambda c:float((np.linalg.det(m.matrices(c['xyz'],tet))*sign/6).sum())
    reports={k:v[0] for x in json.loads((root/f'step-{step:04d}-summary.json').read_text('utf-8'))['reports'] for k,v in x.items()}
    storage=1000*(vol(now)-vol(prev))/.025;net=reports['mass-inlet']+reports['mass-outlet'];error=abs(storage-net)/abs(reports['mass-inlet'])
    return {'passed':bool(np.isfinite(error) and error<.001),'relative_error':error,'threshold':.001,'rho_dVdt_kg_s':storage,'net_inflow_kg_s':net,'formula':'abs(rho*dV/dt - (inlet+outlet))/abs(inlet)'}
