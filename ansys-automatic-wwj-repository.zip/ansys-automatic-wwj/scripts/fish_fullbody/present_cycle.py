"""Render accepted checkpoints and a separately verified physical loop in Fluent."""
from pathlib import Path
import json,math,hashlib,sys,shutil
import numpy as np
import ansys.fluent.core as pf
from summarize_cycle import summarize
from check_loop import check

def render(solver,root,indices,name,limit):
    dt=float(json.loads((root/'cycle-config.json').read_text('utf-8'))['dt_s'])
    out=root/name;out.mkdir(exist_ok=False);s=solver.settings
    lines=['AnimationSequence1.0',f'NAME: {name}','WINID: 1','STORAGE: 5','PLOTANIMATION: 0',f'FRAMES: {len(indices)}'];frames=[]
    for frame,i in enumerate(indices):
        case=root/f'step-{i:04d}.cas.h5';data=root/f'step-{i:04d}.dat.h5'
        assert json.loads((root/f'step-{i:04d}-audit.json').read_text('utf-8'))['passed']
        solver.chdir(root.as_posix());s.file.read_case_data(file_name=case.as_posix())
        assert abs(s.solution.run_calculation.transient_controls.flow_time()-i*dt)<1e-9
        c=s.results.graphics.contour['fullbody-displacement'];assert c.deformation() is False
        c.range_options.auto_range=False;c.range_options.minimum=0.;c.range_options.maximum=limit;c.display()
        s.results.graphics.views.restore_view(view_name='fullbody-top-oblique')
        pic=s.results.graphics.picture;pic.driver_options.hardcopy_format='hsf';hsf=out/f'{name}_{frame:04d}.hsf';pic.save_picture(file_name=hsf.as_posix())
        assert hsf.stat().st_size>1000
        lines.append(f'Frame {frame} 5 {hsf.name} 1')
        frames.append(dict(frame=frame,accepted_step=i,time_s=i*dt,case_sha256=hashlib.sha256(case.read_bytes()).hexdigest(),data_sha256=hashlib.sha256(data.read_bytes()).hexdigest(),hsf_sha256=hashlib.sha256(hsf.read_bytes()).hexdigest(),display_amplification=False))
    pic.driver_options.hardcopy_format='png';cxa=out/f'{name}.cxa';cxa.write_text('\n'.join(lines)+'\n',encoding='ascii')
    (out/'frame-provenance.json').write_text(json.dumps(frames,indent=2),encoding='utf-8')
    return cxa

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--steps',type=int,required=True);p.add_argument('--server-info',required=True);a=p.parse_args();root=a.root
    dt=float(json.loads((root/'cycle-config.json').read_text('utf-8'))['dt_s'])
    proof=summarize(root,a.steps);loop=check(root,a.steps)
    solver=pf.connect_to_fluent(server_info_file_name=a.server_info,cleanup_on_exit=False,start_watchdog=False,start_transcript=False);s=solver.settings
    limit=math.ceil(max(proof['max_body_surface_displacement_mm'],proof['max_tail_surface_displacement_mm'])/5)*.005
    full=render(solver,root,list(range(1,a.steps+1)),'fullbody-process',limit)
    selected=full;count=a.steps;name='fullbody-process'
    if loop['loop_found']:
        c=loop['chosen'];indices=list(range(c['start_step'],c['end_step']))
        # Reuse the exact native frames already rendered with one fixed range.
        # Exclude the duplicate endpoint so looping preserves the time spacing.
        name='fullbody-loop';out=root/name;out.mkdir(exist_ok=False);count=len(indices)
        provenance=json.loads((full.parent/'frame-provenance.json').read_text('utf-8'))
        lines=['AnimationSequence1.0',f'NAME: {name}','WINID: 1','STORAGE: 5','PLOTANIMATION: 0',f'FRAMES: {count}'];subset=[]
        for frame,i in enumerate(indices):
            source=full.parent/f'fullbody-process_{i-1:04d}.hsf';target=out/f'{name}_{frame:04d}.hsf';shutil.copy2(source,target)
            record=dict(provenance[i-1]);assert record['accepted_step']==i
            assert hashlib.sha256(target.read_bytes()).hexdigest()==record['hsf_sha256']
            record['frame']=frame;subset.append(record);lines.append(f'Frame {frame} 5 {target.name} 1')
        selected=out/f'{name}.cxa';selected.write_text('\n'.join(lines)+'\n',encoding='ascii')
        (out/'frame-provenance.json').write_text(json.dumps(subset,indent=2),encoding='utf-8')
    s.file.read_case_data(file_name=(root/f'step-{a.steps:04d}.cas.h5').as_posix())
    names=['body-y','body-max','tail-y','tail-max','mass-inlet','mass-outlet']
    flat=lambda r:{k:v[0] for x in r for k,v in x.items()}
    before=flat(s.solution.report_definitions.compute(report_defs=names))
    s.file.write_case_data(file_name=(root/'fish-delivery.cas.h5').as_posix())
    s.file.read_case_data(file_name=(root/'fish-delivery.cas.h5').as_posix())
    after=flat(s.solution.report_definitions.compute(report_defs=names))
    assert all(np.isclose(before[k],after[k],rtol=1e-8,atol=1e-10) for k in before)
    assert abs(s.solution.run_calculation.transient_controls.flow_time()-a.steps*dt)<1e-9
    c=s.results.graphics.contour['fullbody-displacement'];assert c.deformation() is False
    c.range_options.auto_range=False;c.range_options.minimum=0;c.range_options.maximum=limit;c.display();s.results.graphics.views.restore_view(view_name='fullbody-top-oblique')
    s.results.graphics.picture.save_picture(file_name=(root/'fish-fullbody-final.png').as_posix())
    pb=s.results.animations.playback;pb.read_animation_file(animation_file_name=selected.as_posix());pb.current_animation=name;pb.view_mode(view_name='current-view')
    pb.play(player='>',start_frame=1,end_frame=count,increment=1,playback_mode='play-once',speed=15)
    result=dict(passed=True,case_data_reopened=True,reports_match_after_reopen=True,time_s=a.steps*dt,accepted_steps=a.steps,animation_frames=count,native_animation_path=str(selected),full_process_animation=str(full),physical_loop_verified=loop['loop_found'],display_amplification=False,gui_left_open=True)
    (root/'native-presentation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
