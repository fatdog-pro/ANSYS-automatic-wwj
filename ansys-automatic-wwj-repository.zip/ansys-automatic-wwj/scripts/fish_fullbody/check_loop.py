"""Judge a repeated motion using actual FE wet-surface positions, not video tricks."""
from pathlib import Path
import argparse,json,sys
import numpy as np
import native_fields as nf
from audit_remesh import canonical_map

def check(root,end):
    config=json.loads((root/'cycle-config.json').read_text('utf-8'))
    dt=float(config['dt_s']);period=1./float(config['frequency_Hz'])
    ref=nf.read_case(root/'initial.cas.h5')
    nodes=np.unique(np.concatenate([nf.surface_nodes(ref,n) for n in ['body_water-shadow','fish_eyes-shadow','tail_water-shadow']]))
    tail=nf.surface_nodes(ref,'tail_water-shadow')
    series=[];tail_y=[];rows=[]
    for i in range(1,end+1):
        a=json.loads((root/f'step-{i:04d}-audit.json').read_text('utf-8'));assert a['passed']
        d=nf.read_data(root/f'step-{i:04d}.dat.h5');assert d['step']==i and abs(d['time_s']-i*dt)<1e-9
        full=np.zeros_like(ref['xyz']);full[canonical_map(ref,d)]=d['displacement']
        series.append(full[nodes]);tail_y.append(float(full[tail,1].mean()))
        rows.append({'step':i,'time_s':d['time_s'],'tail_mean_y_m':tail_y[-1],'body_bending_m':a['non_affine_body_bending_peak_m']})
    u=np.array(series);v=np.diff(u,axis=0)/dt;candidates=[]
    period_steps=int(round(period/dt));assert abs(period_steps*dt-period)<1e-9
    for start in range(2,end-period_steps+1):
        finish=start+period_steps
        window=u[start-1:finish];vel=v[start-2:finish-1]
        amplitude=float(np.sqrt(np.mean(np.sum((window.max(axis=0)-window.min(axis=0))**2,axis=1))))
        du=u[finish-1]-u[start-1]
        relative_position=float(np.sqrt(np.mean(np.sum(du**2,axis=1)))/max(amplitude,1e-12))
        dv=v[finish-2]-v[start-2]
        speed=float(np.max(np.sqrt(np.mean(np.sum(vel**2,axis=2),axis=1))))
        relative_velocity=float(np.sqrt(np.mean(np.sum(dv**2,axis=1)))/max(speed,1e-12))
        ty=np.array(tail_y[start-1:finish]);dy=np.diff(ty)
        # A cycle beginning at an extremum has its second reversal at the join.
        # Closure remains independently gated by solved position and velocity.
        turns=int(np.sum(dy[:-1]*dy[1:]<0))+int(dy[-1]*dy[0]<0)
        checks={'same_forcing_phase':True,'both_sides_of_reference':bool(ty.min()<-.001 and ty.max()>.001),'two_direction_reversals':turns>=2,'position_closure':relative_position<=.05,'velocity_closure':relative_velocity<=.15}
        candidates.append({'start_step':start,'end_step':finish,'start_time_s':start*dt,'end_time_s':finish*dt,'relative_position_seam':relative_position,'relative_velocity_seam':relative_velocity,'max_position_seam_m':float(np.linalg.norm(du,axis=1).max()),'turns':turns,'checks':checks,'passed':all(checks.values())})
    accepted=[c for c in candidates if c['passed']]
    result={'accepted_steps':end,'time_s':end*dt,'drive_period_s':period,'loop_found':bool(accepted),'chosen':min(accepted,key=lambda c:c['relative_position_seam']+c['relative_velocity_seam']) if accepted else None,'best_candidate':min(candidates,key=lambda c:c['relative_position_seam']+c['relative_velocity_seam']) if candidates else None,'all_candidates':candidates,'tail_motion':rows,'scope':'Position and finite-difference velocity continuity for native geometry playback only; does not establish periodic convergence of the fluid field.'}
    (root/'loop-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--end',type=int,required=True);a=p.parse_args();r=check(a.root,a.end);print(json.dumps({k:v for k,v in r.items() if k not in ['tail_motion','all_candidates']},indent=2))
