"""Use native time-step HSF frames; audit all fields and reopen final Case/Data."""
from pathlib import Path
import argparse, hashlib, json, shutil
import numpy as np
import ansys.fluent.core as pf
from summarize_cycle import summarize
from check_loop import check

p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--steps',type=int,required=True);p.add_argument('--server-info',required=True)
a=p.parse_args();root=a.root
config=json.loads((root/'cycle-config.json').read_text('utf-8'));dt=float(config['dt_s'])
proof=summarize(root,a.steps);loop=check(root,a.steps)
source=root/'animations';original=(source/'fullbody-swim.cxa').read_text('ascii')
assert f'FRAMES: {a.steps}' in original
assert len(list(source.glob('fullbody-swim_*.hsf')))==a.steps
limit=config['animation_limit_m']
assert max(proof['max_body_surface_displacement_mm'],proof['max_tail_surface_displacement_mm'])/1000<=limit, 'Recorded color range exceeded: rerender with a larger fixed range'
out=root/'fullbody-process';out.mkdir(exist_ok=False)
lines=['AnimationSequence1.0','NAME: fullbody-process','WINID: 1','STORAGE: 5','PLOTANIMATION: 0',f'FRAMES: {a.steps}'];frames=[]
for frame in range(a.steps):
    i=frame+1;src=source/f'fullbody-swim_{frame:04d}.hsf';dst=out/f'fullbody-process_{frame:04d}.hsf'
    assert f'Frame {frame} 5 {src.name} 1' in original and src.stat().st_size>1000
    checkpoint=json.loads((root/f'step-{i:04d}-frame.json').read_text('utf-8'))
    digest=hashlib.sha256(src.read_bytes()).hexdigest();assert digest==checkpoint['hsf_sha256']
    assert checkpoint['accepted_step']==i and abs(checkpoint['time_s']-i*dt)<1e-9
    assert json.loads((root/f'step-{i:04d}-audit.json').read_text('utf-8'))['passed']
    shutil.copy2(src,dst);lines.append(f'Frame {frame} 5 {dst.name} 1')
    frames.append(dict(frame=frame,accepted_step=i,time_s=i*dt,hsf_sha256=digest,
        case_sha256=hashlib.sha256((root/f'step-{i:04d}.cas.h5').read_bytes()).hexdigest(),
        data_sha256=hashlib.sha256((root/f'step-{i:04d}.dat.h5').read_bytes()).hexdigest(),
        source='Fluent native solution animation at end of converged time step',
        display_amplification=False,interpolated=False,color_limit_m=limit))
cxa=out/'fullbody-process.cxa';cxa.write_text('\n'.join(lines)+'\n',encoding='ascii')
(out/'frame-provenance.json').write_text(json.dumps(frames,indent=2),encoding='utf-8')
solver=pf.connect_to_fluent(server_info_file_name=a.server_info,cleanup_on_exit=False,start_watchdog=False,start_transcript=False);s=solver.settings
solver.chdir(root.as_posix());assert abs(s.solution.run_calculation.transient_controls.flow_time()-a.steps*dt)<1e-9
names=['body-y','body-max','tail-y','tail-max','mass-inlet','mass-outlet']
flat=lambda r:{k:v[0] for x in r for k,v in x.items()}
before=flat(s.solution.report_definitions.compute(report_defs=names))
saved=flat(json.loads((root/f'step-{a.steps:04d}-summary.json').read_text('utf-8'))['reports'])
assert all(np.isclose(before[k],saved[k],rtol=1e-8,atol=1e-10) for k in before)
s.file.write_case_data(file_name=(root/'fish-delivery.cas.h5').as_posix())
s.file.read_case_data(file_name=(root/'fish-delivery.cas.h5').as_posix())
after=flat(s.solution.report_definitions.compute(report_defs=names))
assert all(np.isclose(before[k],after[k],rtol=1e-8,atol=1e-10) for k in before)
assert abs(s.solution.run_calculation.transient_controls.flow_time()-a.steps*dt)<1e-9
c=s.results.graphics.contour['fullbody-displacement'];assert c.deformation() is False
assert np.isclose(c.range_options.maximum(),limit)
c.display();s.results.graphics.views.restore_view(view_name='fullbody-top-oblique')
s.results.graphics.picture.driver_options.hardcopy_format='png'
s.results.graphics.picture.save_picture(file_name=(root/'fish-fullbody-final.png').as_posix())
pb=s.results.animations.playback;pb.read_animation_file(animation_file_name=cxa.as_posix());pb.current_animation='fullbody-process';pb.view_mode(view_name='current-view')
pb.play(player='>',start_frame=1,end_frame=a.steps,increment=1,playback_mode='play-once',speed=15)
result=dict(passed=True,case_data_reopened=True,reports_match_after_reopen=True,time_s=a.steps*dt,accepted_steps=a.steps,
    animation_frames=a.steps,native_animation_path=str(cxa),full_process_animation=str(cxa),
    physical_loop_verified=loop['loop_found'],display_amplification=False,gui_left_open=True,
    route='Native per-step HSF capture, independent all-checkpoint audit, final Case/Data reopen; no per-frame case reload')
(root/'native-presentation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
