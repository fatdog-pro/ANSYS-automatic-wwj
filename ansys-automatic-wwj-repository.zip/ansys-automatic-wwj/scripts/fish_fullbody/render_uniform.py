from pathlib import Path
import json,hashlib,math

def render(solver,root,steps):
    s=solver.settings
    out=root/'playback-uniform';out.mkdir(exist_ok=False)
    peak=max(v[0] for i in range(1,steps+1) for item in json.loads((root/f'step-{i:04d}-summary.json').read_text('utf-8'))['reports'] for k,v in item.items() if k in ['body-max','tail-max'])
    limit=math.ceil(peak/.005)*.005
    frames=[];lines=['AnimationSequence1.0','NAME: fullbody-swim','WINID: 1','STORAGE: 5','PLOTANIMATION: 0',f'FRAMES: {steps}']
    for i in range(1,steps+1):
        case=root/f'step-{i:04d}.cas.h5';data=root/f'step-{i:04d}.dat.h5'
        solver.chdir(root.as_posix());s.file.read_case_data(file_name=case.as_posix())
        assert abs(s.solution.run_calculation.transient_controls.flow_time()-i*.025)<1e-9
        contour=s.results.graphics.contour['fullbody-displacement'];assert contour.deformation() is False
        contour.range_options.auto_range=False;contour.range_options.minimum=0.;contour.range_options.maximum=limit
        contour.display();s.results.graphics.views.restore_view(view_name='fullbody-top-oblique')
        picture=s.results.graphics.picture;picture.driver_options.hardcopy_format='hsf'
        target=out/f'fullbody-swim_{i-1:04d}.hsf';picture.save_picture(file_name=target.as_posix())
        assert target.is_file() and target.stat().st_size>1000
        lines.append(f'Frame {i-1} 5 {target.name} 1')
        frames.append({'accepted_step':i,'time_s':i*.025,'source_case_sha256':hashlib.sha256(case.read_bytes()).hexdigest(),'source_data_sha256':hashlib.sha256(data.read_bytes()).hexdigest(),'hsf_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'color_max_m':limit,'native_render_from_accepted_checkpoint':True,'deformation_amplification':False})
    picture.driver_options.hardcopy_format='png'
    (out/'fullbody-swim.cxa').write_text('\n'.join(lines)+'\n',encoding='ascii')
    (out/'frame-provenance.json').write_text(json.dumps(frames,indent=2),encoding='utf-8')
    return out/'fullbody-swim.cxa'
