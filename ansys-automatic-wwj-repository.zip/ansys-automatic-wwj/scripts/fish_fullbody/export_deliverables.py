"""Export verified fish results through Fluent API and encode chat-ready media.

No solve calls. Standalone reruns use a new --out directory. The default replay
invokes this after native validation. Requires PyFluent, matplotlib and FFmpeg.
"""
from pathlib import Path
import argparse, csv, hashlib, json, math, re, shutil, subprocess, time, uuid


def read(path):
    return json.loads(Path(path).read_text('utf-8'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(exe, args):
    result = subprocess.run([str(exe), '-hide_banner', '-loglevel', 'error',
                             '-nostdin', *map(str, args)], capture_output=True,
                            text=True, encoding='utf-8', errors='replace', timeout=120)
    if result.returncode:
        raise RuntimeError(result.stderr[-5000:])
    return result.stdout


def preflight(fluent=None, ffmpeg=None):
    import matplotlib
    candidates = [Path(ffmpeg)] if ffmpeg else []
    if not ffmpeg and fluent:
        for parent in Path(fluent).resolve().parents:
            candidates += sorted((parent/'tp/ffmpeg').glob('*/winx64/ffmpeg.exe'), reverse=True)
    if not ffmpeg and shutil.which('ffmpeg'):
        candidates.append(Path(shutil.which('ffmpeg')))
    for exe in candidates:
        if not exe.is_file():
            continue
        encoders = command(exe, ['-encoders'])
        codec = next((c for c in ['libopenh264', 'libx264']
                      if re.search(r'\b'+c+r'\b', encoders)), None)
        if codec and re.search(r'\bgif\b', encoders):
            return {'ffmpeg': str(exe), 'h264_encoder': codec,
                    'matplotlib_version': matplotlib.__version__}
    raise RuntimeError('Provide --ffmpeg with GIF and libopenh264 or libx264 encoders. '
                       'Also install matplotlib into the solver Python environment.')


def decode_frames(exe, path):
    raw = command(exe, ['-i', path, '-f', 'framemd5', '-'])
    tb = re.search(r'#tb 0:\s*(\d+)/(\d+)', raw)
    rows = [line.split(',') for line in raw.splitlines()
            if line.strip() and not line.startswith('#')]
    assert tb and rows, 'Media decode failed'
    duration = sum(int(row[3]) for row in rows)*int(tb[1])/int(tb[2])
    return {'frames':len(rows), 'duration_s':duration,
            'distinct_decoded_frames':len({row[-1].strip() for row in rows})}


def curves(root, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    with (root/'fullbody-motion.csv').open(encoding='utf-8-sig', newline='') as stream:
        rows = [{k:float(v) for k,v in row.items()} for row in csv.DictReader(stream)]
    t = [row['time_s'] for row in rows]
    fig, axes = plt.subplots(2, 2, figsize=(11, 7), constrained_layout=True)
    for label, field, color in [('Body','body','#2563eb'),('Tail','tail','#e07020')]:
        axes[0,0].plot(t,[row[field+'_max_mm'] for row in rows],label=label,color=color)
        axes[0,1].plot(t,[row[field+'_mean_y_mm'] for row in rows],label=label,color=color)
    axes[0,0].set_title('Maximum surface displacement');axes[0,0].set_ylabel('mm')
    axes[0,1].set_title('Mean lateral displacement');axes[0,1].set_ylabel('mm')
    axes[0,1].axhline(0,color='gray',linewidth=.7)
    axes[1,0].plot(t,[row['body_bending_mm'] for row in rows],color='#15803d')
    axes[1,0].set_title('Non-affine body bending indicator');axes[1,0].set_ylabel('mm')
    axes[1,1].semilogy(t,[max(row['relative_ALE_mass_error'],1e-15) for row in rows],color='#7e22ce')
    axes[1,1].axhline(.001,color='red',linestyle='--',label='Acceptance limit')
    axes[1,1].set_title('Relative ALE mass-balance error');axes[1,1].set_ylabel('dimensionless')
    for ax in axes.flat:
        ax.set_xlabel('Physical time (s)');ax.grid(alpha=.25)
    axes[0,0].legend();axes[0,1].legend();axes[1,1].legend()
    fig.suptitle('Full-body fish — solved transient results')
    fig.savefig(out/'result-curves.png',dpi=150)
    plt.close(fig)
    shutil.copy2(root/'fullbody-motion.csv',out/'results.csv')


def export(root, server_info, out, media, fps=10):
    import ansys.fluent.core as pf
    root=Path(root).resolve();out=Path(out).resolve()
    assert str(out).isascii(), 'Fluent export directory must use an ASCII path'
    assert not out.exists(), 'Use a new output directory; existing exports are preserved'
    assert 1 <= fps <= 40 and 100 % fps == 0, 'Use an exact GIF frame interval, e.g. 5, 10, 20'
    proof=read(root/'fullbody-validation.json');native=read(root/'native-presentation.json')
    cfg=read(root/'cycle-config.json');dt=float(cfg['dt_s']);steps=int(proof['accepted_steps'])
    assert proof['passed'] and native['passed'] and native['case_data_reopened']
    assert native['reports_match_after_reopen'] and native['animation_frames']==steps
    assert math.isclose(proof['time_s'],steps*dt,abs_tol=1e-9)
    provenance=read(root/'fullbody-process/frame-provenance.json')
    assert len(provenance)==steps
    for i,row in enumerate(provenance,1):
        hsf=root/'fullbody-process'/f'fullbody-process_{i-1:04d}.hsf'
        assert row['accepted_step']==i and math.isclose(row['time_s'],i*dt,abs_tol=1e-9)
        assert digest(hsf)==row['hsf_sha256'] and read(root/f'step-{i:04d}-audit.json')['passed']
    started=time.monotonic();out.mkdir(parents=True)
    report={'status':'exporting','source_run':str(root),'solve_performed':False,
            'frames':steps,'fps':fps,'slowdown_factor':1/(dt*fps),
            'physical_time_s':proof['time_s'],'physical_loop_closed':native['physical_loop_verified'],
            'interpolated':False,'reversed':False,'media_backend':media}
    try:
        final_hashes={n:digest(root/n) for n in ['fish-delivery.cas.h5','fish-delivery.dat.h5']}
        f=pf.connect_to_fluent(server_info_file_name=str(server_info),cleanup_on_exit=False,
                              start_watchdog=False,start_transcript=False)
        s=f.settings
        assert math.isclose(s.solution.run_calculation.transient_controls.flow_time(),steps*dt,abs_tol=1e-9)
        names=['body-y','body-max','tail-y','tail-max','mass-inlet','mass-outlet']
        flatten=lambda x:{k:v[0] for block in x for k,v in block.items()}
        before=flatten(s.solution.report_definitions.compute(report_defs=names))
        expected=flatten(read(root/f'step-{steps:04d}-summary.json')['reports'])
        assert all(math.isclose(before[k],expected[k],rel_tol=1e-8,abs_tol=1e-10) for k in names)
        # A unique sequence name prevents any duplicate-name overwrite dialog.
        sequence='fish-export-'+uuid.uuid4().hex[:8]
        seq=out/'native-sequence';seq.mkdir();frames=out/'frames';frames.mkdir()
        lines=['AnimationSequence1.0','NAME: '+sequence,'WINID: 1','STORAGE: 5',
               'PLOTANIMATION: 0',f'FRAMES: {steps}']
        for i in range(steps):
            name=f'fullbody-process_{i:04d}.hsf'
            shutil.copy2(root/'fullbody-process'/name,seq/name)
            lines.append(f'Frame {i} 5 {name} 1')
        cxa=seq/(sequence+'.cxa');cxa.write_text('\n'.join(lines)+'\n',encoding='ascii')
        p=s.results.animations.playback;previous_animation=p.current_animation()
        p.read_animation_file(animation_file_name=cxa.as_posix());p.current_animation=sequence
        s.results.graphics.views.restore_view(view_name='fullbody-top-oblique')
        p.view_mode(view_name='current-view')
        picture=s.results.graphics.picture
        old_format=picture.driver_options.hardcopy_format()
        picture.driver_options.hardcopy_format='png'
        exported=[]
        try:
            for i in range(1,steps+1):
                p.play(player='>',start_frame=i,end_frame=i,increment=1,playback_mode='play-once',speed=100)
                path=frames/f'frame-{i:04d}.png'
                picture.save_picture(file_name=path.as_posix())
                assert path.stat().st_size>1000
                exported.append(dict(frame=i,physical_time_s=i*dt,png_sha256=digest(path),
                                     source_hsf_sha256=provenance[i-1]['hsf_sha256']))
                print(f'EXPORTED {i}/{steps}',flush=True)
        finally:
            # [] stop has a 26.1 Scheme error; use the tested forward play command.
            p.set_custom_frames.start_frame=1;p.set_custom_frames.end_frame=steps;p.set_custom_frames.increment=1
            p.play(player='>',start_frame=1,end_frame=steps,increment=1,playback_mode='play-once',speed=100)
            if previous_animation:p.current_animation=previous_animation
            picture.driver_options.hardcopy_format=old_format
        assert len({row['png_sha256'] for row in exported})==steps,'Repeated/stale frames detected'
        shutil.copy2(frames/f'frame-{steps:04d}.png',out/'displacement-final.png')
        # Export the actual final wet-surface fluid pressure, independently of HSF playback.
        graphics=s.results.graphics;key='delivery-pressure-'+uuid.uuid4().hex[:8]
        graphics.contour.create(name=key);c=graphics.contour[key]
        assert 'pressure' in c.field.allowed_values()
        c.field='pressure';c.surfaces_list=['body_water','fish_eyes','tail_water','fish_drive']
        c.options.filled=True;c.options.node_values=True;c.range_options.auto_range=True
        picture.driver_options.hardcopy_format='png'
        try:
            c.display();picture.save_picture(file_name=(out/'pressure-final.png').as_posix())
        finally:
            graphics.contour['fullbody-displacement'].display()
            picture.driver_options.hardcopy_format=old_format
        after=flatten(s.solution.report_definitions.compute(report_defs=names))
        assert all(math.isclose(before[k],after[k],rel_tol=1e-8,abs_tol=1e-10) for k in names)
        assert math.isclose(s.solution.run_calculation.transient_controls.flow_time(),steps*dt,abs_tol=1e-9)
        assert all(digest(root/n)==h for n,h in final_hashes.items())
        exe=media['ffmpeg'];codec=media['h264_encoder']
        mp4=out/'fish-swimming.mp4';gif=out/'fish-swimming.gif'
        inputs=['-y','-framerate',fps,'-start_number',1,'-i',frames/'frame-%04d.png','-frames:v',steps]
        command(exe,inputs+['-vf','pad=ceil(iw/2)*2:ceil(ih/2)*2:color=white',
                '-c:v',codec,'-b:v','4M','-pix_fmt','yuv420p','-movflags','+faststart',mp4])
        command(exe,inputs+['-vf','split[a][b];[a]palettegen=stats_mode=full[p];[b][p]paletteuse=dither=sierra2_4a',
                           '-loop',0,gif])
        decoded={path.name:decode_frames(exe,path) for path in [mp4,gif]}
        assert all(v['frames']==steps and v['distinct_decoded_frames']==steps and
                   math.isclose(v['duration_s'],steps/fps,abs_tol=.011) for v in decoded.values())
        curves(root,out)
        summary={k:v for k,v in proof.items() if k!='all_step_audits'}
        summary.update(final_native_reports=after,physical_loop_closed=native['physical_loop_verified'])
        (out/'results-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
        (out/'frame-provenance.json').write_text(json.dumps(exported,indent=2),encoding='utf-8')
        report.update(status='complete',passed=True,elapsed_s=time.monotonic()-started,
                      media_decode_validation=decoded,final_case_data_unchanged=True,
                      native_reports_unchanged=True,gui_left_open=True)
        items={p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in out.iterdir() if p.is_file()}
        report['artifacts']=items
        (out/'results.md').write_text(
            '# 全身柔性鱼仿真结果\n\n作者：抖音 萌猪过河\n\n'
            f"实际求解 {proof['time_s']:.2f} s，共 {steps} 步。动画 {fps} fps，"
            f"{report['slowdown_factor']:g} 倍慢放，未插值、倒放或放大位移。\n\n"
            f"- 鱼身最大位移：{proof['max_body_surface_displacement_mm']:.3f} mm\n"
            f"- 鱼尾最大位移：{proof['max_tail_surface_displacement_mm']:.3f} mm\n"
            f"- 非线性侧弯指标：{proof['max_body_bending_after_affine_removal_mm']:.3f} mm\n"
            f"- 最低网格正交质量：{proof['minimum_native_orthogonal_quality']:.6g}\n"
            f"- 最大界面误差：{proof['max_interface_error_m']*1e6:.4f} µm\n"
            f"- 最大相对 ALE 质量误差：{proof['max_relative_ALE_mass_error']:.4g}\n\n"
            '![鱼游动](fish-swimming.gif)\n\n[MP4](fish-swimming.mp4) · '
            '[曲线](result-curves.png) · [位移云图](displacement-final.png) · '
            '[水侧压力云图](pressure-final.png) · [CSV](results.csv) · [数值摘要](results-summary.json)\n\n'
            '[原生 Case](../fish-delivery.cas.h5) 和 [Data](../fish-delivery.dat.h5) 需配对保留，'
            '原生 HSF 动画位于上级 fullbody-process/。\n\n'
            f"首尾闭合检查：{'通过' if report['physical_loop_closed'] else '未通过，循环接缝有跳变'}。"
            '这是头端约束的教学启动瞬态，未进行网格/时间步独立性或实验校准。'
            '水侧压力云图是最终求解时刻的数据，曲线来自真实保存步的 CSV。\n',encoding='utf-8')
    except BaseException as exc:
        report.update(status='export-failed',passed=False,error=type(exc).__name__+': '+str(exc),
                      elapsed_s=time.monotonic()-started)
        raise
    finally:
        (out/'delivery.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True);p.add_argument('--server-info',type=Path,required=True)
    p.add_argument('--fluent',type=Path);p.add_argument('--ffmpeg',type=Path)
    p.add_argument('--out',type=Path);p.add_argument('--fps',type=int,default=10)
    a=p.parse_args();media=preflight(a.fluent,a.ffmpeg)
    report=export(a.root,a.server_info,a.out or a.root/'deliverables',media,a.fps)
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
