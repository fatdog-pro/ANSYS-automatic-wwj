from pathlib import Path
import importlib.util,re,json
import numpy as np
import native_fields as m
import native_residuals as v
def audit(root,step):
    config_path=root/'cycle-config.json'
    config=json.loads(config_path.read_text('utf-8')) if config_path.exists() else {}
    continuity=config.get('continuity_criterion',.005) if step>=4 else .005
    ref=m.read_case(root/'initial.cas.h5');case=m.read_case(root/f'step-{step:04d}.cas.h5');data=m.read_data(root/f'step-{step:04d}.dat.h5')
    checks={}
    checks['same_connectivity']=all(np.array_equal(ref[k],case[k]) for k in ['tet','faces','c0','c1'])
    checks['fullbody_zones']=set(case['zones']['cells'])=={'water','stiff_body','soft_tail'}
    checks['reference_ids']=np.max(np.abs(data['reference_xyz']-ref['xyz'][data['ids']]))<1e-12
    xyz=ref['xyz'].copy();xyz[data['ids']]+=data['displacement']
    solid_cells=np.concatenate([np.arange(z['minId']-1,z['maxId']) for n,z in ref['zones']['cells'].items() if n!='water'])
    checks['all_structural_node_ids']=np.array_equal(np.sort(data['ids']),np.unique(ref['tet'][solid_cells]))
    native=json.loads((root/f'step-{step:04d}-summary.json').read_text('utf-8'))
    native_reports={k:v[0] for item in native['reports'] for k,v in item.items()}
    field_checks={}
    for region,surface in [('body','body_water-shadow'),('tail','tail_water-shadow')]:
        nodes=m.surface_nodes(ref,surface);disp=(xyz-ref['xyz'])[nodes]
        values={region+'-max':float(np.linalg.norm(disp,axis=1).max()),region+'-y':float(disp[:,1].mean())}
        field_checks.update({k:bool(np.isclose(value,native_reports[k],rtol=1e-6,atol=1e-10)) for k,value in values.items()})
    checks['native_displacements_match_HDF']=all(field_checks.values())
    D0=np.linalg.det(m.matrices(ref['xyz'],ref['tet']))
    wet={}
    for name in ['body_water','fish_eyes','tail_water','fish_drive']:
        fluid=m.surface_nodes(ref,name);solid=m.surface_nodes(ref,name+'-shadow')
        mapping=m.unique_reference_matches(ref['xyz'],fluid,solid)
        wet[name]=float(np.linalg.norm(case['xyz'][fluid]-xyz[mapping],axis=1).max())
    checks['coupled_interfaces_consistent']=all(x<=1e-6 for x in wet.values())
    volumes={};J={}
    for name,z in ref['zones']['cells'].items():
        ids=np.arange(z['minId']-1,z['maxId']);tet=ref['tet'][ids]
        if name=='water':volumes[name]=float((np.linalg.det(m.matrices(case['xyz'],tet))*np.sign(D0[ids])/6).min())
        else:J[name]=float((np.linalg.det(m.matrices(xyz,tet))/D0[ids]).min())
    checks['positive_water_volume']=all(x>0 for x in volumes.values());checks['positive_solid_J']=all(x>0 for x in J.values())
    fixed=m.surface_nodes(ref,'fish_drive-shadow');checks['head_anchor_fixed']=float(np.linalg.norm(xyz[fixed]-ref['xyz'][fixed],axis=1).max())<1e-8
    # Remove best affine rigid lateral shift/rotation; a remaining nonlinear
    # displacement profile measures actual body bending, not whole-body sway.
    nodes=m.surface_nodes(ref,'body_water-shadow');X=ref['xyz'][nodes];dy=(xyz-ref['xyz'])[nodes,1]
    stations=[]
    for a,b in zip([.02,.04,.06,.08,.10,.12],[.04,.06,.08,.10,.12,.14]):
        mask=(X[:,0]>=a)&(X[:,0]<b)&(np.abs(X[:,1])<.018)&(np.abs(X[:,2])<.035)
        stations.append({'x_m':(a+b)/2,'mean_y_displacement_m':float(dy[mask].mean()),'nodes':int(mask.sum())})
    sx=np.array([r['x_m'] for r in stations]);sy=np.array([r['mean_y_displacement_m'] for r in stations]);res=sy-np.polyval(np.polyfit(sx,sy,1),sx)
    text=(root/f'step-{step:04d}.trn').read_text('utf-8',errors='replace')
    rows,diag=v.parse_transcript(text)
    last=rows[-1] if rows else {}
    checks['actual_time']=data['step']==step and abs(data['time_s']-step*.025)<1e-9
    checks['converged_marker']=last.get('converged_marker',False)
    checks['residuals']=all(v.finite(last.get(eq)) and 0<=last[eq]<(continuity if eq=='continuity' else 1e-4) for eq in v.EQUATIONS)
    last['legacy_1e3_continuity_comparison']=last.pop('residual_thresholds_passed',False)
    last['legacy_1e3_step_comparison']=last.pop('step_numerically_converged',False)
    last['declared_continuity_threshold']=continuity
    last['declared_other_residual_threshold']=1e-4
    last['declared_thresholds_passed']=checks['residuals']
    last['step_numerically_converged']=bool(checks['residuals'] and checks['converged_marker'])
    checks['no_solver_errors']=not diag['unacknowledged_runtime_errors_after_first_iteration'] and not diag['nonfinite_residual_rows']
    checks['no_residual_parse_errors']=not diag['parse_issues']
    q=re.findall(r'Minimum Orthogonal Quality\s*=\s*([-+\d.eE]+)',text)
    checks['native_mesh_quality']=bool(q) and float(q[-1])>=.001
    return {'passed':all(bool(x) for x in checks.values()),'checks':{k:bool(x) for k,x in checks.items()},'time_s':data['time_s'],'step':step,'interfaces_error_m':wet,'minimum_water_volume_m3':volumes,'minimum_structural_J':J,'body_stations':stations,'non_affine_body_bending_peak_m':float(np.abs(res).max()),'residuals':last,'minimum_orthogonal_quality':float(q[-1]) if q else None}
