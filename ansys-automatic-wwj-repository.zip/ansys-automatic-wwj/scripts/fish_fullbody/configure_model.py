assert set(s.setup.cell_zone_conditions.solid.get_object_names())=={'stiff_body','soft_tail'}
s.setup.models.structure.expert.include_pop_in_fsi_force=False
s.setup.models.structure.expert.include_viscous_fsi_force=True
s.setup.models.structure.controls.unsteady_damping_rayleigh='Backward Euler'
s.setup.models.structure.controls.amg_stabilization='bcgstab'
s.setup.models.structure.controls.max_iter=500
s.setup.models.structure.controls.numerical_damping_factor=0.
s.setup.models.structure.controls.enhanced_strain=False
s.setup.models.structure.expert.explicit_fsi_force=False
for zone,E in [('stiff_body',2e5),('soft_tail',2e6)]:
    name='active-'+zone
    s.setup.materials.solid.create(name=name)
    m=s.setup.materials.solid[name]
    m.density.value=1000.;m.struct_youngs_modulus.value=E;m.struct_poisson_ratio.value=.35
    s.setup.cell_zone_conditions.solid[zone].general.material=name
s.setup.materials.fluid.create(name='water-demo')
w=s.setup.materials.fluid['water-demo'];w.density.value=1000.;w.viscosity.value=.001
s.setup.cell_zone_conditions.fluid['water'].general.material='water-demo'
inlet=s.setup.boundary_conditions.velocity_inlet['inlet'].momentum
inlet.velocity_specification_method='Components'
for i,v in enumerate([.05,0,0]):inlet.velocity_components[i].value=v
s.setup.boundary_conditions.pressure_outlet['outlet'].momentum.gauge_pressure.value=0
s.setup.general.operating_conditions.operating_pressure=0
for name in ['body_water-shadow','fish_eyes-shadow','tail_water-shadow']:
    b=s.setup.boundary_conditions.wall[name].structure
    for axis in 'xyz':getattr(b,axis+'_disp_boundary_condition').set_state('Intrinsic FSI')
b=s.setup.boundary_conditions.wall['fish_drive-shadow'].structure
for axis in 'xyz':
    getattr(b,axis+'_disp_boundary_condition').set_state('Node '+axis.upper()+'-Displacement')
    getattr(b,axis+'_disp_boundary_value').set_state({'option':'value','value':0})
dm=s.setup.dynamic_mesh
dm.methods.smoothing.method='spring';dm.methods.smoothing.spring_settings.skew_smooth_niter=0
dm.methods.smoothing.method='diffusion'
assert solver.rp_vars('smooth-mesh/niter')==0
dm.options.implicit_update={'enabled':True,'update_interval':1,'relaxation_factor':.5,'residual_criterion':1e-10}
for name in ['body_water','fish_eyes','tail_water','fish_drive','inlet','outlet','farfield']:
    before=set(dm.dynamic_zones.get_object_names());dm.dynamic_zones.create(zone=name)
    obj=dm.dynamic_zones[(set(dm.dynamic_zones.get_object_names())-before).pop()]
    obj.type='intrinsic-fsi' if name in ['body_water','fish_eyes','tail_water'] else 'stationary'
    if obj.type()=='intrinsic-fsi':obj.solver.stabilization.enabled=False
solver.chdir(OUT.as_posix())
shutil.copy2(script_dir/'fish_active.c',OUT/'fish_active.c')
s.setup.user_defined.compiled_udf(library_name='libfish_active',source_files=[(OUT/'fish_active.c').as_posix()],header_files=[],use_built_in_compiler=True)
s.setup.user_defined.load(udf_library_name='libfish_active')
source=s.setup.cell_zone_conditions.solid['stiff_body'].sources
source.enable=True

term=source.terms['y-displacement'];term.resize(size=1);term[0].option='udf'
choices=term[0].udf.allowed_values()
binding=[n for n in choices if n=='active_body_y::libfish_active'];assert len(binding)==1
term[0].udf=binding[0]
record('fullbody-setup',{'materials':s.setup.materials.solid.get_state(),'zones':s.setup.cell_zone_conditions.solid.get_state(),'walls':s.setup.boundary_conditions.wall.get_state(),'dynamic':dm.get_state()})
