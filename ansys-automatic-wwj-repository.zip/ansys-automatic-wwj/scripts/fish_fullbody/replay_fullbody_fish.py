"""Fresh GUI replay candidate for a complete elastic, actively driven fish.

--plan is read-only. A normal invocation regenerates CAD/mesh (unless an exact
mesh is supplied), initializes t=0, solves, audits, saves, and leaves Fluent open.
No cached solution is loaded. Run in an ASCII output path on Windows.
"""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time,types,uuid
from datetime import datetime

CONFIG={'dt_s':.025,'max_iterations_per_step':60,'flow_scheme':'Coupled',
        'structure_under_relaxation':1.,'structure_under_relaxation_after_first':1.,
        'structure_corrector_under_relaxation':.3,'implicit_mesh_relaxation':1.,
        'implicit_mesh_residual_criterion':1e-10,'drive_amplitude_N_m3':15000,
        'frequency_Hz':2.,'ramp_s':.15,'body_E_Pa':2e5,'tail_E_Pa':2e6,'continuity_criterion':.01}
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fluent',type=Path)
    parser.add_argument('--mesh-python',type=Path)
    parser.add_argument('--mesh',type=Path,help='Use this full water/body/tail mesh, never a case/data solution.')
    parser.add_argument('--runtime-root',type=Path)
    parser.add_argument('--steps',type=int,default=8)
    parser.add_argument('--plan',action='store_true')
    args=parser.parse_args()
    if not 1<=args.steps<=20:parser.error('--steps must be in [1,20]')
    if args.plan:
        print(json.dumps({'configuration':CONFIG,'steps':args.steps,'seconds':args.steps*.025,
            'route':['fresh refined full-body mesh','water and complete elastic fish','distributed active body force','all wet-wall intrinsic FSI','t0 initialization','per-step native solve and HDF checks','save and native playback'],
            'status':'candidate; see published validation scope','needs':['Fluent standalone 26.1 + intrinsic FSI license','PyFluent and NumPy/h5py','Gmsh interpreter unless --mesh supplied'],'gui_left_open':True},indent=2));return
    if args.fluent is None or not args.fluent.is_file():parser.error('Provide --fluent with the installed executable')
    if args.runtime_root is None or not str(args.runtime_root).isascii():parser.error('Provide --runtime-root with an ASCII path')
    if args.mesh is None and (args.mesh_python is None or not args.mesh_python.is_file()):parser.error('Provide --mesh-python for CAD/mesh regeneration')
    if args.mesh is not None and not args.mesh.is_file():parser.error('Provided mesh does not exist')
    import ansys.fluent.core as pf
    from advance_step import advance_with_structure_corrector
    from audit import audit
    script_dir=Path(__file__).resolve().parent
    OUT=args.runtime_root/('fish-fullbody-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);OUT.mkdir(parents=True,exist_ok=False)
    def record(n,v):(OUT/(n+'.json')).write_text(json.dumps(v,indent=2,default=str),encoding='utf-8')
    status={'status':'building','run_dir':str(OUT),'completed_steps':0,'steps':args.steps};record('status',status)
    shutil.copytree(script_dir,OUT/'replay',ignore=shutil.ignore_patterns('__pycache__'))
    def command(argv,log):
        with (OUT/log).open('w',encoding='utf-8') as f:subprocess.run([str(x) for x in argv],stdout=f,stderr=subprocess.STDOUT,check=True)
    if args.mesh:
        shutil.copy2(args.mesh,OUT/'fish-fullbody.msh');mesh=OUT/'fish-fullbody.msh'
    else:
        geometry=OUT/'geometry'
        command([args.mesh_python,script_dir/'generate_realistic_fish.py','--output',geometry,'--body-size','.003','--tail-size','.002','--far-size','.03','--eye-size','.001','--gill-size','.00075'],'geometry.log')
        command([sys.executable,script_dir/'split_eye_zone.py','--geometry-dir',geometry],'eye-split.log')
        mesh=geometry/'fish_refined_eyes.msh'
    record('mesh-origin',{'path':str(mesh),'sha256':hashlib.sha256(mesh.read_bytes()).hexdigest(),'cached_physics_loaded':False})
    solver=pf.launch_fluent(fluent_path=str(args.fluent),product_version='26.1.0',dimension=3,precision='double',processor_count=1,mode='solver',ui_mode='gui',py=False,cwd=str(OUT),start_timeout=120,cleanup_on_exit=False,start_watchdog=False)
    solver.tui.server.write_or_reset_grpc_server_info((OUT/'server.info').as_posix())
    s=solver.settings;solver.chdir(OUT.as_posix())
    config=dict(CONFIG);record('cycle-config',config)
    try:
        s.file.start_transcript(file_name=(OUT/'setup.trn').as_posix())
        s.file.read_mesh(file_name=mesh.as_posix())
        s.setup.general.solver.time='unsteady-1st-order';s.setup.models.viscous.model='laminar'
        s.setup.models.energy.enabled=False;s.setup.models.structure.model='nonlinear-elasticity';s.setup.dynamic_mesh.enabled=True
        ns={'solver':solver,'s':s,'OUT':OUT,'run_dir':OUT.as_posix(),'replay_settings':config,'record':record,'save':record,'Path':Path,'json':json,'shutil':shutil,'script_dir':script_dir}
        for phase in ['configure_model.py','initialize.py','configure_display.py']:
            ns['__file__']=str(script_dir/phase);exec(compile((script_dir/phase).read_text('utf-8'),str(script_dir/phase),'exec'),ns)
        # Full mesh update is essential at shared wet-wall seams. A partly
        # relaxed shared node next to fully moved FE nodes can invert a thin tet.
        s.setup.dynamic_mesh.options.implicit_update.relaxation_factor=config['implicit_mesh_relaxation']
        s.file.write_case_data(file_name=(OUT/'initial.cas.h5').as_posix());s.file.stop_transcript()
        h=types.SimpleNamespace(solver=solver,settings=config,record=record)
        status['status']='solving';record('status',status)
        for step in range(1,args.steps+1):
            started=time.monotonic();s.file.start_transcript(file_name=(OUT/f'step-{step:04d}.trn').as_posix())
            s.solution.controls.under_relaxation['structure']=1.
            s.solution.monitor.residual.equations['continuity'].absolute_criteria=.005 if step<=3 else config['continuity_criterion']
            if step>=5:
                s.solution.methods.spatial_discretization.discretization_scheme['mom']='first-order-upwind'
                config['max_iterations_per_step']=100
                config['momentum_scheme']='first-order-upwind'
                record('cycle-config',config)
            events=advance_with_structure_corrector(h,step)
            s.mesh.check();s.mesh.quality()
            s.file.write_case_data(file_name=(OUT/f'step-{step:04d}.cas.h5').as_posix())
            reports=s.solution.report_definitions.compute(report_defs=['body-y','body-max','tail-y','tail-max','mass-inlet','mass-outlet'])
            s.results.graphics.contour['fullbody-displacement'].display();s.file.stop_transcript()
            record(f'step-{step:04d}-summary',{'elapsed_s':time.monotonic()-started,'reports':reports,'event_validation':events['validation']})
            result=audit(OUT,step);record(f'step-{step:04d}-audit',result)
            if not events['validation']['passed'] or not result['passed']:raise RuntimeError(f'Step {step} failed; native evidence saved')
            from mass_check import check_mass
            mass=check_mass(OUT,step);record(f'mass-{step:04d}',mass)
            if not mass['passed']:raise RuntimeError(f'Step {step} moving-volume mass balance failed')
            status.update(completed_steps=step,time_s=step*.025,last_step_elapsed_s=time.monotonic()-started);record('status',status)
            print(json.dumps(status),flush=True)
            if (OUT/'STOP_AFTER_STEP').exists():
                status['status']='stopped-at-requested-boundary';record('status',status);return
        s.file.write_case_data(file_name=(OUT/'fish-final.cas.h5').as_posix())
        from present_results import present
        from render_uniform import render
        animation=render(solver,OUT,args.steps)
        present(solver,OUT,args.steps,animation)
        status['status']='complete';record('status',status)
        print(str(OUT),flush=True)
    except BaseException as e:
        status.update(status='stopped',error=type(e).__name__+': '+str(e));record('status',status);raise

if __name__=='__main__':main()
