"""Revalidate native checkpoints including changed fluid connectivity."""
from pathlib import Path
import json,csv
from audit_remesh import audit

def summarize(root,steps):
    dt=float(json.loads((root/'cycle-config.json').read_text('utf-8'))['dt_s'])
    audits=[];rows=[]
    for i in range(1,steps+1):
        a=audit(root,i);assert a['passed'],(i,a);audits.append(a)
        r={k:v[0] for x in json.loads((root/f'step-{i:04d}-summary.json').read_text('utf-8'))['reports'] for k,v in x.items()}
        rows.append(dict(step=i,time_s=a['time_s'],body_max_mm=1000*r['body-max'],tail_max_mm=1000*r['tail-max'],body_mean_y_mm=1000*r['body-y'],tail_mean_y_mm=1000*r['tail-y'],body_bending_mm=1000*a['non_affine_body_bending_peak_m'],relative_ALE_mass_error=a['relative_ALE_mass_error'],native_min_orthogonal_quality=a['minimum_orthogonal_quality'],water_cells=a['cell_counts']['water']))
    with (root/'fullbody-motion.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    proof=dict(passed=True,accepted_steps=steps,time_s=steps*dt,
        max_body_surface_displacement_mm=max(r['body_max_mm'] for r in rows),
        max_tail_surface_displacement_mm=max(r['tail_max_mm'] for r in rows),
        max_body_bending_after_affine_removal_mm=max(r['body_bending_mm'] for r in rows),
        bending_peak_step=max(rows,key=lambda r:r['body_bending_mm'])['step'],
        minimum_native_orthogonal_quality=min(a['minimum_orthogonal_quality'] for a in audits),
        max_relative_ALE_mass_error=max(a['relative_ALE_mass_error'] for a in audits),
        max_interface_error_m=max(v for a in audits for v in a['interfaces_error_m'].values()),
        all_step_audits=audits,
        limitation='Teaching transient; tethered head, surrogate active drive. Periodicity requires separate loop check; not free swimming or quantitatively validated.')
    (root/'fullbody-validation.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    return proof

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--steps',type=int,required=True);a=p.parse_args()
    print(json.dumps({k:v for k,v in summarize(a.root,a.steps).items() if k!='all_step_audits'},indent=2))
