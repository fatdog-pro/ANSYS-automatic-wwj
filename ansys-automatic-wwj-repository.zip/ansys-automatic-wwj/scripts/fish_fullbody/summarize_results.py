"""Offline aggregate of accepted full-body checkpoints and mass conservation."""
from pathlib import Path
import csv,json
import numpy as np
import native_fields as m
from audit import audit
from advance_step import check_structure_corrector_record

def summarize(root,steps):
    reference=m.read_case(root/'initial.cas.h5')
    wz=reference['zones']['cells']['water'];ids=np.arange(wz['minId']-1,wz['maxId']);tet=reference['tet'][ids]
    d0=np.linalg.det(m.matrices(reference['xyz'],tet));orientation=np.sign(d0)
    previous_volume=float(np.abs(d0).sum()/6)
    audits=[];rows=[];events=[]
    config=json.loads((root/'cycle-config.json').read_text('utf-8'))
    for step in range(1,steps+1):
        result=audit(root,step);audits.append(result)
        event=check_structure_corrector_record(json.loads((root/f'structure-corrector-{step:04d}.json').read_text('utf-8')),step,config)
        events.append(event)
        if not event['passed']:raise RuntimeError(f'Saved callback evidence {step} failed')
        if not result['passed']:raise RuntimeError(f'Saved checkpoint {step} failed')
        saved=json.loads((root/f'step-{step:04d}-summary.json').read_text('utf-8'))
        reports={k:v[0] for item in saved['reports'] for k,v in item.items()}
        case=m.read_case(root/f'step-{step:04d}.cas.h5')
        volume=float((np.linalg.det(m.matrices(case['xyz'],tet))*orientation/6).sum())
        net=reports['mass-inlet']+reports['mass-outlet'];storage=1000*(volume-previous_volume)/.025
        row={'step':step,'time_s':result['time_s'],'body_max_mm':reports['body-max']*1000,'tail_max_mm':reports['tail-max']*1000,'body_mean_y_mm':reports['body-y']*1000,'tail_mean_y_mm':reports['tail-y']*1000,'body_bending_mm':result['non_affine_body_bending_peak_m']*1000,'fluid_volume_m3':volume,'net_inflow_kg_s':net,'rho_dVdt_kg_s':storage,'relative_ALE_mass_error':abs(storage-net)/abs(reports['mass-inlet']),'native_min_orthogonal_quality':result['minimum_orthogonal_quality']}
        for station in result['body_stations']:row[f"body_at_x{round(station['x_m']*1000):03d}mm_y_mm"]=station['mean_y_displacement_m']*1000
        rows.append(row);previous_volume=volume
    with (root/'fullbody-motion.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    proof={'passed':all(r['passed'] for r in audits) and all(e['passed'] for e in events) and all(np.isfinite(r['relative_ALE_mass_error']) and r['relative_ALE_mass_error']<.001 for r in rows),'accepted_steps':steps,'time_s':steps*.025,
        'max_body_surface_displacement_mm':max(r['body_max_mm'] for r in rows),
        'max_tail_surface_displacement_mm':max(r['tail_max_mm'] for r in rows),
        'max_body_bending_after_affine_removal_mm':max(r['body_bending_mm'] for r in rows),
        'body_peak_step':max(rows,key=lambda r:r['body_max_mm'])['step'],
        'bending_peak_step':max(rows,key=lambda r:r['body_bending_mm'])['step'],
        'max_relative_ALE_mass_error':max(r['relative_ALE_mass_error'] for r in rows),
        'minimum_native_orthogonal_quality':min(r['native_min_orthogonal_quality'] for r in rows),
        'max_interface_error_m':max(x for r in audits for x in r['interfaces_error_m'].values()),
        'fullbody_bending_observed':max(r['body_bending_mm'] for r in rows)>.1,
        'limitation':'Teaching transient startup, tethered anterior tip, surrogate active force; not free swimming, not periodic/mesh-independent/experimentally validated.',
        'all_step_audits':audits,'all_event_schedules_passed':all(e['passed'] for e in events),'all_mass_checks_passed':all(r['relative_ALE_mass_error']<.001 for r in rows)}
    (root/'fullbody-validation.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    return proof

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--steps',type=int,required=True);a=p.parse_args()
    result=summarize(a.root,a.steps);print(json.dumps({k:v for k,v in result.items() if k!='all_step_audits'},indent=2))
