s.solution.methods.spatial_discretization.gradient_scheme='least-square-cell-based'
s.solution.methods.spatial_discretization.discretization_scheme['mom']='second-order-upwind'
s.solution.methods.spatial_discretization.discretization_scheme['pressure']='second-order'
s.solution.methods.high_order_term_relaxation.enable=False
s.solution.controls.p_v_controls.flow_courant_number=50
s.solution.controls.p_v_controls.explicit_pressure_under_relaxation=.75
s.solution.controls.p_v_controls.explicit_momentum_under_relaxation=.75
s.solution.controls.advanced.multi_grid.mg_controls['pressure-coupled'].termination_criteria=.001
s.solution.controls.advanced.multi_grid.amg_controls.coupled_parameters.fixed_cycle_parameters.max_cycle=30
for n in s.solution.monitor.residual.equations.get_object_names():s.solution.monitor.residual.equations[n].absolute_criteria=.005 if n=='continuity' else 1e-4
g=s.results.graphics
g.contour.create(name='fullbody-displacement');c=g.contour['fullbody-displacement']
c.field='total-displacement';c.surfaces_list=['body_water-shadow','fish_eyes-shadow','tail_water-shadow','fish_drive-shadow']
c.options.filled=True;c.options.node_values=True
assert c.deformation() is False
c.range_options.auto_range=False;c.range_options.minimum=0.;c.range_options.maximum=.01
c.display()
g.views.camera.position=[.1,-.10,.45];g.views.camera.target=[.1,0,0];g.views.camera.up_vector=[0,1,0];g.views.camera.field=[.27,.18]
g.views.save_view(view_name='fullbody-top-oblique')
animations=s.solution.calculation_activity.solution_animations
(OUT/'animations').mkdir(exist_ok=True)
animations.create(name='fullbody-swim',storage_dir=(OUT/'animations').as_posix(),animate_on='fullbody-displacement')
a=animations['fullbody-swim'];a.frequency_of='time-step';a.frequency=1;a.storage_type='hsf';a.window_id=1;a.view='fullbody-top-oblique'
rd=s.solution.report_definitions
report_names=[]
for name,surface,field,kind in [('body-y','body_water-shadow','y-displacement','surface-vertexavg'),('body-max','body_water-shadow','total-displacement','surface-vertexmax'),('tail-y','tail_water-shadow','y-displacement','surface-vertexavg'),('tail-max','tail_water-shadow','total-displacement','surface-vertexmax')]:
    rd.surface.create(name=name);r=rd.surface[name];r.report_type=kind;r.surface_names=[surface];r.field=field;report_names.append(name)
for name,zone in [('mass-inlet','inlet'),('mass-outlet','outlet')]:
    rd.surface.create(name=name);r=rd.surface[name];r.report_type='surface-massflowrate';r.surface_names=[zone];report_names.append(name)
