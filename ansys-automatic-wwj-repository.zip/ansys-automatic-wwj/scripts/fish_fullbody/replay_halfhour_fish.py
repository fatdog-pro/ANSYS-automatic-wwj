"""Fresh full-body fish replay targeting a 30-minute teaching demonstration."""
from pathlib import Path
from datetime import datetime
import argparse, json, subprocess, sys, time, uuid

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--fluent', type=Path)
    p.add_argument('--mesh-python', type=Path)
    p.add_argument('--runtime-root', type=Path)
    p.add_argument('--budget', type=float, default=1800)
    p.add_argument('--ffmpeg', type=Path, help='Optional encoder path; otherwise discover under Ansys or PATH')
    p.add_argument('--plan', action='store_true')
    a = p.parse_args()
    if a.plan:
        print(json.dumps({'route': 'fresh geometry, mesh, t=0 FSI, audits, native reopen, GIF/MP4, result plots and summary',
            'dt_s': .025, 'steps': 28, 'physical_time_s': .70, 'budget_s': a.budget,
            'delivery_outputs': ['Case/Data', 'HSF', 'GIF', 'MP4', 'displacement PNG', 'pressure PNG', 'curves PNG', 'CSV', 'JSON', 'results.md'],
            'cached_physics_loaded': False, 'loop_guaranteed': False,
            'scope': 'Coarse teaching transient, not engineering validation'}, indent=2))
        return
    if not a.fluent or not a.fluent.is_file(): p.error('Provide the installed --fluent executable')
    if not a.mesh_python or not a.mesh_python.is_file(): p.error('Provide --mesh-python with Gmsh and NumPy')
    if not a.runtime_root or not str(a.runtime_root).isascii(): p.error('Provide an ASCII --runtime-root')
    if a.budget < 500: p.error('Budget must allow setup, a safe checkpoint and media export')
    from export_deliverables import preflight
    media = preflight(a.fluent, a.ffmpeg)
    here = Path(__file__).resolve().parent
    root = a.runtime_root / ('fish-halfhour-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    root.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    def phase(name, python, script, args):
        print('PHASE', name, str(root), flush=True)
        with (root / (name + '.log')).open('w', encoding='utf-8') as log:
            subprocess.run([str(python), '-u', str(here/script), *map(str,args)], stdout=log, stderr=subprocess.STDOUT, check=True)
    result = {'status': 'running', 'cached_physics_loaded': False, 'budget_s': a.budget,
              'delivery_status':'pending', 'media_preflight':media}
    solve_validated = False
    try:
        phase('geometry', a.mesh_python, 'generate_realistic_fish.py', [
            '--output',root/'geometry','--lightweight','--body-size',.004,'--tail-size',.0025,'--far-size',.035,
            '--eye-size',.0015,'--gill-size',0,'--opt-iterations',10,'--max-cells',40000])
        phase('eye-zone',sys.executable,'split_eye_zone.py',['--geometry-dir',root/'geometry'])
        mesh_elapsed = time.monotonic()-started
        result['geometry_and_split_elapsed_s'] = mesh_elapsed
        phase('solve',sys.executable,'run_halfhour.py',[
            '--mesh',root/'geometry'/'fish_refined_eyes.msh','--out',root/'solution',
            '--fluent',a.fluent,'--helper-dir',here,'--steps',28,'--dt',.025,'--corrector',.5,
            '--budget',a.budget-mesh_elapsed-120])
        status=json.loads((root/'solution'/'status.json').read_text('utf-8'))
        assert status['status']=='validated-complete'
        solve_validated = True
        result['native_validation_elapsed_s'] = time.monotonic()-started
        phase('delivery',sys.executable,'export_deliverables.py',[
            '--root',root/'solution','--server-info',root/'solution'/'server.info',
            '--ffmpeg',media['ffmpeg'],'--out',root/'solution'/'deliverables'])
        delivery = json.loads((root/'solution'/'deliverables'/'delivery.json').read_text('utf-8'))
        assert delivery['passed'] and delivery['status']=='complete'
        result.update(status='validated-complete',solution=str(root/'solution'),
                      delivery_status='complete',deliverables=str(root/'solution'/'deliverables'),
                      delivery_elapsed_s=delivery['elapsed_s'],
                      elapsed_s=time.monotonic()-started,within_budget=time.monotonic()-started<=a.budget,
                      physical_loop_verified=status['native_presentation']['physical_loop_verified'])
    except BaseException as exc:
        result.update(status='solve-validated-delivery-failed' if solve_validated else 'stopped',
                      delivery_status='failed' if solve_validated else 'not-started',
                      elapsed_s=time.monotonic()-started,error=type(exc).__name__+': '+str(exc))
        raise
    finally:
        (root/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__': main()
