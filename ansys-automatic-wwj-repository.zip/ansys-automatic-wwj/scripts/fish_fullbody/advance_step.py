import math
import time
def check_structure_corrector_record(value, step, settings):
    """Recompute the event schedule contract; this is not a convergence check.

    Fluent can emit one old-index event when a new time level opens. It must
    precede new iterations and leave the predictor unchanged. Only the first
    genuinely new IterationEnded event may write the corrector URF.
    """
    checks, failures = {}, []
    def close(actual, expected, tolerance=1e-12):
        return (not isinstance(actual, bool) and isinstance(actual, (int, float))
                and math.isfinite(actual) and math.isclose(actual, expected, rel_tol=0, abs_tol=tolerance))
    def integer(value):
        return isinstance(value, int) and not isinstance(value, bool)
    try:
        predictor = settings['structure_under_relaxation'] if step == 1 else settings['structure_under_relaxation_after_first']
        corrector, dt = settings['structure_corrector_under_relaxation'], settings['dt_s']
        start, end = value.get('starting_iteration'), value.get('ending_iteration')
        rows = value.get('events', [])
        checks = {
            'enabled_and_identified': corrector is not None and value.get('enabled') is True and value.get('step') == step,
            'declared_schedule_matches': close(value.get('predictor_urf'), predictor) and close(value.get('corrector_urf'), corrector),
            'registered_and_unregistered': value.get('registered') is True and value.get('unregistered') is True,
            'one_native_physical_step_call': value.get('native_call_count') == 1 and value.get('native_call_returned') is True,
            'no_runtime_or_callback_errors': value.get('errors') == [],
            'start_end_iteration_valid': integer(start) and integer(end) and start >= 0 and 1 <= end-start <= settings['max_iterations_per_step'],
            'start_end_time_valid': close(value.get('flow_time_before_s'), (step-1)*dt, max(1e-10,dt*1e-7)) and close(value.get('flow_time_after_s'),step*dt,max(1e-10,dt*1e-7)),
            'start_end_urf_valid': close(value.get('urf_before'), predictor) and close(value.get('urf_after'),corrector),
            'nonempty_session_identity': isinstance(value.get('expected_session_id'), str) and bool(value.get('expected_session_id')),
            'events_are_nonempty_list': isinstance(rows, list) and bool(rows),
        }
        new_count, carryover_count = 0, 0
        for position, row in enumerate(rows, 1):
            index = row.get('native_iteration')
            is_carryover = row.get('event_kind') == 'time_level_carryover'
            expected_pre = predictor if new_count == 0 else corrector
            row_checks = {
                'position': row.get('callback_count') == position,
                'step': row.get('step') == step,
                'identity': row.get('session_id') == value.get('expected_session_id'),
                'index_types_and_agreement': integer(index) and integer(row.get('event_index')) and row.get('event_index') == index,
                'new_time_level': close(row.get('flow_time_s'),step*dt,max(1e-10,dt*1e-7)),
                'no_error': row.get('error') is None,
                'urf_before': close(row.get('urf_before'),expected_pre),
            }
            if is_carryover:
                row_checks.update(carryover_only_once_at_start=position == 1 and carryover_count == 0 and new_count == 0 and index == start,
                                  no_setter=row.get('setter_attempted') is False,
                                  predictor_unchanged=close(row.get('urf_after'),predictor))
                carryover_count += 1
            else:
                row_checks.update(new_iteration_kind=row.get('event_kind') == 'new_iteration',
                                  contiguous_new_index=index == start + new_count + 1,
                                  first_new_only_setter=row.get('setter_attempted') is (new_count == 0),
                                  corrector_readback=close(row.get('urf_after'),corrector))
                new_count += 1
            if not all(row_checks.values()):
                failures.append({'callback_count': position, 'checks': row_checks})
        checks.update(all_event_checks_passed=not failures,
                      all_new_iterations_observed=integer(start) and integer(end) and new_count == end-start,
                      carryover_count_valid=carryover_count <= 1,
                      declared_counts_match=value.get('new_iteration_count') == new_count and value.get('carryover_count') == carryover_count)
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError) as error:
        checks['record_is_well_formed'] = False
        failures.append({'error': type(error).__name__ + ': ' + str(error)})
    return {'passed': bool(checks) and all(item is True for item in checks.values()),
            'checks': checks, 'failures': failures,
            'scope': 'Iteration scheduling only; original residual, native convergence, mesh and interface checks remain separately required.'}

def advance_with_structure_corrector(self, step):
        """One native step with official synchronous IterationEnded auto-pause.

        Callback errors are preserved, then fail the step after its checkpoint.
        The bounded native call finishes; no unverified interrupt/resume RPC or
        extra iterate call is issued from a callback.
        """
        import ansys.fluent.core as pyfluent
        urf = self.solver.settings.solution.controls.under_relaxation['structure']
        flow_time = self.solver.settings.solution.run_calculation.transient_controls.flow_time
        scheme_eval = self.solver.scheme.eval
        predictor = self.settings['structure_under_relaxation'] if step == 1 else self.settings['structure_under_relaxation_after_first']
        corrector = self.settings['structure_corrector_under_relaxation']
        evidence = {'schema_version': 1, 'enabled': True, 'step': step,
                    'predictor_urf': predictor, 'corrector_urf': corrector,
                    'expected_session_id': self.solver.id,
                    'starting_iteration': int(scheme_eval('(get-current-iteration)')),
                    'flow_time_before_s': float(flow_time.get_state()), 'urf_before': float(urf.get_state()),
                    'registered': False, 'unregistered': False, 'native_call_count': 0,
                    'native_call_returned': False, 'events': [], 'errors': [],
                    'new_iteration_count': 0, 'carryover_count': 0}
        callback_id = None
        def on_iteration_ended(session, event_info):
            callback_start = time.monotonic()
            row = {'callback_count': len(evidence['events']) + 1, 'step': step,
                   'event_kind': 'unclassified', 'setter_attempted': False, 'error': None}
            try:
                if evidence['errors']:
                    raise RuntimeError('Earlier callback failed; refuse further structure setters.')
                row.update(session_id=session.id, event_index=int(event_info.index),
                           native_iteration=int(scheme_eval('(get-current-iteration)')),
                           flow_time_s=float(flow_time.get_state()), urf_before=float(urf.get_state()))
                if row['session_id'] != evidence['expected_session_id']:
                    raise RuntimeError('Callback public session identity mismatch.')
                index = row['native_iteration']
                if row['event_index'] != index:
                    raise RuntimeError('Event index differs from native iteration.')
                if not math.isclose(row['flow_time_s'],step*self.settings['dt_s'],rel_tol=0,abs_tol=max(1e-10,self.settings['dt_s']*1e-7)):
                    raise RuntimeError('Callback is not in the requested physical time level.')
                if index == evidence['starting_iteration']:
                    row['event_kind'] = 'time_level_carryover'
                    if evidence['events'] or evidence['carryover_count']:
                        raise RuntimeError('Repeated or out-of-order time-level carryover event.')
                    evidence['carryover_count'] += 1
                    expected_pre = predictor
                else:
                    row['event_kind'] = 'new_iteration'
                    if index != evidence['starting_iteration'] + evidence['new_iteration_count'] + 1:
                        raise RuntimeError('Missing, repeated or out-of-order new iteration event.')
                    expected_pre = predictor if evidence['new_iteration_count'] == 0 else corrector
                if not math.isclose(row['urf_before'],expected_pre,rel_tol=0,abs_tol=1e-12):
                    raise RuntimeError('Unexpected structure URF before callback.')
                if row['event_kind'] == 'new_iteration':
                    if evidence['new_iteration_count'] == 0:
                        row['setter_attempted'] = True
                        urf.set_state(corrector)
                    evidence['new_iteration_count'] += 1
                row['urf_after'] = float(urf.get_state())
                expected_post = predictor if row['event_kind'] == 'time_level_carryover' else corrector
                if not math.isclose(row['urf_after'],expected_post,rel_tol=0,abs_tol=1e-12):
                    raise RuntimeError('Structure URF readback mismatch after callback.')
            except BaseException as error:
                row['error'] = type(error).__name__ + ': ' + str(error)
                evidence['errors'].append({'phase': 'callback', 'callback_count': row['callback_count'], 'error': row['error']})
            finally:
                row['callback_wall_s'] = time.monotonic() - callback_start
                evidence['events'].append(row)
                try:
                    self.record(f'structure-corrector-{step:04d}',evidence)
                except BaseException as error:
                    evidence['errors'].append({'phase': 'record_callback', 'error': type(error).__name__ + ': ' + str(error)})
                # Official event manager resumes automatically after this returns.
        try:
            if not math.isclose(evidence['urf_before'],predictor,rel_tol=0,abs_tol=1e-12):
                raise RuntimeError('Predictor URF was not applied before callback registration.')
            callback_id = self.solver.events.register_callback(pyfluent.SolverEvent.ITERATION_ENDED,on_iteration_ended)
            evidence['registered'] = True
            evidence['native_call_count'] += 1
            self.solver.settings.solution.run_calculation.dual_time_iterate(
                time_step_count=1,max_iter_per_step=self.settings['max_iterations_per_step'])
            evidence['native_call_returned'] = True
        except Exception as error:
            evidence['errors'].append({'phase': 'native_step_or_registration', 'error': type(error).__name__ + ': ' + str(error)})
        finally:
            if callback_id is not None:
                try:
                    self.solver.events.unregister_callback(callback_id)
                    evidence['unregistered'] = True
                except Exception as error:
                    evidence['errors'].append({'phase': 'unregister', 'error': type(error).__name__ + ': ' + str(error)})
            try:
                evidence.update(ending_iteration=int(scheme_eval('(get-current-iteration)')),
                                flow_time_after_s=float(flow_time.get_state()),urf_after=float(urf.get_state()))
            except Exception as error:
                evidence['errors'].append({'phase': 'final_readback', 'error': type(error).__name__ + ': ' + str(error)})
            evidence['validation'] = check_structure_corrector_record(evidence,step,self.settings)
            self.record(f'structure-corrector-{step:04d}',evidence)
        return evidence
