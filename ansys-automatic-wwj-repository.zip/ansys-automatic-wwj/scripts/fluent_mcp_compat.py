"""Official Fluent MCP with the public py=False launch default for this PC.

Fluent 2026 R1 embedded Python console fails to decode the Chinese host name.
Keep the supported external gRPC settings API and disable only that console.
No installed Ansys or MCP source files are changed.
"""
from functools import wraps
import ansys.fluent.core as pyfluent

_launch = pyfluent.launch_fluent


@wraps(_launch)
def launch_without_embedded_console(*args, **kwargs):
    kwargs.setdefault('py', False)
    return _launch(*args, **kwargs)


pyfluent.launch_fluent = launch_without_embedded_console

from ansys.fluent.mcp.__main__ import launcher

if __name__ == '__main__':
    launcher()
