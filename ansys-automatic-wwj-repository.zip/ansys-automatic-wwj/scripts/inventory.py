"""Read-only Ansys file/package inventory. Never launches a solver or checks out a license."""
from __future__ import annotations
import argparse
import fnmatch
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def load_config(path=None):
    path = path or os.environ.get('ANSYS_UNIFIED_CONFIG') or ROOT / 'assets/runtime.local.json'
    config = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    if config.get('schema_version') != 1:
        raise ValueError('Unsupported runtime configuration version')
    return config


def load_registry():
    return json.loads((ROOT / 'assets/products.json').read_text(encoding='utf-8-sig'))['products']


def get_product(product_id):
    key = product_id.strip().casefold()
    hits = [p for p in load_registry() if key in [p['id'].casefold(), p['label'].casefold()] + [a.casefold() for a in p.get('aliases', [])]]
    if len(hits) != 1:
        raise ValueError('Unknown or ambiguous product: ' + product_id)
    return hits[0]


def _metadata(python, package):
    # Read distribution metadata, without importing the SDK or starting its application.
    code = 'import importlib.metadata as m,json,sys; print(json.dumps({"version":m.version(sys.argv[1])}))'
    env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    kwargs = {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}
    try:
        result = subprocess.run([python, '-c', code, package], capture_output=True,
                                text=True, encoding='utf-8', timeout=20, env=env, **kwargs)
        if result.returncode == 0:
            return {'status': 'installed_metadata', **json.loads(result.stdout)}
        if 'PackageNotFoundError' in result.stderr:
            return {'status': 'missing'}
        return {'status': 'unknown', 'reason': 'Metadata probe failed', 'returncode': result.returncode}
    except (OSError, subprocess.TimeoutExpired, ValueError) as exc:
        return {'status': 'unknown', 'reason': type(exc).__name__}


def _indexed_candidates(root):
    found = []
    for folder, _, names in os.walk(root):
        for name in names:
            if name.lower().endswith(('.exe', '.com', '.bat')):
                file = Path(folder) / name
                found.append((file.relative_to(root).as_posix().casefold(), file))
    return found


def inspect_product(product_id, config=None, _scan_cache=None, _metadata_cache=None):
    config = config or load_config()
    product = get_product(product_id)
    candidates = []
    for root in config.get('ansys_roots', []):
        directory = Path(root)
        if not directory.is_dir():
            continue
        for pattern in product.get('executable_globs', []):
            # Patterns come from this shipped registry, never from a tool caller.
            if '**' in pattern and _scan_cache is not None:
                key = str(directory)
                if key not in _scan_cache:
                    _scan_cache[key] = _indexed_candidates(directory)
                lower = pattern.casefold()
                # '**/' also matches zero intermediate directories.
                patterns = [lower, lower.replace('**/', '')]
                matches = [file for relative, file in _scan_cache[key]
                           if any(fnmatch.fnmatchcase(relative, item) for item in patterns)]
            else:
                matches = directory.glob(pattern)
            for file in matches:
                if file.is_file():
                    candidates.append(str(file.resolve()))
                    if len(candidates) >= 20:
                        break
            if len(candidates) >= 20:
                break
    python = config.get('python_runtimes', {}).get(product.get('runtime', 'general'))
    runtime_exists = bool(python and Path(python).is_file())
    sdk = {'status': 'not_applicable', 'python': python,
           'package': product.get('python_package'), 'import_name': product.get('python_import'),
           'import_tested': False}
    if product.get('python_package') and runtime_exists:
        key = (python, product['python_package'])
        if _metadata_cache is None:
            meta = _metadata(*key)
        else:
            if key not in _metadata_cache:
                _metadata_cache[key] = _metadata(*key)
            meta = _metadata_cache[key]
        sdk.update(meta)
    elif product.get('execution_kind') in ('bundled_python_api', 'local_python_adapter'):
        paths = config.get('bundled_api_paths', {}).get(product['id'], [])
        sdk['status'] = 'configured_unverified' if paths and all(Path(p).is_dir() for p in paths) else 'missing'
        sdk['api_paths'] = paths
    student_block = product.get('student_api_blocked', False) and config.get('edition', '').casefold() == 'student'
    if student_block:
        status, reason = 'blocked_student_api', 'This Student product explicitly disables its programming API.'
    elif product.get('execution_kind') == 'adapter_required':
        status, reason = 'blocked_no_python_route', 'Use the documented official product route; an execution adapter must be prepared first.'
    elif not runtime_exists:
        status, reason = 'blocked_missing_runtime', 'Configure an existing compatible Python runtime.'
    elif sdk['status'] not in ('installed_metadata', 'configured_unverified'):
        status, reason = 'blocked_missing_sdk', 'Install the exact official SDK or configure the bundled API; then test its import.'
    else:
        status, reason = 'eligible_for_script', 'Runner prerequisite only. SDK import, application connection and license are not verified.'
    return {
        'product_id': product['id'], 'label': product['label'],
        'installation': {'status': 'candidate_files_found' if candidates else 'not_found_in_configured_roots',
                         'executables': sorted(set(candidates)), 'search_scope': config.get('ansys_roots', [])},
        'sdk': sdk,
        'license': {'status': 'unsupported_student_api' if student_block else 'unknown_not_checked',
                    'edition_hint': config.get('edition', 'unknown')},
        'execution': {'status': status, 'reason': reason},
        'verification': product['verification'], 'notes': product.get('notes', ''),
        'sources': product.get('sources', [])
    }


def inventory(config=None):
    config = config or load_config()
    scan_cache, metadata_cache = {}, {}
    return {'schema_version': 1, 'read_only': True, 'license_checkout_performed': False,
            'meaning': 'File candidates and package metadata only; eligible_for_script does not mean solver-ready.',
            'products': [inspect_product(p['id'], config, scan_cache, metadata_cache) for p in load_registry()]}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config')
    parser.add_argument('--product')
    parser.add_argument('--output')
    args = parser.parse_args()
    cfg = load_config(args.config)
    data = inspect_product(args.product, cfg) if args.product else inventory(cfg)
    output = json.dumps(data, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(output + '\n', encoding='utf-8')
    else:
        print(output)
