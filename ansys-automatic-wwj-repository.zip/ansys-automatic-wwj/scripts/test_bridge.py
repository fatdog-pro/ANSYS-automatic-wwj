"""Behavior tests for the bridge; never launch Ansys or touch user projects."""
from __future__ import annotations

import asyncio
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest

from bridge import Bridge, MAX_LOG_BYTES, MAX_RETURN_CHARS, build_server


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="ansys-bridge-test-")
        self.root = Path(self.temporary.name)
        self.projects = self.root / "projects"
        self.projects.mkdir()
        self.config = {"project_roots": [str(self.projects)], "python_runtimes": {"general": sys.executable}}
        self.registry = [{"id": "mechanical", "aliases": ["结构"]}, {"id": "fluent"}, {"id": "zemax"}]
        self.mode = "eligible_for_script"

        def inspect(product, config):
            canonical = "mechanical" if product == "结构" else product
            if canonical not in {p["id"] for p in self.registry}:
                raise ValueError("Unknown product")
            mode = "blocked_student_api" if canonical == "zemax" else self.mode
            return {"product_id": canonical, "sdk": {"python": sys.executable, "status": "installed_metadata"}, "execution": {"status": mode, "reason": "test preflight"}, "license": {"status": "unknown"}}

        self.bridge = Bridge(self.config, inspector=inspect, inventory_fn=lambda config: {"products": []}, registry=self.registry)
        self.project = str(self.projects / "demo")

    def tearDown(self):
        # Only tiny Python helpers created by these tests; no solver APIs are called.
        for job in self.bridge.jobs.values():
            job["process"].wait(timeout=10)
        time.sleep(0.05)
        self.temporary.cleanup()

    def write(self, code="print('bridge-ok')", product="mechanical", policy="dedicated-keep-open", filename="run.py"):
        source = "# ansys-product: %s\n# ansys-session: %s\n%s\n" % (product, policy, code)
        return self.bridge.write_script(self.project, filename, source)

    def start(self, written, product="mechanical"):
        return self.bridge.start_job(product, self.project, written["relative_path"], written["sha256"])

    def wait(self, job):
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            status = self.bridge.job_status(job["job_id"])
            if status["status"] != "running":
                # Allow the pipe reader to finish flushing after helper termination.
                for _ in range(100):
                    if self.bridge.jobs[job["job_id"]]["process"].stdout.closed:
                        return status
                    time.sleep(0.01)
                return status
            time.sleep(0.02)
        self.fail("helper timeout")

    def test_success_and_durable_metadata(self):
        written = self.write("print('实际 UTF-8 日志')")
        self.assertEqual(written["status"], "written")
        job = self.start(written, product="结构")
        done = self.wait(job)
        self.assertEqual(done["exit_code"], 0)
        self.assertEqual(done["status"], "completed")
        self.assertEqual(done["solver_result"], "not_assessed")
        self.assertIn("实际 UTF-8 日志", self.bridge.read_job_log(job["job_id"])["text"])
        metadata = json.loads(Path(done["log_path"]).with_name("job.json").read_text(encoding="utf-8"))
        self.assertEqual(metadata["status"], "completed")
        self.assertNotIn("process", metadata)

    def test_failed_script_is_failed(self):
        job = self.start(self.write("raise RuntimeError('intentional bridge test')"))
        status = self.wait(job)
        self.assertEqual(status["status"], "failed")
        self.assertNotEqual(status["exit_code"], 0)
        self.assertIn("intentional bridge test", self.bridge.read_job_log(job["job_id"])["text"])

    def test_paths_cannot_escape(self):
        for relative in ["../outside.py", "sub/../../outside.py", "C:/outside.py", "run.py:other"]:
            with self.subTest(relative=relative), self.assertRaises(ValueError):
                self.bridge.write_script(self.project, relative, "print(1)")
        with self.assertRaises(ValueError):
            self.bridge.write_script(str(self.root / "outside"), "x.py", "print(1)")
        with self.assertRaises(ValueError):
            self.bridge.write_script(self.project, ".ansys-unified-jobs/x.py", "print(1)")
        with self.assertRaises(ValueError):
            self.bridge.write_script(self.project, "x.cmd", "echo no")

    def test_symlink_cannot_escape(self):
        Path(self.project).mkdir()
        outside = self.root / "outside"
        outside.mkdir()
        try:
            (Path(self.project) / "link").symlink_to(outside, target_is_directory=True)
        except OSError:
            self.skipTest("Creating directory symlinks is not permitted on this Windows account.")
        with self.assertRaises(ValueError):
            self.bridge.write_script(self.project, "link/escape.py", "print(1)")

    def test_hash_mismatch_and_overwrite_default(self):
        written = self.write()
        with self.assertRaises(FileExistsError):
            self.write("print('different')")
        Path(self.project, written["relative_path"]).write_text("print('changed')", encoding="utf-8")
        result = self.start(written)
        self.assertEqual(result["status"], "blocked_hash_mismatch")
        self.assertEqual(len(self.bridge.jobs), 0)

    def test_headers_match_canonical_product_and_session(self):
        written = self.bridge.write_script(self.project, "none.py", "print(1)")
        self.assertEqual(self.start(written)["status"], "blocked_script_header")
        written = self.write(product="fluent", filename="wrong.py")
        self.assertEqual(self.start(written)["status"], "blocked_script_header")
        written = self.write(policy="close-everything", filename="bad.py")
        self.assertEqual(self.start(written)["status"], "blocked_script_header")
        self.assertEqual(len(self.bridge.jobs), 0)

    def test_missing_sdk_and_student_api_block_before_execution(self):
        written = self.write()
        self.mode = "blocked_missing_sdk"
        self.assertEqual(self.start(written)["status"], "blocked_missing_sdk")
        zemax = self.write(product="zemax", filename="zemax.py")
        self.assertEqual(self.start(zemax, product="zemax")["status"], "blocked_student_api")
        self.assertEqual(len(self.bridge.jobs), 0)

    def test_unregistered_runtime_is_blocked(self):
        written = self.write()
        self.bridge.config = {**self.config, "python_runtimes": {}}
        self.assertEqual(self.start(written)["status"], "blocked_missing_runtime")
        self.assertEqual(len(self.bridge.jobs), 0)

    def test_bounded_logs(self):
        job = self.start(self.write("print('x' * %d); print('THE-END')" % (MAX_LOG_BYTES + 100_000)))
        self.wait(job)
        log = self.bridge.read_job_log(job["job_id"])
        self.assertLessEqual(Path(log["log_path"]).stat().st_size, MAX_LOG_BYTES)
        self.assertGreater(log["log_bytes_discarded"], 0)
        self.assertLessEqual(len(log["text"]), MAX_RETURN_CHARS)
        self.assertTrue(log["text"].endswith("THE-END"))

    def test_configured_bundled_api_path(self):
        sdk_path = self.root / "bundled-sdk"
        sdk_path.mkdir()
        (sdk_path / "bridge_test_sdk.py").write_text("VALUE = 'bundled-api-loaded'\n", encoding="utf-8")
        original = self.bridge.inspector
        def inspect(product, config):
            info = original(product, config)
            info["sdk"]["api_paths"] = [str(sdk_path)]
            return info
        self.bridge.inspector = inspect
        job = self.start(self.write("import bridge_test_sdk; print(bridge_test_sdk.VALUE)"))
        self.assertEqual(self.wait(job)["exit_code"], 0)
        self.assertIn("bundled-api-loaded", self.bridge.read_job_log(job["job_id"])["text"])

    def test_tool_discovery_and_mcp_roundtrip(self):
        async def exercise():
            from fastmcp import Client
            async with Client(build_server(self.bridge)) as client:
                tools = await client.list_tools()
                names = {tool.name for tool in tools}
                self.assertEqual(names, {"inventory", "product_info", "write_script", "start_job", "job_status", "read_job_log"})
                info = await client.call_tool("product_info", {"product_id": "结构"})
                self.assertFalse(info.is_error)
                self.assertEqual(info.data["product_id"], "mechanical")
                result = await client.call_tool("inventory", {})
                self.assertFalse(result.is_error)
        asyncio.run(exercise())


if __name__ == "__main__":
    unittest.main(verbosity=2)
