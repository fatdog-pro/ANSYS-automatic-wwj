import json, os
from System import Enum
from Ansys.ACT.Math import Vector3D
out = globals().get('WWJ_RUN_DIR')
assert out, 'Inject WWJ_RUN_DIR with the dedicated run directory before executing this stage'
graphics=ExtAPI.Graphics
graphics.Camera.UpVector=Vector3D(0,0,1)
graphics.Camera.ViewVector=Vector3D(1,-1,0.8)
graphics.Camera.SetFit()
settings=Ansys.Mechanical.Graphics.GraphicsImageExportSettings()
settings.Width=1920;settings.Height=1080
settings.CurrentGraphicsDisplay=False
settings.FontMagnification=1.2
graphics.ViewOptions.ShowMesh=False
graphics.ViewOptions.ShowLegend=True
def image(obj,name):
    obj.Activate()
    if obj != Model.Mesh:
        graphics.ViewOptions.ShowMesh=False
        rp=graphics.ViewOptions.ResultPreference
        rp.ExtraModelDisplay=Enum.Parse(rp.ExtraModelDisplay.GetType(),'NoWireframe')
        rp.ShowMinimum=False
        rp.ShowMaximum=False
    graphics.ExportImage(out+'\\'+name+'.png',GraphicsImageExportFormat.PNG,settings)
image(Model.Geometry,'01_geometry')
image(Model.Mesh,'02_mesh')
image(Model.Analyses[0],'03_boundary_conditions')
pref=graphics.ViewOptions.ResultPreference
pref.DeformationScaling=Enum.Parse(pref.DeformationScaling.GetType(),'True')
pref.DeformationScaleMultiplier=200
static=Model.Analyses[0].Solution
for name,filename in [('Static_Total_Deformation','04_static_deformation_200x'),('Static_von_Mises_Stress','05_static_stress_200x')]:
    r=[x for x in static.Children if x.Name==name][0]
    image(r,filename)
pref.DeformationScaling=Enum.Parse(pref.DeformationScaling.GetType(),'Auto')
pref.DeformationScaleMultiplier=1
graphics.ResultAnimationOptions.NumberOfFrames=60
graphics.ResultAnimationOptions.Duration=Quantity('4 [s]')
graphics.ResultAnimationOptions.UpdateContourRangeAtEachFrame=False
anim=Ansys.Mechanical.Graphics.AnimationExportSettings()
anim.Width=1920;anim.Height=1080
exports=[]
for r in Model.Analyses[1].Solution.Children:
    if not r.Name.startswith('Mode_'):continue
    stem='mode_%02d_%0.1fHz'%(int(r.Mode),float(r.ReportedFrequency.Value))
    image(r,stem)
    r.ExportAnimation(out+'\\'+stem+'.gif',GraphicsAnimationExportFormat.GIF,anim)
    exports.append({'mode':int(r.Mode),'frequency_Hz':float(r.ReportedFrequency.Value),'file':stem+'.gif'})
    with open(out+r'\animation_exports.json','w') as f:json.dump(exports,f,indent=2)
Model.Analyses[1].Solution.Children[1].Activate()
json.dumps({'animations':exports,'resolution':[1920,1080],'frames':60,'playback_seconds':4,'static_display_multiplier':200,'modal_display':'Auto, normalized mode shapes; playback slowed for illustration'})
