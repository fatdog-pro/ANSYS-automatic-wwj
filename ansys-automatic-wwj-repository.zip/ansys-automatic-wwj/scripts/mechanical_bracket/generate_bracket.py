"""Parametric single-solid robot bearing bracket, dimensions in mm."""
import argparse, json
from pathlib import Path
import gmsh

p = argparse.ArgumentParser()
p.add_argument('--out', required=True)
args = p.parse_args()
out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
gmsh.initialize()
gmsh.model.add('WWJ_Robot_Bearing_Bracket')
occ = gmsh.model.occ
base = occ.addBox(-70,-50,0,140,100,10)
parts = [(3,base)]
for y in [-34,26]:
    outline = [(-48,8),(45,8),(45,92),(30,105),(10,92),(-48,26)]
    pts = [occ.addPoint(x,y,z) for x,z in outline]
    lines = [occ.addLine(pts[i],pts[(i+1)%len(pts)]) for i in range(len(pts))]
    face = occ.addPlaneSurface([occ.addWire(lines)])
    parts += [(d,t) for d,t in occ.extrude([(2,face)],0,8,0) if d==3]
parts.append((3,occ.addCylinder(25,-38,92,0,76,0,20)))
# Two broad root ribs reduce the web/base bending concentration.
for y in [-26,18]:
    pts=[occ.addPoint(x,y,z) for x,z in [(-45,8),(35,8),(35,24)]]
    wire=occ.addWire([occ.addLine(pts[i],pts[(i+1)%3]) for i in range(3)])
    face=occ.addPlaneSurface([wire])
    parts += [(d,t) for d,t in occ.extrude([(2,face)],0,8,0) if d==3]
solid,_=occ.fuse(parts[:1],parts[1:])
holes=[]
for x in [-55,55]:
    for y in [-37,37]:
        holes.append((3,occ.addCylinder(x,y,-2,0,0,14,6)))
holes.append((3,occ.addCylinder(25,-42,92,0,84,0,12)))
# Lightening windows in both side webs, with smooth circular boundaries.
for x,z,r in [(-13,31,9),(13,53,13),(29,29,9)]:
    holes.append((3,occ.addCylinder(x,-40,z,0,80,0,r)))
solid,_=occ.cut(solid,holes)
occ.synchronize()
vols=gmsh.model.getEntities(3)
assert len(vols)==1, vols
volume=occ.getMass(*vols[0])
gmsh.option.setString('Geometry.OCCTargetUnit','MM')
gmsh.write(str(out/'robot_bracket.step'))
metadata={'model':'Lightweight robot bearing bracket','length_unit':'mm',
 'bounds_mm':[-70,70,-50,50,0,112], 'solid_count':len(vols),
 'volume_mm3':volume,'steel_mass_kg':volume*7.85e-6,
 'base_mm':[140,100,10], 'web_thickness_mm':8,
 'bearing_axis':'Y','bearing_center_xz_mm':[25,92],
 'bearing_bore_radius_mm':12,'bearing_outer_radius_mm':20,
 'mounting_holes':4,'mounting_hole_radius_mm':6,
 'idealization':'One monolithic steel body, no bolted-contact or shaft model.'}
(out/'geometry.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
print(json.dumps(metadata))
gmsh.finalize()
