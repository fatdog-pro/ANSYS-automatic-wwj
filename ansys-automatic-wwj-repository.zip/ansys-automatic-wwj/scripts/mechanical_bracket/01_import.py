import json, os
out = globals().get('WWJ_RUN_DIR')
assert out, 'Inject WWJ_RUN_DIR with the dedicated run directory before executing this stage'
assert len(Model.Geometry.GetChildren(DataModelObjectCategory.Body, True)) == 0
ExtAPI.Application.ActiveUnitSystem = MechanicalUnitSystem.StandardNMM
imp = Model.GeometryImportGroup.AddGeometryImport()
prefs = Ansys.ACT.Mechanical.Utilities.GeometryImportPreferences()
prefs.ProcessNamedSelections = True
imp.Import(out + r'\robot_bracket.step', Ansys.Mechanical.DataModel.Enums.GeometryImportPreference.Format.Automatic, prefs)
bodies = list(Model.Geometry.GetChildren(DataModelObjectCategory.Body, True))
assert len(bodies) == 1
body = bodies[0]
body.Name = 'WWJ_Lightweight_Robot_Bracket'
body.Material = 'Structural Steel'
faces = list(body.GetGeoBody().Faces)
records = [{'id':int(f.Id),'centroid':[float(v) for v in f.Centroid], 'area':float(f.Area), 'type':unicode(f.SurfaceType)} for f in faces]
Model.Geometry.Activate()
ExtAPI.Graphics.Camera.SetSpecificViewOrientation(ViewOrientationType.Iso)
ExtAPI.Graphics.Camera.SetFit()
ExtAPI.Graphics.ExportImage(out + r'\01_geometry.png', GraphicsImageExportFormat.PNG)
data = {'body':unicode(body.Name),'geo_unit':unicode(ExtAPI.DataModel.GeoData.Unit),'faces':records,
 'animation_api': [str(x) for x in dir(ExtAPI.Graphics.ResultAnimationOptions)],
 'view_api':[str(x) for x in dir(ExtAPI.Graphics.ViewOptions)]}
with open(out + r'\geometry_import.json','w') as f: json.dump(data,f,indent=2)
json.dumps(data)
