import argparse, hashlib, json
from pathlib import Path
from PIL import Image

parser=argparse.ArgumentParser()
parser.add_argument('--out',required=True)
args=parser.parse_args()
root=Path(args.out)
manifest=json.loads((root/'animation_exports.json').read_text())
assert len(manifest)==6
records=[]
for entry in manifest:
    path=root/entry['file']
    with Image.open(path) as im:
        assert im.size==(1920,1080) and im.n_frames>20
        duration=0
        hashes=[]
        for i in range(im.n_frames):
            im.seek(i)
            duration+=im.info.get('duration',0)
            # Ignore the fixed legend. Check that the result viewport changes.
            if i in [0, im.n_frames//4, im.n_frames//2, 3*im.n_frames//4]:
                hashes.append(hashlib.sha256(im.convert('RGB').crop((500,280,1480,970)).tobytes()).hexdigest())
        assert len(set(hashes))>1,'Animation is static'
        records.append({'file':path.name,'frames':im.n_frames,'size':im.size,
                        'duration_ms':duration,'sampled_viewport_changes':len(set(hashes)),
                        'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
report={'passed':True,'animations':records,
        'note':'Mechanical requested 60 animation frames; actual encoded frames/duration are recorded above.'}
(root/'animation_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
