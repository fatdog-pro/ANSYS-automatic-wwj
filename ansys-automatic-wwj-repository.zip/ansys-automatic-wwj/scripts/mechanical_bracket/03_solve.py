import json, time, math
out = globals().get('WWJ_RUN_DIR')
assert out, 'Inject WWJ_RUN_DIR with the dedicated run directory before executing this stage'
cfg=[c for c in ExtAPI.Application.SolveConfigurations if c.Default][0]
process=cfg.SolveProcessSettings
memory=process.ManualSolverMemorySettings
saved=(bool(process.DistributeSolution),bool(process.HybridParallel),int(process.MaxNumberOfCores),int(process.ThreadsPerProcess),bool(memory.Active),int(memory.Workspace),int(memory.Database))
timings=[]
try:
    process.DistributeSolution=False
    process.HybridParallel=False
    process.MaxNumberOfCores=2
    process.ThreadsPerProcess=2
    memory.Active=True
    memory.Workspace=1024
    memory.Database=128
    for analysis in Model.Analyses:
        start=time.time()
        analysis.Solution.Solve(True)
        analysis.Solution.EvaluateAllResults()
        state=unicode(analysis.Solution.Status)
        timings.append({'analysis':unicode(analysis.Name),'seconds':time.time()-start,'status':state,'working_dir':unicode(analysis.WorkingDir)})
        with open(out+r'\solve_progress.json','w') as f:json.dump(timings,f,indent=2)
        assert state=='Done', unicode(analysis.Name)+': '+state
finally:
    process.DistributeSolution=saved[0]
    process.HybridParallel=saved[1]
    process.MaxNumberOfCores=saved[2]
    process.ThreadsPerProcess=saved[3]
    memory.Workspace=saved[5]
    memory.Database=saved[6]
    memory.Active=saved[4]
def named(sol,name):return [r for r in sol.Children if r.Name==name][0]
def q(value):return {'value':float(value.Value),'quantity':unicode(value)}
ss=Model.Analyses[0].Solution
deform=named(ss,'Static_Total_Deformation')
stress=named(ss,'Static_von_Mises_Stress')
reaction=named(ss,'Mounting_Reaction_Force')
loads=[2000.,750.,-1500.]
reactions=[float(reaction.XAxis.Value),float(reaction.YAxis.Value),float(reaction.ZAxis.Value)]
error=math.sqrt(sum((a+b)**2 for a,b in zip(loads,reactions)))/math.sqrt(sum(a*a for a in loads))
modes=[{'mode':int(r.Mode),'frequency':q(r.ReportedFrequency),'name':unicode(r.Name)} for r in Model.Analyses[1].Solution.Children if r.Name.startswith('Mode_')]
assert len(modes)==6 and all(m['frequency']['value']>0 for m in modes)
assert all(modes[i+1]['frequency']['value']>=modes[i]['frequency']['value'] for i in range(5))
assert error<1e-3, 'Reaction imbalance'
assert float(deform.Maximum.Value)>0 and float(stress.Maximum.Value)>0
data={'analyses':timings,'nodes':int(Model.Mesh.Nodes),'elements':int(Model.Mesh.Elements),
 'max_static_deformation':q(deform.Maximum),'max_von_mises_stress':q(stress.Maximum),
 'applied_force_N':loads,'reaction_force_N':reactions,'relative_force_balance_error':error,
 'modes':modes,'modal_amplitude':'Normalized eigenvector, not physical vibration amplitude',
 'model':'Linear elastic single steel body, rigid base, distributed bore load, independent unprestressed modal analysis'}
deform.ExportToTextFile(out+r'\static_deformation_nodes.txt')
stress.ExportToTextFile(out+r'\static_stress_nodes.txt')
for label in ['X','Y','Z']:named(ss,'Static_'+label+'_Deformation').ExportToTextFile(out+'\\static_'+label+'_displacement_nodes.txt')
with open(out+r'\results.json','w') as f:json.dump(data,f,indent=2)
stress.Activate()
ExtAPI.Graphics.Camera.SetFit()
json.dumps(data)
