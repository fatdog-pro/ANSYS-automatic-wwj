import json, math
out = globals().get('WWJ_RUN_DIR')
assert out, 'Inject WWJ_RUN_DIR with the dedicated run directory before executing this stage'
assert len(Model.Analyses)==0
body = Model.Geometry.GetChildren(DataModelObjectCategory.Body,True)[0]
faces = list(body.GetGeoBody().Faces)
assert unicode(ExtAPI.DataModel.GeoData.Unit)=='mm'
fixed_faces = [f for f in faces if abs(float(f.Centroid[2]))<1e-5 and unicode(f.SurfaceType)=='GeoSurfacePlane']
bore_faces = [f for f in faces if unicode(f.SurfaceType)=='GeoSurfaceCylinder' and abs(float(f.Centroid[0])-25)<1e-3 and abs(float(f.Centroid[2])-92)<1e-3 and abs(float(f.Area)-2*math.pi*12*76)<5]
assert len(fixed_faces)==1 and len(bore_faces)==1
def named(name, chosen):
    ns=Model.AddNamedSelection()
    ns.Name=name
    sel=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
    sel.Ids=[int(f.Id) for f in chosen]
    ns.Location=sel
    return ns
fixed_ns=named('Rigid_Mounting_Base',fixed_faces)
bore_ns=named('Bearing_Bore_Load_Surface',bore_faces)
windows=[f for f in faces if unicode(f.SurfaceType)=='GeoSurfaceCylinder' and 20<float(f.Centroid[2])<70]
window_ns=named('Lightening_Window_Surfaces',windows)
static=Model.AddStaticStructuralAnalysis()
static.Name='01_Static_Combined_Bearing_Load'
static.AnalysisSettings.LargeDeflection=False
support=static.AddFixedSupport()
support.Name='Ideal_Rigid_Base'
support.Location=fixed_ns
load=static.AddForce()
load.Name='Bearing_Force_X2000_Y750_Zminus1500_N'
load.Location=bore_ns
load.DefineBy=LoadDefineBy.Components
for comp,val in [(load.XComponent,2000),(load.YComponent,750),(load.ZComponent,-1500)]:
    comp.Output.DiscreteValues=[Quantity(str(val)+' [N]')]
solution=static.Solution
solution.AddTotalDeformation().Name='Static_Total_Deformation'
solution.AddEquivalentStress().Name='Static_von_Mises_Stress'
for orientation,label in [(NormalOrientationType.XAxis,'X'),(NormalOrientationType.YAxis,'Y'),(NormalOrientationType.ZAxis,'Z')]:
    r=solution.AddDirectionalDeformation();r.NormalOrientation=orientation;r.Name='Static_'+label+'_Deformation'
reaction=solution.AddForceReaction()
reaction.Name='Mounting_Reaction_Force'
reaction.BoundaryConditionSelection=support
modal=Model.AddModalAnalysis()
modal.Name='02_Modal_Six_Natural_Modes'
modal.AnalysisSettings.MaximumModesToFind=6
ms=modal.AddFixedSupport();ms.Location=fixed_ns;ms.Name='Same_Ideal_Rigid_Base'
for mode in range(1,7):
    r=modal.Solution.AddTotalDeformation();r.Mode=mode;r.Name='Mode_%02d_Normalized_Shape'%mode
mesh=Model.Mesh
mesh.ElementOrder=ElementOrder.Quadratic
mesh.ElementSize=Quantity('3 [mm]')
for ns,size in [(bore_ns,2.5),(window_ns,2.5)]:
    sz=mesh.AddSizing();sz.Location=ns;sz.ElementSize=Quantity(str(size)+' [mm]')
mesh.GenerateMesh()
mesh.Activate()
ExtAPI.Graphics.Camera.SetFit()
ExtAPI.Graphics.ExportImage(out+r'\02_mesh.png',GraphicsImageExportFormat.PNG)
data={'nodes':int(mesh.Nodes),'elements':int(mesh.Elements),'element_order':unicode(mesh.ElementOrder),
 'fixed_face_ids':[int(f.Id) for f in fixed_faces],'bore_face_ids':[int(f.Id) for f in bore_faces],
 'force_N':[2000,750,-1500],'modal_prestress':False,
 'analyses':[{'name':unicode(a.Name),'state':unicode(a.ObjectState)} for a in Model.Analyses]}
assert 0<data['nodes']<90000, 'Revisit demo mesh size before solve'
with open(out+r'\setup_mesh.json','w') as f:json.dump(data,f,indent=2)
json.dumps(data)
