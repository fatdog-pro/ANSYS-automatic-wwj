import json, math
from System import Enum
out = globals().get('WWJ_RUN_DIR')
assert out, 'Inject WWJ_RUN_DIR with the dedicated run directory before executing this stage'
with open(out+r'\results.json') as f: baseline=json.load(f)
assert len(Model.Analyses)==2
for a in Model.Analyses:
    a.Solution.EvaluateAllResults()
    assert unicode(a.Solution.Status)=='Done'
ss=Model.Analyses[0].Solution
def result(name):return [r for r in ss.Children if r.Name==name][0]
d=float(result('Static_Total_Deformation').Maximum.Value)
s=float(result('Static_von_Mises_Stress').Maximum.Value)
assert abs(d-baseline['max_static_deformation']['value'])<1e-9
assert abs(s-baseline['max_von_mises_stress']['value'])<1e-6
freq=[]
for r in Model.Analyses[1].Solution.Children:
    if r.Name.startswith('Mode_'):
        val=float(r.ReportedFrequency.Value)
        assert abs(val-baseline['modes'][int(r.Mode)-1]['frequency']['value'])<1e-6
        freq.append(val)
assert len(freq)==6
# Use the Mechanical quality worksheet, independently of the solver's SHPP flag.
m=Model.Mesh
m.ComputeMeshQualityMetrics()
method=[x for x in m.GetType().GetMethods() if x.Name=='GetVolumeMeshQualityWorstMetricValue'][0]
mt=method.GetParameters()[0].ParameterType
metrics={}
for name in ['ElementQuality','AspectRatio','JacobianRatioGaussPoints','Skewness']:
    metric=Enum.Parse(mt,name)
    metrics[name]={'worst':float(m.GetVolumeMeshQualityWorstMetricValue(metric).Value),
     'failed_count':int(m.GetVolumeMeshQualityCountFailed(metric)),
     'average':float(m.GetVolumeMeshQualityAverageMetricValue(metric).Value)}
assert metrics['ElementQuality']['worst']>0
assert metrics['JacobianRatioGaussPoints']['worst']>0
assert all(v['failed_count']==0 for v in metrics.values())
material=Model.Materials.Children[0].GetAsDictionary()
with open(out+r'\material_properties.json','w') as f:json.dump(material,f,indent=2)
data={'native_reopen_passed':True,'project_directory':unicode(ExtAPI.DataModel.Project.ProjectDirectory),
 'statuses':[unicode(a.Solution.Status) for a in Model.Analyses],
 'deformation_mm':d,'stress_MPa':s,'frequencies_Hz':freq,'mesh_quality':metrics,
 'mesh_convergence_study':False,
 'limitations':['Rigid idealized base, no bolt or shaft contact','Linear elasticity, unprestressed modes',
 'Some sliver elements: worst skewness exceeds 0.99; demonstration mesh, not certified design',
 'Mode amplitudes are normalized; slow animation is illustrative, not a transient solution']}
with open(out+r'\native_reopen_verification.json','w') as f:json.dump(data,f,indent=2)
r=[r for r in Model.Analyses[1].Solution.Children if r.Name=='Mode_01_Normalized_Shape'][0]
r.Activate()
json.dumps(data)
