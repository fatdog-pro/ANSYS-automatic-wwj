"""A local stdio MCP adapter for explicit Ansys SDK Python jobs.

This is an orchestration layer, not a Python sandbox. Project-path checks guard
the bridge's own file operations; an executed script has the user's OS rights.
The bridge never clears models, stops solver processes, or installs software.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import threading
from typing import Any, Callable
import uuid


SESSION_POLICIES = {
    "dedicated-keep-open",
    "attach-existing-read-only",
    "attach-existing-authorized",
    "batch-owned",
}
MAX_SCRIPT_BYTES = 1_048_576
MAX_LOG_BYTES = 1_048_576
MAX_RETURN_CHARS = 65_536
RESERVED_DIR = ".ansys-unified-jobs"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class Bridge:
    """Testable implementation; external inventory functions are injected lazily."""

    def __init__(
        self,
        config: dict[str, Any],
        *,
        inspector: Callable | None = None,
        inventory_fn: Callable | None = None,
        registry: list[dict[str, Any]] | None = None,
    ) -> None:
        if inspector is None or inventory_fn is None or registry is None:
            import inventory as product_inventory

            inspector = inspector or product_inventory.inspect_product
            inventory_fn = inventory_fn or product_inventory.inventory
            registry = registry if registry is not None else product_inventory.load_registry()
        self.config = config
        self.inspector = inspector
        self.inventory_fn = inventory_fn
        self.registry = registry
        self.roots = tuple(Path(p).expanduser().resolve() for p in config.get("project_roots", []))
        if not self.roots:
            raise ValueError("Configure at least one project_roots directory before starting the bridge.")
        self.jobs: dict[str, dict[str, Any]] = {}
        self.lock = threading.RLock()

    def inventory(self) -> dict:
        """Read local products/SDKs without launching or licensing any solver."""
        return self.inventory_fn(self.config)

    def product_info(self, product_id: str) -> dict:
        """Resolve an exact product ID or alias; include documented route and evidence."""
        info = self.inspector(product_id, self.config)
        canonical = info["product_id"]
        product = next((p for p in self.registry if p["id"] == canonical), None)
        return {**info, "route": product}

    def _project(self, project_dir: str, *, create: bool = False) -> Path:
        path = Path(project_dir).expanduser()
        if not path.is_absolute():
            raise ValueError("project_dir must be an absolute path inside a configured project root.")
        resolved = path.resolve()
        if not any(resolved.is_relative_to(root) for root in self.roots):
            raise ValueError("project_dir is outside the configured project roots.")
        if create:
            resolved.mkdir(parents=True, exist_ok=True)
        if not resolved.is_dir():
            raise ValueError("project_dir does not exist; use write_script to create a project first.")
        return resolved

    @staticmethod
    def _relative(project: Path, relative_path: str, *, script: bool = True) -> Path:
        relative = Path(relative_path)
        # Reject drive-relative paths, alternate data streams, and reserved job files.
        if not relative_path or relative.is_absolute() or relative.drive or ":" in relative_path:
            raise ValueError("relative_path must be a relative path without a drive or stream name.")
        if ".." in relative.parts or RESERVED_DIR in relative.parts:
            raise ValueError("Parent traversal and the reserved job directory are not allowed.")
        resolved = (project / relative).resolve()
        if not resolved.is_relative_to(project) or resolved == project:
            raise ValueError("The resolved file must remain inside project_dir.")
        if script and resolved.suffix.lower() != ".py":
            raise ValueError("Only .py SDK scripts are accepted.")
        return resolved

    def write_script(self, project_dir: str, relative_path: str, code: str, overwrite: bool = False) -> dict:
        """Write a reviewable UTF-8 .py file under an allowed project; never execute it.

        Before execution include '# ansys-product: PRODUCT_ID' and
        '# ansys-session: dedicated-keep-open | attach-existing-read-only |
        attach-existing-authorized | batch-owned' within the first 40 lines.
        These describe the intended session ownership; they do not enforce it.
        """
        data = code.encode("utf-8")
        if len(data) > MAX_SCRIPT_BYTES:
            raise ValueError("Script exceeds the 1 MiB limit.")
        project = self._project(project_dir, create=True)
        path = self._relative(project, relative_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Resolve once again after creating parents, before the actual file operation.
        path = self._relative(project, relative_path)
        with path.open("wb" if overwrite else "xb") as stream:
            stream.write(data)
        return {
            "status": "written",
            "project_dir": str(project),
            "relative_path": str(path.relative_to(project)),
            "bytes": len(data),
            "sha256": digest(data),
            "executed": False,
        }

    @staticmethod
    def _script_headers(data: bytes, product_id: str) -> tuple[str | None, str | None]:
        try:
            source = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            return None, "Script must use UTF-8 encoding."
        header = "\n".join(source.splitlines()[:40])
        product = re.findall(r"(?m)^\s*#\s*ansys-product:\s*([\w-]+)\s*$", header)
        policy = re.findall(r"(?m)^\s*#\s*ansys-session:\s*([\w-]+)\s*$", header)
        if product != [product_id]:
            return None, "Include exactly one '# ansys-product: %s' declaration in the first 40 lines." % product_id
        if len(policy) != 1 or policy[0] not in SESSION_POLICIES:
            return None, "Include one '# ansys-session: POLICY' declaration; policies: " + ", ".join(sorted(SESSION_POLICIES))
        return policy[0], None

    def start_job(self, product_id: str, project_dir: str, relative_path: str, sha256: str) -> dict:
        """Execute a reviewed SDK script with the registered product Python interpreter.

        Supply the SHA-256 returned by write_script, plus matching product/session
        headers. This runs real Python with current-user privileges, not a sandbox.
        Eligibility means an SDK job can be submitted, not that a license or solve
        is verified. The returned PID belongs only to the Python helper. The bridge
        does not stop Ansys windows at job completion or client disconnection.
        """
        if not re.fullmatch(r"[0-9a-fA-F]{64}", sha256):
            raise ValueError("sha256 must contain exactly 64 hexadecimal characters.")
        project = self._project(project_dir)
        script = self._relative(project, relative_path)
        if not script.is_file():
            raise ValueError("SDK script does not exist.")
        data = script.read_bytes()
        if len(data) > MAX_SCRIPT_BYTES:
            raise ValueError("Script exceeds the 1 MiB limit.")
        if digest(data) != sha256.lower():
            return {"status": "blocked_hash_mismatch", "reason": "Script changed; review it and submit its current SHA-256."}
        info = self.product_info(product_id)
        canonical = info["product_id"]
        execution = info.get("execution", {})
        if execution.get("status") != "eligible_for_script":
            return {
                "status": execution.get("status", "blocked_unknown_execution"),
                "reason": execution.get("reason", "No executable Python route is currently available."),
                "product_id": canonical,
                "started": False,
            }
        policy, error = self._script_headers(data, canonical)
        if error:
            return {"status": "blocked_script_header", "reason": error, "started": False}
        runtime_value = info.get("sdk", {}).get("python")
        if not isinstance(runtime_value, str) or not runtime_value:
            return {"status": "blocked_missing_runtime", "reason": "No product Python interpreter is configured.", "started": False}
        runtime = Path(runtime_value)
        registered = {str(Path(p).resolve()) for p in self.config.get("python_runtimes", {}).values() if p}
        if not runtime.is_file() or str(runtime.resolve()) not in registered:
            return {"status": "blocked_missing_runtime", "reason": "The product interpreter must exist and match a configured Python runtime.", "started": False}
        # Check again immediately before launch; SHA is a review aid, not a hostile-filesystem sandbox.
        if digest(script.read_bytes()) != sha256.lower():
            return {"status": "blocked_hash_mismatch", "reason": "Script changed during preflight.", "started": False}
        job_id = "job-" + uuid.uuid4().hex
        job_root = (project / RESERVED_DIR).resolve()
        if not job_root.is_relative_to(project):
            raise ValueError("The job log directory resolves outside project_dir.")
        job_dir = job_root / job_id
        job_dir.mkdir(parents=True)
        log_path = job_dir / "output.log"
        log_path.touch()
        env = os.environ.copy()
        env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
        # Bundled API paths originate only in local configuration, never tool arguments.
        api_paths = info.get("sdk", {}).get("api_paths", [])
        if api_paths:
            if not all(Path(p).is_dir() for p in api_paths):
                return {"status": "blocked_missing_sdk", "reason": "A configured bundled API directory is unavailable.", "started": False}
            env["PYTHONPATH"] = os.pathsep.join([str(Path(p).resolve()) for p in api_paths] + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
        # Deliberately no arbitrary command/argument/env tools and no shell=True.
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        proc = subprocess.Popen(
            [str(runtime), "-u", str(script)],
            cwd=str(project),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            shell=False,
            creationflags=flags,
            close_fds=True,
        )
        job = {
            "job_id": job_id,
            "product_id": canonical,
            "project_dir": str(project),
            "script": str(script),
            "script_sha256": sha256.lower(),
            "python": str(runtime),
            "session_policy": policy,
            "helper_pid": proc.pid,
            "started_at": utc_now(),
            "finished_at": None,
            "status": "running",
            "exit_code": None,
            "log_path": str(log_path),
            "log_bytes_discarded": 0,
            "log_capture_complete": False,
            "solver_result": "not_assessed",
            "process": proc,
            "log_lock": threading.Lock(),
        }
        with self.lock:
            self.jobs[job_id] = job
        self._save_metadata(job)
        threading.Thread(target=self._capture_log, args=(job,), daemon=True, name=job_id).start()
        return self.job_status(job_id)

    def _get_job(self, job_id: str) -> dict:
        with self.lock:
            if job_id not in self.jobs:
                raise ValueError("Unknown job ID in this bridge session. Durable metadata/logs remain in the project .ansys-unified-jobs directory.")
            return self.jobs[job_id]

    @staticmethod
    def _public(job: dict) -> dict:
        return {k: v for k, v in job.items() if k not in {"process", "log_lock"}}

    def _save_metadata(self, job: dict) -> None:
        path = Path(job["log_path"]).with_name("job.json")
        path.write_text(json.dumps(self._public(job), ensure_ascii=False, indent=2), encoding="utf-8")

    def _capture_log(self, job: dict) -> None:
        proc = job["process"]
        try:
            assert proc.stdout is not None
            # read1 returns currently available bytes; read(size) can delay progress logs.
            while chunk := proc.stdout.read1(16_384):
                with job["log_lock"]:
                    path = Path(job["log_path"])
                    previous = path.read_bytes()
                    joined = previous + chunk
                    if len(joined) > MAX_LOG_BYTES:
                        discarded = len(joined) - MAX_LOG_BYTES
                        job["log_bytes_discarded"] += discarded
                        joined = joined[-MAX_LOG_BYTES:]
                    path.write_bytes(joined)
        except Exception as error:
            job["log_error"] = str(error)
        finally:
            if proc.stdout is not None:
                proc.stdout.close()
            job["log_capture_complete"] = True
            self._refresh(job)
            with self.lock:
                self._save_metadata(job)

    def _refresh(self, job: dict) -> None:
        with self.lock:
            code = job["process"].poll()
            if code is not None and job["exit_code"] is None:
                job["exit_code"] = code
                job["status"] = "completed" if code == 0 else "failed"
                job["finished_at"] = utc_now()
                self._save_metadata(job)

    def job_status(self, job_id: str) -> dict:
        """Read Python-helper state; completed/exit 0 does not certify solver success.

        This does not query, terminate, or reconnect an Ansys solver. Job IDs are
        scoped to the current bridge session; saved job.json/output.log files remain.
        """
        job = self._get_job(job_id)
        self._refresh(job)
        return self._public(job)

    def read_job_log(self, job_id: str, tail_lines: int = 100) -> dict:
        """Read bounded combined stdout/stderr; retain at most 1 MiB per helper job."""
        if not 1 <= tail_lines <= 2000:
            raise ValueError("tail_lines must be between 1 and 2000.")
        job = self._get_job(job_id)
        self._refresh(job)
        with job["log_lock"]:
            data = Path(job["log_path"]).read_bytes()
        tail = "\n".join(data.decode("utf-8", errors="replace").splitlines()[-tail_lines:])
        truncated = len(tail) > MAX_RETURN_CHARS
        return {
            "job_id": job_id,
            "status": job["status"],
            "text": tail[-MAX_RETURN_CHARS:],
            "response_truncated": truncated,
            "log_bytes_discarded": job["log_bytes_discarded"],
            "log_path": job["log_path"],
        }


def build_server(bridge: Bridge):
    """Create six intentionally small MCP tools; no solver is launched at startup."""
    from fastmcp import FastMCP

    server = FastMCP(
        "ansys-unified",
        version="1.0.0",
        strict_input_validation=True,
        instructions=(
            "Prefer the official Mechanical or Fluent MCP for connected sessions. "
            "Use this bridge to inspect routes and submit reviewed SDK Python files. "
            "All writes stay under configured project roots, but executed Python is not sandboxed. "
            "Do not infer solver success from a helper exit code; inspect native artifacts and physics. "
            "The bridge never closes existing Ansys windows."
        ),
    )
    read_only = {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True}
    server.tool(bridge.inventory, name="inventory", annotations=read_only)
    server.tool(bridge.product_info, name="product_info", annotations=read_only)
    server.tool(bridge.write_script, name="write_script", annotations={"readOnlyHint": False, "destructiveHint": True, "idempotentHint": False})
    server.tool(bridge.start_job, name="start_job", annotations={"readOnlyHint": False, "destructiveHint": True, "idempotentHint": False, "openWorldHint": True})
    server.tool(bridge.job_status, name="job_status", annotations=read_only)
    server.tool(bridge.read_job_log, name="read_job_log", annotations=read_only)
    return server


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, help="Local runtime/project-root JSON; default assets/runtime.local.json")
    args = parser.parse_args()
    import inventory as product_inventory

    service = Bridge(product_inventory.load_config(args.config))
    build_server(service).run(transport="stdio", show_banner=False)


if __name__ == "__main__":
    main()
