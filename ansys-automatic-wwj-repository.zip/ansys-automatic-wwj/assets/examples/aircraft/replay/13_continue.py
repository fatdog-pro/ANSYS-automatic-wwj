for batch in range(4):
    s.solution.run_calculation.iterate(iter_count=25)
    latest = collect_state()
    history = latest['histories'].get('residual', {})
    last = {name:values[-1] for name,values in history.get('series', {}).items() if values}
    print('RESIDUAL_CHECK', last, flush=True)
    if last and all(value < (1e-4 if name == 'continuity' else 1e-5) for name,value in last.items()):
        print('ALL_RESIDUAL_TARGETS_REACHED', flush=True)
        break
