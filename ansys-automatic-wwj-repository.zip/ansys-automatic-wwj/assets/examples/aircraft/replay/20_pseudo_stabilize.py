s.file.write_case_data(file_name=str(run_dir/'10_before_pseudo_stabilization.cas.h5'))
ts = s.solution.run_calculation.pseudo_time_settings.time_step_method
ts.time_step_size_scale_factor = 1.0
ts.verbosity = 1
record('pseudo_time_stabilization', {'settings':ts.get_state(),
    'reason':'Reduce late continuity oscillations while retaining all original residual targets and turbulence relaxation factors.'})
print('PSEUDO_TIME_STABILIZATION', ts.get_state())
