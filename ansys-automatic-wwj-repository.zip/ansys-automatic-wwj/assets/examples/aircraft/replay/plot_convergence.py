"""Plot actual Fluent monitor data; no synthetic simulation data is generated."""
import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
ROOT = parser.parse_args().root.resolve()
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
data = json.loads((ROOT/'records/progress.json').read_text(encoding='utf-8'))
histories = data['histories']
fig, axes = plt.subplots(1,3,figsize=(15,4.8),gridspec_kw={'width_ratios':[1.5,1,1]})
colors = ['#2D6CDF','#E86C3A','#319A76','#A563C2','#D59B22','#34465D']
for index,(name,values) in enumerate(histories['residual']['series'].items()):
    rows = dict(zip(histories['residual']['iteration'],values))
    xy = sorted(rows.items())
    axes[0].semilogy([a for a,b in xy],[max(b,1e-20) for a,b in xy],label=name,color=colors[index%len(colors)],lw=1.3)
axes[0].axhline(1e-4,color='#555',ls='--',lw=.8,label='continuity target')
axes[0].axhline(1e-5,color='#999',ls=':',lw=.8,label='other targets')
axes[0].set(xlabel='Iteration',ylabel='Scaled residual',title='Actual solver residuals')
axes[0].legend(fontsize=7.5,ncol=2,loc='lower left')
series=histories['aero-coefficients']
for axis,name,title,color in [(axes[1],'cl','Lift coefficient','#2D6CDF'),(axes[2],'cd','Drag coefficient','#E86C3A')]:
    rows=dict(zip(series['iteration'],series['series'][name]))
    xy=[(i,v) for i,v in sorted(rows.items()) if i>=51]
    axis.plot([i for i,v in xy],[v for i,v in xy],color=color,lw=1.5)
    axis.set(xlabel='Iteration (second-order stage)',ylabel=name.upper(),title=title)
for axis in axes:
    axis.grid(True,alpha=.17)
    axis.spines[['right','top']].set_visible(False)
mesh_report = json.loads((ROOT/'geometry/mesh_validation.json').read_text(encoding='utf-8-sig'))
physics = json.loads((ROOT/'records/physics_setup.json').read_text(encoding='utf-8-sig'))
components = physics['inlet']['momentum']['velocity_components']
speed = float(np.linalg.norm([value['value'] for value in components]))
angle = mesh_report['geometry']['aoa_deg']
cells = mesh_report['mesh']['cells']
fig.suptitle(f'Simplified aircraft | {speed:g} m/s | {angle:g} deg AoA | {cells:,} tetrahedra',fontsize=13,y=1.01)
fig.tight_layout()
fig.savefig(OUT/'convergence.png',dpi=180,bbox_inches='tight')
plt.close(fig)
for group,h in histories.items():
    names=list(h['series'])
    rows={int(i):[h['series'][name][n] for name in names] for n,i in enumerate(h['iteration'])}
    with (OUT/(group+'-history.csv')).open('w',newline='',encoding='utf-8') as handle:
        writer=csv.writer(handle)
        writer.writerow(['iteration']+names)
        writer.writerows([[i]+values for i,values in sorted(rows.items())])
print('Actual convergence plot and CSV histories written to '+str(OUT))
