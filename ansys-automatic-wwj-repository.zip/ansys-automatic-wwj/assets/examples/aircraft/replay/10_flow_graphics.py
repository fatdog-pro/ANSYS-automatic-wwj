g = s.results.graphics
surfaces = s.results.surfaces
if 'section-y0' not in surfaces.plane_surface.get_object_names():
    surfaces.plane_surface.create(name='section-y0')
plane = surfaces.plane_surface['section-y0']
plane.method = 'zx-plane'
plane.y = 0.0
if 'velocity-section' not in g.contour.get_object_names():
    g.contour.create(name='velocity-section')
vc = g.contour['velocity-section']
vc.field = 'velocity-magnitude'
vc.surfaces_list = ['section-y0','aircraft_wall']
vc.options.filled = True
vc.options.node_values = True
vc.display()
g.views.camera.projection = 'orthographic'
g.views.camera.position = [0,-10,0.8]
g.views.camera.target = [0.5,0,0]
g.views.camera.up_vector = [0,0,1]
g.views.camera.field = [9.0,6.75]
g.picture.save_picture(file_name=str(run_dir / 'aircraft_velocity_section.png'))

seeds = []
for index, height in enumerate([-0.12,0.10,0.32]):
    name = 'upstream-seed-' + str(index)
    if name not in surfaces.rake_surface.get_object_names():
        surfaces.rake_surface.create(name=name)
    rake = surfaces.rake_surface[name]
    rake.p0 = [-3.0,-3.5,height]
    rake.p1 = [-3.0,3.5,height]
    rake.number_of_points = 45
    seeds.append(name)
if 'aircraft-streamlines' not in g.pathline.get_object_names():
    g.pathline.create(name='aircraft-streamlines')
pl = g.pathline['aircraft-streamlines']
pl.field = 'velocity-magnitude'
pl.release_from_surfaces = seeds
pl.option.step = 500
pl.option.skip = 0
scenes = s.results.scene
if 'aircraft-streamline-scene' not in scenes.get_object_names():
    scenes.create(name='aircraft-streamline-scene')
scene = scenes['aircraft-streamline-scene']
for name in ['aircraft-surface','aircraft-streamlines']:
    if name not in scene.graphics_objects.get_object_names():
        scene.graphics_objects.add(name=name)
scene.graphics_objects['aircraft-surface'].transparency = 0
scene.display()
camera_aircraft()
g.picture.save_picture(file_name=str(run_dir / 'aircraft_streamlines.png'))
record('flow_graphics', {'contours':g.contour.get_object_names(), 'pathlines':g.pathline.get_object_names(),
                         'seed_names':seeds, 'interpretation':'Streamlines in a steady RANS mean velocity field; not transient particle animation.'})
