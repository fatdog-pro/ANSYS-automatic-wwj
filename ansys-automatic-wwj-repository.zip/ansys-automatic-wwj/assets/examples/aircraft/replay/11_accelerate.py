s.file.write_case_data(file_name=str(run_dir / '06_coupled_checkpoint.cas.h5'))
s.solution.run_calculation.pseudo_time_settings.time_step_method.time_step_size_scale_factor = 5.0
record('pseudo_time_acceleration', {'scale_factor':5.0,'reason':'Continue from stable 160-iteration field; monitor residual response.'})
print('PSEUDO_TIME_SCALE', s.solution.run_calculation.pseudo_time_settings.time_step_method.get_state())
