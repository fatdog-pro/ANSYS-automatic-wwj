g = s.results.graphics
effects = solver.preferences.Graphics.GraphicsEffects
effect_names = ['GridPlaneEnabled','ReflectionsEnabled','ShadowMapEnabled','SimpleShadowsEnabled']
record('graphics_effects_before', {name:getattr(effects,name).get_state() for name in effect_names})
for name in effect_names:
    getattr(effects,name).set_state(False)
g.mesh['aircraft-surface'].options.edges = False

def camera_aircraft():
    g.views.camera.projection = 'orthographic'
    g.views.camera.position = [-8,-10,6]
    g.views.camera.target = [0,0,0]
    g.views.camera.up_vector = [0,0,1]
    g.views.camera.field = [8.6,6.45]

if 'aircraft-pressure' not in g.contour.get_object_names():
    g.contour.create(name='aircraft-pressure')
cp = g.contour['aircraft-pressure']
cp.field = 'pressure'
cp.surfaces_list = ['aircraft_wall']
cp.options.filled = True
cp.options.node_values = True
cp.display()
camera_aircraft()
g.picture.save_picture(file_name=str(run_dir / 'aircraft_pressure.png'))
record('graphics_created', {'contours':g.contour.get_object_names(),
                           'pressure_png':str(run_dir/'aircraft_pressure.png')})
