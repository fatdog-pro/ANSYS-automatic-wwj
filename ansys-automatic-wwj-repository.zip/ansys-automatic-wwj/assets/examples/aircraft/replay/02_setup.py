s = solver.settings
metadata = json.loads((geometry_dir / 'mesh_validation.json').read_text(encoding='utf-8'))
geometry = metadata['geometry']
SREF = geometry['reference_wing_area_m2']
CREF = geometry['reference_mean_aerodynamic_chord_m']
s.setup.general.solver.time = 'steady'
s.setup.models.viscous.model = 'k-omega'
s.setup.models.viscous.k_omega_model = 'sst'
s.setup.models.energy.enabled = False
air = s.setup.materials.fluid['air']
air.density.option = 'constant'
air.density.value = 1.225
air.viscosity.option = 'constant'
air.viscosity.value = 1.7894e-5
s.setup.cell_zone_conditions.fluid['fluid'].general.material = 'air'
inlet = s.setup.boundary_conditions.velocity_inlet['inlet']
inlet.momentum.velocity_specification_method = 'Components'
for index, velocity in enumerate([20.0,0.0,0.0]):
    inlet.momentum.velocity_components[index].option = 'value'
    inlet.momentum.velocity_components[index].value = velocity
inlet.turbulence.turbulence_specification = 'Intensity and Viscosity Ratio'
inlet.turbulence.turbulent_intensity = 0.01
inlet.turbulence.turbulent_viscosity_ratio = 10.0
outlet = s.setup.boundary_conditions.pressure_outlet['outlet']
outlet.momentum.gauge_pressure.option = 'value'
outlet.momentum.gauge_pressure.value = 0.0
outlet.turbulence.turbulence_specification = 'Intensity and Viscosity Ratio'
outlet.turbulence.backflow_turbulent_intensity = 0.01
outlet.turbulence.backflow_turbulent_viscosity_ratio = 10.0
s.setup.general.operating_conditions.operating_pressure = 101325.0
s.solution.methods.p_v_coupling.flow_scheme = 'SIMPLE'
schemes = s.solution.methods.spatial_discretization.discretization_scheme
for key in ['mom','k','omega']:
    if key in schemes.get_state():
        schemes[key] = 'first-order-upwind'
eqs = s.solution.monitor.residual.equations
for eq in eqs.get_object_names():
    eqs[eq].absolute_criteria = 1e-4 if eq == 'continuity' else 1e-5
rv = s.setup.reference_values
rv.area = SREF
rv.length = CREF
rv.density = 1.225
rv.velocity = 20.0
rv.viscosity = 1.7894e-5
rv.pressure = 0.0
rd = s.solution.report_definitions
for name, group, direction, output in [
    ('drag-n', rd.drag, [1,0,0], 'Drag Force'),
    ('lift-n', rd.lift, [0,0,1], 'Lift Force'),
    ('cd', rd.drag, [1,0,0], 'Drag Coefficient'),
    ('cl', rd.lift, [0,0,1], 'Lift Coefficient'),
]:
    if name not in group.get_object_names():
        group.create(name=name)
    report = group[name]
    report.zones = ['aircraft_wall']
    report.force_vector = direction
    report.report_output_type = output
files = s.solution.monitor.report_files
if 'aero-history' not in files.get_object_names():
    files.create(name='aero-history')
history = files['aero-history']
history.file_name = str(run_dir / 'aero-history.out')
history.report_defs = ['drag-n','lift-n','cd','cl']
history.frequency = 1
history.active = True
plots = s.solution.monitor.report_plots
if 'aero-coefficients' not in plots.get_object_names():
    plots.create(name='aero-coefficients')
plots['aero-coefficients'].report_defs = ['cd','cl']
snapshot = {'viscous':s.setup.models.viscous.get_state(),
            'inlet':inlet.get_state(), 'outlet':outlet.get_state(),
            'wall':s.setup.boundary_conditions.wall['aircraft_wall'].get_state(),
            'reference_values':rv.get_state(), 'schemes':schemes.get_state(),
            'residual_targets':{eq:eqs[eq].absolute_criteria.get_state() for eq in eqs.get_object_names()},
            'Re_MAC':1.225*20*CREF/1.7894e-5,
            'assumptions':'Steady incompressible RANS, SST, fixed simplified aircraft at 5 deg AoA; no propeller or motion.'}
record('physics_setup', snapshot)
s.file.write_case(file_name=str(run_dir / '02_setup.cas.h5'))
print('PHYSICS_CONFIGURED', {'reference_area':SREF,'Re_MAC':snapshot['Re_MAC'],
      'model':s.setup.models.viscous.model.get_state(),'scheme':schemes.get_state()})
