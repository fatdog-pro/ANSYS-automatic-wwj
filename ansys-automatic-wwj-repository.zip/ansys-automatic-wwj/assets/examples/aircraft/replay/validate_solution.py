"""Independently validate saved aircraft CFD records; never connects to Ansys.

Exit code zero means the validator ran. Inspect steady_convergence.passed for
convergence, or request --require-converged. No mesh accuracy claim is inferred
from a converged solution on this coarse tetrahedral mesh.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import statistics
import sys


REQUIRED_EQUATIONS = ("continuity", "x-velocity", "y-velocity", "z-velocity", "k", "omega")
RESIDUAL_LIMITS = {name: 1e-4 if name == "continuity" else 1e-5 for name in REQUIRED_EQUATIONS}


def nonfinite_paths(value, path="root"):
    out = []
    if isinstance(value, float) and not math.isfinite(value):
        out.append(path)
    elif isinstance(value, dict):
        for key, child in value.items():
            out.extend(nonfinite_paths(child, f"{path}.{key}"))
    elif isinstance(value, list):
        for i, child in enumerate(value):
            out.extend(nonfinite_paths(child, f"{path}[{i}]"))
    return out


def number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label} must be a finite numeric value")
    return float(value)


def history(raw, name):
    iterations = raw["iteration"]
    series = raw["series"]
    if not iterations or not series:
        raise ValueError(f"Empty {name} history")
    index = [number(i, f"{name}.iteration") for i in iterations]
    if any(i != int(i) or i < 0 for i in index):
        raise ValueError(f"{name} iteration labels must be nonnegative integers")
    if any(a > b for a, b in zip(index, index[1:])):
        raise ValueError(f"{name} iteration labels move backwards; split or repair the record explicitly")
    result = {}
    for key, values in series.items():
        if len(values) != len(index):
            raise ValueError(f"{name}.{key}: {len(values)} values for {len(index)} iteration labels")
        # Monitor restart at a stage boundary can repeat the last iteration.
        # Keep its last real value, and never count it as another solver step.
        result[key] = {int(i): number(v, f"{name}.{key}[{i}]") for i, v in zip(index, values)}
    return result, {
        "recorded_samples": len(index), "unique_iterations": len(set(index)),
        "duplicate_iteration_samples_removed": len(index)-len(set(index)),
        "first_iteration": int(index[0]), "last_iteration": int(index[-1]),
    }


def check_residuals(series, iteration):
    checks = {}
    for equation, threshold in RESIDUAL_LIMITS.items():
        value = series.get(equation, {}).get(iteration)
        checks[equation] = {
            "value": value, "threshold": threshold,
            "passed": value is not None and 0 <= value < threshold,
        }
    return {"iteration": iteration, "passed": all(c["passed"] for c in checks.values()),
            "equations": checks}


def stability(series, last_iteration, count=50):
    requested = list(range(last_iteration-count+1, last_iteration+1))
    missing = [i for i in requested if i not in series]
    values = [series[i] for i in requested if i in series]
    average = statistics.fmean(values) if values else None
    span = max(values)-min(values) if values else None
    relative = span/abs(average) if average is not None and abs(average) > 1e-15 else None
    return {
        "first_iteration": requested[0], "last_iteration": requested[-1],
        "required_samples": count, "available_samples": len(values),
        "missing_iterations": missing, "mean": average,
        "minimum": min(values) if values else None,
        "maximum": max(values) if values else None,
        "range_over_absolute_mean": relative,
        "range_over_absolute_mean_percent": 100*relative if relative is not None else None,
        "threshold_fraction": 0.01,
        "passed": not missing and relative is not None and relative < 0.01,
    }


def validate(progress, mesh, density=1.225, velocity=20.0, second_order_start=51):
    invalid = nonfinite_paths(progress, "progress") + nonfinite_paths(mesh, "mesh")
    if invalid:
        return {"schema_version":1, "record_integrity":{"passed":False,"nonfinite_paths":invalid},
                "physics_consistency":{"passed":False,"status":"invalid_input"},
                "steady_convergence":{"passed":False,"status":"invalid_input"},
                "mesh_accuracy":{"status":"not_validated","passed":False},
                "overall_status":"invalid_input"}
    rho=number(density,"density"); speed=number(velocity,"velocity")
    area=number(mesh["geometry"]["reference_wing_area_m2"],"reference area")
    if min(rho,speed,area) <= 0:
        raise ValueError("Density, velocity and reference area must be positive")
    q=0.5*rho*speed**2
    force={}
    for item in progress["force_reports_raw"]:
        for key, pair in item.items():
            if key in force or not isinstance(pair,list) or len(pair)!=2:
                raise ValueError(f"Invalid or duplicate force report {key}")
            force[key]={"value":number(pair[0],f"force.{key}"),"unit":pair[1]}
    residuals,residual_metadata=history(progress["histories"]["residual"],"residual")
    aero,aero_metadata=history(progress["histories"]["aero-coefficients"],"aero-coefficients")
    last=residual_metadata["last_iteration"]
    coefficient_checks={}
    for coefficient,force_name in [("cd","drag-n"),("cl","lift-n")]:
        value=force[coefficient]["value"]
        computed=force[force_name]["value"]/(q*area)
        monitor=aero.get(coefficient,{}).get(last)
        tolerance=max(1e-10,abs(computed)*1e-6)
        difference=abs(value-computed)
        units_ok=force[force_name]["unit"]=="N" and force[coefficient]["unit"] in ("","1","dimensionless")
        monitor_ok=monitor is not None and math.isclose(value,monitor,rel_tol=1e-7,abs_tol=1e-10)
        coefficient_checks[coefficient]={
            "reported":value,"force_N":force[force_name]["value"],
            "independent_force_over_qS":computed,"absolute_difference":difference,
            "absolute_tolerance":tolerance,"units_correct":units_ok,
            "latest_monitor":monitor,"matches_latest_monitor":monitor_ok,
            "passed":difference<=tolerance and units_ok and monitor_ok,
        }
    mass=progress["mass_flow_raw"]
    incoming=number(mass["inlet"]["Net"],"inlet mass flow")
    outgoing=number(mass["outlet"]["Net"],"outlet mass flow")
    aliases_ok=all(math.isclose(number(mass[zone][zone],f"{zone} alias"),v,rel_tol=1e-10,abs_tol=1e-10)
                   for zone,v in [("inlet",incoming),("outlet",outgoing)])
    imbalance=abs(incoming+outgoing)/abs(incoming) if incoming else None
    mass_check={
        "inlet_kg_s":incoming,"outlet_kg_s":outgoing,"net_kg_s":incoming+outgoing,
        "relative_imbalance":imbalance,"imbalance_percent":100*imbalance if imbalance is not None else None,
        "threshold_fraction":0.001,"duplicated_net_zone_values_consistent":aliases_ok,
        "passed":aliases_ok and incoming>0 and outgoing<0 and imbalance is not None and imbalance<0.001,
        "scope":"Global boundary flux balance only; does not establish local equation convergence.",
    }
    latest=check_residuals(residuals,last)
    previous=check_residuals(residuals,max(0,last-50))
    window_iterations=list(range(last-49,last+1))
    residual_window={}
    for name,limit in RESIDUAL_LIMITS.items():
        values=[residuals.get(name,{}).get(i) for i in window_iterations]
        valid=[v for v in values if v is not None]
        residual_window[name]={"maximum":max(valid) if valid else None,"threshold":limit,
                               "complete":len(valid)==50,
                               "all_50_below_threshold":len(valid)==50 and all(0<=v<limit for v in valid)}
    coefficient_stability={name:stability(aero.get(name,{}),last) for name in ("cl","cd")}
    schemes=progress.get("schemes",{})
    second_order=all(schemes.get(k)=="second-order-upwind" for k in ("mom","k","omega")) and schemes.get("pressure")=="second-order"
    complete_second_order_window=last>100 and window_iterations[0]>=second_order_start and all(
        check["available_samples"]==50 and not check["missing_iterations"] for check in coefficient_stability.values())
    histories_aligned=last==aero_metadata["last_iteration"]
    history_nonnegative=all(value>=0 for equation in residuals.values() for value in equation.values())
    physics_ok=all(c["passed"] for c in coefficient_checks.values()) and mass_check["passed"]
    stable=all(c["passed"] for c in coefficient_stability.values())
    converged=all([latest["passed"],stable,mass_check["passed"],second_order,
                   complete_second_order_window,histories_aligned,history_nonnegative,physics_ok])
    blockers=[]
    if not latest["passed"]:
        blockers.append("Latest residual thresholds not met: "+", ".join(k for k,v in latest["equations"].items() if not v["passed"]))
    if not stable:
        blockers.append("Last 50 iterations CL/CD range divided by absolute mean is not below 1%")
    if not complete_second_order_window:
        blockers.append("Need iteration >100 and 50 consecutive samples entirely within the declared second-order stage")
    if not mass_check["passed"]:
        blockers.append("Global mass imbalance or flux sign check failed")
    if not second_order:
        blockers.append("Recorded discretization schemes are not all the required second-order schemes")
    if not histories_aligned or not history_nonnegative:
        blockers.append("Residual and coefficient histories are misaligned or residuals are negative")
    if not physics_ok:
        blockers.append("Physical consistency checks failed")
    return {
        "schema_version":1,"generated_utc":datetime.now(timezone.utc).isoformat(),
        "progress_record_time":progress.get("time"),"iteration":last,
        "record_integrity":{"passed":histories_aligned and history_nonnegative,"all_numeric_values_finite":True,
                            "histories_aligned":histories_aligned,"residuals_nonnegative":history_nonnegative,
                            "residual_history":residual_metadata,"coefficient_history":aero_metadata},
        "reference_values":{"density_kg_m3":rho,"velocity_m_s":speed,"area_m2":area,
                            "dynamic_pressure_Pa":q,"qS_N":q*area,
                            "source":"Density and speed are explicit validator arguments; area is read from mesh geometry metadata."},
        "physics_consistency":{"passed":physics_ok,"coefficient_normalization":coefficient_checks,
                               "global_mass_balance":mass_check},
        "steady_convergence":{"passed":converged,"status":"criteria_met" if converged else "not_converged",
                              "latest_residuals":latest,"previous_50_step_checkpoint":previous,
                              "last_50_residual_maxima":residual_window,
                              "coefficient_stability_last_50":coefficient_stability,
                              "current_schemes":schemes,"current_schemes_all_second_order":second_order,
                              "declared_second_order_start_iteration":second_order_start,
                              "complete_second_order_window":complete_second_order_window,"blockers":blockers,
                              "acceptance_rule":"Latest continuity <1e-4 and other five residuals <1e-5; final 50 consecutive second-order CL/CD range/|mean| <1%; global mass imbalance <0.1%; matching finite records and force normalization.",
                              "checkpoint_note":"Previous-checkpoint and window-maximum residuals are reported separately; they are not silently substituted for the latest residual acceptance check."},
        "mesh_accuracy":{"status":"not_validated","passed":False,
                         "mesh_topology_checks_passed":bool(mesh["mesh"].get("passed")),
                         "cells":mesh["mesh"].get("cells"),
                         "prism_boundary_layers":False,"mesh_convergence_study":False,
                         "limitations":["Coarse isotropic tetrahedra have no prism inflation layers.",
                                        "No y-plus resolution acceptance or grid-convergence study has been completed.",
                                        "No validated drag or real-aircraft performance claim follows from numerical convergence."]},
        "overall_status":"numerically_converged_demonstration_accuracy_unvalidated" if converged else "demonstration_not_yet_numerically_converged",
    }


def self_test(progress,mesh):
    synthetic=copy.deepcopy(progress)
    synthetic["histories"]={
        "residual":{"iteration":list(range(1,152)),"series":{name:[limit/10]*151 for name,limit in RESIDUAL_LIMITS.items()}},
        "aero-coefficients":{"iteration":list(range(1,152)),"series":{
            name:[next(item[name][0] for item in progress['force_reports_raw'] if name in item)]*151 for name in ('cl','cd')}}}
    synthetic['mass_flow_raw']={'inlet':{'Net':17640.,'inlet':17640.},'outlet':{'Net':-17640.,'outlet':-17640.}}
    result=validate(synthetic,mesh)
    assert result['steady_convergence']['passed']
    assert result['mesh_accuracy']['status']=='not_validated'
    bad=copy.deepcopy(synthetic);bad['histories']['residual']['series']['continuity'][-1]=0.02
    assert not validate(bad,mesh)['steady_convergence']['passed']  # perfect mass balance is insufficient
    bad=copy.deepcopy(synthetic);bad['force_reports_raw'][0]['drag-n'][0]=float('nan')
    assert validate(bad,mesh)['overall_status']=='invalid_input'
    bad=copy.deepcopy(synthetic);bad['histories']['aero-coefficients']['series']['cl'][-20]*=1.1
    assert not validate(bad,mesh)['steady_convergence']['passed']
    bad=copy.deepcopy(synthetic)
    for section in bad['histories'].values():
        section['iteration']=section['iteration'][:100]
        section['series']={key:values[:100] for key,values in section['series'].items()}
    assert not validate(bad,mesh)['steady_convergence']['complete_second_order_window']
    bad=copy.deepcopy(synthetic)
    for section in bad['histories'].values():
        section['iteration'].insert(50,50)
        for values in section['series'].values():values.insert(50,values[49])
    result=validate(bad,mesh)
    assert result['steady_convergence']['passed'] and result['record_integrity']['residual_history']['duplicate_iteration_samples_removed']==1
    print('Self-tests passed: converged fixture, local residual rejection despite perfect global mass, nonfinite data, coefficient instability, second-order window, duplicate iteration handling.')


def main():
    base=Path(__file__).resolve().parents[1]
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--progress',type=Path,required=True)
    parser.add_argument('--mesh',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--density',type=float,default=1.225)
    parser.add_argument('--velocity',type=float,default=20.0)
    parser.add_argument('--second-order-start',type=int,default=51)
    parser.add_argument('--require-converged',action='store_true')
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    progress=json.loads(args.progress.read_text(encoding='utf-8-sig'))
    mesh=json.loads(args.mesh.read_text(encoding='utf-8-sig'))
    if args.self_test:
        self_test(progress,mesh)
    result=validate(progress,mesh,args.density,args.velocity,args.second_order_start)
    result['source_files']={'progress':str(args.progress.resolve()),'mesh':str(args.mesh.resolve())}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'output':str(args.output.resolve()),'iteration':result.get('iteration'),
                      'physics_consistency':result['physics_consistency']['passed'],
                      'steady_convergence':result['steady_convergence']['passed'],
                      'blockers':result['steady_convergence'].get('blockers',[]),
                      'mesh_accuracy':result['mesh_accuracy']['status']},ensure_ascii=False,indent=2))
    if args.require_converged and not result['steady_convergence']['passed']:
        sys.exit(2)


if __name__=='__main__':
    main()
