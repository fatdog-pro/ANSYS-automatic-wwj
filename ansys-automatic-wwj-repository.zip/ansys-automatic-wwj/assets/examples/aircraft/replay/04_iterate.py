import math
from datetime import datetime

def collect_state():
    histories = {}
    for monitor_name in solver.monitors.get_monitor_set_names():
        x, ys = solver.monitors.get_monitor_set_data(monitor_name)
        histories[monitor_name] = {'iteration':x.tolist(),'series':{k:v.tolist() for k,v in ys.items()}}
    forces = s.solution.report_definitions.compute(report_defs=['drag-n','lift-n','cd','cl'])
    mass = {zone:s.results.report.fluxes.get_mass_flow(zones=[zone]) for zone in ['inlet','outlet']}
    data = {'time':datetime.now().isoformat(),'histories':histories,'force_reports_raw':forces,
            'mass_flow_raw':mass,'schemes':s.solution.methods.spatial_discretization.discretization_scheme.get_state()}
    record('progress', data)
    (run_dir / 'progress.json').write_text(json.dumps(data,indent=2,default=str),encoding='utf-8')
    print('AERO_PROGRESS', forces, 'MASS', mass, flush=True)
    return data

s.solution.run_calculation.iterate(iter_count=50)
latest = collect_state()
