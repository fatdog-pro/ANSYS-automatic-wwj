# Preserve the converged monitors before read_case_data refreshes client histories.
before = json.loads((state_dir/'final_values.json').read_text(encoding='utf-8'))
s.file.write_case_data(file_name=str(run_dir/'aircraft.cas.h5'))
s.file.read_case_data(file_name=str(run_dir/'aircraft.cas.h5'))
after = s.solution.report_definitions.compute(report_defs=['drag-n','lift-n','cd','cl'])
def force_dict(raw):
    return {name:float(value[0]) for item in raw for name,value in item.items()}
old_values = force_dict(before['forces'])
new_values = force_dict(after)
diff = {key:abs(new_values[key]-old_values[key]) for key in old_values}
assert all(value < 1e-7*max(1,abs(old_values[key])) for key,value in diff.items()), diff
g = s.results.graphics
g.contour['aircraft-pressure'].display()
camera_aircraft()
g.picture.save_picture(file_name=str(run_dir/'aircraft_pressure.png'))
record('reopen_verification', {'passed':True,'before':old_values,'after':new_values,
                             'absolute_differences':diff,'case':str(run_dir/'aircraft.cas.h5'),
                             'data':str(run_dir/'aircraft.dat.h5'),
                             'model':s.setup.models.viscous.get_state(),
                             'native_contours':g.contour.get_object_names(),
                             'native_scenes':s.results.scene.get_object_names(),
                             'gui_left_open':True})
print('NATIVE_REOPEN_VERIFIED', new_values)
