s.solution.run_calculation.iterate(iter_count=30)
latest = collect_state()
