surfaces = s.results.surfaces
if 'wing-section-y1' not in surfaces.plane_surface.get_object_names():
    surfaces.plane_surface.create(name='wing-section-y1')
wp = surfaces.plane_surface['wing-section-y1']
wp.method = 'three-points'
wp.p0 = [-2.5,1.0,-1.0]
wp.p1 = [4.5,1.0,-1.0]
wp.p2 = [-2.5,1.0,1.5]
wp.bounded = True
if 'wing-velocity' not in g.contour.get_object_names():
    g.contour.create(name='wing-velocity')
wv = g.contour['wing-velocity']
wv.field = 'velocity-magnitude'
wv.surfaces_list = ['wing-section-y1']
wv.options.filled = True
wv.options.node_values = True
scenes = s.results.scene
if 'wing-velocity-scene' not in scenes.get_object_names():
    scenes.create(name='wing-velocity-scene')
scene = scenes['wing-velocity-scene']
for name in ['aircraft-surface','wing-velocity']:
    if name not in scene.graphics_objects.get_object_names():
        scene.graphics_objects.add(name=name)
scene.graphics_objects['aircraft-surface'].transparency = 0
scene.graphics_objects['wing-velocity'].transparency = 10
scene.display()
camera_aircraft()
g.picture.save_picture(file_name=str(run_dir/'aircraft_wing_velocity.png'))
record('wing_section', {'surface':wp.get_state(), 'scene':scene.get_state()})
