"""Create a closed teaching aircraft and a checked Fluent tetrahedral mesh.

Gmsh OpenCASCADE API only; never starts or connects to Ansys. All lengths are m.
Geometry is deliberately generic, not a model of any manufactured aircraft.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path
import time

import gmsh
import numpy as np


SOURCES = [
    "https://gmsh.info/doc/texinfo/",
    "https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/flu_ug/tgd_user_format_gridsect.html",
]


def foil_wire(leading_x, chord, span, vertical=False, z=0.0):
    """Closed symmetric NACA 0012 foil, with mathematically closed trailing edge."""
    occ = gmsh.model.occ
    xs = 0.5 * (1 - np.cos(np.linspace(0, math.pi, 31)))
    ys = 0.6 * (0.2969 * np.sqrt(xs) - 0.126 * xs - 0.3516 * xs**2
                + 0.2843 * xs**3 - 0.1036 * xs**4)
    ys[0] = ys[-1] = 0
    def point(x, t):
        if vertical:
            return occ.addPoint(leading_x + chord*x, chord*t, span)
        return occ.addPoint(leading_x + chord*x, span, z + chord*t)
    upper = [point(x, y) for x, y in zip(xs, ys)]
    lower = [upper[-1]] + [point(x, -y) for x, y in zip(xs[-2:0:-1], ys[-2:0:-1])] + [upper[0]]
    cu = occ.addSpline(upper)
    cl = occ.addSpline(lower)
    return occ.addWire([cu, cl], checkClosed=True)


def wing_half(y_tip, root_x, tip_x, root_chord, tip_chord, z=0):
    root = foil_wire(root_x, root_chord, 0, z=z)
    tip = foil_wire(tip_x, tip_chord, y_tip, z=z)
    return gmsh.model.occ.addThruSections([root, tip], makeSolid=True, makeRuled=True)


def make_geometry(output, aoa):
    occ = gmsh.model.occ
    body = occ.addSphere(0, 0, 0, 1)
    occ.dilate([(3, body)], 0, 0, 0, 2.0, 0.30, 0.35)
    parts = []
    for sign in (-1, 1):
        parts += wing_half(sign*3.0, -0.65, -0.20, 1.15, 0.70)
        parts += wing_half(sign*1.15, 1.05, 1.40, 0.60, 0.35, z=0.06)
    fin0 = foil_wire(0.95, 0.75, 0.05, vertical=True)
    fin1 = foil_wire(1.35, 0.40, 1.20, vertical=True)
    parts += occ.addThruSections([fin0, fin1], makeSolid=True, makeRuled=True)
    aircraft, _ = occ.fuse([(3, body)], parts, removeObject=True, removeTool=True)
    aircraft = [dt for dt in aircraft if dt[0] == 3]
    if len(aircraft) != 1:
        raise RuntimeError(f"Aircraft union must be one solid, got {aircraft}")
    occ.rotate(aircraft, 0, 0, 0, 0, 1, 0, math.radians(aoa))
    occ.synchronize()
    body_volume = sum(occ.getMass(*dt) for dt in aircraft)
    gmsh.write(str(output / "aircraft.step"))
    gmsh.write(str(output / "aircraft.brep"))
    # 3 spans to each side, 3 lengths upstream and 6 downstream.
    box_bounds = [-12, 24, -15, 15, -12, 12]
    box = occ.addBox(-12, -15, -12, 36, 30, 24)
    fluid, _ = occ.cut([(3, box)], aircraft, removeObject=True, removeTool=True)
    occ.synchronize()
    if len(fluid) != 1 or fluid[0][0] != 3:
        raise RuntimeError(f"Need one fluid volume, got {fluid}")
    boundaries = gmsh.model.getBoundary(fluid, oriented=False)
    wall, inlet, outlet, farfield = [], [], [], []
    for dim, tag in boundaries:
        b = gmsh.model.getBoundingBox(dim, tag)
        if abs(b[0] + 12) < 1e-5 and abs(b[3] + 12) < 1e-5:
            inlet.append(tag)
        elif abs(b[0] - 24) < 1e-5 and abs(b[3] - 24) < 1e-5:
            outlet.append(tag)
        elif any(abs(b[j] - lim) < 1e-5 and abs(b[j+3] - lim) < 1e-5
                 for j, lim in [(1,-15),(1,15),(2,-12),(2,12)]):
            farfield.append(tag)
        else:
            wall.append(tag)
    assert len(inlet) == len(outlet) == 1 and len(farfield) == 4 and len(wall) > 1
    groups = {"inlet": inlet, "outlet": outlet, "farfield": farfield, "aircraft_wall": wall}
    gmsh.model.addPhysicalGroup(3, [fluid[0][1]], 2, "fluid")
    for pid, (name, surfaces) in enumerate(groups.items(), start=4):
        gmsh.model.addPhysicalGroup(2, surfaces, pid, name)
    gmsh.write(str(output / "fluid_domain.step"))
    return fluid, groups, {
        "description": "Generic 4 m ellipsoidal fuselage, tapered closed NACA 0012 wing and tail; no propeller, engine, landing gear, or controls.",
        "units": "m", "aoa_deg": aoa, "fuselage_length_m": 4.0,
        "fuselage_width_m": 0.60, "fuselage_height_m": 0.70,
        "wing_span_m": 6.0, "wing_root_chord_m": 1.15, "wing_tip_chord_m": 0.70,
        "wing_root_le_x_m": -0.65, "wing_tip_le_x_m": -0.20,
        "reference_wing_area_m2": 6*(1.15+0.70)/2,
        "reference_mean_aerodynamic_chord_m": (2/3)*1.15*(1+0.70/1.15+(0.70/1.15)**2)/(1+0.70/1.15),
        "horizontal_tail_span_m": 2.30, "vertical_tail_top_z_before_rotation_m": 1.20,
        "aircraft_cad_volume_m3": body_volume, "fluid_cad_volume_m3": occ.getMass(*fluid[0]),
        "box_bounds_m": box_bounds, "box_volume_m3": 36*30*24,
        "rotation": "+5 degrees about +y: nose (-x) rises; freestream is +x",
        "wall_cad_surfaces": len(wall), "closed_solid_count": 1,
    }


def mesh_geometry(groups, surface_size, far_size):
    gmsh.option.setNumber("General.NumThreads", 2)
    gmsh.option.setNumber("Mesh.Algorithm", 6)
    gmsh.option.setNumber("Mesh.Algorithm3D", 1)
    gmsh.option.setNumber("Mesh.ElementOrder", 1)
    gmsh.option.setNumber("Mesh.MeshSizeFromPoints", 0)
    gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", 0)
    gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 0)
    gmsh.option.setNumber("Mesh.MeshSizeMin", surface_size/3)
    gmsh.option.setNumber("Mesh.MeshSizeMax", far_size)
    gmsh.option.setNumber("Mesh.Optimize", 1)
    distance = gmsh.model.mesh.field.add("Distance")
    gmsh.model.mesh.field.setNumbers(distance, "SurfacesList", groups["aircraft_wall"])
    gmsh.model.mesh.field.setNumber(distance, "Sampling", 50)
    threshold = gmsh.model.mesh.field.add("Threshold")
    for key, value in [("InField", distance), ("SizeMin", surface_size),
                       ("SizeMax", far_size), ("DistMin", 0.15), ("DistMax", 6.0)]:
        gmsh.model.mesh.field.setNumber(threshold, key, value)
    wake = gmsh.model.mesh.field.add("Box")
    for key, value in [("VIn",0.35),("VOut",far_size),("XMin",1.0),("XMax",10.0),
                       ("YMin",-3.5),("YMax",3.5),("ZMin",-1.0),("ZMax",1.5),("Thickness",1.0)]:
        gmsh.model.mesh.field.setNumber(wake,key,value)
    minimum = gmsh.model.mesh.field.add("Min")
    gmsh.model.mesh.field.setNumbers(minimum,"FieldsList",[threshold,wake])
    gmsh.model.mesh.field.setAsBackgroundMesh(minimum)
    gmsh.model.mesh.generate(3)
    gmsh.model.mesh.optimize("Netgen")


def extract_and_write(output, groups, geometry):
    tags, flat, _ = gmsh.model.mesh.getNodes()
    coords0 = np.asarray(flat).reshape((-1,3))
    lookup = {int(tag): i for i, tag in enumerate(tags)}
    types, element_tags, element_nodes = gmsh.model.mesh.getElements(3)
    assert list(types) == [4], f"Expected linear tetrahedra, got {types}"
    tetra = np.array([lookup[int(n)] for n in element_nodes[0]], dtype=np.int32).reshape((-1,4))
    used = np.unique(tetra)
    renumber = np.full(len(tags), -1, dtype=np.int32)
    renumber[used] = np.arange(len(used))
    tetra = renumber[tetra]
    coords = coords0[used]
    centers = coords[tetra].mean(axis=1)
    signed6 = np.einsum('ij,ij->i', np.cross(coords[tetra[:,1]]-coords[tetra[:,0]],
                                           coords[tetra[:,2]]-coords[tetra[:,0]]),
                         coords[tetra[:,3]]-coords[tetra[:,0]])
    assert np.all(signed6 > 0), "Negative or zero tetrahedron volume"
    boundary_keys = {}
    for name, surfaces in groups.items():
        for surf in surfaces:
            stypes, _, snodes = gmsh.model.mesh.getElements(2,surf)
            assert list(stypes) == [2]
            for tri in np.asarray(snodes[0]).reshape((-1,3)):
                key = tuple(sorted(int(renumber[lookup[int(n)]]) for n in tri))
                assert key not in boundary_keys
                boundary_keys[key] = name
    # Every unordered triangle maps to exactly one or two tetrahedra.
    faces = {}
    for cell, tet in enumerate(tetra):
        for inds in [(0,1,2),(0,3,1),(0,2,3),(1,3,2)]:
            key = tuple(sorted(int(tet[i]) for i in inds))
            if key in faces:
                assert faces[key][1] == -1, "Non-manifold volume face"
                faces[key][1] = cell
            else:
                faces[key] = [cell,-1]
    zoned = {"interior": [], **{name:[] for name in groups}}
    adjacency_count = np.zeros(len(tetra),dtype=np.int32)
    closure = np.zeros((len(tetra),3))
    wall_edges = Counter()
    wall_signed_volume = 0.0
    wall_frontal_projection = 0.0
    min_face_area = float('inf')
    for key, (c0,c1) in faces.items():
        a,b,c = key
        vector = np.cross(coords[b]-coords[a],coords[c]-coords[a])/2
        # Legacy Fluent ASCII grid format points the RH normal TOWARD first cell c0.
        # This differs from some runtime/modern CFF conventions: do not swap casually.
        if np.dot(vector, centers[c0]-coords[a]) < 0:
            b,c = c,b
            vector *= -1
        assert np.dot(vector, centers[c0]-coords[a]) > 0
        adjacency_count[c0] += 1
        closure[c0] += vector
        min_face_area = min(min_face_area,float(np.linalg.norm(vector)))
        if c1 >= 0:
            assert key not in boundary_keys
            assert np.dot(vector, centers[c1]-coords[a]) < 0
            adjacency_count[c1] += 1
            closure[c1] -= vector
            name = "interior"
        else:
            assert key in boundary_keys, f"Unclassified boundary {key}"
            name = boundary_keys.pop(key)
        zoned[name].append((a+1,b+1,c+1,c0+1,c1+1))
        if name == "aircraft_wall":
            for edge in [(a,b),(b,c),(c,a)]:
                wall_edges[tuple(sorted(edge))] += 1
            # At aircraft wall the RH normal points out of aircraft into fluid.
            wall_signed_volume += float(np.dot(coords[a], vector))/3
            wall_frontal_projection += abs(float(vector[0]))/2
    assert not boundary_keys, "Unused CAD boundary triangles"
    assert np.all(adjacency_count == 4)
    assert all(v == 2 for v in wall_edges.values()), "Aircraft surface not watertight"
    assert wall_signed_volume > 0
    max_closure = float(np.linalg.norm(closure,axis=1).max())
    assert max_closure < 1e-9
    total = float((signed6/6).sum())
    expected = geometry["box_volume_m3"]-wall_signed_volume
    assert abs(total-expected)/expected < 1e-10
    zones = [(3,"interior","interior",2),(4,"inlet","velocity-inlet",10),
             (5,"outlet","pressure-outlet",5),(6,"farfield","symmetry",7),
             (7,"aircraft_wall","wall",3)]
    path = output / "aircraft_fluent.msh"
    with path.open('w',encoding='ascii',newline='\n') as f:
        f.write('(0 "Generic 3D aircraft external flow; metres; generated and topology checked")\n(2 3)\n')
        f.write(f'(10 (0 1 {len(coords):x} 0 3))\n(12 (0 1 {len(tetra):x} 0))\n')
        f.write(f'(13 (0 1 {len(faces):x} 0))\n(10 (1 1 {len(coords):x} 1 3)(\n')
        for xyz in coords:
            f.write(' '.join(f'{x:.16g}' for x in xyz)+'\n')
        f.write(f'))\n(12 (2 1 {len(tetra):x} 1 2))\n')
        first = 1
        for zid,name,kind,bc in zones:
            entries = zoned[name]
            last = first+len(entries)-1
            f.write(f'(13 ({zid:x} {first:x} {last:x} {bc:x} 3)(\n')
            for row in entries:
                f.write(' '.join(f'{v:x}' for v in row)+'\n')
            f.write('))\n')
            first=last+1
        f.write('(45 (2 fluid fluid 1)())\n')
        for zid,name,kind,_ in zones:
            f.write(f'(45 ({zid} {kind} {name} 1)())\n')
    with (output / "aircraft_surface.stl").open('w',encoding='ascii') as f:
        f.write('solid generic_aircraft\n')
        for a,b,c,_,_ in zoned['aircraft_wall']:
            p=coords[np.array([a,b,c])-1]
            norm=np.cross(p[1]-p[0],p[2]-p[0]); norm/=np.linalg.norm(norm)
            f.write(' facet normal '+' '.join(f'{v:.12g}' for v in norm)+'\n  outer loop\n')
            for xyz in p:
                f.write('   vertex '+' '.join(f'{v:.12g}' for v in xyz)+'\n')
            f.write('  endloop\n endfacet\n')
        f.write('endsolid generic_aircraft\n')
    qualities=np.asarray(gmsh.model.mesh.getElementQualities(element_tags[0],"minSICN"))
    return {
        "passed":True,"mesh_file":str(path),"nodes":len(coords),"cells":len(tetra),
        "faces":len(faces),"boundary_faces":{k:len(v) for k,v in zoned.items()},
        "minimum_cell_volume_m3":float(signed6.min()/6),"maximum_cell_volume_m3":float(signed6.max()/6),
        "total_mesh_volume_m3":total,"body_triangulated_volume_m3":wall_signed_volume,
        "cad_to_triangulated_body_volume_relative_difference":abs(wall_signed_volume-geometry['aircraft_cad_volume_m3'])/geometry['aircraft_cad_volume_m3'],
        "minimum_face_area_m2":min_face_area,"maximum_cell_area_vector_closure_m2":max_closure,
        "all_cells_four_faces":True,"all_boundary_triangles_matched":True,
        "wall_edge_incidence_exactly_two":True,"volume_matches_box_minus_triangulated_aircraft":True,
        "gmsh_minSICN_min":float(qualities.min()),"gmsh_minSICN_mean":float(qualities.mean()),
        "frontal_surface_projection_sum_m2":wall_frontal_projection,
        "frontal_blockage_upper_bound":wall_frontal_projection/(30*24),
        "blockage_note":"Half summed |nx| dA counts overlaps, hence an upper bound for silhouette area.",
        "boundary_layers":"No prism inflation layers; coarse isotropic tetra demonstration, unsuitable for validated drag prediction.",
        "native_mesh_read_check":"Pending in Ansys Fluent; this script validates topology but does not launch Fluent.",
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'geometry')
    parser.add_argument('--surface-size',type=float,default=0.10)
    parser.add_argument('--far-size',type=float,default=3.0)
    parser.add_argument('--aoa',type=float,default=5.0)
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    started=time.time()
    gmsh.initialize()
    gmsh.logger.start()
    try:
        gmsh.model.add('generic_aircraft')
        fluid,groups,geometry=make_geometry(args.output,args.aoa)
        mesh_geometry(groups,args.surface_size,args.far_size)
        gmsh.option.setNumber('Mesh.MshFileVersion',4.1)
        gmsh.write(str(args.output/'aircraft_gmsh.msh'))
        checks=extract_and_write(args.output,groups,geometry)
        report={'geometry':geometry,'mesh':checks,'gmsh_version':gmsh.__version__,
                'surface_size_m':args.surface_size,'far_size_m':args.far_size,
                'elapsed_s':time.time()-started,'sources':SOURCES}
        (args.output/'mesh_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(json.dumps(report,indent=2),flush=True)
    finally:
        (args.output/'gmsh_generation.log').write_text('\n'.join(gmsh.logger.get()),encoding='utf-8')
        gmsh.finalize()


if __name__=='__main__':
    main()
