s.file.write_case_data(file_name=str(run_dir / '07_before_turbulence_refinement.cas.h5'))
factors = s.solution.controls.pseudo_time_explicit_relaxation_factor.global_dt_pseudo_relax
for equation in ['k','omega']:
    factors[equation] = 0.5
    s.solution.controls.advanced.multi_grid.mg_controls[equation].termination_criteria = 0.01
record('turbulence_controls', {'relaxation':factors.get_state(),
                              'multigrid':s.solution.controls.advanced.multi_grid.mg_controls.get_state(),
                              'residual_targets_unchanged':True})
print('TURBULENCE_CONTROLS', factors.get_state())
