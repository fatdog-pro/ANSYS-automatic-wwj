s.file.write_case_data(file_name=str(run_dir / '05_simple_checkpoint.cas.h5'))
s.solution.methods.p_v_coupling.flow_scheme = 'Coupled'
s.solution.methods.pseudo_time_method.formulation.coupled_solver = 'global-time-step'
ts = s.solution.run_calculation.pseudo_time_settings.time_step_method
ts.time_step_method = 'automatic'
ts.time_step_size_scale_factor = 1.0
ts.length_scale_methods = 'conservative'
ts.verbosity = 1
record('coupled_settings', {'pv':s.solution.methods.p_v_coupling.get_state(),
                            'pseudo':s.solution.methods.pseudo_time_method.get_state(),
                            'time_step':ts.get_state()})
print('COUPLED_PSEUDO_TIME_ENABLED', ts.get_state())
