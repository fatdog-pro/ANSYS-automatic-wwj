# Run the already verified native graphics stages against the final field,
# then collect native integrals and save the case/data pair.
stage_root = script_dir
for stage in ('10_flow_graphics.py', '16_wing_section.py', '12_final_values.py'):
    path = stage_root/stage
    exec(compile(path.read_text(encoding='utf-8'),str(path),'exec'),globals())
    print('FINAL_EXPORT_STAGE_DONE',stage,flush=True)
