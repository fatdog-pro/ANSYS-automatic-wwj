s.file.write_case_data(file_name=str(run_dir/'09_before_linear_refinement.cas.h5'))
mg = s.solution.controls.advanced.multi_grid
mg.mg_controls['pressure-coupled'].termination_criteria = 0.001
mg.amg_controls.coupled_parameters.fixed_cycle_parameters.max_cycle = 30
record('final_linear_controls', mg.get_state())
print('Pressure-coupled linear tolerance 0.001, up to 30 AMG cycles; residual acceptance targets unchanged.')
