import shutil
mesh_source = (geometry_dir / 'aircraft_fluent.msh')
assert mesh_source.is_file()
shutil.copy2(mesh_source, run_dir / 'aircraft_mesh.msh')
s = solver.settings
s.file.read_mesh(file_name=str(run_dir / 'aircraft_mesh.msh'))
s.mesh.check()
print('Mesh commands:', s.mesh.command_names)
bc = s.setup.boundary_conditions
zones = {'velocity_inlet':bc.velocity_inlet.get_object_names(),
         'pressure_outlet':bc.pressure_outlet.get_object_names(),
         'wall':bc.wall.get_object_names(),
         'symmetry':bc.symmetry.get_object_names(),
         'fluid':s.setup.cell_zone_conditions.fluid.get_object_names()}
print('ACTUAL_ZONES', zones)
assert zones['wall'] == ['aircraft_wall'], zones
assert zones['velocity_inlet'] == ['inlet'] and zones['pressure_outlet'] == ['outlet']
g = s.results.graphics
if 'aircraft-surface' not in g.mesh.get_object_names():
    g.mesh.create(name='aircraft-surface')
bodymesh = g.mesh['aircraft-surface']
bodymesh.surfaces_list = ['aircraft_wall']
bodymesh.options.edges = True
bodymesh.options.faces = True
bodymesh.display()
g.views.auto_scale()
print('Camera projection choices:', g.views.camera.projection.allowed_values())
g.views.camera.position = [-8,-10,6]
g.views.camera.target = [0,0,0]
g.views.camera.up_vector = [0,0,1]
g.views.camera.field = [9,6.75]
g.picture.use_window_resolution = False
g.picture.x_resolution = 1600
g.picture.y_resolution = 1000
g.picture.driver_options.hardcopy_format = 'png'
g.picture.save_picture(file_name=str(run_dir / '01_aircraft_mesh.png'))
s.file.write_case(file_name=str(run_dir / '01_mesh.cas.h5'))
record('mesh_readback', {'zones':zones, 'file':str(run_dir/'aircraft_mesh.msh'),
                        'graphics':bodymesh.get_state()})
print('Numerics:', s.solution.methods.spatial_discretization.discretization_scheme.get_state())
