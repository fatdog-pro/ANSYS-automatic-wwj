latest = collect_state()
integrals = s.results.report.surface_integrals
report = {
    'forces':latest['force_reports_raw'],
    'mass_flow':latest['mass_flow_raw'],
    'wall_yplus_area_average':integrals.get_area_weighted_avg(surface_names=['aircraft_wall'],report_of='y-plus'),
    'wall_yplus_maximum':integrals.get_facet_max(surface_names=['aircraft_wall'],report_of='y-plus'),
    'surface_pressure_minimum':integrals.get_facet_min(surface_names=['aircraft_wall'],report_of='pressure'),
    'surface_pressure_maximum':integrals.get_facet_max(surface_names=['aircraft_wall'],report_of='pressure'),
    'reference_values':s.setup.reference_values.get_state(),
    'numerical_methods':s.solution.methods.get_state(),
    'geometry':geometry,
    'native_graphics':{'contours':g.contour.get_object_names(),'pathlines':g.pathline.get_object_names(),
                       'scenes':s.results.scene.get_object_names()},
}
record('final_values', report)
(run_dir / 'final_values.json').write_text(json.dumps(report,indent=2,default=str),encoding='utf-8')
s.file.write_case_data(file_name=str(run_dir / 'aircraft.cas.h5'))
print('FINAL_VALUES', report['forces'], 'YPLUS', report['wall_yplus_area_average'],report['wall_yplus_maximum'])
