ts = s.solution.run_calculation.pseudo_time_settings.time_step_method
ts.length_scale_methods = 'user-specified'
ts.length_scale = float(geometry['reference_mean_aerodynamic_chord_m'])
ts.time_step_size_scale_factor = 1.0
record('pseudo_time_chord_length', {'settings':ts.get_state(),
    'reason':'Use the aircraft mean aerodynamic chord as the external-flow length scale, rather than the much larger enclosing box.'})
print('PSEUDO_TIME_CHORD', ts.get_state())
