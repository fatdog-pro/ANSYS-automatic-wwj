schemes = s.solution.methods.spatial_discretization.discretization_scheme
for key in ['mom','k','omega']:
    schemes[key] = 'second-order-upwind'
s.file.write_case_data(file_name=str(run_dir / '04_first_order.cas.h5'))
record('second_order_start', {'schemes':schemes.get_state(), 'after_initial_iterations':50})
quality = s.mesh.quality()
size = s.mesh.size_info()
record('fluent_mesh_quality', {'quality':quality,'size':size})
print('FLUENT_MESH_QUALITY', quality, size)
print('SECOND_ORDER_ENABLED', schemes.get_state())
