s.file.write_case_data(file_name=str(run_dir / '08_before_pressure_refinement.cas.h5'))
s.solution.controls.advanced.multi_grid.mg_controls['pressure-coupled'].termination_criteria = 0.01
record('pressure_linear_solver', {'mg_controls':s.solution.controls.advanced.multi_grid.mg_controls.get_state(),
                                   'residual_targets_unchanged':True})
print('Pressure coupled linear-solver tolerance tightened to 0.01.')
