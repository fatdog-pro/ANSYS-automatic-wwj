# 全身柔性鱼仿真结果

作者：抖音 萌猪过河

实际求解 0.70 s，共 28 步。动画 10 fps，4 倍慢放，未插值、倒放或放大位移。

- 鱼身最大位移：33.504 mm
- 鱼尾最大位移：42.138 mm
- 非线性侧弯指标：1.268 mm
- 最低网格正交质量：0.00519305
- 最大界面误差：0.2088 µm
- 最大相对 ALE 质量误差：1.745e-06

![鱼游动](fish-swimming.gif)

[MP4](fish-swimming.mp4) · [曲线](result-curves.png) · [位移云图](displacement-final.png) · [水侧压力云图](pressure-final.png) · [CSV](results.csv) · [数值摘要](results-summary.json)

[原生 Case（完整版）](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases) 和 [Data（完整版）](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases) 需配对保留，原生 HSF 动画位于上级 fullbody-process/。

首尾闭合检查：未通过，循环接缝有跳变。这是头端约束的教学启动瞬态，未进行网格/时间步独立性或实验校准。水侧压力云图是最终求解时刻的数据，曲线来自真实保存步的 CSV。
