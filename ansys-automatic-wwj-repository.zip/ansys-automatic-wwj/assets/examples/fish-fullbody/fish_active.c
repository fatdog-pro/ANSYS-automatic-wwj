#include "udf.h"
/* Teaching surrogate for active distributed actuation, N/m^3.
 * This is a LOAD, not a prescribed wet-wall position: the complete FE fish
 * remains free to respond to elasticity, inertia and fluid traction.
 * x uses the centroid supplied by Fluent through C_CENTROID. There are no
 * mesh writes, coordinate accumulation or overwrites of the FSI displacement.
 */
DEFINE_SOURCE_FE(active_body_y,c,t)
{
    real p[ND_ND], x, envelope, ramp;
    C_CENTROID(p,c,t);
    x=p[0]/0.2;
    envelope=sin(3.141592653589793*MAX(0.0,MIN(x,1.0)));
    ramp=1.0-exp(-CURRENT_TIME/0.15);
    return 15000.0*envelope*ramp*sin(12.566370614359172*CURRENT_TIME-6.283185307179586*x);
}
