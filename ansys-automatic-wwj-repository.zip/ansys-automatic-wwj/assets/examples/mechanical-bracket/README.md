# ANSYS automatic wwj：机械臂支架展示例程

> **仓库版说明：** 本目录保留代码相关记录及轻量预览。下文所述已求解原生工程、Case/Data、HSF、CAD/网格缓存和全部 Mechanical GIF 位于 [Release 完整包](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases)；新运行会重新生成结果。验收记录是作者历史实测，本次打包未重新求解。

作者：抖音 萌猪过河

本例属于原有 `ansys-automatic-wwj` skill。通过官方 Mechanical MCP 和原生脚本完成；不使用屏幕识别或点击。

## 打开与录屏

原生工程：本目录的 `WWJ_Robot_Bracket.mechdb`。
移动工程时保留同目录的 `WWJ_Robot_Bracket_Mech_Files`，其中包含两项分析的求解结果。

Mechanical 树中有两项分析：

- `01_Static_Combined_Bearing_Load`：展开 Solution，选择 `Static_von_Mises_Stress` 或 `Static_Total_Deformation`。
- `02_Modal_Six_Natural_Modes`：展开 Solution，选择 `Mode_01_Normalized_Shape` 至 `Mode_06_Normalized_Shape`，在结果动画栏点击播放，即可录制原生窗口。也可直接使用导出的 `mode_*.gif`。

建议录制顺序：实体 5 秒 → 网格 5 秒 → 约束/载荷 5 秒 → 应力云图 8 秒 → 第一、二、三阶振型各 8 秒。使用录屏软件自行开始/结束录制；本次没有录制其他桌面内容。

口播示例：

> 一句话，让 ANSYS automatic wwj 用接口完成支架建模、网格划分、静力分析和六阶模态分析。这里不是预先画好的动画，而是 Mechanical 求解后的振型展示。计算完成后还会核对反力平衡，并保存可以重新打开的原生工程。

请保留画面中的 Ansys Student 标记。静态截图采用 200 倍变形显示，模态是归一化振型并放慢播放，不代表真实振幅或真实振动速度。展示真实结果，不称为“已完成全部 Ansys 模块”。

## 本次结果

| 项目 | 结果 |
|---|---|
| 几何 | 一体式钢支架，双腹板、减重孔、根部加强筋、轴承座、4 个安装孔 |
| 外形 | 140 × 100 × 112 mm |
| 材料 | Structural Steel，E=200 GPa，ν=0.3，ρ=7850 kg/m³ |
| 约束 | 底面完全固定，理想刚性安装 |
| 载荷 | 轴承孔面分布合力：X=2000 N、Y=750 N、Z=−1500 N |
| 网格 | 二次单元，45075 节点、25083 实体单元 |
| 最大静态位移 | 0.0306351 mm |
| 最大等效应力 | 70.9695 MPa |
| 反力相对不平衡 | 5.35×10⁻⁷ |
| 前六阶固有频率 | 1088.959、3194.516、4345.069、5843.561、6080.027、6797.851 Hz |
| 本机求解时间 | 静力约 18 秒，模态约 15 秒；不含启动、建模、导出 |

模态为独立、无预应力模态分析，未联接静力预应力。模型未包含螺栓接触、轴承接触、塑性或疲劳。没有做网格收敛研究；最差单元偏斜度约 0.993，局部峰值应力仅作教学展示，不是工程设计认证。

原生日志提示 SHPP 未启用；另通过 Mechanical 网格质量接口检查。静力的 material 2 警告来自施加载荷的 SURF154 表面效应单元，实体材料为 Structural Steel。完整记录保留在 `file.err`、`solve.out`、`material_properties.json` 和 `native_reopen_verification.json`。

## 固定执行路线

1. 含 Gmsh 的 Python 执行 `generate_bracket.py --out <专用英文工作目录>`。
2. 启动专用可见 Mechanical 261，会话保持打开，检查为空。
3. 经官方 MCP 依次执行 `01_import.py`、`02_setup_mesh.py`。
4. 将项目另存为 `<工作目录>/WWJ_Robot_Bracket.mechdb`，执行 `03_solve.py`。
5. 执行 `04_present.py`，通过原生接口生成图片与六个 GIF。
6. 保存、重开同一工程，执行 `05_verify_reopened.py`；最后保留 Mechanical 窗口。

脚本在本次作者目录分阶段实际执行。分发到 skill 的版本通过 `WWJ_RUN_DIR` 指定工作目录；应在每段 Mechanical 脚本开头注入该变量，不把 Python 环境里的变量误当作 Mechanical 会话变量。新电脑需要独立验证依赖、许可证和运行结果，不能用内置旧结果替代本次求解。

动画使用 [Mechanical 官方 ExportAnimation 接口](https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/act_ref/item87174236128117169154112458610616822418346413940239108.html)。本机 Student 的 MP4 导出被许可证拒绝，已采用原生 GIF；不尝试解除许可限制。
