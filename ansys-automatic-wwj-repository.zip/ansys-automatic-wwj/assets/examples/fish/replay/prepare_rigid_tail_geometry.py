"""Derive the rigid-body/flexible-tail mesh from this run's fresh fish mesh.

Run AFTER generate_realistic_fish.py and split_eye_zone.py:
  python prepare_rigid_tail_geometry.py --geometry-dir RUN/geometry

This never generates CAD, reads a cache, launches Ansys, or replaces a source.
The source remains geometry/fish_refined_eyes.msh. The new active mesh is
geometry/active-tail/fish_water_tail.msh. A root geometry/mesh_identity.json
is written only after the complete offline extraction/identity/seam checks.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
sys.dont_write_bytecode=True

def prepare(geometry_dir,check_only=False):
    import export_active_mesh
    geometry=Path(geometry_dir).resolve(strict=True)
    if not geometry.is_dir():raise NotADirectoryError(str(geometry))
    output=geometry/'active-tail';manifest=geometry/'mesh_identity.json'
    if output.exists() or manifest.exists():raise FileExistsError('Refuse to overwrite an existing active-tail export or root identity')
    source=geometry/'fish_refined_eyes.msh';quality=geometry/'mesh_validation.json'
    result=export_active_mesh.export_mesh(source,quality,output,'water-tail',check_only)
    if check_only:return result
    import inspect_export_identity
    identity=inspect_export_identity.inspect_directory(source,output,geometry)
    assert identity['status']=='offline_identity_passed'
    return {'status':'offline_mesh_checks_passed','geometry_dir':str(geometry),
       'source_mesh':str(source),'output_mesh':str(output/'fish_water_tail.msh'),
       'geometry_identity':str(manifest),'active_validation':str(output/'mesh_validation.json'),
       'tail_root_topology':str(output/'tail_root_topology.json'),
       'cells_by_zone':{name:data['cells'] for name,data in result['regions'].items()},
       'min_initial_offline_OQ_by_zone':{name:data['min_initial_offline_Fluent_OQ'] for name,data in result['regions'].items()},
       'source_sha256':result['source_mesh_sha256'],'output_sha256':result['output_mesh_sha256'],
       'native_Fluent_read_validated':False,'motion_or_FSI_solved':False}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--geometry-dir',type=Path,required=True)
    p.add_argument('--check-only',action='store_true',help='Only source hash-chain, quality metadata, output availability and memory checks; no writes or NumPy import')
    args=p.parse_args()
    print(json.dumps(prepare(args.geometry_dir,args.check_only),indent=2))

if __name__=='__main__':main()
