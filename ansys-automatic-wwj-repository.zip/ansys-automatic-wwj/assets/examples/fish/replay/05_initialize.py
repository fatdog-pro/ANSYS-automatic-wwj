"""Initialize at t=0 using the runner's finalized settings; never advance time."""
s = solver.settings
s.solution.run_calculation.parameters.time_step_size = replay_settings['dt_s']
s.solution.run_calculation.parameters.profile_update_interval = 1
s.solution.run_calculation.parameters.max_iter_per_time_step = replay_settings['max_iterations_per_step']
s.solution.methods.p_v_coupling.flow_scheme = replay_settings['flow_scheme']
s.solution.controls.under_relaxation['structure'] = replay_settings['structure_under_relaxation']
for name in s.solution.monitor.residual.equations.get_object_names():
    s.solution.monitor.residual.equations[name].absolute_criteria = 1e-3 if name=='continuity' else 1e-4
s.solution.initialization.defaults['x-velocity'] = 0.05
s.solution.initialization.defaults['y-velocity'] = 0.0
s.solution.initialization.defaults['z-velocity'] = 0.0
s.solution.initialization.standard_initialize()
g = s.results.graphics
if 'fish-surface' not in g.mesh.get_object_names():
    g.mesh.create(name='fish-surface')
g.mesh['fish-surface'].surfaces_list=['fish_drive','body_water','tail_water','fish_eyes']
g.mesh['fish-surface'].options.edges=True
g.mesh['fish-surface'].options.faces=True
g.mesh['fish-surface'].display()
g.views.camera.projection='orthographic'
g.views.camera.position=[0.1,-0.3,0.3]
g.views.camera.target=[0.1,0,0]
g.views.camera.up_vector=[0,0,1]
g.views.camera.field=[0.27,0.18]
initial_time = float(s.solution.run_calculation.transient_controls.flow_time.get_state())
if abs(initial_time) > 1e-12:
    raise RuntimeError('Initialization did not reset physical time to zero.')
record('initialization', {
    'flow_time_s': initial_time,
    'replay_settings': dict(replay_settings),
    'residual_equations': s.solution.monitor.residual.equations.get_state(),
    'flow_scheme': s.solution.methods.p_v_coupling.flow_scheme.get_state(),
})
