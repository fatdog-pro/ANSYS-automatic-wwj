"""Compile and bind the native-tested CG translation; no time advancement.

Only the three prescribed forebody walls use this UDF. The elastic tail and
its complete-section driven root are configured separately by stages 03/04.
Importing this helper does not import an SDK, connect, compile, or write files.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import shutil

RIGID_FOREBODY_ZONES = ('body_water', 'fish_drive', 'fish_eyes')
UDF_FUNCTION = 'fish_rigid_forebody_heave'
UDF_LIBRARY = 'libfish_rigid_tail_motion'
UDF_FILENAME = 'fish_rigid_forebody_motion.c'


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compile_and_bind_forebody_motion(solver, source_path, runtime_directory, zone_mapping):
    """Use public Fluent 261 typed APIs; return actual source/binding readbacks.

The caller supplies an idle dedicated serial session and a fresh ASCII runtime.
This function never changes the FE model, root BC, implicit-mesh controls or
physical time. It neither unloads existing libraries nor guesses UDF suffixes.
"""
    source = Path(source_path).resolve(strict=True)
    runtime = Path(runtime_directory).resolve(strict=True)
    if not runtime.is_dir() or not str(runtime).isascii():
        raise RuntimeError('The compiled-motion runtime must be an existing ASCII directory')
    if source.name != UDF_FILENAME or not source.is_file() or source.stat().st_size == 0:
        raise RuntimeError('Expected the explicit forebody CG motion C source')
    actual_processors = int(solver.application_runtime.get_processor_count())
    if actual_processors != 1:
        raise RuntimeError('The native-tested rigid motion route requires one Fluent process')
    s = solver.settings
    if set(s.setup.cell_zone_conditions.solid.get_object_names()) != {'soft_tail'}:
        raise RuntimeError('Rigid-body/flexible-tail model requires soft_tail as the sole solid cell zone')
    if set(s.setup.cell_zone_conditions.fluid.get_object_names()) != {'water'}:
        raise RuntimeError('Rigid-body/flexible-tail model requires water as the sole fluid cell zone')
    if set(RIGID_FOREBODY_ZONES) - set(zone_mapping):
        raise RuntimeError('The three forebody dynamic-zone identities must be supplied explicitly')
    zones = s.setup.dynamic_mesh.dynamic_zones
    for physical in RIGID_FOREBODY_ZONES:
        zone = zones[zone_mapping[physical]]
        if zone.zone.get_state() != physical or zone.type.get_state() != 'rigid-body':
            raise RuntimeError('Wrong dynamic-zone identity/type for ' + physical)
        existing = zone.motion.motion_def.allowed_values()
        # A clean 261 process returns None before any motion library is loaded.
        # Accept that only when this wall has no selected motion definition.
        if existing is None:
            if zone.motion.motion_def.get_state() not in ('', None):
                raise RuntimeError('Motion choices unavailable for a nonempty native binding')
            existing = []
        if any(value.split('::')[0] == UDF_FUNCTION for value in existing):
            raise RuntimeError('The dedicated forebody UDF is already loaded; refuse stale-library reuse')
    source_sha = _sha(source)
    # Fluent's compiler resolves source directories separately from chdir().
    # Keep the source and library beside the native case and use the exact
    # absolute-path invocation verified by the native two-step probe.
    staged = runtime / UDF_FILENAME
    if staged.exists() and _sha(staged) != source_sha:
        raise RuntimeError('Existing runtime UDF differs from the recorded source')
    if source != staged:
        shutil.copyfile(source, staged)
    if _sha(staged) != source_sha:
        raise RuntimeError('ASCII runtime UDF copy is not byte-identical')
    solver.chdir(runtime.as_posix())
    compiled_source_argument = staged.as_posix()
    s.setup.user_defined.compiled_udf(library_name=UDF_LIBRARY,
        source_files=[compiled_source_argument], header_files=[], use_built_in_compiler=True)
    s.setup.user_defined.load(udf_library_name=UDF_LIBRARY)
    bindings = {}
    for physical in RIGID_FOREBODY_ZONES:
        zone = zones[zone_mapping[physical]]
        allowed = zone.motion.motion_def.allowed_values()
        matches = [value for value in allowed if value.split('::')[0] == UDF_FUNCTION]
        if len(matches) != 1:
            raise RuntimeError('Expected one native compiled forebody UDF binding: ' + repr(allowed))
        zone.motion.motion_def = matches[0]
        zone.motion.relative_motion.enabled = False
        zone.motion.exclude_motion_bc = False
        # With global six-DOF disabled, the parent group itself can be inactive.
        if zone.motion.six_dof.is_active() and zone.motion.six_dof.enabled.is_active():
            zone.motion.six_dof.enabled = False
        zone.motion.rigid_body_properties.cg_position = [0., 0., 0.]
        # Zero angular velocity: retain native orientation. Its API shape is not
        # an Euler vector, as the real pure-motion probe established.
        state = zone.get_state()
        motion = state['motion']
        if (state['zone'] != physical or state['type'] != 'rigid-body'
                or motion['motion_def'] != matches[0]
                or motion['relative_motion']['enabled'] is not False
                or motion['exclude_motion_bc'] is not False):
            raise RuntimeError('Prescribed rigid forebody motion did not read back for ' + physical)
        bindings[physical] = {'dynamic_object': zone_mapping[physical],
                              'allowed_values': allowed, 'selected_binding': matches[0], 'state': state}
    if _sha(source) != source_sha or _sha(staged) != source_sha:
        raise RuntimeError('UDF source changed during native compilation or binding')
    return {'udf_function': UDF_FUNCTION, 'library_name': UDF_LIBRARY,
        'source_path': str(source), 'source_sha256': source_sha,
        'staged_source_path': str(staged), 'staged_source_sha256': _sha(staged),
        'compiled_source_argument': compiled_source_argument,
        'compiler': 'Fluent built-in compiler via use_built_in_compiler=True',
        'actual_processor_count': actual_processors,
        'q_of_t': '0.001*sin(4*pi*t)*(1-exp(-t/0.5)) m; t<=0 -> 0',
        'velocity_formula': '(q(time)-q(time-dtime))/dtime',
        'motion_type': 'Prescribed Y translation, zero angular velocity, no accumulator',
        'native_probe_scope': 'Two pure-mesh-motion steps verified end-time convention and saved-node translation; mixed implicit FSI not established by that probe',
        'model_scope': 'Prescribed rigid forebody including eyes and body fins; only soft_tail is elastic with two-way intrinsic FSI. Tail root follows the same q(t). Not free swimming.',
        'bindings': bindings}
