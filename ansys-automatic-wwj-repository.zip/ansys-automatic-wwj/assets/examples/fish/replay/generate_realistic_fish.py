"""Create a closed, more fish-like 0.2 m CAD and conformal Fluent mesh.

Uses official Gmsh OCC APIs and reuses the independently checked tetrahedral
Fluent exporter from the earlier fish example. Does not import or launch Ansys.
This geometry is a stylized crucian/carp, not a measured biological specimen.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import time

import gmsh
import numpy as np
from fluent_quality import quality as inspect_fluent_quality


BASE = Path(__file__).resolve().parent / 'mesh_export.py'
spec = importlib.util.spec_from_file_location('original_fish_mesh', BASE)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
BOX = (-.10, .40, -.085, .085, -.080, .080)
SPLIT_X = .14
MIN_SICN = .08
OPT_ITERATIONS = 5
OPT_THRESHOLD = .8
EYE_SIZE = .00065
GILL_SIZE = .0005
MESH_FIXED_OPTIONS = {
    'General.NumThreads': 1,
    'Mesh.MaxNumThreads1D': 1,
    'Mesh.MaxNumThreads2D': 1,
    'Mesh.MaxNumThreads3D': 1,
    'Mesh.RandomSeed': 1,
    'Mesh.RandomFactor': 1e-9,
    'Mesh.RandomFactor3D': 1e-12,
    'Mesh.Reproducible': 1,
}
STATIONS = [
    # x, half width, half height, vertical center; all metres.
    (0., .0026, .0035, .002), (.005, .0055, .007, .0025),
    (.014, .0086, .0125, .004), (.028, .0115, .0215, .005),
    (.045, .014, .028, .004), (.070, .015, .031, .002),
    (.095, .013, .026, .0), (.120, .009, .017, -.0005),
    (.140, .0048, .009, .0), (.155, .0025, .005, .0),
    (.163, .0020, .0045, .0),
]


def ellipse_wire(x, ry, rz, zc=0):
    occ = gmsh.model.occ
    curve = occ.addEllipse(0, 0, 0, rz, ry)
    occ.rotate([(1, curve)], 0, 0, 0, 0, 1, 0, -np.pi/2)
    occ.translate([(1, curve)], x, 0, zc)
    return occ.addWire([curve], checkClosed=True)


def smooth_plate(points, vector):
    """Extrude one periodic B-spline outline with rounded, finite edges."""
    occ = gmsh.model.occ
    tags = [occ.addPoint(*p) for p in points]
    curve = occ.addBSpline(tags + tags[:1], degree=3)
    wire = occ.addWire([curve], checkClosed=True)
    surface = occ.addPlaneSurface([wire])
    return [(d, t) for d, t in occ.extrude([(2, surface)], *vector) if d == 3]


def xz_fin(outline, thickness):
    return smooth_plate([(x, -thickness/2, z) for x, z in outline],
                        (0, thickness, 0))


def ellipsoid(center, radii):
    occ = gmsh.model.occ
    entity = (3, occ.addSphere(*center, 1))
    occ.dilate([entity], *center, *radii)
    return entity


def build_fish():
    occ = gmsh.model.occ
    body = occ.addThruSections([ellipse_wire(*s) for s in STATIONS],
                              makeSolid=True, makeRuled=False, maxDegree=5)
    # Rounded, forked caudal fin; broad leading root overlaps the peduncle.
    caudal = [( .151,-.004),(.162,-.007),(.177,-.025),(.191,-.034),
              (.201,-.034),(.199,-.027),(.194,-.016),(.185,-.004),
              (.182,0),(.185,.004),(.194,.016),(.199,.027),
              (.201,.034),(.191,.034),(.177,.025),(.162,.007),(.151,.004)]
    dorsal = [(.037,.012),(.043,.028),(.053,.047),(.064,.045),
              (.086,.040),(.113,.028),(.122,.011),(.099,.014),(.064,.020)]
    anal = [(.083,-.010),(.097,-.025),(.117,-.041),(.130,-.039),
            (.127,-.030),(.139,-.010),(.117,-.005)]
    fins = xz_fin(caudal, .0028) + xz_fin(dorsal, .0028) + xz_fin(anal, .0028)
    pectoral = [(.031,.005),(.043,.014),(.071,.032),(.086,.034),
                (.083,.027),(.066,.016),(.051,.005)]
    for side in (-1, 1):
        # A tilted planar blade; root spans well inside body, tip fans outward.
        points = [(x, side*y, -.002-.35*(y-.007)-.0013) for x,y in pectoral]
        fins += smooth_plate(points, (0, 0, .0026))
    eyes, gills = [], []
    eye_specs, gill_specs = [], []
    for side in (-1, 1):
        eye_specs.append({'center_m':[.021, side*.0094, .010],
                          'radii_m':[.0030,.0020,.0030], 'side':side})
        e = eye_specs[-1]
        eyes.append(ellipsoid(e['center_m'], e['radii_m']))
        # Wide shallow ellipsoid gives a visible rounded operculum outline.
        gill_specs.append({'center_m':[.035, side*.0108, .004],
                           'radii_m':[.008,.0030,.016], 'side':side})
        g = gill_specs[-1]
        gills.append(ellipsoid(g['center_m'], g['radii_m']))
    fused, _ = occ.fuse(body, fins + eyes + gills, removeObject=True, removeTool=True)
    assert len(fused) == 1 and fused[0][0] == 3, f'Fish is not one closed fused solid: {fused}'
    occ.synchronize()
    return fused, {'body_stations_x_ry_rz_zc_m': STATIONS,
                   'caudal_outline_control_points_xz_m':caudal,
                   'dorsal_outline_control_points_xz_m':dorsal,
                   'anal_outline_control_points_xz_m':anal,
                   'pectoral_outline_control_points_xy_m':pectoral,
                   'eyes':eye_specs,'gill_covers':gill_specs,
                   'fin_thickness_m':{'caudal':.0028,'dorsal':.0028,'anal':.0028,'pectoral_vertical':.0026}}


def geometry(output):
    occ = gmsh.model.occ
    fish, details = build_fish()
    fish_volume = occ.getMass(*fish[0])
    fish_bounds = occ.getBoundingBox(*fish[0])
    gmsh.write(str(output/'fish.step'))
    # Use disjoint half-space intersections, then fragment water with both
    # pieces. The final operation merges their coincident interface exactly.
    fish_copy = occ.copy(fish)
    left = occ.addBox(-.05,-.1,-.1,SPLIT_X+.05,.2,.2)
    right = occ.addBox(SPLIT_X,-.1,-.1,.15,.2,.2)
    body, _ = occ.intersect(fish_copy, [(3,left)], removeObject=True, removeTool=True)
    tail, _ = occ.intersect(fish, [(3,right)], removeObject=True, removeTool=True)
    assert len(body) == len(tail) == 1
    x0,x1,y0,y1,z0,z1 = BOX
    box = occ.addBox(x0,y0,z0,x1-x0,y1-y0,z1-z0)
    volumes,maps = occ.fragment([(3,box)],body+tail,removeObject=True,removeTool=True)
    occ.synchronize()
    body_tags={t for d,t in maps[1] if d==3}
    tail_tags={t for d,t in maps[2] if d==3}
    water_tags={t for d,t in volumes if d==3} - body_tags - tail_tags
    assert len(body_tags)==len(tail_tags)==len(water_tags)==1, (body_tags,tail_tags,water_tags)
    assert len(gmsh.model.getEntities(3)) == 3, 'Unexpected detached solid or duplicate volume'
    cells={'water':sorted(water_tags),'stiff_body':sorted(body_tags),'soft_tail':sorted(tail_tags)}
    faces={name:{t for d,t in gmsh.model.getBoundary([(3,v) for v in tags], oriented=False) if d==2}
           for name,tags in cells.items()}
    shared=faces['stiff_body'] & faces['soft_tail']
    assert shared
    groups={k:[] for k in ['inlet','outlet','farfield','fish_drive','body_water','tail_water','body_tail']}
    groups['body_tail']=sorted(shared)
    for surf in sorted(faces['water']):
        bounds=gmsh.model.getBoundingBox(2,surf)
        def plane(axis,val):
            return abs(bounds[axis]-val)<1e-6 and abs(bounds[axis+3]-val)<1e-6
        if plane(0,x0):groups['inlet'].append(surf)
        elif plane(0,x1):groups['outlet'].append(surf)
        elif any(plane(a,v) for a,v in [(1,y0),(1,y1),(2,z0),(2,z1)]):groups['farfield'].append(surf)
        elif surf in faces['stiff_body']:groups['fish_drive' if plane(0,0) else 'body_water'].append(surf)
        elif surf in faces['soft_tail']:groups['tail_water'].append(surf)
        else:raise ValueError(f'Unclassified fluid face: {surf}')
    assert len(groups['fish_drive'])==len(groups['inlet'])==len(groups['outlet'])==1
    assert len(groups['farfield'])==4
    for i,(name,tags) in enumerate(cells.items(),2):gmsh.model.addPhysicalGroup(3,tags,i,name)
    for i,(name,tags) in enumerate(groups.items(),11):gmsh.model.addPhysicalGroup(2,tags,i,name)
    gmsh.write(str(output/'fish_water_domain.step'))
    masses={name:sum(occ.getMass(3,t) for t in tags) for name,tags in cells.items()}
    box_volume=(x1-x0)*(y1-y0)*(z1-z0)
    assert abs(sum(masses.values())-box_volume)<1e-8, (masses,box_volume,fish_volume)
    assert abs(masses['stiff_body']+masses['soft_tail']-fish_volume)<1e-8, (masses,fish_volume)
    geo={'units':'m','nominal_length_m':.20,'split_x_m':SPLIT_X,
         'box_bounds_m':BOX,'box_volume_m3':box_volume,'cad_fish_bounds_m':fish_bounds,
         'cad_volume_m3':masses,'cad_surface_tags':groups,'cad_details':details,
         'description':'Stylized crucian/carp: smooth elliptic body, shallow fused eyes and opercula, peduncle, forked caudal fin, dorsal and anal fins, paired pectoral fins.',
         'drive':'Small anterior x=0 end face; no change to prior named wet/drive/interior groups.',
         'cad_checks':{'single_fused_fish_before_partition':True,'three_conformal_final_volumes':True,
                       'solid_partition_volume_preserved':True,'water_box_volume_preserved':True,
                       'absolute_cad_volume_tolerance_m3':1e-8,
                       'water_box_volume_residual_m3':sum(masses.values())-box_volume,
                       'solid_partition_volume_residual_m3':masses['stiff_body']+masses['soft_tail']-fish_volume},
         'limitations':['Stylized fish, not species-calibrated geometry.',
                        'Finite-thickness rounded fin outlines, without fin-ray grooves/scales.',
                        'New geometry has no inherited FSI solution or native Ansys validation.']}
    return cells,groups,geo


def generate_mesh(groups, body_size, tail_size, far_size, dimension):
    for key,val in MESH_FIXED_OPTIONS.items():
        gmsh.option.setNumber(key,val)
    for key,val in [('Mesh.Algorithm',6),('Mesh.Algorithm3D',10),
                    ('Mesh.ElementOrder',1),('Mesh.MeshSizeFromPoints',0),
                    ('Mesh.MeshSizeFromCurvature',12),('Mesh.MeshSizeExtendFromBoundary',0),
                    ('Mesh.MeshSizeMin',.00035),('Mesh.MeshSizeMax',far_size),('Mesh.Optimize',1),
                    ('Mesh.OptimizeThreshold',.3)]:
        gmsh.option.setNumber(key,val)
    fields=[]
    for surfaces,size,reach in [(groups['body_water']+groups['fish_drive'],body_size,.022),
                                (groups['tail_water']+groups['body_tail'],tail_size,.025)]:
        distance=gmsh.model.mesh.field.add('Distance')
        gmsh.model.mesh.field.setNumbers(distance,'SurfacesList',surfaces)
        gmsh.model.mesh.field.setNumber(distance,'Sampling',50)
        threshold=gmsh.model.mesh.field.add('Threshold')
        for key,val in [('InField',distance),('SizeMin',size),('SizeMax',far_size),
                        ('DistMin',.001),('DistMax',reach)]:
            gmsh.model.mesh.field.setNumber(threshold,key,val)
        fields.append(threshold)
    if EYE_SIZE>0:
        for eyey in [-.0094,.0094]:
            field_eye=gmsh.model.mesh.field.add('Ball')
            for key,val in [('XCenter',.024),('YCenter',eyey),('ZCenter',.010),
                            ('Radius',.008),('Thickness',.008),('VIn',EYE_SIZE),('VOut',far_size)]:
                gmsh.model.mesh.field.setNumber(field_eye,key,val)
            fields.append(field_eye)
    if GILL_SIZE>0:
        for gy in [-.0108,.0108]:
            for gz in [-.012,.020]:
                gill_field=gmsh.model.mesh.field.add('Ball')
                for key,val in [('XCenter',.0345),('YCenter',gy),('ZCenter',gz),
                                ('Radius',.0045),('Thickness',.006),('VIn',GILL_SIZE),('VOut',far_size)]:
                    gmsh.model.mesh.field.setNumber(gill_field,key,val)
                fields.append(gill_field)
    field=gmsh.model.mesh.field.add('Min')
    gmsh.model.mesh.field.setNumbers(field,'FieldsList',fields)
    gmsh.model.mesh.field.setAsBackgroundMesh(field)
    gmsh.model.mesh.generate(dimension)
    if dimension==3:
        gmsh.option.setNumber('Mesh.OptimizeThreshold',OPT_THRESHOLD)
        gmsh.model.mesh.optimize('', niter=OPT_ITERATIONS)
        gmsh.model.mesh.optimize('Netgen', niter=OPT_ITERATIONS)
        gmsh.model.mesh.optimize('', niter=OPT_ITERATIONS)


def inspect_volume_quality(cells):
    """Fail closed before exporting a Fluent mesh with an unacceptable sliver."""
    regions={}
    for name,volumes in cells.items():
        tags=[]
        for volume in volumes:
            types,element_tags,_=gmsh.model.mesh.getElements(3,volume)
            if list(types)!=[4]:raise ValueError('Only linear tetrahedra are supported')
            tags.extend(element_tags[0])
        q=np.asarray(gmsh.model.mesh.getElementQualities(tags,'minSICN'))
        finite=bool(len(q) and np.isfinite(q).all())
        regions[name]={'cells':len(q),'all_finite':finite,
                       'minSICN':float(q.min()) if finite else None,
                       'cells_below_threshold':int(np.count_nonzero(q<MIN_SICN)) if finite else None,
                       'passed':bool(finite and np.all(q>=MIN_SICN))}
    return {'metric':'Gmsh minSICN','minimum_allowed':MIN_SICN,
            'passed':all(r['passed'] for r in regions.values()),'regions':regions,
            'fixed_options':{k:gmsh.option.getNumber(k) for k in MESH_FIXED_OPTIONS},
            'configuration_files_loaded':False,
            'optimization':f'Single-thread HXT threshold=.3; then Gmsh, Netgen, Gmsh niter={OPT_ITERATIONS} each at OptimizeThreshold={OPT_THRESHOLD}',
            'scope':'Mesh quality acceptance only; no CFD or structural convergence claim.'}


def write_surface(output,groups,geo):
    tags,flat,_=gmsh.model.mesh.getNodes()
    xyz=np.asarray(flat).reshape(-1,3)
    lookup={int(t):i for i,t in enumerate(tags)}
    triangles=[]; surface_tags=[]
    for name in ['fish_drive','body_water','tail_water']:
        for surface in groups[name]:
            types,_,nodes=gmsh.model.mesh.getElements(2,surface)
            assert list(types)==[2]
            block=np.asarray([lookup[int(n)] for n in nodes[0]]).reshape(-1,3)
            triangles.extend(block);surface_tags.extend([surface]*len(block))
    triangles=np.asarray(triangles)
    np.savez_compressed(output/'fish_surface_arrays.npz',xyz=xyz,triangles=triangles,surface_tags=np.asarray(surface_tags))
    def stl(path,tris):
        with path.open('w',encoding='ascii') as stream:
            stream.write('solid realistic_fish\n')
            for tri in tris:
                p=xyz[tri]; n=np.cross(p[1]-p[0],p[2]-p[0]);n/=np.linalg.norm(n)
                stream.write(' facet normal '+' '.join(f'{x:.12g}' for x in n)+'\n  outer loop\n')
                for v in p:stream.write('   vertex '+' '.join(f'{x:.12g}' for x in v)+'\n')
                stream.write('  endloop\n endfacet\n')
            stream.write('endsolid realistic_fish\n')
    stl(output/'fish_surface.stl',triangles)
    centers=xyz[triangles].mean(axis=1)
    eye_mask=np.zeros(len(triangles),bool)
    for eye in geo['cad_details']['eyes']:
        center=np.asarray(eye['center_m']);r=np.asarray(eye['radii_m'])
        level=np.sum(((centers-center)/r)**2,axis=1)
        eye_mask |= (level>.92)&(level<1.03)&((centers[:,1]-center[1])*eye['side']>0)
    if eye_mask.any():stl(output/'fish_eyes_surface.stl',triangles[eye_mask])
    return {'surface_triangles':len(triangles),'eye_detail_triangles':int(eye_mask.sum()),
            'mesh_fish_bounds_m':np.vstack([xyz[np.unique(triangles)].min(axis=0),xyz[np.unique(triangles)].max(axis=0)]).tolist()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'geometry')
    parser.add_argument('--cad-only',action='store_true',help='CAD and triangulated surface only; no 3-D volume mesh.')
    parser.add_argument('--body-size',type=float,default=.0018)
    parser.add_argument('--tail-size',type=float,default=.0010)
    parser.add_argument('--far-size',type=float,default=.02)
    parser.add_argument('--max-cells',type=int,default=300000)
    parser.add_argument('--opt-iterations',type=int,default=5)
    parser.add_argument('--opt-threshold',type=float,default=.8)
    parser.add_argument('--eye-size',type=float,default=.00065)
    parser.add_argument('--gill-size',type=float,default=.0005)
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    global OPT_ITERATIONS, OPT_THRESHOLD, EYE_SIZE, GILL_SIZE
    OPT_ITERATIONS=args.opt_iterations;OPT_THRESHOLD=args.opt_threshold;EYE_SIZE=args.eye_size;GILL_SIZE=args.gill_size
    started=time.time();gmsh.initialize(readConfigFiles=False);gmsh.logger.start()
    report={'status':'building','geometry_only':args.cad_only,'gmsh_version':gmsh.__version__}
    try:
        gmsh.model.add('realistic_fish')
        cells,groups,geo=geometry(args.output)
        report['geometry']=geo
        (args.output/'geometry_parameters.json').write_text(json.dumps(geo,indent=2),encoding='utf-8')
        generate_mesh(groups,args.body_size,args.tail_size,args.far_size,2 if args.cad_only else 3)
        report['surface']=write_surface(args.output,groups,geo)
        if not args.cad_only:
            count=sum(len(tags) for tags in gmsh.model.mesh.getElements(3)[1])
            if count>args.max_cells:raise ValueError(f'Mesh {count} exceeds explicit maximum {args.max_cells}')
            report['quality_gate']=inspect_volume_quality(cells)
            report['fluent_quality_gate']=inspect_fluent_quality(cells)
            gmsh.option.setNumber('Mesh.MshFileVersion',4.1)
            gmsh.write(str(args.output/'fish_gmsh.msh'))
            if not report['fluent_quality_gate']['passed'] or not report['quality_gate']['passed']:
                raise ValueError('Mesh quality rejected: default Fluent tetrahedral OQ must be >.001 and Gmsh SICN >=.08 (fast teaching profile)')
            report['mesh']=base.export(args.output,cells,groups,geo,single_solid=False)
            report['mesh']['quality_threshold_minSICN']=MIN_SICN
            report['mesh']['quality_gate_passed']=True
            report['mesh']['quality_threshold_fluent_oq']=.001
            report['mesh']['min_fluent_orthogonal_quality']=min(r['min_orthogonal_quality'] for r in report['fluent_quality_gate']['regions'].values())
            report['mesh']['limitations']=['Isotropic tetrahedra without boundary-layer inflation.',
                 'Fin and eye details are geometric; hydrodynamic/structural accuracy unvalidated.',
                 'Thin fin edges can have one through-thickness tetrahedron locally.',
                 'New geometry requires native read/setup/solve validation; prior 75 steps do not apply.']
        report.update(status='complete',elapsed_s=time.time()-started,
                      sizing_m={'body':args.body_size,'tail':args.tail_size,'far':args.far_size,
                                'eye_ball':EYE_SIZE,'gill_pole_ball':GILL_SIZE},
                      official_api_reference='https://gmsh.info/doc/texinfo/#Namespace-gmsh_002fmodel_002focc')
        print(json.dumps(report,indent=2),flush=True)
    except Exception as exc:
        report.update(status='failed',error=f'{type(exc).__name__}: {exc}',elapsed_s=time.time()-started)
        raise
    finally:
        (args.output/'mesh_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        (args.output/'gmsh_generation.log').write_text('\n'.join(gmsh.logger.get()),encoding='utf-8')
        gmsh.finalize()


if __name__=='__main__':main()
