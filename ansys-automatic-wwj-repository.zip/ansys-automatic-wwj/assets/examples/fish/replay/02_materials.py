"""Water and elastic-tail properties; forebody has no structural cells."""
s = solver.settings
s.setup.general.solver.time = 'unsteady-1st-order'
s.setup.models.viscous.model = 'laminar'
s.setup.models.energy.enabled = False
s.setup.models.structure.model = 'nonlinear-elasticity'
s.setup.models.structure.expert.include_pop_in_fsi_force = False
s.setup.models.structure.expert.include_viscous_fsi_force = True
s.setup.models.structure.controls.unsteady_damping_rayleigh = 'Backward Euler'
for name, youngs in [('tail-elastic', 2e6)]:
    if name not in s.setup.materials.solid.get_object_names():
        s.setup.materials.solid.create(name=name)
    material = s.setup.materials.solid[name]
    material.density.value = 1000.0
    material.struct_youngs_modulus.value = youngs
    material.struct_poisson_ratio.value = 0.35
if 'water-demo' not in s.setup.materials.fluid.get_object_names():
    s.setup.materials.fluid.create(name='water-demo')
water = s.setup.materials.fluid['water-demo']
water.density.value = 1000.0
water.viscosity.value = 0.001
s.setup.cell_zone_conditions.fluid['water'].general.material = 'water-demo'
if set(s.setup.cell_zone_conditions.solid.get_object_names()) != {'soft_tail'}:
    raise RuntimeError('Rigid-forebody candidate requires exactly one solid zone: soft_tail.')
s.setup.cell_zone_conditions.solid['soft_tail'].general.material = 'tail-elastic'
inlet = s.setup.boundary_conditions.velocity_inlet['inlet']
inlet.momentum.velocity_specification_method = 'Components'
for i, velocity in enumerate([0.05, 0.0, 0.0]):
    inlet.momentum.velocity_components[i].value = velocity
s.setup.boundary_conditions.pressure_outlet['outlet'].momentum.gauge_pressure.value = 0.0
s.setup.general.operating_conditions.operating_pressure = 0.0
s.setup.dynamic_mesh.enabled = True
record('materials_setup', {
    'water_density_kg_m3': 1000.0,
    'water_viscosity_pa_s': 0.001,
    'inlet_velocity_m_s': [0.05, 0.0, 0.0],
    'solid_material': 'tail-elastic',
    'solid_density_kg_m3': 1000.0,
    'youngs_modulus_pa': 2e6,
    'poisson_ratio': 0.35,
    'solid_zones': ['soft_tail'],
    'interpretation': 'Only the tail is elastic. The detailed forebody is a prescribed rigid fluid boundary, with no forebody structural solution or free swimming.',
    'structure_model_state': s.setup.models.structure.get_state(),
    'solid_material_state': material.get_state(),
    'water_material_state': water.get_state(),
    'inlet_state': inlet.momentum.get_state(),
})

# Explicit values used by the zero-cycle diagnostic (cold-start reproducibility).
s.setup.models.structure.controls.amg_stabilization = 'bcgstab'
s.setup.models.structure.controls.max_iter = 500
s.setup.models.structure.controls.numerical_damping_factor = 0.0
s.setup.models.structure.controls.enhanced_strain = False
s.setup.models.structure.expert.explicit_fsi_force = False
s.solution.methods.spatial_discretization.gradient_scheme = 'least-square-cell-based'
s.solution.methods.spatial_discretization.discretization_scheme['mom'] = 'second-order-upwind'
s.solution.methods.spatial_discretization.discretization_scheme['pressure'] = 'second-order'
s.solution.methods.high_order_term_relaxation.enable = False
