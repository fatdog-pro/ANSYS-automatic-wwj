"""Conformal tetrahedral Fluent exporter; no geometry builder or entry point."""
from collections import Counter

import gmsh
import numpy as np


def export(output, cells, groups, geo, single_solid=False):
    tags, flat, _=gmsh.model.mesh.getNodes()
    xyz=np.asarray(flat).reshape(-1,3)
    lookup={int(t):i for i,t in enumerate(tags)}
    blocks=[]; cell_zones=[]; all_element_tags=[]
    for name, volumes in cells.items():
        for volume in volumes:
            types, etags, nodes=gmsh.model.mesh.getElements(3, volume)
            assert list(types)==[4]
            block=np.array([lookup[int(n)] for n in nodes[0]],dtype=np.int32).reshape(-1,4)
            blocks.append(block)
            cell_zones.extend([name]*len(block))
            all_element_tags.extend(etags[0])
    tetra=np.vstack(blocks)
    used=np.unique(tetra)
    renumber=np.full(len(tags),-1,dtype=np.int32);renumber[used]=np.arange(len(used))
    tetra=renumber[tetra];xyz=xyz[used]
    centers=xyz[tetra].mean(axis=1)
    signed6=np.einsum('ij,ij->i',np.cross(xyz[tetra[:,1]]-xyz[tetra[:,0]],
                 xyz[tetra[:,2]]-xyz[tetra[:,0]]),xyz[tetra[:,3]]-xyz[tetra[:,0]])
    assert np.all(signed6>0)
    boundary={}
    for name, surfaces in groups.items():
        for surf in surfaces:
            types, _, nodes=gmsh.model.mesh.getElements(2,surf)
            assert list(types)==[2]
            for tri in np.asarray(nodes[0]).reshape(-1,3):
                key=tuple(sorted(int(renumber[lookup[int(n)]]) for n in tri))
                assert key not in boundary
                boundary[key]=name
    faces={}
    for cell,tet in enumerate(tetra):
        for inds in [(0,1,2),(0,3,1),(0,2,3),(1,3,2)]:
            key=tuple(sorted(int(tet[i]) for i in inds))
            if key in faces:
                assert faces[key][1]==-1
                faces[key][1]=cell
            else:faces[key]=[cell,-1]
    interior_names=['interior_water','interior_stiff_body','interior_soft_tail']
    zoned={name:[] for name in interior_names+list(groups)}
    closure=np.zeros((len(tetra),3));adj=np.zeros(len(tetra),dtype=int)
    fluid_interface_edges=Counter()
    for key,(c0,c1) in faces.items():
        a,b,c=key
        vector=np.cross(xyz[b]-xyz[a],xyz[c]-xyz[a])/2
        if np.dot(vector,centers[c0]-xyz[a])<0:
            b,c=c,b;vector*=-1
        assert np.dot(vector,centers[c0]-xyz[a])>0
        closure[c0]+=vector;adj[c0]+=1
        if c1>=0:
            assert np.dot(vector,centers[c1]-xyz[a])<0
            closure[c1]-=vector;adj[c1]+=1
        if key in boundary:
            name=boundary.pop(key)
            if name in ['fish_drive','body_water','tail_water']:
                assert c1>=0 and cell_zones[c0]=='water' and cell_zones[c1]!='water'
                for edge in [(a,b),(b,c),(c,a)]:fluid_interface_edges[tuple(sorted(edge))]+=1
            elif name=='body_tail':
                assert c1>=0 and {cell_zones[c0],cell_zones[c1]}=={'stiff_body','soft_tail'}
            else:assert c1==-1
        else:
            assert c1>=0 and cell_zones[c0]==cell_zones[c1]
            name='interior_'+cell_zones[c0]
        zoned[name].append((a+1,b+1,c+1,c0+1,c1+1))
    assert not boundary and np.all(adj==4)
    assert all(n==2 for n in fluid_interface_edges.values())
    assert np.linalg.norm(closure,axis=1).max()<1e-12
    assert abs(signed6.sum()/6-geo['box_volume_m3'])<1e-12
    counts=Counter(cell_zones)
    cell_specs=[(2,'water','fluid',1,counts['water'])]
    if single_solid:
        cell_specs.append((3,'fish_solid','solid',counts['water']+1,len(tetra)))
    else:
        cell_specs.extend([(3,'stiff_body','solid',counts['water']+1,counts['water']+counts['stiff_body']),
                           (4,'soft_tail','solid',counts['water']+counts['stiff_body']+1,len(tetra))])
    zone_specs=[(10,'interior_water','interior',2),(11,'interior_stiff_body','interior',2),
                (12,'interior_soft_tail','interior',2),(13,'body_tail','interior',2),
                (14,'inlet','velocity-inlet',10),(15,'outlet','pressure-outlet',5),
                (16,'farfield','symmetry',7),(17,'fish_drive','wall',3),
                (18,'body_water','wall',3),(19,'tail_water','wall',3)]
    mesh_path=output/('fish_single_solid_fluent.msh' if single_solid else 'fish_fluent.msh')
    with mesh_path.open('w',encoding='ascii',newline='\n') as f:
        f.write('(0 "Conformal 3D teaching fish intrinsic FSI; SI metres")\n(2 3)\n')
        f.write(f'(10 (0 1 {len(xyz):x} 0 3))\n(12 (0 1 {len(tetra):x} 0))\n')
        f.write(f'(13 (0 1 {len(faces):x} 0))\n(10 (1 1 {len(xyz):x} 1 3)(\n')
        for point in xyz:f.write(' '.join(f'{v:.16g}' for v in point)+'\n')
        f.write('))\n')
        for zid,name,kind,first,last in cell_specs:
            cell_type = 1 if kind == 'fluid' else 17
            f.write(f'(12 ({zid:x} {first:x} {last:x} {cell_type:x} 2))\n')
        first=1
        for zid,name,kind,bc in zone_specs:
            rows=zoned[name];last=first+len(rows)-1
            f.write(f'(13 ({zid:x} {first:x} {last:x} {bc:x} 3)(\n')
            for row in rows:f.write(' '.join(f'{v:x}' for v in row)+'\n')
            f.write('))\n');first=last+1
        for zid,name,kind,_,_ in cell_specs:f.write(f'(45 ({zid} {kind} {name} 1)())\n')
        for zid,name,kind,_ in zone_specs:f.write(f'(45 ({zid} {kind} {name} 1)())\n')
    quality=np.asarray(gmsh.model.mesh.getElementQualities(all_element_tags,'minSICN'))
    report={'passed':True,'mesh_file':str(mesh_path),'nodes':len(xyz),'cells':len(tetra),
            'cells_by_geometric_volume':dict(counts),'solid_cells':len(tetra)-counts['water'],
            'face_zones':{name:len(rows) for name,rows in zoned.items()},
            'all_cells_positive_volume':True,'all_cells_four_faces':True,
            'all_surface_triangles_matched':True,'fluid_solid_interface_closed':True,
            'volume_matches_box':True,'min_cell_volume_m3':float(signed6.min()/6),
            'max_cell_area_vector_closure_m2':float(np.linalg.norm(closure,axis=1).max()),
            'gmsh_minSICN_min':float(quality.min()),'gmsh_minSICN_mean':float(quality.mean()),
            'single_solid':single_solid,'fluent_native_read_validation':'pending',
            'limitations':['Coarse isotropic tetrahedra without boundary layer inflation.',
                           'Tail thickness may have only one tetrahedral layer locally.',
                           'Geometry/topology checked; hydrodynamic accuracy unvalidated.']}
    # Also export simple surface triangles for inspection and reproducible geometry snapshots.
    stl=output/'fish_surface.stl'
    with stl.open('w',encoding='ascii') as f:
        f.write('solid fish\n')
        for name in ['fish_drive','body_water','tail_water']:
            for a,b,c,_,_ in zoned[name]:
                points=xyz[np.array([a,b,c])-1]
                normal=np.cross(points[1]-points[0],points[2]-points[0]);normal/=np.linalg.norm(normal)
                f.write(' facet normal '+' '.join(f'{n:.12g}' for n in normal)+'\n  outer loop\n')
                for point in points:f.write('   vertex '+' '.join(f'{v:.12g}' for v in point)+'\n')
                f.write('  endloop\n endfacet\n')
        f.write('endsolid fish\n')
    return report
