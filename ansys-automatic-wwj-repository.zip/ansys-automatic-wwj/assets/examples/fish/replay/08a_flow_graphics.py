"""Display and export solved water velocity, pressure and solid displacement."""
s = solver.settings
g = s.results.graphics
surfaces = s.results.surfaces
if 'fish-midplane' not in surfaces.plane_surface.get_object_names():
    surfaces.plane_surface.create(name='fish-midplane')
plane = surfaces.plane_surface['fish-midplane']
plane.method = 'xy-plane'
plane.z = 0.0
g.picture.use_window_resolution = False
g.picture.x_resolution = 1400
g.picture.y_resolution = 900
g.picture.driver_options.hardcopy_format = 'png'

for name, field, selected in [
    ('fish-water-velocity', 'velocity-magnitude', ['fish-midplane']),
    ('fish-water-pressure', 'pressure', ['body_water', 'tail_water', 'fish_drive', 'fish_eyes']),
]:
    if name not in g.contour.get_object_names():
        g.contour.create(name=name)
    contour = g.contour[name]
    contour.field = field
    contour.surfaces_list = selected
    contour.options.filled = True
    contour.options.node_values = True
    contour.range_options.auto_range = True
    contour.range_options.global_range = False
    contour.display()
    g.views.camera.projection = 'orthographic'
    if name == 'fish-water-velocity':
        g.views.camera.position = [0.15, 0, 0.5]
        g.views.camera.target = [0.15, 0, 0]
        g.views.camera.up_vector = [0, 1, 0]
        g.views.camera.field = [0.62, 0.36]
    else:
        g.views.restore_view(view_name='fish-oblique')
    g.picture.save_picture(file_name=run_dir+'/'+name+'.png')

s.results.scene['fish-moving-geometry'].display()
g.views.restore_view(view_name='fish-oblique')
g.picture.save_picture(file_name=run_dir+'/fish-displacement.png')
record('native_flow_graphics', {
    'flow_time_s': s.solution.run_calculation.transient_controls.flow_time.get_state(),
    'contours': ['fish-water-velocity', 'fish-water-pressure', 'fish-displacement'],
    'deformation_scale': 'Physical moving mesh, no additional display deformation',
    'structural_contour_scope': 'Elastic tail only; forebody is prescribed rigid moving geometry.',
})
