"""Offline linear-tet quality, using documented Fluent default definitions."""
import gmsh
import numpy as np


def quality(cells):
    tags, coord, _ = gmsh.model.mesh.getNodes()
    xyz = np.asarray(coord).reshape(-1, 3)
    lookup = {int(t): i for i, t in enumerate(tags)}
    blocks, sizes, etags = [], {}, []
    for name, volumes in cells.items():
        n = 0
        for volume in volumes:
            types, ets, nodes = gmsh.model.mesh.getElements(3, volume)
            assert list(types) == [4]
            block = np.array([lookup[int(v)] for v in nodes[0]]).reshape(-1, 4)
            blocks.append(block); etags.extend(ets[0]); n += len(block)
        sizes[name] = n
    tet = np.vstack(blocks)
    p = xyz[tet]; ctr = p.mean(axis=1)
    a = p[:, 1:] - p[:, 0, None]
    volume = np.abs(np.linalg.det(a))/6
    r = np.linalg.norm(np.linalg.solve(2*a, np.sum(a*a, axis=2)[..., None])[..., 0], axis=1)
    equivolume = 9*np.sqrt(3)*volume/(8*r**3)
    idx = np.array([[1,2,3],[0,3,2],[0,1,3],[0,2,1]])
    face = p[:, idx]
    centers = face.mean(axis=2)
    norm = np.cross(face[:, :, 1]-face[:, :, 0], face[:, :, 2]-face[:, :, 0])
    norm /= np.linalg.norm(norm, axis=2)[..., None]
    cf = centers-ctr[:, None]
    ortho = (np.abs(np.sum(norm*cf, axis=2))/np.linalg.norm(cf, axis=2)).min(axis=1)
    faceids = np.sort(tet[:, idx].reshape(-1, 3), axis=1)
    order = np.lexsort(faceids.T[::-1])
    sortedfaces = faceids[order]
    pair = np.flatnonzero(np.all(sortedfaces[:-1] == sortedfaces[1:], axis=1))
    first, second = order[pair], order[pair+1]
    c0, c1 = first//4, second//4
    # Two-sided water/solid walls ignore opposite-side centroid vectors.
    water_count = sizes['water']
    valid = ((c0 < water_count) == (c1 < water_count))
    first, second, c0, c1 = first[valid], second[valid], c0[valid], c1[valid]
    delta = ctr[c1]-ctr[c0]
    cos = np.abs(np.sum(norm.reshape(-1,3)[first]*delta, axis=1))/np.linalg.norm(delta, axis=1)
    np.minimum.at(ortho, c0, cos); np.minimum.at(ortho, c1, cos)
    oq = np.minimum(ortho, equivolume)
    sicn = np.asarray(gmsh.model.mesh.getElementQualities(etags, 'minSICN'))
    areas = np.linalg.norm(np.cross(face[:,:,1]-face[:,:,0], face[:,:,2]-face[:,:,0]),axis=2)/2
    dnorm = 3*volume[:,None]/(4*areas)
    dvert = np.linalg.norm(p-ctr[:,None], axis=2)
    dist = np.concatenate([dnorm, dvert], axis=1)
    aspect = dist.max(axis=1)/dist.min(axis=1)
    report = {}; start = 0
    for name, count in sizes.items():
        sl = slice(start,start+count); worst = start+int(np.argmin(oq[sl]))
        report[name] = {'cells':count, 'min_orthogonal_quality':float(oq[sl].min()),
            'min_orthogonality':float(ortho[sl].min()), 'min_equivolume_quality':float(equivolume[sl].min()),
            'max_equivolume_skewness':float(1-equivolume[sl].min()),
            'minSICN':float(sicn[sl].min()), 'min_volume_m3':float(volume[sl].min()),
            'max_fluent_aspect_ratio':float(aspect[sl].max()),
            'cells_below_001':int(np.count_nonzero(oq[sl]<.01)),
            'cells_below_005':int(np.count_nonzero(oq[sl]<.05)),
            'cells_below_01':int(np.count_nonzero(oq[sl]<.1)),
            'worst_element_tag':int(etags[worst]), 'worst_centroid_m':ctr[worst].tolist()}
        start += count
    return {'metric':'Default Fluent tetrahedral orthogonal quality (offline reconstruction)',
        'formula':'min(face/cell-centroid orthogonality, V / regular-tet-volume-with-same-circumradius)',
        'reference':'https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/flu_ug/flu_ug_GridQuality.html',
        'minimum_allowed':.001, 'preferred_minimum':.1,
        'passed':bool(np.isfinite(oq).all() and np.all(oq>.001) and np.all(sicn>0)),
        'preferred_target_passed':bool(np.all(oq>=.1)),
        'regions':report}
