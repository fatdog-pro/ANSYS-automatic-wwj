"""Filter this run's fresh undeformed ASCII Fluent mesh without CAD/Gmsh/Ansys.

water-tail retains every water/tail tetrahedron and coordinate. The deleted
body's wet surfaces become one-sided fluid walls, and the complete body_tail
section becomes a one-sided structural tail_root wall with reversed normal.
water-only is a separate rigid-motion mechanism probe, not an FSI model.
"""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import time

EXPECTED={'water':26638,'stiff_body':20927,'soft_tail':5030}
EXPECTED_FACES={'interior_water': 46911, 'interior_stiff_body': 37390, 'interior_soft_tail': 8605, 'body_tail': 94, 'inlet': 82, 'outlet': 82, 'farfield': 916, 'fish_drive': 21, 'body_water': 8573, 'fish_eyes': 240, 'tail_water': 2816}
np=None

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

class Memory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),
      ('total_physical',ctypes.c_ulonglong),('available_physical',ctypes.c_ulonglong),
      ('total_pagefile',ctypes.c_ulonglong),('available_pagefile',ctypes.c_ulonglong),
      ('total_virtual',ctypes.c_ulonglong),('available_virtual',ctypes.c_ulonglong),
      ('available_extended_virtual',ctypes.c_ulonglong)]

def memory_status():
    m=Memory();m.length=ctypes.sizeof(m)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
    floor=1024**3
    return {'physical_load_percent':m.load,'available_physical_bytes':m.available_physical,
      'remaining_commit_bytes':m.available_pagefile,'minimum_free_physical_and_commit_bytes':floor,
      'expected_export_working_memory_budget_bytes':256*1024**2,
      'basis':'Array-only ASCII extraction: conservative256MiB working budget plus768MiB headroom; no Gmsh or Ansys process.',
      'passed':m.available_physical>=floor and m.available_pagefile>=floor}

def parse(path):
    text=path.read_text(encoding='ascii')
    names={int(i):{'kind':kind,'name':name} for i,kind,name in re.findall(r'\(45 \((\d+) ([\w-]+) ([\w-]+) 1\)',text)}
    node=re.search(r'\(10 \(1 1 ([0-9a-f]+) 1 3\)\(\n(.*?)\n\)\)',text,re.S)
    assert node is not None
    lines=node[2].splitlines()
    xyz=np.fromstring(node[2],sep=' ',dtype=float).reshape(-1,3)
    assert len(lines)==len(xyz)==int(node[1],16)
    cells=[]
    for zid,lo,hi,kind in re.findall(r'\(12 \(([0-9a-f]+) ([0-9a-f]+) ([0-9a-f]+) ([0-9a-f]+) 2\)\)',text):
        zid,lo,hi,kind=map(lambda x:int(x,16),(zid,lo,hi,kind))
        cells.append({'id':zid,'first':lo,'last':hi,'cell_type':kind,**names[zid]})
    blocks=[]
    for zid,lo,hi,kind,rows in re.findall(r'\(13 \(([0-9a-f]+) ([0-9a-f]+) ([0-9a-f]+) ([0-9a-f]+) 3\)\(\n(.*?)\n\)\)',text,re.S):
        zid,lo,hi,kind=map(lambda x:int(x,16),(zid,lo,hi,kind))
        flat=np.fromiter((int(v,16) for row in rows.splitlines() for v in row.split()),dtype=np.int32,count=(hi-lo+1)*5)
        blocks.append({'id':zid,'first':lo,'last':hi,'bc':kind,'rows':flat.reshape(-1,5),**names[zid]})
    assert cells and blocks and all(b['first']==(1 if i==0 else blocks[i-1]['last']+1) for i,b in enumerate(blocks))
    return {'xyz':xyz,'coordinate_lines':lines,'cells':cells,'blocks':blocks,
            'rows':np.vstack([b['rows'] for b in blocks]),'cell_count':max(z['last'] for z in cells)}

def tets(mesh):
    rows=mesh['rows'];n=mesh['cell_count'];valid=rows[:,4]>0
    cell=np.concatenate([rows[:,3]-1,rows[valid,4]-1])
    face=np.concatenate([np.arange(len(rows),dtype=np.int32),np.flatnonzero(valid).astype(np.int32)])
    order=np.argsort(cell,kind='stable')
    assert np.array_equal(cell[order],np.repeat(np.arange(n),4)), 'Each cell must have exactly four faces'
    raw=np.sort(rows[face[order],:3].reshape(n,12),axis=1)
    tet=raw[:,::3]-1
    assert np.array_equal(raw,np.repeat(tet+1,3,axis=1)), 'Four unique tet vertices required'
    assert np.all(np.diff(tet,axis=1)>0)
    return tet

def quality(xyz,tet,rows,active,water_last):
    """Default Fluent tet OQ, including internal same-phase centroid directions."""
    p=xyz[tet[active]];centers=xyz[tet].mean(axis=1)
    a=p[:,1:]-p[:,0,None]
    volume=np.abs(np.linalg.det(a))/6
    radius=np.linalg.norm(np.linalg.solve(2*a,np.sum(a*a,axis=2)[...,None])[...,0],axis=1)
    equivolume=9*np.sqrt(3)*volume/(8*radius**3)
    ortho=np.ones(len(active))
    for idx in ((1,2,3),(0,3,2),(0,1,3),(0,2,1)):
        f=p[:,idx];normal=np.cross(f[:,1]-f[:,0],f[:,2]-f[:,0])
        normal/=np.linalg.norm(normal,axis=1)[:,None]
        cf=f.mean(axis=1)-centers[active]
        ortho=np.minimum(ortho,np.abs(np.sum(normal*cf,axis=1))/np.linalg.norm(cf,axis=1))
    index=np.full(len(tet),-1,dtype=np.int32);index[active]=np.arange(len(active),dtype=np.int32)
    c0=rows[:,3]-1;c1=rows[:,4]-1
    interior=c1>=0
    # The canonical fluid/solid shared walls do not include opposite-side centroids.
    valid=interior & ((c0<water_last)==(c1<water_last))
    valid &= (index[c0]>=0)|((c1>=0)&(index[np.maximum(c1,0)]>=0))
    r=rows[valid];i0=c0[valid];i1=c1[valid]
    f=xyz[r[:,:3]-1];normal=np.cross(f[:,1]-f[:,0],f[:,2]-f[:,0])
    normal/=np.linalg.norm(normal,axis=1)[:,None]
    delta=centers[i1]-centers[i0]
    cosine=np.abs(np.sum(normal*delta,axis=1))/np.linalg.norm(delta,axis=1)
    for ids in (i0,i1):
        ok=index[ids]>=0;np.minimum.at(ortho,index[ids[ok]],cosine[ok])
    return np.minimum(ortho,equivolume),volume

def edge_counts(tris,nodes):
    edge=np.sort(tris[:,[[0,1],[1,2],[2,0]]].reshape(-1,2),axis=1).astype(np.int64)
    key=edge[:,0]*(nodes+1)+edge[:,1]
    return np.unique(key,return_counts=True)

def components(pairs,first,last):
    parent=np.arange(last-first+1,dtype=np.int32)
    def root(v):
        while parent[v]!=v:parent[v]=parent[parent[v]];v=int(parent[v])
        return v
    for a,b in pairs:
        x,y=root(int(a)-first),root(int(b)-first)
        if x!=y:parent[y]=x
    return len({root(i) for i in range(len(parent))})

def write_mesh(path,source,blocks,cellzones,used,node_map,cell_map):
    nfaces=sum(len(b['rows']) for b in blocks)
    with path.open('w',encoding='ascii',newline='\n') as f:
        f.write('(0 "Canonical undeformed fish mesh extraction; SI metres; independent research model")\n(2 3)\n')
        f.write(f'(10 (0 1 {len(used):x} 0 3))\n(12 (0 1 {max(z["last"] for z in cellzones):x} 0))\n(13 (0 1 {nfaces:x} 0))\n')
        f.write(f'(10 (1 1 {len(used):x} 1 3)(\n')
        for old in used:f.write(source['coordinate_lines'][int(old)-1]+'\n')
        f.write('))\n')
        for z in cellzones:f.write(f'(12 ({z["id"]:x} {z["first"]:x} {z["last"]:x} {z["cell_type"]:x} 2))\n')
        first=1
        for b in blocks:
            last=first+len(b['rows'])-1;b['new_first']=first;b['new_last']=last
            f.write(f'(13 ({b["id"]:x} {first:x} {last:x} {b["bc"]:x} 3)(\n')
            for row in b['rows']:f.write(' '.join(f'{int(v):x}' for v in row)+'\n')
            f.write('))\n');first=last+1
        for z in cellzones:f.write(f'(45 ({z["id"]} {z["kind"]} {z["name"]} 1)())\n')
        for b in blocks:f.write(f'(45 ({b["id"]} {b["kind"]} {b["name"]} 1)())\n')

def source_evidence(source,record):
    """Use current adjacent files and their hashes, never an old machine path."""
    qmeta=json.loads(record.read_text(encoding='utf-8-sig'))
    assert qmeta['status']=='complete' and qmeta['mesh']['cells_by_geometric_volume']==EXPECTED
    assert not qmeta['geometry_only'] and not qmeta['mesh']['single_solid']
    assert qmeta['geometry']['units']=='m' and abs(qmeta['geometry']['split_x_m']-.14)<1e-12
    assert qmeta['fluent_quality_gate']['passed'] and qmeta['quality_gate']['passed']
    for name in EXPECTED:
        region=qmeta['quality_gate']['regions'][name]
        fluent=qmeta['fluent_quality_gate']['regions'][name]
        assert region['cells']==EXPECTED[name] and fluent['cells']==EXPECTED[name]
        assert region['passed'] and region['all_finite'] and float(region['minSICN'])>=.08
        assert float(fluent['min_orthogonal_quality'])>.001
    split_path=source.parent/'eye-zone-split.json'
    base_path=source.parent/'fish_fluent.msh'
    split=json.loads(split_path.read_text(encoding='utf-8-sig'))
    assert sha(source)==split['output_sha256'], 'Current eye-split mesh hash differs from split record'
    assert sha(base_path)==split['source_sha256'], 'Current unsplit mesh hash differs from split record'
    for key in ('node_section_unchanged','original_face_connectivity_and_adjacency_preserved','volume_zones_unchanged'):
        assert split[key] is True, key
    assert split['eye_zone_name']=='fish_eyes' and split['eye_zone_id']==20
    assert split['eye_faces']==EXPECTED_FACES['fish_eyes'] and split['body_faces_after']==EXPECTED_FACES['body_water']
    return qmeta,{'source_mesh_sha256':sha(source),'quality_record_sha256':sha(record),
       'unsplit_mesh':str(base_path),'unsplit_mesh_sha256':sha(base_path),
       'eye_split_record':str(split_path),'eye_split_record_sha256':sha(split_path)}

def export_mesh(source,record,output,mode='water-tail',check_only=False):
    """Return the offline validation record; create only a new output directory."""
    source=Path(source).resolve(strict=True);record=Path(record).resolve(strict=True)
    output=Path(output).resolve()
    if mode not in ('water-tail','water-only'):raise ValueError('Unsupported extraction mode')
    qmeta,evidence=source_evidence(source,record)
    mem=memory_status()
    if check_only:return {'source_input_verified':True,'source_evidence':evidence,'memory':mem,'mode':mode,'mesh_created':False}
    if not mem['passed']:raise RuntimeError(json.dumps({'status':'not_run_memory_guard','memory':mem}))
    if output.exists():raise FileExistsError('Use a new output directory: '+str(output))
    global np
    os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    import numpy as np
    started=time.time();original=parse(source)
    counts={z['name']:z['last']-z['first']+1 for z in original['cells']}
    assert counts==EXPECTED
    assert {b['name']:len(b['rows']) for b in original['blocks']}==EXPECTED_FACES
    assert [(z['id'],z['name'],z['first'],z['last']) for z in original['cells']]==[
      (2,'water',1,26638),(3,'stiff_body',26639,47565),(4,'soft_tail',47566,52595)]
    assert len(original['xyz'])==qmeta['mesh']['nodes'] and np.all(np.isfinite(original['xyz']))
    oldtet=tets(original)
    sourceq,sourcevol=quality(original['xyz'],oldtet,original['rows'],np.arange(len(oldtet)),EXPECTED['water'])
    assert np.all(np.isfinite(sourceq)) and np.all(sourceq>.001) and np.all(sourcevol>0)
    for zone in original['cells']:
        sl=slice(zone['first']-1,zone['last']);fluent=qmeta['fluent_quality_gate']['regions'][zone['name']]
        assert np.isclose(sourceq[sl].min(),fluent['min_orthogonal_quality'],rtol=1e-8,atol=1e-12), 'Fresh mesh and quality record disagree'
        assert np.isclose(sourcevol[sl].min(),fluent['min_volume_m3'],rtol=1e-8,atol=1e-24)
    active_names=['water','soft_tail'] if mode=='water-tail' else ['water']

    # Existing extraction/verification logic continues below. The source identity
    # is pinned for this call only and rechecked before successful return.
    active=np.concatenate([np.arange(z['first']-1,z['last']) for z in original['cells'] if z['name'] in active_names])
    cellmap=np.zeros(original['cell_count']+1,dtype=np.int32);cellmap[active+1]=np.arange(1,len(active)+1)
    used=np.unique(oldtet[active])+1
    nodemap=np.zeros(len(original['xyz'])+1,dtype=np.int32);nodemap[used]=np.arange(1,len(used)+1)
    facemap=np.zeros(len(original['rows'])+1,dtype=np.int32)
    blocks=[];zone_changes=[];nextface=1
    for original_block in original['blocks']:
        name=original_block['name'];rows=original_block['rows']
        if name=='interior_stiff_body' or (mode=='water-only' and name in ['interior_soft_tail','body_tail']):
            zone_changes.append({'source_name':name,'source_id':original_block['id'],'source_faces':len(rows),'action':'remove_inactive_cell_internal_faces'})
            continue
        b={k:v for k,v in original_block.items() if k!='rows'};r=rows.copy()
        if name=='body_tail':
            assert mode=='water-tail'
            assert np.all(cellmap[r[:,3]]==0) and np.all(cellmap[r[:,4]]>0)
            assert np.max(np.abs(original['xyz'][r[:,:3]-1,0]-.14))<1e-12
            r[:,[1,2]]=r[:,[2,1]];r[:,3]=r[:,4];r[:,4]=0
            b.update(name='tail_root',kind='wall',bc=3)
            action='reverse_all_original_interface_faces_to_one_sided_tail_root'
        elif name in ['body_water','fish_drive','fish_eyes'] or (mode=='water-only' and name=='tail_water'):
            assert np.all(cellmap[r[:,3]]>0) and np.all(cellmap[r[:,4]]==0)
            r[:,4]=0;action='same_triangles_single_sided_water_wall'
        else:action='retain_geometry_and_adjacency_with_ID_mapping'
        r[:,:3]=nodemap[r[:,:3]];r[:,3:5]=cellmap[r[:,3:5]]
        assert np.all(r[:,:4]>0)
        b['rows']=r;blocks.append(b)
        facemap[original_block['first']:original_block['last']+1]=np.arange(nextface,nextface+len(r))
        nextface+=len(r)
        zone_changes.append({'source_name':name,'output_name':b['name'],'zone_id':b['id'],'source_faces':len(rows),'output_faces':len(r),'action':action})
    cellzones=[]
    for z in original['cells']:
        if z['name'] in active_names:cellzones.append({**z,'first':int(cellmap[z['first']]),'last':int(cellmap[z['last']])})
    output.mkdir(parents=True,exist_ok=False)
    path=output/('fish_water_tail.msh' if mode=='water-tail' else 'fish_water_only.msh')
    write_mesh(path,original,blocks,cellzones,used,nodemap,cellmap)
    new=parse(path);newtet=tets(new)
    assert np.array_equal(new['xyz'],original['xyz'][used-1])
    assert np.array_equal(newtet,nodemap[oldtet[active]+1]-1)
    assert len(np.unique(newtet))==len(new['xyz']), 'Orphan nodes are forbidden'
    oldq,oldvol=quality(original['xyz'],oldtet,original['rows'],active,EXPECTED['water'])
    newq,newvol=quality(new['xyz'],newtet,new['rows'],np.arange(len(newtet)),EXPECTED['water'])
    assert np.array_equal(oldvol,newvol) and np.all(newvol>0)
    assert np.all(newq>.001) and np.all(newq>=oldq-1e-12)
    assert np.array_equal(oldq[:EXPECTED['water']],newq[:EXPECTED['water']])
    centers=new['xyz'][newtet].mean(axis=1)
    rows=new['rows'];tri=new['xyz'][rows[:,:3]-1]
    area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])/2
    c0=rows[:,3]-1;c1=rows[:,4]-1;inside=c1>=0
    assert np.all(np.sum(area*(centers[c0]-tri[:,0]),axis=1)>0)
    assert np.all(np.sum(area[inside]*(centers[c1[inside]]-tri[inside,0]),axis=1)<0)
    closure=np.zeros((len(newtet),3));np.add.at(closure,c0,area);np.add.at(closure,c1[inside],-area[inside])
    assert np.linalg.norm(closure,axis=1).max()<1e-12
    byname={b['name']:b for b in new['blocks']}
    wet=np.vstack([byname[n]['rows'][:,:3] for n in ['body_water','fish_drive','fish_eyes','tail_water']])
    _,wetcounts=edge_counts(wet,len(new['xyz']));assert np.all(wetcounts==2)
    root_check=None
    if mode=='water-tail':
        root=byname['tail_root']['rows'];tail=byname['tail_water']['rows']
        assert len(root)==94 and np.all(root[:,4]==0) and np.all(root[:,3]>EXPECTED['water'])
        assert np.all(tail[:,3]<=EXPECTED['water']) and np.all(tail[:,4]>EXPECTED['water'])
        _,tailcounts=edge_counts(np.vstack([root[:,:3],tail[:,:3]]),len(new['xyz']));assert np.all(tailcounts==2)
        rootedges,rootcounts=edge_counts(root[:,:3],len(new['xyz']));tailedges,tailcounts=edge_counts(tail[:,:3],len(new['xyz']))
        front=np.vstack([byname[n]['rows'][:,:3] for n in ['body_water','fish_drive','fish_eyes']])
        frontedges,frontcounts=edge_counts(front,len(new['xyz']))
        assert np.array_equal(rootedges[rootcounts==1],tailedges[tailcounts==1])
        assert np.array_equal(rootedges[rootcounts==1],frontedges[frontcounts==1])
        root_check={'all_original_94_section_faces_retained':True,'all_x_0_14_m':True,'one_sided_tail_cell_only':True,
          'tail_closed_with_root':True,'root_tail_and_body_seam_edges_identical':True,
          'section_faces':len(root),'section_nodes':len(np.unique(root[:,:3])),
          'seam_edges':int(np.count_nonzero(rootcounts==1))}
    else:assert all(np.all(byname[n]['rows'][:,4]==0) for n in ['body_water','fish_drive','fish_eyes','tail_water'])
    regions={}
    for z in new['cells']:
        sl=slice(z['first']-1,z['last']);name=z['name']
        ncomponents=components(byname['interior_'+name]['rows'][:,3:5],z['first'],z['last'])
        assert ncomponents==1
        inherited=qmeta['quality_gate']['regions'][name]['minSICN']
        assert inherited>=.08
        regions[name]={'cells':z['last']-z['first']+1,'nodes':len(np.unique(newtet[sl])),'connected_components':ncomponents,
          'min_initial_offline_Fluent_OQ':float(newq[sl].min()),'min_source_offline_Fluent_OQ':float(oldq[sl].min()),
          'OQ_cells_changed_due_to_removed_neighbor':int(np.count_nonzero(newq[sl]!=oldq[sl])),
          'OQ_no_decrease':bool(np.all(newq[sl]>=oldq[sl]-1e-12)),
          'source_minSICN_inherited_by_identical_tetrahedra':inherited,'min_cell_volume_m3':float(newvol[sl].min()),
          'active_region_volume_m3':float(newvol[sl].sum())}
    np.savez_compressed(output/'source_to_active_ids.npz',source_node_id_to_active_id=nodemap,
       source_cell_id_to_active_id=cellmap,source_face_id_to_active_id=facemap,
       active_node_id_to_source_id=np.concatenate([[0],used]),active_cell_id_to_source_id=np.concatenate([[0],active+1]))
    mapping={'indexing':'Index is source ID; value0 means removed. All IDs are1-based, index0 is sentinel.',
      'source_nodes':len(original['xyz']),'active_nodes':len(new['xyz']),
      'removed_inactive_only_nodes':len(original['xyz'])-len(new['xyz']),
      'source_cells':len(oldtet),'active_cells':len(newtet),'removed_cells':len(oldtet)-len(newtet),
      'source_faces':len(original['rows']),'active_faces':len(new['rows']),
      'node_coordinate_values_preserved_bitwise':True,'copied_coordinate_text_lines_unchanged':True,
      'retained_tetrahedra_exact_after_mapping':True,'no_orphan_nodes':True,'zone_changes':zone_changes}
    result={'status':'offline_mesh_checks_passed','mode':mode,'source_mesh':str(source),'source_mesh_sha256':sha(source),
      'fresh_source_chain':evidence,
      'source_quality_record':str(record),'source_quality_record_sha256':sha(record),
      'output_mesh':str(path),'output_mesh_sha256':sha(path),'memory_preflight':mem,'mapping':mapping,
      'regions':regions,'face_zones':{n:{'id':b['id'],'type':b['kind'],'faces':len(b['rows']),'one_sided_faces':int(np.count_nonzero(b['rows'][:,4]==0))} for n,b in byname.items()},
      'checks':{'all_cells_have_four_faces_and_four_vertices':True,'all_oriented_faces_correct_for_adjacent_cells':True,
        'all_retained_cells_positive_initial_volume':True,'max_area_vector_closure_m2':float(np.linalg.norm(closure,axis=1).max()),
        'complete_fish_wet_surface_closed':True,'all_original_wet_geometry_retained':True,'all_regions_connected':True,
        'all_initial_OQ_strictly_greater_0_01':True,'all_source_SICN_at_least_0_1_inherited':True},
      'tail_root':root_check,'elapsed_s':time.time()-started,
      'native_Fluent_read_validated':False,'motion_or_FSI_solved':False,'production_model_selected':False,
      'limitations':['Independent fallback physics model, not a success claim for the fully flexible fish.',
        'No fresh CAD or Gmsh generation. Source tetrahedra and all active coordinates are unchanged.',
        'Tail-root boundary removes the old body-neighbor centroid from OQ; affected tail OQ can improve, never decrease.',
        'Native import, rigid motion/seam compatibility, solution and acceptance remain untested.']}
    assert source_evidence(source,record)[1]==evidence, 'Source inputs changed during extraction'
    (output/'mesh_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--quality-record',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--mode',choices=['water-tail','water-only'],default='water-tail')
    parser.add_argument('--check-only',action='store_true')
    args=parser.parse_args()
    result=export_mesh(args.source,args.quality_record,args.output,args.mode,args.check_only)
    print(json.dumps({k:v for k,v in result.items() if k not in ['mapping','face_zones','limitations']},indent=2))

if __name__=='__main__':main()
