"""Read-only validation of native Fluent fish-FSI transcript and report history.

This program never imports an Ansys SDK or operates a solver. It writes only to
the explicitly selected output directory. Solver convergence is checked for
each completed physical time step; GUI, topology, FSI configuration and native
reopen evidence must be provided separately, otherwise their status is unknown.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sys


EQUATIONS = ["continuity", "x-velocity", "y-velocity", "z-velocity",
             "x-displace", "y-displace", "z-displace"]
REPORT_COLUMNS = ["drive-y", "tail-y-mean", "tail-y-max", "tail-y-min",
                  "tail-displacement", "force-x", "force-y", "mass-net",
                  "mass-inlet", "mass-outlet"]
EXTERNAL_EVIDENCE = ["fsi_configuration", "fluid_solid_topology",
                     "dynamic_mesh_quality", "native_reopen"]
NUMBER = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][+-]?\d+)?"
FLOW = re.compile(r"Flow\s+time\s*=\s*(%s)\s*s\s*,\s*time\s+step\s*=\s*(\d+)" % NUMBER, re.I)
CONVERGED = re.compile(r"!?\s*(\d+)\s+solution\s+is\s+converged", re.I)
ITER = re.compile(r"^\s*(\d+)\s+(.+?)\s+\d+:\d+:\d+\s+\d+\s*$")
FATAL = re.compile(r"floating[ -]point|\bFPU\b|divergence detected|diverged|negative cell volume|"
                   r"negative volume|inverted (?:cell|element)|fatal error|^\s*Error(?:\s+Object)?:", re.I)
DISPLAY_REJECTED_WRITE = "Error: api-set-var: the object cannot be edited"
DISPLAY_DEFORMATION_OBJECT = 'Error Object: "results/graphics/contour/fish-displacement/deformation-scale"'


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def number(token):
    return float(token.replace("D", "e").replace("d", "e"))


def parse_transcript(text, start_line=1):
    """Tie the final NEW iteration to its subsequent Flow-time completion line.

    Fluent prints the previous step's final row and converged marker again at
    the beginning of a new dual-time-iterate call. Those repeated rows must not
    count as convergence of the new step.
    """
    completed, issues, errors, nonfinite_rows = [], [], [], []
    unacknowledged_errors, display_events = [], []
    acknowledged_display_lines = set()
    rows, marks = [], set()
    last_completed_iteration = -1
    first_iteration_line = None
    header = None
    mesh_updates = 0
    step_mesh_updates = 0
    source_lines = text.splitlines()
    for lineno, line in enumerate(source_lines, 1):
        if lineno < start_line:
            continue
        words = line.split()
        if words and words[0] == "iter" and "continuity" in words:
            header = words[1:words.index("time/iter")] if "time/iter" in words else words[1:8]
            if header != EQUATIONS:
                issues.append({"line": lineno, "reason": "Unexpected residual columns", "columns": header})
        match = ITER.match(line)
        if match and header == EQUATIONS:
            values = match.group(2).split()
            if len(values) != len(EQUATIONS):
                issues.append({"line": lineno, "reason": "Residual row has wrong field count"})
                continue
            try:
                row = dict(zip(EQUATIONS, map(number, values)))
            except ValueError:
                issues.append({"line": lineno, "reason": "Residual row is not numeric"})
                continue
            iteration = int(match.group(1))
            if first_iteration_line is None:
                first_iteration_line = lineno
            if iteration == last_completed_iteration:
                continue  # Stale display of the preceding converged state.
            if iteration < last_completed_iteration:
                issues.append({"line": lineno, "reason": "Iteration reset; select one run using --start-line"})
            row.update(iteration=iteration, transcript_line=lineno)
            if not all(finite(row[eq]) for eq in EQUATIONS):
                nonfinite_rows.append({"line": lineno, "iteration": iteration})
            rows.append(row)
        match = CONVERGED.search(line)
        if match and int(match.group(1)) > last_completed_iteration:
            marks.add(int(match.group(1)))
        if first_iteration_line is not None and FATAL.search(line):
            error = {"line": lineno, "text": line.strip(), "raw_text": line}
            errors.append(error)  # Retain the complete runtime-error record.
            if lineno in acknowledged_display_lines:
                pass
            elif (line.strip() == DISPLAY_REJECTED_WRITE and lineno < len(source_lines)
                  and source_lines[lineno].strip() == DISPLAY_DEFORMATION_OBJECT):
                # Only this exact adjacent two-line event is recognized.
                # A solver-control path, another contour, another message,
                # or an intervening line cannot enter this narrow exception.
                acknowledged_display_lines.update({lineno, lineno + 1})
                display_events.append({
                    "start_line": lineno, "end_line": lineno + 1,
                    "raw_lines": [line, source_lines[lineno]],
                    "object_path": "results/graphics/contour/fish-displacement/deformation-scale",
                    "classification": "acknowledged_rejected_display_property_write",
                    "after_completed_step": completed[-1]["step"] if completed else None,
                    "explanation": "Fluent rejected this exact contour deformation-scale write. It is a display-property edit error, not a solver-control or convergence error. The replay source omits this setter when deformation is disabled. This classification does not itself prove that solution fields were unchanged.",
                    "excluded_from_physical_runtime_error_gate": True,
                })
            else:
                unacknowledged_errors.append(error)
        if "Updating mesh at iteration... done." in line:
            mesh_updates += 1
            step_mesh_updates += 1
        match = FLOW.search(line)
        if match:
            last = rows[-1] if rows else {}
            values_finite = all(finite(last.get(eq)) for eq in EQUATIONS)
            thresholds_met = values_finite and all(
                0 <= last[eq] < (1e-3 if eq == "continuity" else 1e-4)
                for eq in EQUATIONS)
            marker = bool(last) and last["iteration"] in marks
            item = {"step": int(match.group(2)), "flow_time_s": number(match.group(1)),
                    "final_iteration": last.get("iteration"), "iterations_observed": len(rows),
                    "flow_time_transcript_line": lineno,
                    "final_residual_transcript_line": last.get("transcript_line"),
                    **{eq: last.get(eq) for eq in EQUATIONS},
                    "converged_marker": marker, "residuals_finite": values_finite,
                    "residual_thresholds_passed": bool(thresholds_met),
                    "step_numerically_converged": bool(marker and thresholds_met),
                    "successful_iteration_mesh_update_messages": step_mesh_updates}
            completed.append(item)
            if last:
                last_completed_iteration = last["iteration"]
            rows, marks = [], set()
            step_mesh_updates = 0
    return completed, {"parse_issues": issues, "runtime_errors_after_first_iteration": errors,
                       "unacknowledged_runtime_errors_after_first_iteration": unacknowledged_errors,
                       "non_solver_display_events": display_events,
                       "non_solver_display_event_count": len(display_events),
                       "nonfinite_residual_rows": nonfinite_rows,
                       "first_iteration_line": first_iteration_line,
                       "incomplete_next_step": {"iterations_observed": len(rows),
                                                "last_residual": rows[-1] if rows else None},
                       "successful_iteration_mesh_update_messages": mesh_updates}


def parse_history(text, dt):
    rows, issues = [], []
    header = None
    for lineno, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if stripped.startswith("(") and '"Time Step"' in stripped:
            header = re.findall(r'"([^"]+)"', stripped)
            continue
        if not stripped or not re.match(r"^[+-]?\d", stripped):
            continue
        values = stripped.split()
        names = header or ["Time Step"] + REPORT_COLUMNS
        if len(values) != len(names):
            issues.append({"line": lineno, "reason": "History field count mismatch", "fields": len(values)})
            continue
        try:
            data = dict(zip(names, map(number, values)))
            step_value = data["Time Step"]
            if not finite(step_value) or step_value != int(step_value):
                raise ValueError("Time Step is not an integer")
            step = int(step_value)
        except (ValueError, KeyError):
            issues.append({"line": lineno, "reason": "Invalid history numeric row or Time Step column"})
            continue
        all_finite = all(finite(data.get(name)) for name in REPORT_COLUMNS)
        inlet, net = data.get("mass-inlet"), data.get("mass-net")
        imbalance = abs(net) / abs(inlet) if finite(inlet) and finite(net) and abs(inlet) > 1e-12 else None
        delta = data.get("tail-y-mean", math.nan) - data.get("drive-y", math.nan)
        row = {"step": step, "flow_time_s_from_dt": step * dt,
               **{name: data.get(name) for name in REPORT_COLUMNS},
               "tail_mean_relative_to_drive_m": delta,
               "mass_imbalance_fraction": imbalance,
               "mass_balance_passed": imbalance is not None and imbalance < 0.01,
               "values_finite": all_finite, "history_line": lineno}
        rows.append(row)
    if header is not None and (header[0] != "Time Step" or set(header[1:]) != set(REPORT_COLUMNS)):
        issues.append({"reason": "Unexpected history columns", "columns": header})
    return rows, issues


def sequence_check(rows, expected_steps):
    observed = [r["step"] for r in rows]
    expected = list(range(1, expected_steps + 1))
    return {"passed": observed == expected, "observed_steps": observed,
            "missing_steps": sorted(set(expected) - set(observed)),
            "unexpected_steps": sorted(set(observed) - set(expected)),
            "duplicate_steps": sorted({s for s in observed if observed.count(s) > 1})}


def separate_initial_state(rows):
    """Allow one initial report row at step 0, only before all solved rows.

    Keep any later/repeated zero in the solved sequence so validation fails;
    never discard malformed restarts or repeated time steps to make them pass.
    """
    initial = rows[0] if rows and rows[0]["step"] == 0 else None
    solved_rows = rows[1:] if initial is not None else rows
    issues = [{"line": row["history_line"],
               "reason": "Step 0 is permitted only once as the first history row"}
              for row in solved_rows if row["step"] == 0]
    return initial, solved_rows, issues


def clean_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {k: clean_json(v) for k, v in value.items()}
    if isinstance(value, list):
        return [clean_json(v) for v in value]
    return value


def file_record(path, raw):
    return {"path": str(path), "bytes_read": len(raw), "sha256_of_snapshot": hashlib.sha256(raw).hexdigest()}


def write_csv(path, rows, fallback_columns):
    with path.open("w", encoding="utf-8", newline="") as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]) if rows else fallback_columns)
        writer.writeheader()
        writer.writerows(rows)


def validate(run_dir, output_dir, expected_steps, dt, start_line=1, evidence_path=None):
    transcript_path = run_dir / "fish-transcript.trn"
    history_path = run_dir / "fish-history.out"
    missing = [str(p) for p in [transcript_path, history_path] if not p.is_file()]
    transcript_bytes = transcript_path.read_bytes() if transcript_path.is_file() else b""
    history_bytes = history_path.read_bytes() if history_path.is_file() else b""
    # ASCII diagnostics and numeric fields survive unknown Windows transcript encoding.
    steps, diagnostics = parse_transcript(transcript_bytes.decode("utf-8", errors="replace"), start_line)
    history_input, history_issues = parse_history(history_bytes.decode("utf-8", errors="replace"), dt)
    initial_state, history, initial_issues = separate_initial_state(history_input)
    history_issues.extend(initial_issues)
    if expected_steps is None:
        expected_steps = max([0] + [row["step"] for row in steps + history])
        expected_basis = "largest observed completed/report step; final requested duration is not verified"
    else:
        expected_basis = "explicit --expected-steps"
    step_sequence, history_sequence = sequence_check(steps, expected_steps), sequence_check(history, expected_steps)
    time_tolerance = max(1e-10, dt * 1e-7)
    times_match = all(abs(row["flow_time_s"] - row["step"] * dt) <= time_tolerance for row in steps)
    numerical_checks = {
        "input_files_present": not missing,
        "completed_steps_present": bool(steps) and expected_steps > 0,
        "transcript_step_sequence_complete": step_sequence["passed"],
        "history_step_sequence_complete": history_sequence["passed"],
        "physical_times_match_fixed_dt": times_match,
        "all_completed_steps_converged_and_below_residual_limits": bool(steps) and all(r["step_numerically_converged"] for r in steps),
        "all_history_values_finite": bool(history) and all(r["values_finite"] for r in history),
        "initial_state_values_finite_if_present": initial_state is None or initial_state["values_finite"],
        "initial_state_order_valid": not initial_issues,
        "mass_imbalance_below_one_percent_each_step": bool(history) and all(r["mass_balance_passed"] for r in history),
        "no_transcript_parse_issues": not diagnostics["parse_issues"],
        "no_history_parse_issues": not history_issues,
        "no_unacknowledged_runtime_error_after_first_iteration": not diagnostics["unacknowledged_runtime_errors_after_first_iteration"],
        "no_nonfinite_intermediate_residuals": not diagnostics["nonfinite_residual_rows"],
        "no_unfinished_next_step": diagnostics["incomplete_next_step"]["iterations_observed"] == 0,
    }
    numerical_passed = all(numerical_checks.values())
    supplied = json.loads(evidence_path.read_text(encoding="utf-8-sig")) if evidence_path else {}
    external = {}
    for key in EXTERNAL_EVIDENCE:
        evidence = supplied.get(key)
        if isinstance(evidence, dict) and evidence.get("status") in {"passed", "failed", "unknown"}:
            external[key] = {**evidence, "source_file": str(evidence_path), "independently_retested_by_this_parser": False}
        else:
            external[key] = {"status": "unknown", "reason": "No separate explicit evidence supplied"}
    external_passed = all(v["status"] == "passed" for v in external.values())
    external_failed = any(v["status"] == "failed" for v in external.values())
    max_relative = max([abs(r["tail_mean_relative_to_drive_m"]) for r in history if finite(r["tail_mean_relative_to_drive_m"])] or [0.0])
    imbalance_values = [r["mass_imbalance_fraction"] for r in history if finite(r["mass_imbalance_fraction"])]
    result = {"schema_version": 3, "created_at_utc": datetime.now(timezone.utc).isoformat(),
              "run_dir": str(run_dir), "expected_steps": expected_steps, "expected_steps_basis": expected_basis,
              "dt_s": dt, "expected_end_time_s": expected_steps * dt,
              "last_completed_time_s": steps[-1]["flow_time_s"] if steps else None,
              "completed_steps": len(steps), "history_rows": len(history),
              "history_input_rows": len(history_input), "initial_state": initial_state,
              "thresholds": {"continuity_strictly_below": 1e-3, "velocity_and_structure_strictly_below": 1e-4,
                             "mass_imbalance_fraction_strictly_below": 0.01, "physical_time_abs_tolerance_s": time_tolerance},
              "numerical_checks": numerical_checks, "numerical_validation_passed": numerical_passed,
              "non_solver_display_event_count": diagnostics["non_solver_display_event_count"],
              "non_solver_display_events": diagnostics["non_solver_display_events"],
              "runtime_error_line_count": len(diagnostics["runtime_errors_after_first_iteration"]),
              "unacknowledged_runtime_error_line_count": len(diagnostics["unacknowledged_runtime_errors_after_first_iteration"]),
              "external_evidence": external,
              "overall_status": ("passed" if numerical_passed and external_passed else
                                 "external_evidence_failed" if numerical_passed and external_failed else
                                 "numerical_checks_passed_external_evidence_incomplete" if numerical_passed else
                                 "incomplete_or_failed"),
              "passed": numerical_passed and external_passed,
              "transcript_sequence": step_sequence, "history_sequence": history_sequence,
              "max_mass_imbalance_fraction": max(imbalance_values) if imbalance_values else None,
              "max_tail_mean_relative_to_drive_m": max_relative,
              "nonzero_relative_tail_motion_observed": max_relative > 1e-9,
              "two_way_fsi_proved_by_motion_alone": False,
              "notes": ["Relative tail/drive motion is a diagnostic, not sufficient proof of two-way FSI.",
                        "Mesh-update success text does not verify positive cell volumes or structural topology.",
                        "Native reopen and exact coupling configuration require separate evidence.",
                        "This audit does not establish biological realism, periodic convergence, or mesh/time independence.",
                        "Process exit code and result-file existence are not used as solver success evidence.",
                        "A numerical pass does not claim an error-free runtime. Exact acknowledged display errors remain recorded separately with original lines; every other runtime error remains a failure.",
                        "One leading history step 0 is preserved as initial_state and checked for finite values; it is not a completed step.",
                        "Input files may be growing during a live solve; hashes identify exactly the snapshots read."],
              "missing_input_files": missing, "history_parse_issues": history_issues,
              "transcript_diagnostics": diagnostics,
              "input_snapshots": [file_record(transcript_path, transcript_bytes), file_record(history_path, history_bytes)]}
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "step_residuals.csv", steps, ["step", "flow_time_s"] + EQUATIONS)
    write_csv(output_dir / "motion_history.csv", history, ["step", "flow_time_s_from_dt"] + REPORT_COLUMNS)
    (output_dir / "validation.json").write_text(json.dumps(clean_json(result), indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--expected-steps", type=int)
    parser.add_argument("--dt", type=float, default=0.01)
    parser.add_argument("--start-line", type=int, default=1,
                        help="First transcript line of the selected run, if a file contains restarts")
    parser.add_argument("--evidence", type=Path,
                        help="Optional JSON of explicit fsi_configuration/fluid_solid_topology/dynamic_mesh_quality/native_reopen evidence")
    args = parser.parse_args(argv)
    if not finite(args.dt) or args.dt <= 0 or (args.expected_steps is not None and args.expected_steps <= 0) or args.start_line < 1:
        parser.error("dt, expected-steps and start-line must be positive")
    result = validate(args.run_dir.resolve(), args.output_dir.resolve(), args.expected_steps,
                      args.dt, args.start_line, args.evidence)
    print(json.dumps({"overall_status": result["overall_status"], "numerical_validation_passed": result["numerical_validation_passed"],
                      "completed_steps": result["completed_steps"], "expected_steps": result["expected_steps"],
                      "validation_file": str(args.output_dir.resolve() / "validation.json")}, ensure_ascii=False))
    return 0 if result["numerical_validation_passed"] else 2


if __name__ == "__main__":
    sys.exit(main())
