"""Two-way elastic tail FSI and complete-section prescribed tail-root motion."""
s = solver.settings
for name in ['tail_water-shadow']:
    structure = s.setup.boundary_conditions.wall[name].structure
    structure.x_disp_boundary_condition = 'Intrinsic FSI'
    structure.y_disp_boundary_condition = 'Intrinsic FSI'
    structure.z_disp_boundary_condition = 'Intrinsic FSI'
drive = s.setup.boundary_conditions.wall['tail_root'].structure
drive.x_disp_boundary_condition = 'Node X-Displacement'
drive.x_disp_boundary_value = {'option':'value','value':0.0}
drive.y_disp_boundary_condition = 'Node Y-Displacement'
drive.y_disp_boundary_value = {'option':'value','value':'0.001 [m]*sin(12.566370614359172 [s^-1]*t)*(1-exp(-t/0.5 [s]))'}
drive.z_disp_boundary_condition = 'Node Z-Displacement'
drive.z_disp_boundary_value = {'option':'value','value':0.0}
record('fsi_boundary_setup', {
    'structure_boundaries': {name: s.setup.boundary_conditions.wall[name].structure.get_state()
                             for name in ['tail_water-shadow', 'tail_root']},
    'drive_amplitude_m': 0.001,
    'drive_frequency_hz': 2.0,
    'drive_ramp_time_s': 0.5,
    'drive_direction': 'Y',
    'interpretation': 'Prescribed rigid forebody and matching tail-root translation in inflow; the elastic tail alone has two-way FSI. No free swimming or forebody elasticity.',
})
