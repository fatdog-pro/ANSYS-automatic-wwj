"""Prescribed rigid forebody plus intrinsic-FSI tail; no time advancement."""
import importlib.util
from pathlib import Path

s = solver.settings
s.mesh.check()
dm = s.setup.dynamic_mesh
dm.enabled = True
dm.methods.smoothing.enabled = True
dm.methods.smoothing.method = 'diffusion'
# Explicit cold-start controls from the observed one-step configuration.
# Do not inherit mesh controls from a previously opened project.
dm.methods.smoothing.diffusion_settings.set_state({'diffusion_coeff_function': 'boundary-distance', 'diffusion_coeff_parameter': 1.5, 'amg_stabilization': 'CG', 'max_iter': 50, 'relative_tolerance': 1e-10, 'verbosity': 0, 'boundary_distance_method': False, 'smooth_from_ref': False, 'diffusion_fvm': False})
_original_smoothing = dm.methods.smoothing.get_state()
_before_cycles = solver.rp_vars('smooth-mesh/niter')
try:
    dm.methods.smoothing.method = 'spring'
    _cycles = dm.methods.smoothing.spring_settings.skew_smooth_niter
    _range_min = _cycles.min()
    if not _cycles.is_active() or (_range_min is not None and _range_min > 0):
        raise RuntimeError('Native public skew-smoothing setting does not support zero')
    _cycles.set_state(replay_settings['skew_smoothing_cycles'])
    if _cycles.get_state() != 0 or solver.rp_vars('smooth-mesh/niter') != 0:
        raise RuntimeError('Native public zero-cycle control did not read back')
finally:
    # No preview, mesh update, initialization or physical solve in spring context.
    dm.methods.smoothing.set_state(_original_smoothing)
if dm.methods.smoothing.get_state() != _original_smoothing or solver.rp_vars('smooth-mesh/niter') != 0:
    raise RuntimeError('Original diffusion controls and zero cycles were not preserved')
record('skew_smoothing_setup', {'before_cycles': _before_cycles, 'after_cycles': 0,
    'public_API': 'setup.dynamic_mesh.methods.smoothing.spring_settings.skew_smooth_niter',
    'temporary_context': 'spring, with no mesh/time advancement; full diffusion state restored',
    'diffusion_state': _original_smoothing, 'scope': 'Numerical mesh control, not a change to FSI physics'})
dm.methods.remeshing.enabled = False
dm.methods.layering.enabled = False
dm.options.in_cylinder.enabled = False
dm.options.six_dof.enabled = False
dm.options.implicit_update = {
    'enabled': True,
    'update_interval': 1,
    'relaxation_factor': replay_settings['implicit_mesh_relaxation'],
    'residual_criterion': replay_settings['implicit_mesh_residual_criterion'],
}
zone_mapping = {}
for zone, kind in [('body_water', 'rigid-body'), ('tail_water', 'intrinsic-fsi'),
                   ('fish_drive', 'rigid-body'), ('fish_eyes', 'rigid-body'), ('inlet', 'stationary'),
                   ('outlet', 'stationary'), ('farfield', 'stationary')]:
    matches = [name for name in dm.dynamic_zones.get_object_names()
               if dm.dynamic_zones[name].zone.get_state() == zone]
    if not matches:
        before = set(dm.dynamic_zones.get_object_names())
        dm.dynamic_zones.create(zone=zone)
        matches = list(set(dm.dynamic_zones.get_object_names()) - before)
    if len(matches) != 1:
        raise RuntimeError('Expected exactly one dynamic-mesh object for ' + zone)
    dm.dynamic_zones[matches[0]].type = kind
    if kind == 'intrinsic-fsi':
        stabilization = dm.dynamic_zones[matches[0]].solver.stabilization
        stabilization.enabled = replay_settings['solution_stabilization_enabled']
        if replay_settings['solution_stabilization_enabled']:
            stabilization.parameters.method = 'coefficient-based'
            stabilization.parameters.scale = replay_settings['solution_stabilization_scale']
    zone_mapping[zone] = matches[0]

_motion_source_dir = Path(script_dir) if 'script_dir' in globals() else Path(__file__).parent
_motion_spec = importlib.util.spec_from_file_location(
    'fish_rigid_tail_native_motion', _motion_source_dir / 'rigid_tail_motion.py')
_motion_helper = importlib.util.module_from_spec(_motion_spec)
_motion_spec.loader.exec_module(_motion_helper)
_motion_evidence = _motion_helper.compile_and_bind_forebody_motion(
    solver, _motion_source_dir / 'fish_rigid_forebody_motion.c', Path(run_dir), zone_mapping)
record('rigid_forebody_motion_setup', _motion_evidence)

_native_dm = dm.get_state()
_actual_dynamic_zones = _native_dm['dynamic_zones']
_expected_dynamic = {'body_water': 'rigid-body', 'fish_drive': 'rigid-body',
                     'fish_eyes': 'rigid-body', 'tail_water': 'intrinsic-fsi',
                     'inlet': 'stationary', 'outlet': 'stationary', 'farfield': 'stationary'}
_actual_dynamic = {value['zone']: value['type'] for value in _actual_dynamic_zones.values()}
if len(_actual_dynamic) != len(_actual_dynamic_zones) or _actual_dynamic != _expected_dynamic:
    raise RuntimeError('Expected exactly three rigid walls, one FSI tail and three stationary outer boundaries; tail_root is an FE constraint only')
_implicit = _native_dm['options']['implicit_update']
if (_implicit['enabled'] is not True or _implicit['update_interval'] != 1
        or _implicit['relaxation_factor'] != replay_settings['implicit_mesh_relaxation']
        or _implicit['residual_criterion'] != replay_settings['implicit_mesh_residual_criterion']
        or _native_dm['options']['six_dof']['enabled'] is not False
        or _native_dm['options']['in_cylinder']['enabled'] is not False):
    raise RuntimeError('Mixed-model implicit mesh controls did not read back exactly')
record('dynamic_mesh_setup', {'zone_mapping': zone_mapping, 'state': _native_dm,
    'rigid_forebody_motion': _motion_evidence,
    'elastic_fsi_wall': 'tail_water', 'elastic_fsi_solid_side': 'tail_water-shadow',
    'tail_root_role': 'Complete-section prescribed structural node displacement; no fluid dynamic zone',
    'mixed_cg_and_implicit_fsi_validation': 'Requires actual first-step and every saved-step kinematic/interface checks; pure-motion probe alone is insufficient'})
