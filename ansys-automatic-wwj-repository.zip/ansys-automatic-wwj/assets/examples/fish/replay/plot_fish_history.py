"""Plot observed anchored fish-FSI histories; optional and solver-independent.

Example:
    python plot_fish_history.py --input-dir RUN/results --expected-steps 20

Inputs are motion_history.csv and step_residuals.csv from validate_fish_run.py.
No interpolation, smoothing, extrapolation, or substitution of missing rows is
performed. Matplotlib is imported only for this optional reporting command.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import sys


MOTION_FIELDS = ['flow_time_s_from_dt', 'drive-y', 'tail-y-mean', 'tail-y-min',
                 'tail-y-max', 'tail-displacement', 'force-x', 'force-y',
                 'mass-net', 'mass-inlet', 'mass-outlet', 'mass_imbalance_fraction']
RESIDUALS = ['continuity', 'x-velocity', 'y-velocity', 'z-velocity',
             'x-displace', 'y-displace', 'z-displace']


def read_csv(path, numeric_fields, integer_fields):
    raw = path.read_bytes()
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
    missing = set(numeric_fields + integer_fields) - set(reader.fieldnames or [])
    if missing:
        raise ValueError(f'{path.name}: missing columns {sorted(missing)}')
    rows = []
    for index, source in enumerate(reader, 2):
        row = dict(source)
        row['csv_line'] = index
        for name in numeric_fields + integer_fields:
            try:
                value = float(source[name])
            except (TypeError, ValueError) as exc:
                raise ValueError(f'{path.name}:{index}: invalid {name}') from exc
            if not math.isfinite(value):
                raise ValueError(f'{path.name}:{index}: nonfinite {name}')
            if name in integer_fields:
                if value != int(value):
                    raise ValueError(f'{path.name}:{index}: noninteger {name}')
                value = int(value)
            row[name] = value
        rows.append(row)
    if not rows:
        raise ValueError(f'{path.name}: no data rows')
    return rows, {'path': str(path.resolve()), 'bytes': len(raw),
                  'sha256': hashlib.sha256(raw).hexdigest(), 'row_count': len(rows)}


def series_range(rows, name):
    minimum = min(rows, key=lambda row: row[name])
    maximum = max(rows, key=lambda row: row[name])
    return {'minimum': minimum[name], 'minimum_step': minimum['step'],
            'maximum': maximum[name], 'maximum_step': maximum['step']}


def make_report(input_dir, output_dir, expected_steps):
    motion, motion_source = read_csv(input_dir / 'motion_history.csv', MOTION_FIELDS,
                                      ['step', 'history_line'])
    residual, residual_source = read_csv(input_dir / 'step_residuals.csv',
        ['flow_time_s', *RESIDUALS], ['step', 'final_iteration', 'iterations_observed',
                                    'flow_time_transcript_line', 'final_residual_transcript_line'])
    steps = [row['step'] for row in motion]
    if steps != list(range(1, len(motion) + 1)):
        raise ValueError('Motion rows must preserve a complete sequence from step 1.')
    if steps != [row['step'] for row in residual]:
        raise ValueError('Motion and residual CSVs must contain the same ordered steps.')
    times = [row['flow_time_s_from_dt'] for row in motion]
    if times[0] <= 0 or any(b <= a for a, b in zip(times, times[1:])):
        raise ValueError('Observed physical times must be positive and increasing.')
    index_rows = []
    for m, r in zip(motion, residual):
        if not math.isclose(m['flow_time_s_from_dt'], r['flow_time_s'], rel_tol=0, abs_tol=1e-10):
            raise ValueError(f'Time mismatch at step {m["step"]}.')
        if not m['tail-y-min'] <= m['tail-y-mean'] <= m['tail-y-max']:
            raise ValueError(f'Invalid tail surface envelope at step {m["step"]}.')
        if m['tail-displacement'] < 0 or any(r[name] < 0 for name in RESIDUALS):
            raise ValueError(f'Negative magnitude or residual at step {m["step"]}.')
        if abs(m['mass-inlet']) <= 1e-12:
            raise ValueError(f'Cannot normalize zero inlet flux at step {m["step"]}.')
        ratio = abs(m['mass-net']) / abs(m['mass-inlet'])
        if not math.isclose(ratio, m['mass_imbalance_fraction'], rel_tol=1e-10, abs_tol=1e-14):
            raise ValueError(f'Inconsistent normalized flux difference at step {m["step"]}.')
        t = m['flow_time_s_from_dt']
        predicted = .001 * math.sin(4 * math.pi * t) * (1 - math.exp(-t / .5))
        index_rows.append({
            'step': m['step'], 'time_s': t,
            'motion_csv_line': m['csv_line'], 'original_history_line': m['history_line'],
            'residual_csv_line': r['csv_line'],
            'original_flow_time_transcript_line': r['flow_time_transcript_line'],
            'original_final_residual_transcript_line': r['final_residual_transcript_line'],
            'final_iteration': r['final_iteration'], 'iterations_observed': r['iterations_observed'],
            'observed_motion_SI': {name: m[name] for name in MOTION_FIELDS if name != 'flow_time_s_from_dt'},
            'observed_final_residuals': {name: r[name] for name in RESIDUALS},
            'head_expression_m': predicted, 'head_expression_error_m': m['drive-y'] - predicted,
            'step_numerically_converged_in_validator': r.get('step_numerically_converged', '').lower() == 'true'})
    errors = [row['head_expression_error_m'] for row in index_rows]
    maximum_tail = max(motion, key=lambda row: row['tail-displacement'])
    maximum_flux = max(motion, key=lambda row: row['mass_imbalance_fraction'])
    summary = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'model': 'Anchored fish; Fluent intrinsic two-way FSI; prescribed head actuator',
        'observed_steps': len(steps), 'observed_step_indices': steps,
        'planned_steps': expected_steps, 'planned_duration_fully_observed': len(steps) == expected_steps,
        'missing_planned_steps': sorted(set(range(1, expected_steps + 1)) - set(steps)),
        'unexpected_steps': [step for step in steps if step > expected_steps],
        'observed_time_range_s': [times[0], times[-1]],
        'head_expression': {'formula': '0.001*sin(4*pi*t)*(1-exp(-t/0.5)) [m]',
                            'evaluated_only_at_observed_times': True,
                            'max_absolute_error_m': max(abs(error) for error in errors),
                            'rms_error_m': math.sqrt(sum(error * error for error in errors) / len(errors)),
                            'maximum_error_step': index_rows[max(range(len(errors)), key=lambda i: abs(errors[i]))]['step']},
        'maximum_tail_total_displacement': {'m': maximum_tail['tail-displacement'],
            'mm': maximum_tail['tail-displacement'] * 1000, 'step': maximum_tail['step'],
            'time_s': maximum_tail['flow_time_s_from_dt']},
        'force_x_range_N': series_range(motion, 'force-x'),
        'force_y_range_N': series_range(motion, 'force-y'),
        'tail_surface_y_min_range_m': series_range(motion, 'tail-y-min'),
        'tail_surface_y_max_range_m': series_range(motion, 'tail-y-max'),
        'normalized_inlet_outlet_flux_difference': {
            'definition': 'abs(mass-net)/abs(mass-inlet)',
            'maximum_fraction': maximum_flux['mass_imbalance_fraction'],
            'maximum_percent': maximum_flux['mass_imbalance_fraction'] * 100,
            'maximum_ppm': maximum_flux['mass_imbalance_fraction'] * 1e6,
            'maximum_step': maximum_flux['step'], 'signed_net_flux_range_kg_s': series_range(motion, 'mass-net')},
        'residual_maxima': {name: max(row[name] for row in residual) for name in RESIDUALS},
        'all_observed_steps_converged_in_validator': all(row['step_numerically_converged_in_validator'] for row in index_rows),
        'source_snapshots': {'motion': motion_source, 'residuals': residual_source},
        'source_index': index_rows,
        'notes': ['Only observed rows are drawn; no smoothing, interpolation or extrapolation.',
                  'Straight line segments join recorded samples; they add no computed time samples.',
                  'Tail min/max shading is the spatial surface range, not an uncertainty interval.',
                  'This report does not validate free swimming, periodic convergence or mesh/time independence.',
                  'Inlet/outlet flux difference is a diagnostic; deforming-domain mass conservation also involves volume change.',
                  'A partial history remains partial even when every observed step converged.']}

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import MaxNLocator
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.titleweight': 'bold', 'axes.labelcolor': '#253247',
        'axes.edgecolor': '#8491a5', 'text.color': '#253247',
        'grid.color': '#dce2eb', 'grid.linewidth': .65,
        'figure.facecolor': 'white', 'savefig.facecolor': 'white',
        'pdf.fonttype': 42, 'ps.fonttype': 42})
    output_dir.mkdir(parents=True, exist_ok=True)
    count_text = f'Observed {len(steps)} / planned {expected_steps} steps | {times[0]:g}–{times[-1]:g} s'
    saved = []

    def finish(fig, axes, stem, footnote):
        for ax in axes:
            ax.grid(axis='both', alpha=.8)
            ax.set_axisbelow(True)
            ax.margins(x=.025)
            ax.xaxis.set_major_locator(MaxNLocator(nbins=7))
        axes[-1].set_xlabel('Time (s)')
        fig.text(.105, .02, footnote, fontsize=8, color='#657388')
        fig.subplots_adjust(left=.105, right=.965, top=.86, bottom=.105, hspace=.38)
        for suffix in ['png', 'pdf']:
            path = output_dir / f'{stem}.{suffix}'
            fig.savefig(path, dpi=200 if suffix == 'png' else None)
            saved.append(str(path.resolve()))
        plt.close(fig)

    fig, axes = plt.subplots(2, 1, figsize=(10, 7.2), sharex=True)
    fig.suptitle('Anchored fish · intrinsic two-way FSI', x=.105, y=.965, ha='left', fontsize=16, weight='bold')
    fig.text(.105, .915, count_text + ' | recorded solver data', color='#657388')
    ax = axes[0]
    ax.fill_between(times, [r['tail-y-min'] * 1000 for r in motion],
                    [r['tail-y-max'] * 1000 for r in motion], color='#90bed0', alpha=.35,
                    label='Tail surface min–max', linewidth=0)
    ax.plot(times, [r['drive-y'] * 1000 for r in motion], color='#d26742', lw=1.6,
            marker='o', ms=2.5, label='Head drive y')
    ax.plot(times, [r['tail-y-mean'] * 1000 for r in motion], color='#17647e', lw=1.8,
            marker='o', ms=2.5, label='Tail surface mean y')
    ax.axhline(0, color='#a0a9b7', lw=.7)
    ax.set_ylabel('Y displacement (mm)')
    ax.set_title('A  Prescribed head motion and computed flexible-tail response', loc='left', fontsize=11)
    ax.legend(frameon=False, ncol=3, fontsize=9, loc='upper left')
    ax = axes[1]
    ax.plot(times, [r['force-x'] * 1000 for r in motion], color='#17647e', lw=1.7,
            marker='o', ms=2.5, label='Fx')
    ax.plot(times, [r['force-y'] * 1000 for r in motion], color='#b45c87', lw=1.7,
            marker='o', ms=2.5, label='Fy')
    ax.axhline(0, color='#a0a9b7', lw=.7)
    ax.set_ylabel('Hydrodynamic force (mN)')
    ax.set_title('B  Fluid force on the fish surfaces', loc='left', fontsize=11)
    ax.legend(frameon=False, ncol=2, fontsize=9)
    finish(fig, axes, 'fish_motion_forces', 'Raw samples; no smoothing or extrapolation. Shading: spatial tail-surface range. Anchored actuator, not free swimming.')

    fig, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
    fig.suptitle('Anchored fish · numerical history', x=.105, y=.965, ha='left', fontsize=16, weight='bold')
    fig.text(.105, .925, count_text + ' | final residual of each observed step', color='#657388')
    groups = [('Continuity', ['continuity'], '#253247'),
              ('Max. velocity residual', RESIDUALS[1:4], '#17647e'),
              ('Max. structural residual', RESIDUALS[4:], '#b45c87')]
    for label, fields, color in groups:
        values = [max(row[field] for field in fields) for row in residual]
        # Exact zero has no logarithm; mask it and report the count, never invent a floor.
        axes[0].semilogy(times, [value if value > 0 else math.nan for value in values],
                         color=color, lw=1.3, marker='o', ms=2, label=label)
    axes[0].axhline(1e-3, color='#253247', lw=.9, ls='--', label='Continuity limit 1e−3')
    axes[0].axhline(1e-4, color='#9a7c69', lw=.9, ls=':', label='Other equations limit 1e−4')
    axes[0].set_ylabel('Scaled residual')
    axes[0].set_title('A  End-of-step residuals', loc='left', fontsize=11)
    axes[0].legend(frameon=False, fontsize=8, ncol=2, loc='center right', bbox_to_anchor=(.995, .46))
    axes[1].plot(times, [row['mass_imbalance_fraction'] * 1e6 for row in motion],
                 color='#337e69', lw=1.5, marker='o', ms=2.5)
    axes[1].set_ylabel('Flux difference (ppm)')
    axes[1].set_title('B  |Net inlet/outlet flux| / |inlet flux|', loc='left', fontsize=11)
    widths = min(b - a for a, b in zip(times, times[1:])) * .72 if len(times) > 1 else times[0] * .5
    axes[2].bar(times, [row['iterations_observed'] for row in residual], width=widths,
                color=['#69879e' if row['step_numerically_converged_in_validator'] else '#c45852' for row in index_rows])
    axes[2].set_ylabel('Inner iterations')
    axes[2].set_title('C  Iterations per physical step (red = validator did not mark converged)', loc='left', fontsize=11)
    summary['zero_residual_samples_masked_on_log_plot'] = sum(
        max(row[field] for field in fields) == 0 for _, fields, _ in groups for row in residual)
    finish(fig, axes, 'fish_numerical_history', 'Observed steps only. Flux difference is a diagnostic; it does not include deforming-domain volume storage.')
    summary['plot_files'] = saved
    path = output_dir / 'fish_history_statistics.json'
    path.write_text(json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    return {'observed_steps': len(steps), 'time_range_s': summary['observed_time_range_s'],
            'head_expression_max_error_m': summary['head_expression']['max_absolute_error_m'],
            'maximum_tail_displacement_mm': summary['maximum_tail_total_displacement']['mm'],
            'statistics': str(path.resolve()), 'plots': saved}


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, required=True, help='Directory containing the two validator CSVs')
    parser.add_argument('--output-dir', type=Path, help='Default: INPUT_DIR/plots')
    parser.add_argument('--expected-steps', type=int, default=20, help='Planned count for disclosure only; no rows are synthesized')
    args = parser.parse_args()
    if args.expected_steps < 1:
        parser.error('--expected-steps must be positive')
    result = make_report(args.input_dir.resolve(), (args.output_dir or args.input_dir / 'plots').resolve(), args.expected_steps)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()

