"""Offline identity/seam supplement; no solver, CAD, or remeshing imports."""
from __future__ import annotations
import hashlib
import json
import os
import argparse
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np
import export_active_mesh as reader
reader.np=np

def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def ref(p,base):
    return {'path':Path(os.path.relpath(p,base)).as_posix(),'sha256':digest(p),'bytes':p.stat().st_size}

def write(p,value):
    p.write_text(json.dumps(value,indent=2),encoding='utf-8')

def inspect_directory(source,folder,identity_root=None):
    """Audit one fresh water-tail export; optionally publish a geometry manifest."""
    base=Path(__file__).resolve().parent
    folder=Path(folder).resolve(strict=True);source=Path(source).resolve(strict=True)
    first=json.loads((folder/'mesh_validation.json').read_text(encoding='utf-8'))
    assert first['status']=='offline_mesh_checks_passed' and first['mode']=='water-tail'
    assert digest(source)==first['source_mesh_sha256']
    assert not (folder/'mesh_identity.json').exists() and not (folder/'tail_root_topology.json').exists()
    if identity_root is not None:
        identity_root=Path(identity_root).resolve(strict=True)
        assert not (identity_root/'mesh_identity.json').exists()
    old=reader.parse(source);oldby={b['name']:b for b in old['blocks']}
    oldtet=reader.tets(old)
    for mode,meshname in [('water-tail','fish_water_tail.msh')]:
        meshpath=folder/meshname;new=reader.parse(meshpath)
        assert digest(meshpath)==first['output_mesh_sha256']
        newby={b['name']:b for b in new['blocks']};maps_path=folder/'source_to_active_ids.npz'
        with np.load(maps_path,allow_pickle=False) as mapping:
            tosource=mapping['active_node_id_to_source_id'].copy()
            cellsource=mapping['active_cell_id_to_source_id'].copy()
            maps_schema={name:{'dtype':str(mapping[name].dtype),'shape':list(mapping[name].shape)} for name in mapping.files}
        tet=reader.tets(new)
        assert np.array_equal(tosource[tet+1]-1,oldtet[cellsource[1:]-1])
        assert np.array_equal(new['xyz'],old['xyz'][tosource[1:]-1])
        wet_checks={}
        for name in ['body_water','fish_drive','fish_eyes','tail_water']:
            wet_checks[name]=bool(np.array_equal(tosource[newby[name]['rows'][:,:3]],oldby[name]['rows'][:,:3]))
        assert all(wet_checks.values())
        identity={'schema_version':1,'status':'offline_identity_passed','mode':mode,
          'path_base':'directory containing this JSON',
          'files':{'source_mesh':ref(source,folder),'output_mesh':ref(meshpath,folder),'id_mapping':ref(maps_path,folder)},
          'canonical_source_mesh':ref(source,folder),
          'active_mesh':ref(meshpath,folder),'source_to_active_ids':ref(maps_path,folder),
          'exporter_source_sha256':digest(base/'export_active_mesh.py'),
          'mesh_validation':ref(folder/'mesh_validation.json',folder),
          'mapping_schema':{'indexing':'All IDs 1-based; index0 sentinel; removed source IDs map to0. active_*_to_source_id arrays are indexed by active IDs.',
            'arrays':maps_schema},'cell_zones':new['cells'],
          'checks':{'active_xyz_bitwise_equal_source':True,'every_retained_tet_exact_source_vertex_IDs':True,
             'wet_triangle_vertex_order_identical_source':wet_checks},
          'native_import_verified':False,'native_cell_ID_order_verified':False,
          'note':'Fluent may duplicate shared interface vertices. Native HDF identity must compare tetrahedron coordinate sets within each named cell zone, not assume global node-ID preservation.'}
        root=newby['tail_root']['rows'][:,:3];rootids=np.unique(root)
        assert np.array_equal(tosource[root],oldby['body_tail']['rows'][:,[0,2,1]])
        keys,counts=reader.edge_counts(root,len(new['xyz']));radix=len(new['xyz'])+1
        edges=np.column_stack([keys[counts==1]//radix,keys[counts==1]%radix])
        rim=np.unique(edges);values,degrees=np.unique(edges.ravel(),return_counts=True)
        assert len(edges)==len(rim)==24 and np.all(degrees==2)
        adjacency={int(v):[] for v in rim}
        for a,b in edges:adjacency[int(a)].append(int(b));adjacency[int(b)].append(int(a))
        start=int(rim.min());ordered=[start];previous=None;current=start
        while True:
            nextnode=next(n for n in sorted(adjacency[current]) if n!=previous)
            if nextnode==start:break
            assert nextnode not in ordered
            ordered.append(nextnode);previous,current=current,nextnode
        assert len(ordered)==24
        for names in [['tail_water'],['body_water','fish_drive','fish_eyes']]:
            tri=np.vstack([newby[n]['rows'][:,:3] for n in names])
            k,c=reader.edge_counts(tri,len(new['xyz']))
            assert np.array_equal(k[c==1],keys[counts==1])
        xyz=new['xyz'];pts=xyz[rootids-1]
        assert np.max(np.abs(pts[:,0]-.14))<1e-12
        triangles=xyz[root-1];av=np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])/2
        areas=np.linalg.norm(av,axis=1)
        topology={'schema_version':1,'status':'offline_seam_passed','source_mesh':ref(source,folder),
          'active_mesh':ref(meshpath,folder),'source_to_active_ids':ref(maps_path,folder),
          'tail_root':{'zone_id':13,'faces':len(root),'nodes':len(rootids),'plane_x_m':.14,
             'xyz_bounds_m':[pts.min(axis=0).tolist(),pts.max(axis=0).tolist()],
             'area_m2':float(areas.sum()),'area_weighted_centroid_m':np.average(triangles.mean(axis=1),weights=areas,axis=0).tolist(),
             'summed_oriented_area_vector_m2':av.sum(axis=0).tolist(),
             'active_node_ids':rootids.tolist(),
             'all_original_body_tail_triangles_retained_with_reversed_orientation':True},
          'seam':{'edges':24,'vertices':24,'connected_rings':1,'each_vertex_degree':2,
             'root_tail_water_and_rigid_front_boundary_edge_sets_exactly_identical':True,
             'ring_active_node_ids':ordered,
             'vertices_in_ring_order':[{'active_node_id':n,'source_node_id':int(tosource[n]),'xyz_m':xyz[n-1].tolist()} for n in ordered]},
          'native_duplicate_vertices_expected':True,
          'note':'Source IDs and active ASCII IDs only. Native shadow creation may duplicate vertex IDs; compare exact reference coordinates and require a unique per-surface correspondence.'}
        write(folder/'tail_root_topology.json',topology)
        identity['files']['tail_root_topology']=ref(folder/'tail_root_topology.json',folder)
        identity['files']['active_validation']=ref(folder/'mesh_validation.json',folder)
        identity['files']['source_quality_record']=ref(source.parent/'mesh_validation.json',folder)
        identity['files']['source_unsplit_mesh']=ref(source.parent/'fish_fluent.msh',folder)
        identity['files']['source_eye_split_record']=ref(source.parent/'eye-zone-split.json',folder)
        assert digest(source)==first['source_mesh_sha256'] and digest(meshpath)==first['output_mesh_sha256']
        write(folder/'mesh_identity.json',identity)
        if identity_root is not None:
            def rebase(value):
                if isinstance(value,dict):
                    if 'path' in value and 'sha256' in value:
                        return {**value,'path':Path(os.path.relpath((folder/value['path']).resolve(strict=True),identity_root)).as_posix()}
                    return {k:rebase(v) for k,v in value.items()}
                if isinstance(value,list):return [rebase(v) for v in value]
                return value
            root_identity=rebase(identity)
            root_identity['path_base']='directory containing this JSON'
            write(identity_root/'mesh_identity.json',root_identity)
        print(json.dumps({'mode':mode,'seam_vertices':len(rim),'root_bbox':topology['tail_root']['xyz_bounds_m'],'root_area_m2':float(areas.sum())}))
    return identity

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--identity-root',type=Path)
    args=p.parse_args();inspect_directory(args.source,args.output,args.identity_root)
    print('Current source-to-active tetrahedron and wet-surface identities passed.')

if __name__=='__main__':main()
