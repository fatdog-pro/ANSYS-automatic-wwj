"""Inspect Fluent 261 rigid-forebody/flexible-tail case/data files offline.

No Ansys SDK or solver calls. The supported structural restart layout is
accepted only after reference-node IDs and five native report values agree.
This verifies saved checkpoints, not every intermediate nonlinear iteration.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

import h5py
import numpy as np


INTERFACE_COORDINATE_TOLERANCE_M = 1e-7
FLUID_DENSITY_KG_M3 = 1000.0
FLUID_INTERFACE_NAMES = ("body_water", "tail_water", "fish_drive", "fish_eyes")
RIGID_SURFACE_NAMES = ("body_water", "fish_drive", "fish_eyes")
WET_INTERFACE_PAIRS = (("tail_water", "tail_water-shadow"),)
EXPECTED_CELL_COUNTS = {"water": 26638, "soft_tail": 5030}
EXPECTED_TAIL_ROOT_FACES = 94
MODEL = "realistic-fish-rigid-forebody-flexible-tail"
SCHEMA_VERSION = 5
DT_S = 0.025


def prescribed_translation(time_s):
    """Actual saved coordinates, not a velocity/UDF declaration, are checked."""
    return np.array([0.0, .001*np.sin(12.566370614359172*time_s)
                     *(1-np.exp(-time_s/.5)), 0.0])


def check_model_topology(case):
    cells, faces = case["zones"]["cells"], case["zones"]["faces"]
    assert set(cells) == set(EXPECTED_CELL_COUNTS), "Expected only water and soft_tail; old full-body FSI cases are rejected"
    actual = {name: z["maxId"]-z["minId"]+1 for name,z in cells.items()}
    assert actual == EXPECTED_CELL_COUNTS, "Rigid-tail cell counts differ from canonical geometry"
    covered = np.concatenate([np.arange(z["minId"]-1,z["maxId"]) for z in cells.values()])
    assert np.array_equal(np.sort(covered), np.arange(len(case["tet"]))), "Cell zones do not cover exactly the active mesh"
    assert "body_tail" not in faces, "Old internal body-tail zone must become tail_root"
    required = set(FLUID_INTERFACE_NAMES) | {"tail_water-shadow", "tail_root"}
    assert required <= set(faces), "Missing required rigid, coupled-tail, or root surface"
    assert not any(name+"-shadow" in faces for name in RIGID_SURFACE_NAMES), "Rigid surfaces must not have invented structural shadows"
    root = faces["tail_root"]
    assert root["maxId"]-root["minId"]+1 == EXPECTED_TAIL_ROOT_FACES, "Expected the complete 94-face tail-root section"
    for name in required:
        z = faces[name]
        face_ids = np.arange(z["minId"]-1,z["maxId"])
        assert len(face_ids) > 0 and np.all(case["c1"][face_ids] == -1), "Expected boundary-only fish surfaces"
        owner = cells["soft_tail" if name in {"tail_root","tail_water-shadow"} else "water"]
        assert np.all((case["c0"][face_ids] >= owner["minId"]-1)
                      & (case["c0"][face_ids] < owner["maxId"])), "Fish boundary belongs to the wrong cell zone"
    return actual


def unique_reference_matches(reference_xyz, target_nodes, source_nodes):
    """Return source IDs; distinct arrays are never paired by array position."""
    source_nodes = np.asarray(source_nodes, dtype=int)
    assert len(source_nodes) > 0 and len(np.unique(source_nodes)) == len(source_nodes)
    source_xyz = reference_xyz[source_nodes]
    mapping = []
    for node in target_nodes:
        matches = np.flatnonzero(np.linalg.norm(source_xyz-reference_xyz[node], axis=1) < 1e-12)
        assert len(matches) == 1, "Reference vertex correspondence is missing or ambiguous"
        mapping.append(source_nodes[matches[0]])
    assert len(np.unique(mapping)) == len(mapping), "Reference correspondence must be one-to-one"
    return np.asarray(mapping, dtype=int)


def tail_root_perimeter_nodes(case):
    z = case["zones"]["faces"]["tail_root"]
    triangles = case["faces"][z["minId"]-1:z["maxId"]]
    edges = np.sort(np.concatenate([triangles[:,[0,1]],triangles[:,[1,2]],triangles[:,[2,0]]]), axis=1)
    unique_edges, counts = np.unique(edges, axis=0, return_counts=True)
    assert np.all(counts <= 2), "Tail-root section has nonmanifold edges"
    perimeter_edges = unique_edges[counts == 1]
    assert len(perimeter_edges) >= 3, "Tail-root perimeter is absent"
    nodes, degree = np.unique(perimeter_edges, return_counts=True)
    assert np.all(degree == 2), "Tail-root perimeter is not closed"
    reached, pending = {int(nodes[0])}, [int(nodes[0])]
    while pending:
        n = pending.pop()
        for a,b in perimeter_edges:
            if n in (a,b):
                other = int(b if n == a else a)
                if other not in reached:
                    reached.add(other)
                    pending.append(other)
    assert reached == set(map(int,nodes)), "Tail-root section has multiple disconnected perimeters"
    return nodes


def read_ascii_identity_mesh(path):
    """Read the exact ASCII tetrahedral layout emitted by the bundled exporter."""
    text = path.read_text(encoding="ascii")
    names = {int(i):name for i,kind,name in re.findall(r'\(45 \((\d+) ([\w-]+) ([\w-]+) 1\)',text)}
    node = re.search(r'\(10 \(1 1 ([0-9a-f]+) 1 3\)\(\n(.*?)\n\)\)',text,re.S)
    assert node is not None, "Unsupported canonical ASCII node layout"
    xyz = np.fromstring(node[2],sep=" ",dtype=float).reshape(-1,3)
    assert len(xyz) == int(node[1],16) and np.isfinite(xyz).all()
    cells = {}
    for zid,lo,hi,kind in re.findall(r'\(12 \(([0-9a-f]+) ([0-9a-f]+) ([0-9a-f]+) ([0-9a-f]+) 2\)\)',text):
        zid,lo,hi = (int(x,16) for x in (zid,lo,hi))
        assert names[zid] not in cells
        cells[names[zid]] = {"minId":lo,"maxId":hi}
    blocks, face_zones, next_face = [], {}, 1
    for zid,lo,hi,kind,body in re.findall(r'\(13 \(([0-9a-f]+) ([0-9a-f]+) ([0-9a-f]+) ([0-9a-f]+) 3\)\(\n(.*?)\n\)\)',text,re.S):
        zid,lo,hi = int(zid,16),int(lo,16),int(hi,16)
        assert lo == next_face
        assert names[zid] not in face_zones
        face_zones[names[zid]] = {"minId":lo,"maxId":hi}
        flat = np.fromiter((int(v,16) for v in body.split()),dtype=np.int64)
        assert len(flat) == (hi-lo+1)*5
        blocks.append(flat.reshape(-1,5)); next_face = hi+1
    assert cells and blocks
    rows = np.vstack(blocks)
    count = max(z["maxId"] for z in cells.values())
    assert np.all((rows[:,:3]>=1)&(rows[:,:3]<=len(xyz)))
    assert np.all((rows[:,3]>=1)&(rows[:,3]<=count)) and np.all((rows[:,4]>=0)&(rows[:,4]<=count))
    valid = rows[:,4] > 0
    cell = np.r_[rows[:,3]-1,rows[valid,4]-1]
    face = np.r_[np.arange(len(rows)),np.flatnonzero(valid)]
    order = np.argsort(cell,kind="stable")
    assert np.array_equal(cell[order],np.repeat(np.arange(count),4)), "ASCII cells do not have four faces"
    raw = np.sort(rows[face[order],:3].reshape(count,12),axis=1)
    tet = raw[:,::3]-1
    assert np.array_equal(raw,np.repeat(tet+1,3,axis=1)) and np.all(np.diff(tet,axis=1)>0)
    return {"xyz":xyz,"tet":tet,"rows":rows,"cells":cells,"faces":face_zones}


def verify_canonical_reference(reference, identity_path):
    """Verify source IDs and native per-zone tetrahedra, allowing shadow copies.

    Only the explicitly named manifest is used; no timestamp/path guessing.
    Native node IDs can differ from exported IDs and coordinates may be shared
    by fluid/shadow nodes. The comparison uses each cell's four XYZ vertices.
    """
    check_model_topology(reference)
    identity_path = Path(identity_path).resolve(strict=True)
    raw = identity_path.read_bytes()
    identity = json.loads(raw.decode("utf-8-sig"))
    files = identity["files"]
    paths, snapshots = {}, {}
    for key in ("source_mesh","output_mesh","id_mapping"):
        item = files[key]
        relative = Path(item["path"])
        assert not relative.is_absolute(), "Geometry manifest must use relative artifact paths"
        path = (identity_path.parent/relative).resolve(strict=True)
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        assert sha == item["sha256"], "Geometry identity artifact SHA mismatch"
        paths[key] = path
        snapshots[key] = {"path":str(path),"sha256":sha}
    source, active = read_ascii_identity_mesh(paths["source_mesh"]), read_ascii_identity_mesh(paths["output_mesh"])
    assert {n:z["maxId"]-z["minId"]+1 for n,z in source["cells"].items()} == {"water":26638,"stiff_body":20927,"soft_tail":5030}
    assert {n:z["maxId"]-z["minId"]+1 for n,z in active["cells"].items()} == EXPECTED_CELL_COUNTS
    with np.load(paths["id_mapping"],allow_pickle=False) as archive:
        maps = {name:archive[name] for name in ("source_node_id_to_active_id","source_cell_id_to_active_id",
            "source_face_id_to_active_id","active_node_id_to_source_id","active_cell_id_to_source_id")}
    for arr in maps.values():
        assert arr.ndim == 1 and np.issubdtype(arr.dtype,np.integer) and len(arr)>0 and arr[0] == 0 and np.all(arr>=0)
    nm,cm,fm = (maps[n] for n in ("source_node_id_to_active_id","source_cell_id_to_active_id","source_face_id_to_active_id"))
    ni,ci = (maps[n] for n in ("active_node_id_to_source_id","active_cell_id_to_source_id"))
    assert len(nm) == len(source["xyz"])+1 and len(cm) == len(source["tet"])+1 and len(fm) == len(source["rows"])+1
    assert len(ni) == len(active["xyz"])+1 and len(ci) == len(active["tet"])+1
    for forward,inverse in ((nm,ni),(cm,ci)):
        retained = np.flatnonzero(forward)
        assert np.array_equal(np.sort(forward[retained]),np.arange(1,len(inverse)))
        assert np.all((inverse[1:]>=1)&(inverse[1:]<len(forward)))
        assert np.array_equal(forward[inverse[1:]],np.arange(1,len(inverse)))
    keep_cells = np.concatenate([np.arange(source["cells"][name]["minId"],source["cells"][name]["maxId"]+1) for name in EXPECTED_CELL_COUNTS])
    assert np.array_equal(np.flatnonzero(cm),keep_cells), "Unexpected retained or removed source cells"
    assert np.array_equal(active["xyz"],source["xyz"][ni[1:]-1]), "Active coordinates differ from exact source coordinates"
    assert np.array_equal(active["tet"],nm[source["tet"][ci[1:]-1]+1]-1), "Active tetrahedra differ from mapped source cells"
    assert np.array_equal(np.unique(active["tet"]),np.arange(len(active["xyz"]))), "Active mesh has orphan nodes"
    keep_faces = (cm[source["rows"][:,3]]>0)|(cm[source["rows"][:,4]]>0)
    assert np.array_equal(np.flatnonzero(fm),np.flatnonzero(keep_faces)+1)
    assert np.array_equal(np.sort(fm[fm>0]),np.arange(1,len(active["rows"])+1))
    source_face_ids = np.flatnonzero(fm); source_face_ids = source_face_ids[np.argsort(fm[source_face_ids])]
    expected_rows = source["rows"][source_face_ids-1].copy()
    expected_rows[:,:3] = nm[expected_rows[:,:3]]
    expected_rows[:,3:] = cm[expected_rows[:,3:]]
    flip = expected_rows[:,3] == 0
    expected_rows[flip] = expected_rows[flip][:,[0,2,1,4,3]]
    assert np.array_equal(expected_rows,active["rows"]), "Active faces or adjacency differ from mapped source"
    def sorted_vertices(x):
        return np.take_along_axis(x,np.lexsort((x[:,:,2],x[:,:,1],x[:,:,0]),axis=1)[:,:,None],axis=1)
    samples = {}
    for name in EXPECTED_CELL_COUNTS:
        native_zone, active_zone = reference["zones"]["cells"][name],active["cells"][name]
        native_tets = reference["tet"][native_zone["minId"]-1:native_zone["maxId"]]
        active_tets = active["tet"][active_zone["minId"]-1:active_zone["maxId"]]
        actual = sorted_vertices(reference["xyz"][native_tets])
        expected = sorted_vertices(active["xyz"][active_tets])
        assert actual.shape == expected.shape and np.array_equal(actual,expected), "Native initial cell vertices differ from canonical active cells"
        samples[name] = {"cells":len(actual),"all_four_vertex_coordinates_exact":True}
    surface_samples = {}
    def sorted_triangles(x):
        x = sorted_vertices(x).reshape(-1,9)
        return x[np.lexsort(tuple(x[:,i] for i in reversed(range(9))))]
    for native_name in (*FLUID_INTERFACE_NAMES,"tail_root","tail_water-shadow"):
        active_name = "tail_water" if native_name == "tail_water-shadow" else native_name
        nz,az = reference["zones"]["faces"][native_name],active["faces"][active_name]
        actual = sorted_triangles(reference["xyz"][reference["faces"][nz["minId"]-1:nz["maxId"]]])
        expected = sorted_triangles(active["xyz"][active["rows"][az["minId"]-1:az["maxId"],:3]-1])
        assert actual.shape == expected.shape and np.array_equal(actual,expected), "Native initial named surface differs from canonical geometry"
        surface_samples[native_name] = {"triangles":len(actual),"all_three_vertex_coordinates_exact":True}
    assert identity_path.read_bytes() == raw
    assert all(hashlib.sha256(paths[k].read_bytes()).hexdigest()==item["sha256"] for k,item in snapshots.items()), "Geometry identity inputs changed during audit"
    return {"status":"passed","manifest":str(identity_path),"manifest_sha256":hashlib.sha256(raw).hexdigest(),
            "files":snapshots,"source_to_active_ids_verified":True,"native_initial_tetrahedra":samples,
            "native_initial_surface_triangles":surface_samples,
            "scope":"Exact source-ID and native per-cell vertex comparison; native shadow-node duplication is permitted."}


def native_step_time(variables):
    step = int(re.search(r"\(time-step\s+(\d+)\)", variables).group(1))
    time = float(re.search(r"\(flow-time\s+([^\)]+)\)", variables).group(1))
    assert np.isfinite(time), "Native flow time is nonfinite"
    return step, time


def read_native_time(path):
    before = signature(path)
    with h5py.File(path, "r") as f:
        step, time = native_step_time(f["settings/Data Variables"][0].decode())
    assert signature(path) == before, "Native data changed while its time was read"
    return {"step": step, "time_s": time, "data_file": str(path)}


def value(a):
    return int(np.asarray(a).reshape(-1)[0])


def signature(path):
    st = path.stat()
    return st.st_size, st.st_mtime_ns


def read_case(path):
    before = signature(path)
    with h5py.File(path, "r") as f:
        m = f["meshes/1"]
        assert value(m.attrs["dimension"]) == 3
        count = value(m.attrs["cellCount"])
        assert value(m["nodes/coords/1"].attrs["minId"]) == 1
        xyz = m["nodes/coords/1"][:]
        assert len(xyz) == value(m.attrs["nodeCount"])
        assert np.all(m["faces/nodes/1/nnodes"][:] == 3)
        faces = m["faces/nodes/1/nodes"][:].astype(np.int64).reshape(-1, 3) - 1
        c0 = m["faces/c0/1"][:].astype(np.int64) - 1
        c1 = np.full(len(faces), -1, dtype=np.int64)
        ds = m["faces/c1/1"]
        lo, hi = value(ds.attrs["minId"]) - 1, value(ds.attrs["maxId"])
        c1[lo:hi] = ds[:].astype(np.int64) - 1
        zones = {}
        for kind in ["cells", "faces"]:
            group = m[f"{kind}/zoneTopology"]
            names = group["name"][0].decode().split(";")
            zones[kind] = {name: {k: int(group[k][i]) for k in group if k not in {"name", "fields"}}
                           for i, name in enumerate(names)}
        assert all(z["cellType"] == 2 for z in zones["cells"].values()), "Only tetrahedra are supported"
        version = f["settings/Version"][0].decode()
    assert signature(path) == before, "Case file changed while being read"
    assert len(faces) == len(c0) and np.all((c0 >= 0) & (c0 < count))
    sets = [set() for _ in range(count)]
    adjacency = np.zeros(count, dtype=int)
    for i, face in enumerate(faces):
        for cell in (c0[i], c1[i]):
            if cell >= 0:
                assert cell < count
                sets[cell].update(map(int, face))
                adjacency[cell] += 1
    assert np.all(adjacency == 4), "Every tetrahedron must have four faces"
    assert all(len(nodes) == 4 for nodes in sets), "Every tetrahedron must have four unique vertices"
    tet = np.array([sorted(nodes) for nodes in sets], dtype=int)
    assert np.all((tet >= 0) & (tet < len(xyz))) and np.isfinite(xyz).all()
    return {"xyz": xyz, "faces": faces, "c0": c0, "c1": c1, "tet": tet,
            "zones": zones, "version": version, "signature": before}


def read_data(path):
    before = signature(path)
    with h5py.File(path, "r") as f:
        g = f["special/structure-node-data/nodes/1"]
        ids = g["elemids"][:].astype(np.int64) - 1
        assert np.all(g["ndata"][:] == 21), "Unsupported structural restart layout"
        data = g["data"][:].reshape(-1, 21)
        assert len(ids) == len(data) and len(np.unique(ids)) == len(ids)
        direct = f["special/structure-direct-data/data"][:].tolist()
        assert direct == list(range(11431, 11449)) + [11455, 11456, 11457], "Unknown Fluent 261 structural field layout"
        variables = f["settings/Data Variables"][0].decode()
        step, time = native_step_time(variables)
        stress = {}
        for name in ["XX", "YY", "ZZ", "XY", "YZ", "XZ"]:
            ds = f[f"results/1/phase-1/cells/SV_SIGMA_{name}/1"]
            stress[name] = (value(ds.attrs["minId"]) - 1, value(ds.attrs["maxId"]), ds[:])
    assert signature(path) == before, "Data file changed while being read"
    assert np.isfinite(data).all()
    return {"ids": ids, "reference_xyz": data[:, -3:], "displacement": data[:, [0, 6, 12]],
            "step": step, "time_s": time, "stress": stress, "signature": before}


def matrices(xyz, tet):
    return (xyz[tet[:, 1:]] - xyz[tet[:, 0, None]]).transpose(0, 2, 1)


def surface_nodes(case, name):
    zone = case["zones"]["faces"][name]
    return np.unique(case["faces"][zone["minId"]-1:zone["maxId"]])


def report_rows(path):
    columns = ["drive-y", "tail-y-mean", "tail-y-max", "tail-y-min", "tail-displacement",
               "force-x", "force-y", "mass-net", "mass-inlet", "mass-outlet"]
    out = {}
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        if re.match(r"^\d+\s", line):
            fields = line.split()
            assert len(fields) == 11
            step = int(fields[0])
            assert step not in out, "Duplicate native report step"
            out[step] = dict(zip(columns, map(float, fields[1:])))
            assert all(np.isfinite(v) for v in out[step].values()), "Native report has a nonfinite value"
    return out


def analyze_step(reference, case, data, history):
    model_counts = check_model_topology(reference)
    assert check_model_topology(case) == model_counts
    assert case["version"] == reference["version"]
    for key in ["faces", "c0", "c1", "tet"]:
        assert np.array_equal(case[key], reference[key]), "Mesh connectivity/IDs changed; mapping is unsupported"
    assert case["zones"] == reference["zones"], "Zone identity changed"
    assert isinstance(data["step"], int) and not isinstance(data["step"], bool) and data["step"] >= 0
    assert np.isfinite(data["time_s"]) and abs(data["time_s"]-data["step"]*DT_S) <= 2e-9, "Native clock differs from the fixed fast-profile 0.025 s contract"
    ids = data["ids"]
    assert len(ids) > 0 and np.all((ids >= 0) & (ids < len(reference["xyz"])))
    assert len(np.unique(ids)) == len(ids), "Structural node IDs are not unique"
    ref_error = float(np.max(np.abs(data["reference_xyz"] - reference["xyz"][ids])))
    assert ref_error < 1e-12, "Explicit structural node IDs do not map to reference-case coordinates"
    full_disp = np.full_like(case["xyz"], np.nan)
    full_disp[ids] = data["displacement"]
    root_nodes = surface_nodes(case, "tail_root")
    drive = full_disp[root_nodes]
    tail = full_disp[surface_nodes(case, "tail_water-shadow")]
    assert np.isfinite(drive).all() and np.isfinite(tail).all()
    computed = {"drive-y": float(drive[:, 1].mean()), "tail-y-mean": float(tail[:, 1].mean()),
                "tail-y-max": float(tail[:, 1].max()), "tail-y-min": float(tail[:, 1].min()),
                "tail-displacement": float(np.linalg.norm(tail, axis=1).max())}
    compare = {}
    for name, actual in computed.items():
        expected = history[name]
        diff = abs(actual - expected)
        ok = bool(np.isclose(actual, expected, rtol=1e-6, atol=1e-10))
        compare[name] = {"hdf_reconstructed": actual, "native_report": expected, "absolute_difference": diff, "passed": ok}
    assert all(c["passed"] for c in compare.values()), "Restart displacement mapping did not match native reports"
    # Orientation is inherited from each initial tetrahedron, never reoriented
    # independently in the current mesh (which would hide inverted elements).
    tet = case["tet"]
    dref = matrices(reference["xyz"], tet)
    determinants_ref = np.linalg.det(dref)
    assert np.all(np.abs(determinants_ref) > 1e-30)
    determinant_current = np.linalg.det(matrices(case["xyz"], tet))
    volumes = determinant_current * np.sign(determinants_ref) / 6
    water = case["zones"]["cells"]["water"]
    fluid_cells = np.arange(water["minId"]-1, water["maxId"])
    tail_zone = case["zones"]["cells"]["soft_tail"]
    solid_cells = np.arange(tail_zone["minId"]-1,tail_zone["maxId"])
    solid_nodes = np.unique(tet[solid_cells])
    assert np.array_equal(np.sort(ids), solid_nodes), "Structural IDs must cover exactly all solid vertices"
    solid_xyz = reference["xyz"].copy()
    solid_xyz[ids] += data["displacement"]
    solid_ds = matrices(solid_xyz, tet[solid_cells])
    F = solid_ds @ np.linalg.inv(dref[solid_cells])
    J = np.linalg.det(F)
    C = F.transpose(0, 2, 1) @ F
    principal_strain = np.sqrt(np.maximum(np.linalg.eigvalsh(C), 0.0)) - 1.0
    stress_arrays = {}
    for name, (lo, hi, values) in data["stress"].items():
        assert np.array_equal(np.arange(lo, hi), solid_cells), "Stress cell IDs differ from solid cell IDs"
        stress_arrays[name] = values
    a = stress_arrays
    von_mises = np.sqrt(0.5*((a["XX"]-a["YY"])**2+(a["YY"]-a["ZZ"])**2+(a["ZZ"]-a["XX"])**2)
                        + 3*(a["XY"]**2+a["YZ"]**2+a["XZ"]**2))
    wet_errors = {}
    for fluid_name, solid_name in WET_INTERFACE_PAIRS:
        assert fluid_name in case["zones"]["faces"] and solid_name in case["zones"]["faces"], "A required realistic-fish interface or shadow is missing"
        fluid_nodes = surface_nodes(case, fluid_name)
        paired_solid_nodes = surface_nodes(case, solid_name)
        # Mapping uses exact initial coordinates, with a uniqueness check,
        # never equal array positions in independently numbered node arrays.
        mapping = unique_reference_matches(reference["xyz"],fluid_nodes,paired_solid_nodes)
        err = np.linalg.norm(case["xyz"][fluid_nodes]-solid_xyz[mapping], axis=1)
        shadow_motion = case["xyz"][paired_solid_nodes] - reference["xyz"][paired_solid_nodes]
        shadow_error = shadow_motion - full_disp[paired_solid_nodes]
        wet_errors[fluid_name] = {
            "vertices": len(fluid_nodes),
            "max_fluid_coordinate_vs_solved_solid_error_m": float(err.max()),
            "interface_coordinate_tolerance_m": INTERFACE_COORDINATE_TOLERANCE_M,
            "interface_coordinate_consistency_passed": bool(np.isfinite(err).all() and np.all(err <= INTERFACE_COORDINATE_TOLERANCE_M)),
            "solid_shadow_vertices": len(paired_solid_nodes),
            "solid_shadow_max_case_coordinate_motion_m": float(np.linalg.norm(shadow_motion, axis=1).max()),
            "solid_shadow_max_solved_displacement_m": float(np.linalg.norm(full_disp[paired_solid_nodes], axis=1).max()),
            "solid_shadow_max_coordinate_motion_vs_solved_displacement_error_m": float(np.linalg.norm(shadow_error, axis=1).max()),
            "solid_shadow_mean_coordinate_motion_minus_solved_displacement_xyz_m": shadow_error.mean(axis=0).tolist(),
            "solid_shadow_max_abs_coordinate_motion_minus_solved_displacement_xyz_m": np.abs(shadow_error).max(axis=0).tolist(),
        }
    coupled_passed = set(wet_errors) == {"tail_water"} and all(x["interface_coordinate_consistency_passed"] for x in wet_errors.values())
    expected_translation = prescribed_translation(data["time_s"])
    rigid_errors = {}
    for name in RIGID_SURFACE_NAMES:
        nodes = surface_nodes(case,name)
        expected = reference["xyz"][nodes] + expected_translation
        error = np.linalg.norm(case["xyz"][nodes]-expected,axis=1)
        rigid_errors[name] = {"vertices":len(nodes),
            "max_actual_coordinate_vs_prescribed_error_m":float(error.max()),
            "coordinate_tolerance_m":INTERFACE_COORDINATE_TOLERANCE_M,
            "passed":bool(np.isfinite(error).all() and np.all(error <= INTERFACE_COORDINATE_TOLERANCE_M))}
    root_error = np.linalg.norm(drive-expected_translation,axis=1)
    root_check = {"faces":EXPECTED_TAIL_ROOT_FACES,"vertices":len(root_nodes),
        "max_FE_displacement_vs_prescribed_error_m":float(root_error.max()),
        "coordinate_tolerance_m":INTERFACE_COORDINATE_TOLERANCE_M,
        "passed":bool(np.isfinite(root_error).all() and np.all(root_error <= INTERFACE_COORDINATE_TOLERANCE_M))}
    perimeter_nodes = tail_root_perimeter_nodes(reference)
    rigid_nodes = np.unique(np.concatenate([surface_nodes(reference,name) for name in RIGID_SURFACE_NAMES]))
    rigid_perimeter_nodes = unique_reference_matches(reference["xyz"],perimeter_nodes,rigid_nodes)
    seam_error = np.linalg.norm(case["xyz"][rigid_perimeter_nodes]-solid_xyz[perimeter_nodes],axis=1)
    seam_check = {"vertices":len(perimeter_nodes),"reference_matching":"unique reference coordinate within 1e-12 m",
        "max_rigid_coordinate_vs_solved_tail_root_error_m":float(seam_error.max()),
        "coordinate_tolerance_m":INTERFACE_COORDINATE_TOLERANCE_M,
        "passed":bool(np.isfinite(seam_error).all() and np.all(seam_error <= INTERFACE_COORDINATE_TOLERANCE_M))}
    rigid_passed = set(rigid_errors) == set(RIGID_SURFACE_NAMES) and all(x["passed"] for x in rigid_errors.values())
    interface_passed = coupled_passed and rigid_passed and root_check["passed"] and seam_check["passed"]
    finite = bool(np.isfinite(volumes).all() and np.isfinite(J).all() and np.isfinite(principal_strain).all() and np.isfinite(von_mises).all())
    return {"step": data["step"], "time_s": data["time_s"], "mapping_verified": True,
            "model":MODEL,"active_cell_counts":model_counts,
            "drive_report_surface":"tail_root","prescribed_translation_m":expected_translation.tolist(),
            "reference_coordinate_mapping_max_error_m": ref_error, "native_report_crosschecks": compare,
            "fluid_cells": len(fluid_cells), "solid_cells": len(solid_cells), "solid_nodes": len(ids),
            "fluid_min_volume_m3": float(volumes[fluid_cells].min()),
            "fluid_total_volume_m3": float(volumes[fluid_cells].sum()),
            "reference_fluid_volume_m3": float((np.abs(determinants_ref[fluid_cells])/6).sum()),
            "fluid_nonpositive_volume_cells": int(np.count_nonzero(volumes[fluid_cells] <= 0)),
            "all_case_mesh_min_volume_m3": float(volumes.min()),
            "all_case_mesh_nonpositive_volume_cells": int(np.count_nonzero(volumes <= 0)),
            "solid_min_deformation_J": float(J.min()), "solid_max_deformation_J": float(J.max()),
            "solid_nonpositive_deformation_J_cells": int(np.count_nonzero(J <= 0)),
            "solid_max_abs_principal_engineering_strain": float(np.abs(principal_strain).max()),
            "solid_max_von_mises_Pa": float(von_mises.max()),
            "solid_max_displacement_m": float(np.linalg.norm(data["displacement"], axis=1).max()),
            "fluid_solid_interface_coordinate_comparison": wet_errors,
            "coupled_tail_interface_consistency_passed":coupled_passed,
            "rigid_surface_coordinate_comparison":rigid_errors,
            "rigid_surfaces_follow_prescribed_motion":rigid_passed,
            "tail_root_constraint":root_check,"body_tail_perimeter_seam":seam_check,
            "interface_coordinate_tolerance_m": INTERFACE_COORDINATE_TOLERANCE_M,
            "interface_coordinate_consistency_passed": interface_passed,
            "all_computed_values_finite": finite,
            "geometric_checks_passed": bool(finite and np.all(volumes > 0) and np.all(J > 0) and interface_passed)}


def add_ale_mass_diagnostics(results, history, initial, expected_count=None):
    """Add a diagnostic, not an acceptance gate, for moving-domain storage.

    The native inlet/outlet mass report uses positive net inflow. For this
    fixed-density, impermeable-wall domain the first-order global balance is
    rho*(V[n]-V[n-1])/(t[n]-t[n-1]) - net_inflow. Native timestamps are used;
    no derivative is inferred across a missing completed step.
    """
    states = {x["step"]: x for x in results}
    if initial.get("status") == "read":
        states[0] = initial
    computed = []
    for item in results:
        step = item["step"]
        previous = states.get(step-1)
        diagnostic = {
            "status": "unknown", "acceptance_gate": False,
            "fluid_density_kg_m3": FLUID_DENSITY_KG_M3,
            "density_basis": "Fixed density 1000 kg/m3 of this prescribed water example; no density field reconstruction.",
            "native_mass_net_kg_s": history[step]["mass-net"],
            "native_mass_inlet_kg_s": history[step]["mass-inlet"],
            "native_mass_outlet_kg_s": history[step]["mass-outlet"],
            "native_report_sign": "Positive net inflow; native mass-net is inlet plus outlet flux only.",
            "formula": "rho*(V_n-V_previous)/(t_n-t_previous) - native_mass_net",
            "scope": "First-order finite difference over adjacent saved native times; stationary outer boundaries and impermeable moving fish wall.",
        }
        item["ale_mass_balance_diagnostic"] = diagnostic
        if previous is None:
            diagnostic["reason"] = "Previous adjacent saved step or native initial time was not audited."
            continue
        dt = item["time_s"] - previous["time_s"]
        if not np.isfinite(dt) or dt <= 0:
            diagnostic["reason"] = "Adjacent native times are not finite and strictly increasing."
            continue
        storage = FLUID_DENSITY_KG_M3*(item["fluid_total_volume_m3"]-previous["fluid_total_volume_m3"])/dt
        residual = storage - history[step]["mass-net"]
        inlet = abs(history[step]["mass-inlet"])
        normalized = abs(residual)/inlet if inlet > 1e-12 else None
        if not np.isfinite(storage) or not np.isfinite(residual):
            diagnostic["reason"] = "Storage or combined ALE residual is nonfinite."
            continue
        diagnostic.update(status="computed", previous_step=step-1,
                          previous_time_s=previous["time_s"], native_dt_s=dt,
                          previous_fluid_volume_m3=previous["fluid_total_volume_m3"],
                          fluid_volume_change_m3=item["fluid_total_volume_m3"]-previous["fluid_total_volume_m3"],
                          storage_rho_dV_dt_kg_s=float(storage),
                          ale_mass_residual_kg_s=float(residual),
                          abs_ale_residual_over_abs_inlet=float(normalized) if normalized is not None else None)
        if normalized is None:
            diagnostic["normalization_reason"] = "Native inlet flow magnitude is at most 1e-12 kg/s."
        computed.append(diagnostic)
    expected_count = len(results) if expected_count is None else expected_count
    summary = {
        "status": "computed_for_all_requested_steps" if results and len(computed) == expected_count else "partial_or_unavailable",
        "computed_steps": len(computed), "requested_steps": expected_count, "acceptance_gate": False,
        "formula": "rho*dV_fluid/dt - native_mass_net, with positive native net inflow",
        "limitation": "Independent moving-control-volume diagnostic; not experimental accuracy, not an added acceptance threshold, and not the inlet/outlet flux difference alone.",
    }
    if computed:
        summary.update(max_abs_storage_rho_dV_dt_kg_s=max(abs(x["storage_rho_dV_dt_kg_s"]) for x in computed),
                       max_abs_ale_mass_residual_kg_s=max(abs(x["ale_mass_residual_kg_s"]) for x in computed))
        normalized = [x["abs_ale_residual_over_abs_inlet"] for x in computed if x["abs_ale_residual_over_abs_inlet"] is not None]
        summary["max_abs_ale_residual_over_abs_inlet"] = max(normalized) if normalized else None
    return summary


def unique_existing(candidates, description):
    found = list(dict.fromkeys(p.resolve() for p in candidates if p.exists()))
    if len(found) != 1:
        raise ValueError(f"Expected exactly one {description}; found {len(found)}: {[str(p) for p in found]}")
    return found[0]


def checkpoint_paths(root, step, checkpoint_dir=None):
    directories = [Path(checkpoint_dir).resolve()] if checkpoint_dir else [root, root / "checkpoints"]
    candidates = [(directory / f"{stem}.cas.h5", directory / f"{stem}.dat.h5")
                  for directory in directories
                  for stem in [f"fish-step{step:04d}", f"fish-step-{step:04d}"]]
    # An incomplete pair remains a candidate so it cannot silently be ignored
    # in favor of another filename. Ambiguity is an error, never a best guess.
    found = [(cas.resolve(), dat.resolve()) for cas, dat in candidates if cas.exists() or dat.exists()]
    found = list(dict.fromkeys(found))
    if len(found) != 1:
        raise ValueError(f"Expected exactly one checkpoint pair for step {step}; found {len(found)}: {found}")
    cas, dat = found[0]
    if not cas.is_file() or not dat.is_file():
        raise ValueError(f"Incomplete checkpoint pair for step {step}: {cas}, {dat}")
    return cas, dat


def validate(run_dir, steps, output, reference_case=None, checkpoint_dir=None, geometry_identity=None):
    """Read completed checkpoints, write the JSON audit, and return its dict.

    Supports root/fish-step0001.* and checkpoints/fish-step-0001.*.
    Multiple matching layouts are rejected. Explicit overrides resolve an
    intended checkpoint directory/reference without choosing by timestamp.
    """
    root = Path(run_dir).resolve()
    output = Path(output)
    steps = list(steps)
    if not steps or any(isinstance(s, bool) or not isinstance(s, int) or s < 1 for s in steps) or len(set(steps)) != len(steps):
        raise ValueError("Steps must be a nonempty list of unique positive integers")
    ref_candidates = ([Path(checkpoint_dir) / "fish-initial.cas.h5"] if checkpoint_dir
                      else [root / "fish-initial.cas.h5", root / "checkpoints/fish-initial.cas.h5"])
    ref_path = Path(reference_case).resolve() if reference_case else unique_existing(ref_candidates, "initial reference case")
    reference = read_case(ref_path)
    check_model_topology(reference)
    identity_path = Path(geometry_identity) if geometry_identity else root/"geometry/mesh_identity.json"
    canonical_identity = verify_canonical_reference(reference,identity_path)
    history = report_rows(root / "fish-history.out")
    results, failures = [], []
    for step in steps:
        try:
            cas, dat = checkpoint_paths(root, step, checkpoint_dir)
            case, data = read_case(cas), read_data(dat)
            assert data["step"] == step, "Checkpoint filename and native time-step disagree"
            item = analyze_step(reference, case, data, history[step])
            item["source_files"] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [cas, dat]}
            assert signature(cas) == case["signature"] and signature(dat) == data["signature"], "Checkpoint changed during audit"
            results.append(item)
        except Exception as exc:
            failures.append({"step": step, "error": f"{type(exc).__name__}: {exc}"})
    # The initial volume comes from the verified reference mesh. Its time must
    # come from the native initial data; a missing file is never assumed t=0.
    water = reference["zones"]["cells"]["water"]
    ref_fluid_tet = reference["tet"][water["minId"]-1:water["maxId"]]
    reference_volume = float((np.abs(np.linalg.det(matrices(reference["xyz"], ref_fluid_tet)))/6).sum())
    initial = {"status": "unknown", "fluid_total_volume_m3": reference_volume}
    try:
        if not ref_path.name.endswith(".cas.h5"):
            raise ValueError("Reference case name cannot identify its native initial data pair")
        initial_dat = ref_path.with_name(ref_path.name[:-len(".cas.h5")] + ".dat.h5")
        initial.update(read_native_time(initial_dat))
        assert initial["step"] == 0, "Reference data must be native initial time-step zero"
        assert abs(initial["time_s"]) <= 2e-9, "Reference data must be native flow-time zero"
        initial["status"] = "read"
    except Exception as exc:
        initial["reason"] = f"{type(exc).__name__}: {exc}"
    ale_diagnostics = add_ale_mass_diagnostics(results, history, initial, expected_count=len(steps))
    complete = len(results) == len(steps) and not failures and initial.get("status") == "read"
    report = {"schema_version": SCHEMA_VERSION, "model": MODEL, "run_dir": str(root), "requested_steps": steps,
              "required_fluid_interfaces": list(FLUID_INTERFACE_NAMES),
              "required_coupled_interfaces":["tail_water"],"required_rigid_surfaces":list(RIGID_SURFACE_NAMES),
              "expected_cell_counts":EXPECTED_CELL_COUNTS,"required_root_surface":"tail_root",
              "scope": "Saved checkpoints only; no guarantee for unsaved intermediate iterations",
              "mapping_method": "Native node/cell ID attributes, identical case connectivity, exact reference-coordinate equality and native report comparisons",
              "reference_case": str(ref_path), "results": results, "failures": failures,
              "canonical_reference_identity":canonical_identity,
              "reference_fluid_volume_m3": reference_volume,
              "native_initial_state": initial, "ale_mass_balance_diagnostic": ale_diagnostics,
              "interface_coordinate_tolerance_m": INTERFACE_COORDINATE_TOLERANCE_M,
              "interface_tolerance_scope": "0.1 micrometre numerical position-consistency gate; not experimental or physical accuracy.",
              "all_requested_interface_coordinate_checks_passed": bool(complete and all(x["interface_coordinate_consistency_passed"] for x in results)),
              "all_requested_checkpoint_geometry_checks_passed": bool(complete and all(x["geometric_checks_passed"] for x in results)),
              "limitations": ["Layout-specific to the inspected Fluent 261 files; unknown layouts fail closed.",
                              "Geometric strain is reconstructed from linear tetrahedral nodal displacement, not a new Ansys result field.",
                              "Forebody is prescribed rigid motion; FE displacement and stress are verified only for the flexible tail.",
                              "Case-mesh solid interior coordinates are not interpreted as physical solid displacement.",
                              "No native reopen, solution convergence, material calibration or mesh/time independence is inferred."]}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)+"\n", encoding="utf-8")
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--steps", nargs="+", type=int, required=True,
                        help="Explicit already-completed checkpoints; do not select a file being written")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--reference-case", type=Path)
    parser.add_argument("--checkpoint-dir", type=Path,
                        help="Explicit directory if automatic root/checkpoints resolution is ambiguous")
    parser.add_argument("--geometry-identity", type=Path,
                        help="Explicit exported mesh_identity.json; default is run-dir/geometry/mesh_identity.json")
    args = parser.parse_args(argv)
    report = validate(args.run_dir, args.steps, args.output, args.reference_case, args.checkpoint_dir,args.geometry_identity)
    results, failures = report["results"], report["failures"]
    print(json.dumps({"completed_checkpoints": len(results), "failures": failures,
                      "passed": report["all_requested_checkpoint_geometry_checks_passed"], "output": str(args.output)}, ensure_ascii=False))
    return 0 if report["all_requested_checkpoint_geometry_checks_passed"] else 2


if __name__ == "__main__":
    sys.exit(main())
