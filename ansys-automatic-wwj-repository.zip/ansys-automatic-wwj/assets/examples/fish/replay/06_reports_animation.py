"""Show the rigid forebody plus solved tail displacement in one native scene."""
from pathlib import Path

s=solver.settings
g=s.results.graphics
animations=s.solution.calculation_activity.solution_animations
if 'fish-swim' in animations.get_object_names():
    animations.delete(name_list=['fish-swim'])
if 'fish-displacement' not in g.contour.get_object_names():
    g.contour.create(name='fish-displacement')
c=g.contour['fish-displacement']
c.field='total-displacement'
c.surfaces_list=['tail_water-shadow']
c.options.filled=True
c.options.node_values=True
c.range_options.auto_range=False
c.range_options.minimum=0.0
c.range_options.maximum=0.004
# These intrinsic-FSI wall/shadow coordinates already follow the solved motion.
# Do not add postprocessing displacement to the moving interface a second time.
# The fresh contour already disables extra postprocessing deformation. Fluent
# exposes this value as read-only before the first structural solution.
if c.deformation.get_state() is not False:
    raise RuntimeError('Extra display deformation must be disabled for moving-mesh animation.')
# deformation_scale is read-only when this moving-mesh contour has deformation
# disabled; retain its native default instead of calling its setter.
body_name='fish-rigid-forebody'
if body_name not in g.mesh.get_object_names():
    g.mesh.create(name=body_name)
body=g.mesh[body_name]
body.surfaces_list=['body_water','fish_drive','fish_eyes']
body.options.edges=False
body.options.faces=True
scene_name='fish-moving-geometry'
scenes=s.results.scene
if scene_name in scenes.get_object_names():
    scenes.delete(name_list=[scene_name])
scenes.create(name=scene_name)
scene=scenes[scene_name]
scene.graphics_objects.add(name=body_name)
scene.graphics_objects.add(name='fish-displacement')
scene.display()
g.views.camera.projection='orthographic'
g.views.camera.position=[0.1,-0.3,0.3]
g.views.camera.target=[0.1,0,0]
g.views.camera.up_vector=[0,0,1]
g.views.camera.field=[0.30,0.20]
# Replaying into a dedicated existing session can retain its named view.
# Delete only this example's view to avoid the native overwrite question.
if 'fish-oblique' in (g.views.restore_view.view_name.allowed_values() or []):
    g.views.delete_view(view_name='fish-oblique')
g.views.save_view(view_name='fish-oblique')
rd=s.solution.report_definitions
for name, kind, field, zones in [
    ('tail-y-mean','surface-vertexavg','y-displacement',['tail_water-shadow']),
    ('tail-y-max','surface-vertexmax','y-displacement',['tail_water-shadow']),
    ('tail-y-min','surface-vertexmin','y-displacement',['tail_water-shadow']),
    ('drive-y','surface-vertexavg','y-displacement',['tail_root']),
    ('tail-displacement','surface-vertexmax','total-displacement',['tail_water-shadow']),
    ('mass-net','surface-massflowrate',None,['inlet','outlet']),
    ('mass-inlet','surface-massflowrate',None,['inlet']),
    ('mass-outlet','surface-massflowrate',None,['outlet'])]:
    if name not in rd.surface.get_object_names():
        rd.surface.create(name=name)
    r=rd.surface[name]
    r.report_type=kind
    r.surface_names=zones
    if field:
        r.field=field
for name, group, direction, output in [('force-x',rd.drag,[1,0,0],'Drag Force'),('force-y',rd.lift,[0,1,0],'Lift Force')]:
    if name not in group.get_object_names():
        group.create(name=name)
    group[name].zones=['body_water','tail_water','fish_drive','fish_eyes']
    group[name].force_vector=direction
    group[name].report_output_type=output
names=['drive-y','tail-y-mean','tail-y-max','tail-y-min','tail-displacement','force-x','force-y','mass-net','mass-inlet','mass-outlet']
files=s.solution.monitor.report_files
if 'fish-history' not in files.get_object_names():
    files.create(name='fish-history')
files['fish-history'].file_name=run_dir+'/fish-history.out'
files['fish-history'].report_defs=names
files['fish-history'].frequency=1
files['fish-history'].active=True
plots=s.solution.monitor.report_plots
if 'fish-motion-history' not in plots.get_object_names():
    plots.create(name='fish-motion-history')
plots['fish-motion-history'].report_defs=['drive-y','tail-y-mean']
animation_dir = Path(run_dir) / 'animations'
animation_dir.mkdir(exist_ok=True)
animations.create(name='fish-swim', storage_dir=animation_dir.as_posix(), animate_on=scene_name)
animations['fish-swim'].frequency_of='time-step'
animations['fish-swim'].frequency=1
animations['fish-swim'].storage_type='hsf'
animations['fish-swim'].window_id=1
animations['fish-swim'].view='fish-oblique'
if Path(animations['fish-swim'].storage_dir.get_state()).resolve() != animation_dir.resolve():
    raise RuntimeError('Native animation storage directory belongs to another run.')
if animations['fish-swim'].animate_on.get_state() != scene_name:
    raise RuntimeError('Native animation is not attached to the complete moving fish scene.')
g.views.rendering_options.double_buffering=True
record('reports_animation_setup', {
    'report_names': names,
    'report_file': files['fish-history'].get_state(),
    'animation': animations['fish-swim'].get_state(),
    'contour': c.get_state(),
    'scene': scene.get_state(),
    'rigid_forebody_mesh': body.get_state(),
    'drive_report_scope': 'Mean FE Y-displacement on the complete tail_root section.',
    'initial_reports': rd.compute(report_defs=names),
})
