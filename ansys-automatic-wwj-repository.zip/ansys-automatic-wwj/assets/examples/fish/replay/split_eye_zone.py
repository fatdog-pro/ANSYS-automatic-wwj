"""Split existing wet faces into an eye display/BC zone; coordinates stay fixed."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import numpy as np


def main():
    p=argparse.ArgumentParser();p.add_argument('--geometry-dir',type=Path,required=True);a=p.parse_args()
    source=a.geometry_dir/'fish_fluent.msh'
    output=a.geometry_dir/'fish_refined_eyes.msh'
    text=source.read_text(encoding='ascii')
    node=re.search(r'\(10 \(1 1 ([0-9a-f]+) 1 3\)\(\n(.*?)\n\)\)',text,re.S)
    if not node:raise ValueError('Expected explicit ASCII node section')
    xyz=np.array([[float(v) for v in line.split()] for line in node[2].splitlines()])
    assert len(xyz)==int(node[1],16)
    eyes=a.geometry_dir/'fish_eyes_surface.stl'
    values=re.findall(r'^\s*vertex\s+([-+eE.\d]+)\s+([-+eE.\d]+)\s+([-+eE.\d]+)',eyes.read_text(encoding='ascii'),re.M)
    eye_tri=np.array(values,dtype=float).reshape(-1,3,3)
    # STL writes 12 significant digits whereas the volume mesh writes 16.
    # Recover exact node IDs with a strict distance bound, not rounded keys.
    points, inverse=np.unique(eye_tri.reshape(-1,3),axis=0,return_inverse=True)
    node_ids=[];distances=[]
    for point in points:
        distance2=np.einsum('ij,ij->i',xyz-point,xyz-point)
        index=int(distance2.argmin());distance=float(np.sqrt(distance2[index]))
        if distance>2e-12:raise ValueError(f'Eye STL node mismatch: {distance} m')
        node_ids.append(index+1);distances.append(distance)
    eye_nodes=np.asarray(node_ids)[inverse].reshape(-1,3)
    eye_keys={tuple(sorted(map(int,tri))) for tri in eye_nodes}
    block=re.search(r'\(13 \(12 ([0-9a-f]+) ([0-9a-f]+) 3 3\)\(\n(.*?)\n\)\)',text,re.S)
    if not block:raise ValueError('Expected body_water face zone 18')
    assert '(45 (20 ' not in text and not re.search(r'\(13 \(14 ',text)
    first,last=int(block[1],16),int(block[2],16)
    rows=[[int(v,16) for v in line.split()] for line in block[3].splitlines()]
    assert len(rows)==last-first+1 and all(len(row)==5 for row in rows)
    selected=[];remaining=[];found=set()
    for row in rows:
        key=tuple(sorted(row[:3]))
        if key in eye_keys:selected.append(row);found.add(key)
        else:remaining.append(row)
    assert len(selected)==len(eye_keys) and found==eye_keys,(len(selected),len(eye_keys))
    assert len(remaining)>0 and len(selected)>0
    def encode(zone,start,items):
        head=f'(13 ({zone:x} {start:x} {start+len(items)-1:x} 3 3)(\n'
        return head+'\n'.join(' '.join(f'{v:x}' for v in row) for row in items)+'\n))'
    replacement=encode(18,first,remaining)+'\n'+encode(20,first+len(remaining),selected)
    updated=text[:block.start()]+replacement+text[block.end():]+'(45 (20 wall fish_eyes 1)())\n'
    assert node[0] in updated
    assert sorted(map(tuple,remaining+selected))==sorted(map(tuple,rows))
    output.write_text(updated,encoding='ascii',newline='\n')
    report={'source':str(source.resolve()),'output':str(output.resolve()),
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'body_faces_before':len(rows),'body_faces_after':len(remaining),'eye_faces':len(selected),
        'node_section_unchanged':True,'original_face_connectivity_and_adjacency_preserved':True,
        'volume_zones_unchanged':True,'eye_zone_name':'fish_eyes','eye_zone_id':20,
        'max_stl_node_match_error_m':max(distances),'node_matching_tolerance_m':2e-12,
        'future_fsi_note':'Include fish_eyes and fish_eyes-shadow in dynamic-mesh/FSI and force groups before a new solve.',
        'scope':'Surface zone partition of existing mesh faces, with no new geometry or solution fields.'}
    (a.geometry_dir/'eye-zone-split.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
