"""Rebuild a refined rigid forebody and two-way FSI flexible tail via official APIs.

Only --plan and --check-only are read-only. A normal run creates fresh geometry,
initializes new fields, and recomputes every physical time step. No bundled
case/data is loaded. The native Fluent GUI remains open on success or failure.

The numerical schedule is isolated in 07_numerical_controls.py. Phase scripts
must not advance time themselves. --check-only reports missing final assets.
"""
from __future__ import annotations

import argparse
from collections import Counter
import contextlib
import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid


BASELINE_VERSION = '26.1.0'
REPLAY_SETTINGS = {
    'physical_model': 'realistic-fish-rigid-forebody-flexible-tail',
    'skew_smoothing_cycles': 0,
    'processor_count': 1,
    'solution_stabilization_enabled': False,
    'solution_stabilization_scale': 0.01,
    'dt_s': 0.025,
    'time_steps': 20,
    'max_iterations_per_step': 100,
    'flow_scheme': 'Coupled',
    'structure_under_relaxation': 1.0,
    'structure_under_relaxation_after_first': 1.0,
    'structure_corrector_under_relaxation': None,  # Optional synchronous event corrector.
    'implicit_mesh_relaxation': 0.25,
    'implicit_mesh_residual_criterion': 1e-10,
}
GEOMETRY_GENERATOR = 'generate_realistic_fish.py'
GEOMETRY_SETTINGS = {'body': 0.003, 'tail': 0.002, 'far': 0.03,
                     'eye_ball': 0.001, 'gill_pole_ball': 0.00075}
SOLVER_MESH = 'active-tail/fish_water_tail.msh'
CONFIGURATION_STAGES = (
    ('02_materials.py', 'Set water and elastic-tail material/model definitions'),
    ('03_fsi_boundaries.py', 'Set tail intrinsic two-way FSI and complete tail-root displacement'),
    ('04_dynamic_mesh.py', 'Compile and bind prescribed rigid forebody motion and coupled tail mesh'),
    ('05_initialize.py', 'Initialize newly generated mesh at physical time zero'),
    ('06_reports_animation.py', 'Create native reports, displacement display and animation'),
)
NUMERICAL_STAGE = '07_numerical_controls.py'
GRAPHICS_STAGE = '08a_flow_graphics.py'
FINAL_STAGE = '08_finalize.py'
REQUIRED_FILES = ['replay_fluent_fish.py', GEOMETRY_GENERATOR, 'mesh_export.py', 'fluent_quality.py', 'split_eye_zone.py',
                  'rigid_tail_motion.py', 'fish_rigid_forebody_motion.c',
                  'prepare_rigid_tail_geometry.py', 'export_active_mesh.py', 'inspect_export_identity.py',
                  'validate_fish_run.py', 'validate_fish_checkpoints.py',
                  *[name for name, _ in CONFIGURATION_STAGES], NUMERICAL_STAGE, GRAPHICS_STAGE, FINAL_STAGE]


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def write_json(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str,
                                   allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def check_structure_corrector_record(value, step, settings):
    """Recompute the event schedule contract; this is not a convergence check.

    Fluent can emit one old-index event when a new time level opens. It must
    precede new iterations and leave the predictor unchanged. Only the first
    genuinely new IterationEnded event may write the corrector URF.
    """
    checks, failures = {}, []
    def close(actual, expected, tolerance=1e-12):
        return (not isinstance(actual, bool) and isinstance(actual, (int, float))
                and math.isfinite(actual) and math.isclose(actual, expected, rel_tol=0, abs_tol=tolerance))
    def integer(value):
        return isinstance(value, int) and not isinstance(value, bool)
    try:
        predictor = settings['structure_under_relaxation'] if step == 1 else settings['structure_under_relaxation_after_first']
        corrector, dt = settings['structure_corrector_under_relaxation'], settings['dt_s']
        start, end = value.get('starting_iteration'), value.get('ending_iteration')
        rows = value.get('events', [])
        checks = {
            'enabled_and_identified': corrector is not None and value.get('enabled') is True and value.get('step') == step,
            'declared_schedule_matches': close(value.get('predictor_urf'), predictor) and close(value.get('corrector_urf'), corrector),
            'registered_and_unregistered': value.get('registered') is True and value.get('unregistered') is True,
            'one_native_physical_step_call': value.get('native_call_count') == 1 and value.get('native_call_returned') is True,
            'no_runtime_or_callback_errors': value.get('errors') == [],
            'start_end_iteration_valid': integer(start) and integer(end) and start >= 0 and 1 <= end-start <= settings['max_iterations_per_step'],
            'start_end_time_valid': close(value.get('flow_time_before_s'), (step-1)*dt, max(1e-10,dt*1e-7)) and close(value.get('flow_time_after_s'),step*dt,max(1e-10,dt*1e-7)),
            'start_end_urf_valid': close(value.get('urf_before'), predictor) and close(value.get('urf_after'),corrector),
            'nonempty_session_identity': isinstance(value.get('expected_session_id'), str) and bool(value.get('expected_session_id')),
            'events_are_nonempty_list': isinstance(rows, list) and bool(rows),
        }
        new_count, carryover_count = 0, 0
        for position, row in enumerate(rows, 1):
            index = row.get('native_iteration')
            is_carryover = row.get('event_kind') == 'time_level_carryover'
            expected_pre = predictor if new_count == 0 else corrector
            row_checks = {
                'position': row.get('callback_count') == position,
                'step': row.get('step') == step,
                'identity': row.get('session_id') == value.get('expected_session_id'),
                'index_types_and_agreement': integer(index) and integer(row.get('event_index')) and row.get('event_index') == index,
                'new_time_level': close(row.get('flow_time_s'),step*dt,max(1e-10,dt*1e-7)),
                'no_error': row.get('error') is None,
                'urf_before': close(row.get('urf_before'),expected_pre),
            }
            if is_carryover:
                row_checks.update(carryover_only_once_at_start=position == 1 and carryover_count == 0 and new_count == 0 and index == start,
                                  no_setter=row.get('setter_attempted') is False,
                                  predictor_unchanged=close(row.get('urf_after'),predictor))
                carryover_count += 1
            else:
                row_checks.update(new_iteration_kind=row.get('event_kind') == 'new_iteration',
                                  contiguous_new_index=index == start + new_count + 1,
                                  first_new_only_setter=row.get('setter_attempted') is (new_count == 0),
                                  corrector_readback=close(row.get('urf_after'),corrector))
                new_count += 1
            if not all(row_checks.values()):
                failures.append({'callback_count': position, 'checks': row_checks})
        checks.update(all_event_checks_passed=not failures,
                      all_new_iterations_observed=integer(start) and integer(end) and new_count == end-start,
                      carryover_count_valid=carryover_count <= 1,
                      declared_counts_match=value.get('new_iteration_count') == new_count and value.get('carryover_count') == carryover_count)
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError) as error:
        checks['record_is_well_formed'] = False
        failures.append({'error': type(error).__name__ + ': ' + str(error)})
    return {'passed': bool(checks) and all(item is True for item in checks.values()),
            'checks': checks, 'failures': failures,
            'scope': 'Iteration scheduling only; original residual, native convergence, mesh and interface checks remain separately required.'}


def asset_layout(argument):
    if argument:
        root = Path(argument).expanduser().resolve()
    elif Path(__file__).with_name(GEOMETRY_GENERATOR).is_file():
        # Standalone development replay directory has its own script identity.
        # Do not apply the parent geometry-preview manifest to a new solver route.
        root = Path(__file__).resolve().parent
    else:
        root = Path(__file__).resolve().parents[1] / 'assets' / 'examples' / 'fish'
    candidates = [root / 'replay', root / 'scripts', root]
    scripts = next((p for p in candidates if (p / GEOMETRY_GENERATOR).is_file()), candidates[0])
    return root, scripts


def replay_settings(root, scripts):
    settings = dict(REPLAY_SETTINGS)
    path = next((p for p in [root / 'replay_config.json', scripts / 'replay_config.json']
                 if p.is_file()), None)
    if path:
        supplied = json.loads(path.read_text(encoding='utf-8-sig'))
        settings.update({key: supplied[key] for key in REPLAY_SETTINGS if key in supplied})
    return settings, path


def settings_errors(settings):
    errors = []
    if settings.get('physical_model') != 'realistic-fish-rigid-forebody-flexible-tail':
        errors.append('This runner requires the explicit rigid-forebody/flexible-tail physical model.')
    if type(settings.get('skew_smoothing_cycles')) is not int or settings['skew_smoothing_cycles'] != 0:
        errors.append('This verified-route candidate requires skew_smoothing_cycles=0.')
    cores = settings.get('processor_count')
    if isinstance(cores, bool) or not isinstance(cores, int) or cores != 1:
        errors.append('The compiled-motion route currently requires the verified single-compute-process configuration.')
    stabilization = settings.get('solution_stabilization_scale')
    if not isinstance(settings.get('solution_stabilization_enabled'), bool):
        errors.append('solution_stabilization_enabled must be a boolean.')
    if isinstance(stabilization, bool) or not isinstance(stabilization, (int, float)) or not math.isfinite(stabilization) or stabilization <= 0:
        errors.append('solution_stabilization_scale must be positive and finite.')
    dt = settings.get('dt_s')
    if isinstance(dt, bool) or not isinstance(dt, (int, float)) or not math.isfinite(dt) or dt <= 0:
        errors.append('dt_s must be a positive finite number.')
    for name in ['time_steps', 'max_iterations_per_step']:
        value = settings.get(name)
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            errors.append(name + ' must be finalized as a positive integer in replay_config.json.')
    for name in ['structure_under_relaxation', 'structure_under_relaxation_after_first', 'implicit_mesh_relaxation']:
        value = settings.get(name)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= 1:
            errors.append(name + ' must be finite and greater than zero, at most one.')
    corrector = settings.get('structure_corrector_under_relaxation')
    if corrector is not None:
        if isinstance(corrector, bool) or not isinstance(corrector, (int, float)) or not math.isfinite(corrector) or not 0 < corrector <= 1:
            errors.append('structure_corrector_under_relaxation must be null or finite in (0, 1].')
        if any(settings.get(key) != 1.0 for key in ['structure_under_relaxation', 'structure_under_relaxation_after_first']):
            errors.append('The event-corrector route requires a predictor structure URF of 1 for every physical step.')
    value = settings.get('implicit_mesh_residual_criterion')
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        errors.append('implicit_mesh_residual_criterion must be positive and finite.')
    if settings.get('flow_scheme') != 'Coupled':
        errors.append('This fixed numerical route requires flow_scheme=Coupled.')
    return errors


def plan(args):
    root, scripts = asset_layout(args.asset_root)
    settings, path = replay_settings(root, scripts)
    return {'mode': 'plan', 'sdk_imported': False, 'files_written': False,
            'solver_launched': False, 'asset_root': str(root), 'script_directory': str(scripts),
            'settings': settings, 'configuration_file': str(path) if path else None,
            'configuration_stages': [{'script': n, 'purpose': p} for n, p in CONFIGURATION_STAGES],
            'mesh': 'Fresh refined fish CAD/Gmsh generation and eye-face partition, then preserve original water/tail tetrahedra and all wetted geometry while removing forebody structural cells; load active-tail/fish_water_tail.msh.',
            'geometry_checks': 'CAD volume/topology checks, original tetrahedral export checks, closed triangulated fish surface, eye-zone partition identity/connectivity preservation. No old hard-coded tail cross-section test.',
            'time_step_route': ['Apply ' + NUMERICAL_STAGE + ' with step_index, without advancing time',
                                'Advance exactly one physical step', 'Save a new native case/data checkpoint',
                                'Run a native mesh check and record the current minimum cell volume',
                                'Independently validate transcript and report files',
                                'Continue only when all completed steps pass numerical checks'],
            'final_stage': FINAL_STAGE,
            'saved_checkpoint_audit': 'Before finalization, independently inspect every saved case/data pair for positive fluid volumes, positive solid J and verified node mapping.',
            'final_contract': 'Write records/fsi_evidence.json including topology, FSI settings, mesh quality and native reopen evidence.',
            'readiness_notes': settings_errors(settings),
            'existing_session_policy': 'Default: refuse while Fluent runs. Explicit --attach-server-info targets an already-authorized dedicated session and replaces its state with this new mesh.',
            'failure_policy': 'Stop at the first failure. Preserve logs, checkpoints and GUI. Do not change controls, relax thresholds or load old results.'}


def metadata(python, packages):
    code = ("import importlib.metadata as m,json,sys\n"
            "d={'python':sys.executable,'python_version':list(sys.version_info[:3]),'packages':{}}\n"
            "for n in sys.argv[1:]:\n"
            " try:d['packages'][n]=m.version(n)\n"
            " except m.PackageNotFoundError:d['packages'][n]=None\n"
            "print(json.dumps(d))\n")
    result = subprocess.run([python, '-B', '-c', code, *packages], capture_output=True,
                            text=True, encoding='utf-8', errors='replace', timeout=30,
                            check=True, **hidden_window())
    return json.loads(result.stdout)


def hidden_window():
    return {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}


def existing_fluent_processes():
    if os.name != 'nt':
        raise RuntimeError('This verified native-GUI route currently supports Windows only.')
    executable = Path(os.environ.get('WINDIR', '')) / 'System32' / 'tasklist.exe'
    result = subprocess.run([str(executable), '/FO', 'CSV', '/NH'], capture_output=True,
                            text=True, errors='replace', timeout=30, **hidden_window())
    if result.returncode:
        raise RuntimeError('Process check failed: ' + (result.stderr.strip() or result.stdout.strip())[:800])
    rows = list(csv.reader(result.stdout.splitlines()))
    if not any(len(row) > 1 and row[1].isdigit() for row in rows):
        raise RuntimeError('Could not validate Windows process inventory.')
    return [{'image': row[0], 'pid': int(row[1])} for row in rows
            if len(row) > 1 and row[1].isdigit()
            and re.fullmatch(r'(?:fl\d{4}|fluent)\.exe', row[0], re.I)]


def normalize_version(value):
    if re.fullmatch(r'\d{3}', value):
        value = value[:2] + '.' + value[2] + '.0'
    elif re.fullmatch(r'\d{2}\.\d', value):
        value += '.0'
    if not re.fullmatch(r'\d{2}\.\d\.\d+', value):
        raise ValueError('Use a product version such as 26.1.0 or 261.')
    return value


def locate_fluent(args):
    version = normalize_version(args.product_version)
    if args.fluent_exe:
        return {'path': str(Path(args.fluent_exe).expanduser().resolve()), 'product_version': version}
    code = ''.join(version.split('.')[:2])
    roots = []
    if os.environ.get('AWP_ROOT' + code):
        roots.append(Path(os.environ['AWP_ROOT' + code]) / 'fluent')
    if os.environ.get('PYFLUENT_FLUENT_ROOT'):
        roots.append(Path(os.environ['PYFLUENT_FLUENT_ROOT']))
    for root in roots:
        executable = root / 'ntbin' / 'win64' / 'fluent.exe'
        if executable.is_file():
            return {'path': str(executable.resolve()), 'product_version': version}
    raise ValueError('Fluent launcher was not found; set --fluent-exe or AWP_ROOT' + code + '.')


def run_root(argument):
    root = Path(argument).expanduser().resolve() if argument else Path(tempfile.gettempdir()).resolve() / 'ansys-automatic-wwj' / 'fish-runs'
    if not str(root).isascii():
        raise ValueError('Choose an ASCII-only --run-root.')
    if root.exists() and not root.is_dir():
        raise ValueError('--run-root must be a directory.')
    return root


def verify_assets(root, scripts):
    missing = [name for name in REQUIRED_FILES if not (scripts / name).is_file()]
    if missing:
        raise ValueError('Missing fixed-route scripts: ' + ', '.join(missing))
    manifest_path = root / 'manifest.json'
    verified = {}
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
        for item in manifest['files']:
            relative = Path(item['path'])
            path = (root / relative).resolve()
            if relative.is_absolute() or not path.is_relative_to(root) or path == root:
                raise ValueError('Manifest entry escapes asset root.')
            if item['path'] in verified:
                raise ValueError('Duplicate manifest entry: ' + item['path'])
            if not path.is_file() or path.stat().st_size != item['bytes'] or sha256(path) != item['sha256']:
                raise ValueError('Asset content differs from manifest: ' + item['path'])
            verified[item['path']] = item['sha256']
        for name in REQUIRED_FILES:
            if (scripts / name).relative_to(root).as_posix() not in verified:
                raise ValueError('Required script omitted from manifest: ' + name)
    return {'manifest_verified': manifest_path.is_file(), 'manifest_files': len(verified),
            'script_hashes': {name: sha256(scripts / name) for name in REQUIRED_FILES},
            'development_without_manifest': not manifest_path.is_file()}


def inspect(args):
    result = {'mode': 'check-only', 'sdk_imported': False, 'solver_launched': False,
              'files_written': False, 'errors': [], 'warnings': [], 'launch_guards': []}
    try:
        root, scripts = asset_layout(args.asset_root)
        result.update(asset_root=str(root), script_directory=str(scripts), run_root=str(run_root(args.run_root)))
        settings, config_path = replay_settings(root, scripts)
        result['settings'] = settings
        result['configuration_file'] = str(config_path) if config_path else None
        result['errors'].extend(settings_errors(settings))
        result['assets'] = verify_assets(root, scripts)
        if result['assets']['development_without_manifest']:
            result['warnings'].append('Development asset directory has no manifest; script hashes are recorded, not compared with a published baseline.')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        result['errors'].append('Assets/settings: ' + str(exc))
    for label, python, packages in [('mesh_dependencies', args.mesh_python, ('gmsh', 'numpy')),
                                     ('solver_dependencies', sys.executable, ('ansys-fluent-core',)),
                                     ('checkpoint_audit_dependencies', sys.executable, ('numpy', 'h5py'))]:
        try:
            result[label] = metadata(python, packages)
            result['errors'].extend(label + ': missing ' + name for name, version in result[label]['packages'].items() if not version)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            result['errors'].append(label + ': ' + str(exc))
    try:
        result['fluent'] = locate_fluent(args)
        if not Path(result['fluent']['path']).is_file():
            raise ValueError('Fluent executable path is not a file.')
        result['existing_fluent_processes'] = existing_fluent_processes()
        if args.attach_server_info:
            # Do not read or print server-info contents, endpoints or credentials.
            if not Path(args.attach_server_info).expanduser().is_file():
                raise ValueError('The explicitly supplied server-info file does not exist.')
            result['session_mode'] = 'attach_explicit_dedicated_session'
            result['server_info_file_present'] = True
        else:
            result['session_mode'] = 'fresh_dedicated_gui'
            if result['existing_fluent_processes']:
                result['launch_guards'].append('Fluent already runs; fresh launch is blocked. An explicitly authorized dedicated session can be selected with --attach-server-info.')
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:
        result['errors'].append('Installation/session check: ' + str(exc))
    result['dependencies_ready'] = all(
        label in result and all(result[label]['packages'].values())
        for label in ['mesh_dependencies', 'solver_dependencies', 'checkpoint_audit_dependencies'])
    result['preflight_passed'] = not result['errors']
    result['session_launch_permitted'] = not result['launch_guards'] and 'session_mode' in result
    result['ready'] = result['preflight_passed'] and result['session_launch_permitted']
    return result


class Tee:
    def __init__(self, terminal, log):
        self.terminal, self.log = terminal, log

    def write(self, message):
        self.terminal.write(message)
        if not self.log.closed:
            self.log.write(message)
        return len(message)

    def flush(self):
        self.terminal.flush()
        if not self.log.closed:
            self.log.flush()

    def __getattr__(self, name):
        return getattr(self.terminal, name)


def inspect_closed_surface(path):
    """Check the newly generated STL using standard Python, without plotting."""
    values = re.findall(r'^\s*vertex\s+([-+eE.\d]+)\s+([-+eE.\d]+)\s+([-+eE.\d]+)',
                        path.read_text(encoding='ascii'), re.M)
    if not values or len(values) % 3:
        raise RuntimeError('Generated fish STL has an incomplete triangle list.')
    vertices = [tuple(float(v) for v in row) for row in values]
    if not all(math.isfinite(v) for point in vertices for v in point):
        raise RuntimeError('Generated fish surface has nonfinite coordinates.')
    edges = Counter()
    signed_volume, degenerate = 0.0, 0
    for index in range(0, len(vertices), 3):
        a, b, c = vertices[index:index+3]
        for p, q in ((a, b), (b, c), (c, a)):
            edges[tuple(sorted((p, q)))] += 1
        u, v = [b[i]-a[i] for i in range(3)], [c[i]-a[i] for i in range(3)]
        cross = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
        degenerate += math.sqrt(sum(x*x for x in cross))/2 <= 1e-18
        signed_volume += (a[0]*(b[1]*c[2]-b[2]*c[1])
                          + a[1]*(b[2]*c[0]-b[0]*c[2])
                          + a[2]*(b[0]*c[1]-b[1]*c[0])) / 6
    boundary = sum(n == 1 for n in edges.values())
    nonmanifold = sum(n > 2 for n in edges.values())
    return {'source_stl': str(path.resolve()), 'source_sha256': sha256(path),
            'surface_triangles': len(vertices)//3, 'finite_coordinates': True,
            'boundary_edges': boundary, 'nonmanifold_edges': nonmanifold,
            'degenerate_triangles': int(degenerate), 'signed_enclosed_volume_m3': signed_volume,
            'closed_surface_checks_passed': boundary == nonmanifold == degenerate == 0 and signed_volume > 0,
            'scope': 'Generated STL edge incidence, finite coordinates, nondegenerate triangles and positive signed volume; no self-intersection or through-fin-thickness convergence claim.'}


class Replay:
    def __init__(self, args, checks):
        self.args, self.checks = args, checks
        self.settings = checks['settings']
        self.run_dir = Path(checks['run_root']) / ('fish-rigid-tail-replay-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
        self.run_dir.mkdir(parents=True, exist_ok=False)
        self.records, self.results = self.run_dir / 'records', self.run_dir / 'results'
        self.geometry, self.scripts = self.run_dir / 'geometry', self.run_dir / 'replay'
        self.mesh_path = self.geometry / SOLVER_MESH
        for path in [self.records, self.results, self.geometry, self.scripts, self.run_dir / 'checkpoints', self.records / 'stages']:
            path.mkdir()
        for name in REQUIRED_FILES:
            shutil.copyfile(Path(checks['script_directory']) / name, self.scripts / name)
            if sha256(self.scripts / name) != checks['assets']['script_hashes'][name]:
                raise RuntimeError('Script changed after preflight: ' + name)
        write_json(self.run_dir / 'replay_config.json', self.settings)
        self.summary = {'schema_version': 2, 'physical_model': self.settings['physical_model'],
                        'status': 'running', 'started_utc': utc_now(),
                        'run_dir': str(self.run_dir), 'settings': self.settings, 'checks': checks,
                        'recomputed': False, 'bundled_solution_loaded': False,
                        'completed_steps': 0, 'actual_flow_time_s': None,
                        'solver_launched': False, 'attached_to_explicit_session': False,
                        'session_left_open': False, 'geometry_generated': False,
                        'stages': [], 'failures': [], 'numerical_validation_passed': False,
                        'native_reopen_passed': False}
        self.solver = None
        self.namespace = {}
        self.save_summary()

    def save_summary(self):
        write_json(self.run_dir / 'replay_summary.json', self.summary)

    def record(self, name, value):
        if not re.fullmatch(r'[A-Za-z0-9_.-]+', name) or name in {'.', '..'}:
            raise ValueError('Invalid record name.')
        write_json(self.records / (name if name.endswith('.json') else name + '.json'), value)

    def stage(self, name, action):
        number = len(self.summary['stages']) + 1
        log_path = self.records / 'stages' / f'{number:04d}-{name}.log'
        item = {'name': name, 'started_utc': utc_now(), 'status': 'running', 'log': str(log_path)}
        self.summary['stages'].append(item)
        self.save_summary()
        print('FISH_STAGE_START', name, flush=True)
        started = time.monotonic()
        try:
            with log_path.open('w', encoding='utf-8') as log:
                with contextlib.redirect_stdout(Tee(sys.stdout, log)), contextlib.redirect_stderr(Tee(sys.stderr, log)):
                    result = action()
            item['status'] = 'passed'
            return result
        except Exception as exc:
            item.update(status='failed', error=type(exc).__name__ + ': ' + str(exc))
            self.summary['failures'].append({'stage': name, 'error': item['error']})
            raise
        finally:
            item.update(finished_utc=utc_now(), elapsed_seconds=time.monotonic()-started)
            write_json(log_path.with_suffix('.json'), item)
            self.save_summary()

    def process(self, command):
        with subprocess.Popen(command, cwd=str(self.run_dir), stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace',
                              env=dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8'),
                              **hidden_window()) as process:
            for line in process.stdout:
                print(line, end='', flush=True)
            code = process.wait()
        if code:
            raise RuntimeError('Helper exited with status ' + str(code))

    def generate_geometry(self):
        self.process([self.args.mesh_python, str(self.scripts / GEOMETRY_GENERATOR),
                      '--output', str(self.geometry), '--body-size', str(GEOMETRY_SETTINGS['body']),
                      '--tail-size', str(GEOMETRY_SETTINGS['tail']), '--far-size', str(GEOMETRY_SETTINGS['far']),
                      '--eye-size', str(GEOMETRY_SETTINGS['eye_ball']), '--gill-size', str(GEOMETRY_SETTINGS['gill_pole_ball'])])
        report = json.loads((self.geometry / 'mesh_validation.json').read_text(encoding='utf-8'))
        if report.get('status') != 'complete' or report.get('geometry_only') is not False:
            raise RuntimeError('Refined geometry/volume-mesh generation is incomplete.')
        mesh = report.get('mesh', {})
        base_mesh = self.geometry / 'fish_fluent.msh'
        if not mesh.get('passed') or not base_mesh.is_file():
            raise RuntimeError('Fresh mesh validation did not pass.')
        minimum_sicn = mesh.get('gmsh_minSICN_min')
        if (not isinstance(minimum_sicn, (int, float)) or not math.isfinite(minimum_sicn)
                or minimum_sicn < 0.08 or mesh.get('quality_gate_passed') is not True):
            raise RuntimeError('Fresh mesh must pass the fixed minimum SICN quality gate of 0.08 for the fast teaching profile.')
        offline_oq = mesh.get('min_fluent_orthogonal_quality')
        if (report.get('fluent_quality_gate', {}).get('passed') is not True
                or not isinstance(offline_oq, (int, float)) or not math.isfinite(offline_oq)
                or offline_oq <= 0.001):
            raise RuntimeError('Fresh mesh must pass the independently reconstructed Fluent tetrahedral quality gate.')
        if mesh.get('single_solid') is not False:
            raise RuntimeError('The accepted route requires the two-solid primary mesh, not the single-solid alternative.')
        if Path(mesh['mesh_file']).resolve() != base_mesh.resolve():
            raise RuntimeError('Primary mesh metadata points to a different artifact.')
        required_checks = ['all_cells_positive_volume', 'all_cells_four_faces',
                           'all_surface_triangles_matched', 'fluid_solid_interface_closed', 'volume_matches_box']
        if not all(mesh.get(name) is True for name in required_checks):
            raise RuntimeError('Refined primary tetrahedral checks are incomplete.')
        cad_checks = report.get('geometry', {}).get('cad_checks', {})
        if not all(cad_checks.get(name) is True for name in [
                'single_fused_fish_before_partition', 'three_conformal_final_volumes',
                'solid_partition_volume_preserved', 'water_box_volume_preserved']):
            raise RuntimeError('Refined CAD topology/volume checks are incomplete.')
        if report.get('sizing_m') != GEOMETRY_SETTINGS:
            raise RuntimeError('Geometry generator did not use the fixed refined sizing.')
        surface = inspect_closed_surface(self.geometry / 'fish_surface.stl')
        self.record('surface-inspection', surface)
        if not surface['closed_surface_checks_passed'] or surface['surface_triangles'] != report['surface']['surface_triangles']:
            raise RuntimeError('Refined closed fish-surface inspection did not pass.')
        self.process([self.args.mesh_python, str(self.scripts / 'split_eye_zone.py'),
                      '--geometry-dir', str(self.geometry)])
        split = json.loads((self.geometry / 'eye-zone-split.json').read_text(encoding='utf-8'))
        full_eye_mesh = self.geometry / 'fish_refined_eyes.msh'
        split_checks = {
            'source_matches': Path(split['source']).resolve() == base_mesh.resolve(),
            'output_matches': Path(split['output']).resolve() == full_eye_mesh.resolve(),
            'source_hash_matches': split['source_sha256'] == sha256(base_mesh),
            'output_hash_matches': full_eye_mesh.is_file() and split['output_sha256'] == sha256(full_eye_mesh),
            'nodes_unchanged': split.get('node_section_unchanged') is True,
            'connectivity_unchanged': split.get('original_face_connectivity_and_adjacency_preserved') is True,
            'volume_zones_unchanged': split.get('volume_zones_unchanged') is True,
            'eye_faces_present': split.get('eye_zone_name') == 'fish_eyes' and split.get('eye_faces', 0) > 0,
            'face_count_preserved': split.get('body_faces_before') == split.get('body_faces_after', 0) + split.get('eye_faces', 0),
            'source_body_count_matches': split.get('body_faces_before') == mesh['face_zones']['body_water'],
            'node_match_within_tolerance': math.isfinite(float(split['max_stl_node_match_error_m']))
                and 0 <= split['max_stl_node_match_error_m'] <= split['node_matching_tolerance_m'],
        }
        self.record('refined-mesh-identity', {'checks': split_checks, 'split': split,
                    'full_eye_mesh': str(full_eye_mesh), 'source_mesh_metadata': report,
                    'surface_inspection': surface})
        if not all(split_checks.values()):
            raise RuntimeError('Eye-zone partition identity/preservation checks failed.')
        # Derive the active water/tail mesh without changing source geometry,
        # coordinates or tetrahedra; preserve the original generated metadata.
        self.export_active_tail_mesh()
        self.summary.update(geometry_generated=True, mesh=mesh,
                            solver_mesh=str(self.mesh_path), solver_mesh_sha256=sha256(self.mesh_path),
                            refined_surface_passed=True, eye_zone_partition_passed=True)

    def export_active_tail_mesh(self):
        self.process([self.args.mesh_python, str(self.scripts / 'prepare_rigid_tail_geometry.py'),
                      '--geometry-dir', str(self.geometry)])
        identity_path = self.geometry / 'mesh_identity.json'
        identity = json.loads(identity_path.read_text(encoding='utf-8'))
        if identity.get('status') != 'offline_identity_passed' or identity.get('mode') != 'water-tail':
            raise RuntimeError('Fresh active-tail mesh identity checks did not pass.')
        verified = {}
        for key, entry in identity.get('files', {}).items():
            path = (self.geometry / entry['path']).resolve()
            if (not path.is_relative_to(self.geometry.resolve()) or not path.is_file()
                    or path.stat().st_size != entry['bytes'] or sha256(path) != entry['sha256']):
                raise RuntimeError('Active-tail geometry artifact differs or escapes this run: ' + key)
            verified[key] = str(path)
        expected_paths = {'source_mesh': self.geometry / 'fish_refined_eyes.msh',
                          'output_mesh': self.mesh_path,
                          'id_mapping': self.geometry / 'active-tail' / 'source_to_active_ids.npz'}
        for key, expected in expected_paths.items():
            if key not in verified or Path(verified[key]) != expected.resolve():
                raise RuntimeError('Missing or unexpected active-tail artifact: ' + key)
        self.record('active-tail-geometry', {'identity_file': str(identity_path),
            'identity_sha256': sha256(identity_path), 'identity': identity,
            'verified_files': verified, 'physical_model': self.settings['physical_model']})
        self.summary.update(active_tail_geometry_exported=True,
                            active_tail_geometry_identity=str(identity_path))

    def connect(self):
        import ansys.fluent.core as pyfluent
        if self.args.attach_server_info:
            try:
                self.solver = pyfluent.connect_to_fluent(
                    server_info_file_name=str(Path(self.args.attach_server_info).expanduser().resolve()),
                    cleanup_on_exit=False, start_watchdog=False)
            except Exception as exc:
                # Deliberately omit exception text that might contain connection credentials.
                raise RuntimeError('Could not attach to the explicitly selected dedicated session (' + type(exc).__name__ + ').') from None
            self.summary['attached_to_explicit_session'] = True
        else:
            if existing_fluent_processes():
                raise RuntimeError('Fluent appeared since preflight; fresh launch is blocked.')
            # Keep native startup diagnostics, which are separate from the solve
            # transcript. Do not silently change global MPI/network settings.
            with (self.run_dir / 'native-launch.log').open('w', encoding='utf-8') as launch_log:
                pyfluent.config.launch_fluent_stdout = launch_log
                pyfluent.config.launch_fluent_stderr = launch_log
                try:
                    self.solver = pyfluent.launch_fluent(
                        fluent_path=self.checks['fluent']['path'], product_version=self.checks['fluent']['product_version'],
                        dimension=3, precision='double', processor_count=self.settings['processor_count'], mode='solver', ui_mode='gui', py=False,
                        cwd=str(self.run_dir), start_timeout=120, cleanup_on_exit=False, start_watchdog=False)
                finally:
                    pyfluent.config.launch_fluent_stdout = None
                    pyfluent.config.launch_fluent_stderr = None
            self.summary['solver_launched'] = True
        self.summary.update(session_left_open=True, fluent_version=str(self.solver.get_fluent_version()))
        actual_processors = int(self.solver.application_runtime.get_processor_count())
        self.summary['actual_processor_count'] = actual_processors
        if actual_processors != self.settings['processor_count']:
            raise RuntimeError('Connected Fluent processor count does not match the fixed replay settings.')
        self.namespace = {'solver': self.solver, 'run_dir': self.run_dir.as_posix(),
                          'run_path': self.run_dir, 'state_dir': self.records, 'geometry_dir': self.geometry,
                          'mesh_path': self.mesh_path, 'solver_mesh_path': self.mesh_path,
                          'script_dir': self.scripts, 'record': self.record, 'Path': Path, 'json': json,
                          'replay_settings': dict(self.settings),
                          'check_structure_corrector_record': check_structure_corrector_record,
                          '__name__': '__fish_replay_stage__'}
        spec = importlib.util.spec_from_file_location('fish_file_validator', self.scripts / 'validate_fish_run.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.validate_files = module.validate

    def load_new_mesh(self):
        if self.solver.settings.file.stop_transcript.is_active():
            self.solver.settings.file.stop_transcript()
        self.solver.settings.file.start_transcript(file_name=str(self.run_dir / 'fish-transcript.trn'))
        self.solver.settings.file.read_mesh(file_name=str(self.mesh_path))
        self.solver.settings.mesh.check()
        self.native_quality_check(0)

    def native_quality_check(self, step):
        """Check Fluent's own quality metric before solving and after each step."""
        transcript = self.run_dir / 'fish-transcript.trn'
        offset = transcript.stat().st_size
        self.solver.settings.mesh.quality()
        fragment = ''
        quality = aspect = []
        for attempt in range(20):
            with transcript.open('rb') as stream:
                stream.seek(offset)
                fragment = stream.read().decode('utf-8', errors='replace')
            quality = re.findall(r'Minimum Orthogonal Quality\s*=\s*([-+\d.eE]+)', fragment)
            aspect = re.findall(r'Maximum Aspect Ratio\s*=\s*([-+\d.eE]+)', fragment)
            if quality and aspect:
                break
            time.sleep(0.1)
        minimum = float(quality[-1]) if quality else None
        maximum = float(aspect[-1]) if aspect else None
        warning_lines = [line.strip() for line in fragment.splitlines()
                         if re.search(r'\bWarning:', line, re.I)]
        # Explicitly disclosed coarse teaching profile. Preserve the native
        # warning in evidence; every other warning/error remains a failure.
        expected_quality_warning = 'Warning: minimum Orthogonal Quality below 0.01.'
        passed = (minimum is not None and math.isfinite(minimum) and minimum >= 0.001
                  and maximum is not None and math.isfinite(maximum)
                  and not re.search(r'\bError:', fragment, re.I)
                  and all(line == expected_quality_warning for line in warning_lines))
        (self.records / f'mesh-quality-{step:04d}.txt').write_text(fragment, encoding='utf-8')
        self.record(f'mesh-quality-{step:04d}', {
            'step': step, 'status': 'passed' if passed else 'failed',
            'minimum_orthogonal_quality': minimum, 'maximum_aspect_ratio': maximum,
            'minimum_orthogonal_quality_threshold': 0.001,
            'native_warnings_preserved': warning_lines,
            'quality_scope': 'User-authorized coarse teaching preview; below the standard 0.01 recommendation, not engineering accuracy.',
            'method': 'Native Fluent mesh.quality; separate from Gmsh minSICN.'})
        if not passed:
            raise RuntimeError('Native Fluent orthogonal mesh quality did not pass; do not solve or package this mesh.')

    def script(self, name):
        path = self.scripts / name
        self.namespace['__file__'] = str(path)
        exec(compile(path.read_text(encoding='utf-8-sig'), str(path), 'exec'), self.namespace)

    def flow_time(self):
        return float(self.solver.settings.solution.run_calculation.transient_controls.flow_time.get_state())

    def checkpoint(self, name):
        case = self.run_dir / 'checkpoints' / (name + '.cas.h5')
        self.solver.settings.file.write_case_data(file_name=str(case))
        data = case.with_name(name + '.dat.h5')
        if not case.is_file() or not data.is_file():
            raise RuntimeError('Native checkpoint pair is incomplete.')
        return {'case': str(case), 'data': str(data), 'flow_time_s': self.flow_time()}

    def validate(self, expected_steps, final=False):
        evidence = self.records / 'fsi_evidence.json'
        output = self.results if final else self.records / f'validation-step-{expected_steps:04d}'
        result = self.validate_files(self.run_dir, output, expected_steps, self.settings['dt_s'],
                                     evidence_path=evidence if evidence.is_file() else None)
        self.summary.update(completed_steps=result['completed_steps'],
                            actual_flow_time_s=result['last_completed_time_s'],
                            recomputed=result['completed_steps'] > 0,
                            numerical_validation_passed=result['numerical_validation_passed'],
                            latest_validation_file=str(output / 'validation.json'))
        if final:
            self.summary['native_reopen_passed'] = result['external_evidence']['native_reopen']['status'] == 'passed'
            self.summary['overall_validation_passed'] = result['passed']
        self.save_summary()
        return result

    def native_mesh_check(self, step):
        transcript = self.run_dir / 'fish-transcript.trn'
        offset = transcript.stat().st_size
        self.solver.settings.mesh.check()
        fragment = ''
        matches = []
        # Wait only for transcript delivery, never retry or alter numerical work.
        for attempt in range(10):
            with transcript.open('rb') as stream:
                stream.seek(offset)
                fragment = stream.read().decode('utf-8', errors='replace')
            matches = re.findall(r'minimum\s+volume\s*\(m3\)\s*:\s*([+\-\d.eEdD]+)', fragment, re.I)
            if matches and 'Done.' in fragment:
                break
            time.sleep(0.1)
        fragment_path = self.records / f'mesh-check-{step:04d}.txt'
        fragment_path.write_text(fragment, encoding='utf-8')
        minimum = float(matches[-1].replace('D', 'e').replace('d', 'e')) if matches else None
        native_errors = re.findall(r'^.*(?:Error:|negative cell volume|negative volume|inverted cell).*$', fragment, re.I | re.M)
        passed = minimum is not None and math.isfinite(minimum) and minimum > 0 and not native_errors and 'Done.' in fragment
        evidence = {'step': step, 'flow_time_s': self.flow_time(), 'status': 'passed' if passed else 'unknown_or_failed',
                    'minimum_cell_volume_m3': minimum, 'native_errors': native_errors,
                    'native_transcript_excerpt': str(fragment_path), 'transcript_start_byte': offset,
                    'method': 'Native mesh.check after this step checkpoint; no inference from earlier steps.'}
        self.record(f'mesh-check-{step:04d}', evidence)
        if not passed:
            raise RuntimeError('Current-step native mesh check could not confirm a positive minimum volume.')
        return evidence

    def advance_with_structure_corrector(self, step):
        """One native step with official synchronous IterationEnded auto-pause.

        Callback errors are preserved, then fail the step after its checkpoint.
        The bounded native call finishes; no unverified interrupt/resume RPC or
        extra iterate call is issued from a callback.
        """
        import ansys.fluent.core as pyfluent
        urf = self.solver.settings.solution.controls.under_relaxation['structure']
        flow_time = self.solver.settings.solution.run_calculation.transient_controls.flow_time
        scheme_eval = self.solver.scheme.eval
        predictor = self.settings['structure_under_relaxation'] if step == 1 else self.settings['structure_under_relaxation_after_first']
        corrector = self.settings['structure_corrector_under_relaxation']
        evidence = {'schema_version': 1, 'enabled': True, 'step': step,
                    'predictor_urf': predictor, 'corrector_urf': corrector,
                    'expected_session_id': self.solver.id,
                    'starting_iteration': int(scheme_eval('(get-current-iteration)')),
                    'flow_time_before_s': float(flow_time.get_state()), 'urf_before': float(urf.get_state()),
                    'registered': False, 'unregistered': False, 'native_call_count': 0,
                    'native_call_returned': False, 'events': [], 'errors': [],
                    'new_iteration_count': 0, 'carryover_count': 0}
        callback_id = None
        def on_iteration_ended(session, event_info):
            row = {'callback_count': len(evidence['events']) + 1, 'step': step,
                   'event_kind': 'unclassified', 'setter_attempted': False, 'error': None}
            try:
                if evidence['errors']:
                    raise RuntimeError('Earlier callback failed; refuse further structure setters.')
                row.update(session_id=session.id, event_index=int(event_info.index),
                           native_iteration=int(scheme_eval('(get-current-iteration)')),
                           flow_time_s=float(flow_time.get_state()), urf_before=float(urf.get_state()))
                if row['session_id'] != evidence['expected_session_id']:
                    raise RuntimeError('Callback public session identity mismatch.')
                index = row['native_iteration']
                if row['event_index'] != index:
                    raise RuntimeError('Event index differs from native iteration.')
                if not math.isclose(row['flow_time_s'],step*self.settings['dt_s'],rel_tol=0,abs_tol=max(1e-10,self.settings['dt_s']*1e-7)):
                    raise RuntimeError('Callback is not in the requested physical time level.')
                if index == evidence['starting_iteration']:
                    row['event_kind'] = 'time_level_carryover'
                    if evidence['events'] or evidence['carryover_count']:
                        raise RuntimeError('Repeated or out-of-order time-level carryover event.')
                    evidence['carryover_count'] += 1
                    expected_pre = predictor
                else:
                    row['event_kind'] = 'new_iteration'
                    if index != evidence['starting_iteration'] + evidence['new_iteration_count'] + 1:
                        raise RuntimeError('Missing, repeated or out-of-order new iteration event.')
                    expected_pre = predictor if evidence['new_iteration_count'] == 0 else corrector
                if not math.isclose(row['urf_before'],expected_pre,rel_tol=0,abs_tol=1e-12):
                    raise RuntimeError('Unexpected structure URF before callback.')
                if row['event_kind'] == 'new_iteration':
                    if evidence['new_iteration_count'] == 0:
                        row['setter_attempted'] = True
                        urf.set_state(corrector)
                    evidence['new_iteration_count'] += 1
                row['urf_after'] = float(urf.get_state())
                expected_post = predictor if row['event_kind'] == 'time_level_carryover' else corrector
                if not math.isclose(row['urf_after'],expected_post,rel_tol=0,abs_tol=1e-12):
                    raise RuntimeError('Structure URF readback mismatch after callback.')
            except BaseException as error:
                row['error'] = type(error).__name__ + ': ' + str(error)
                evidence['errors'].append({'phase': 'callback', 'callback_count': row['callback_count'], 'error': row['error']})
            finally:
                evidence['events'].append(row)
                try:
                    self.record(f'structure-corrector-{step:04d}',evidence)
                except BaseException as error:
                    evidence['errors'].append({'phase': 'record_callback', 'error': type(error).__name__ + ': ' + str(error)})
                # Official event manager resumes automatically after this returns.
        try:
            if not math.isclose(evidence['urf_before'],predictor,rel_tol=0,abs_tol=1e-12):
                raise RuntimeError('Predictor URF was not applied before callback registration.')
            callback_id = self.solver.events.register_callback(pyfluent.SolverEvent.ITERATION_ENDED,on_iteration_ended)
            evidence['registered'] = True
            evidence['native_call_count'] += 1
            self.solver.settings.solution.run_calculation.dual_time_iterate(
                time_step_count=1,max_iter_per_step=self.settings['max_iterations_per_step'])
            evidence['native_call_returned'] = True
        except Exception as error:
            evidence['errors'].append({'phase': 'native_step_or_registration', 'error': type(error).__name__ + ': ' + str(error)})
        finally:
            if callback_id is not None:
                try:
                    self.solver.events.unregister_callback(callback_id)
                    evidence['unregistered'] = True
                except Exception as error:
                    evidence['errors'].append({'phase': 'unregister', 'error': type(error).__name__ + ': ' + str(error)})
            try:
                evidence.update(ending_iteration=int(scheme_eval('(get-current-iteration)')),
                                flow_time_after_s=float(flow_time.get_state()),urf_after=float(urf.get_state()))
            except Exception as error:
                evidence['errors'].append({'phase': 'final_readback', 'error': type(error).__name__ + ': ' + str(error)})
            evidence['validation'] = check_structure_corrector_record(evidence,step,self.settings)
            self.record(f'structure-corrector-{step:04d}',evidence)
        return evidence

    def advance_one_step(self, step):
        dt = self.settings['dt_s']
        before = self.flow_time()
        if not math.isclose(before, (step-1)*dt, abs_tol=max(1e-10,dt*1e-7), rel_tol=0):
            raise RuntimeError('Unexpected pre-step physical time; refuse to skip or reuse completed fields.')
        self.namespace['step_index'] = step
        self.script(NUMERICAL_STAGE)
        if not math.isclose(self.flow_time(), before, abs_tol=1e-12, rel_tol=0):
            raise RuntimeError('Numerical-control script must not advance physical time.')
        actual_dt = float(self.solver.settings.solution.run_calculation.parameters.time_step_size.get_state())
        if not math.isclose(actual_dt, dt, abs_tol=1e-12, rel_tol=0):
            raise RuntimeError('Numerical controls changed the fixed time-step size.')
        scheduling = None
        native_error = None
        try:
            if self.settings.get('structure_corrector_under_relaxation') is not None:
                scheduling = self.advance_with_structure_corrector(step)
            else:
                self.solver.settings.solution.run_calculation.dual_time_iterate(
                    time_step_count=1, max_iter_per_step=self.settings['max_iterations_per_step'])
        except Exception as error:
            native_error = type(error).__name__ + ': ' + str(error)
            self.record(f'physical-step-error-{step:04d}', {'step': step, 'error': native_error})
        actual = self.flow_time()
        # Preserve the actual native state even if the solver failed to reach the requested time.
        checkpoint = self.checkpoint(f'fish-step-{step:04d}')
        self.record(f'checkpoint-{step:04d}', checkpoint)
        if native_error:
            raise RuntimeError('Native step failed; the actual checkpoint was preserved: ' + native_error)
        if scheduling is not None and not scheduling['validation']['passed']:
            raise RuntimeError('Structure-corrector schedule failed; the actual checkpoint was preserved. See structure-corrector record.')
        self.native_mesh_check(step)
        self.native_quality_check(step)
        if not math.isclose(actual, step*dt, abs_tol=max(1e-10,dt*1e-7), rel_tol=0):
            raise RuntimeError('Solver did not reach exactly the requested physical step.')
        validation = self.validate(step)
        if not validation['numerical_validation_passed']:
            failed = [key for key,value in validation['numerical_checks'].items() if not value]
            raise RuntimeError('Independent per-step validation failed: ' + ', '.join(failed))
        self.audit_one_checkpoint(step)

    def audit_one_checkpoint(self, step):
        # A converged residual table does not by itself establish a consistent
        # fluid/solid interface. Check the saved physical state before advancing.
        spec = importlib.util.spec_from_file_location('fish_step_checkpoint_validator',
            self.scripts / 'validate_fish_checkpoints.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        output = self.records / f'checkpoint-audit-{step:04d}.json'
        report = module.validate(self.run_dir, [step], output)
        passed = report.get('all_requested_checkpoint_geometry_checks_passed') is True
        self.summary.update(latest_checkpoint_geometry_step=step,
            latest_checkpoint_geometry_passed=passed,
            latest_checkpoint_geometry_audit_file=str(output))
        self.save_summary()
        if not passed:
            raise RuntimeError('Current saved checkpoint failed geometry/interface audit: ' + str(output))
        return report

    def run_loop(self):
        for step in range(1, self.settings['time_steps'] + 1):
            self.stage(f'physical-step-{step:04d}', lambda step=step: self.advance_one_step(step))

    def audit_saved_checkpoints(self):
        # Import HDF dependencies only during an actual run, never --check-only
        # or --plan. This helper does not import Ansys or contact the solver.
        spec = importlib.util.spec_from_file_location('fish_checkpoint_validator', self.scripts / 'validate_fish_checkpoints.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        output = self.records / 'checkpoint-audit.json'
        report = module.validate(self.run_dir, list(range(1, self.settings['time_steps'] + 1)), output)
        self.namespace['checkpoint_audit'] = report
        self.namespace['checkpoint_audit_path'] = str(output)
        passed = report.get('all_requested_checkpoint_geometry_checks_passed') is True
        self.summary.update(saved_checkpoint_geometry_passed=passed,
                            saved_checkpoint_audit_file=str(output))
        self.save_summary()
        if not passed:
            raise RuntimeError('Independent saved-checkpoint geometry audit failed; see ' + str(output))
        return report

    def execute(self):
        try:
            self.stage('generate-geometry', self.generate_geometry)
            self.stage('connect-dedicated-session', self.connect)
            self.stage('load-new-mesh', self.load_new_mesh)
            for name, _ in CONFIGURATION_STAGES:
                self.stage(name, lambda name=name: self.script(name))
            if not math.isclose(self.flow_time(), 0.0, abs_tol=1e-12, rel_tol=0):
                raise RuntimeError('Configuration stages advanced time; the fixed runner requires a freshly initialized state.')
            self.solver.settings.solution.run_calculation.parameters.time_step_size = self.settings['dt_s']
            self.stage('initial-native-checkpoint', lambda: self.checkpoint('fish-initial'))
            self.run_loop()
            self.stage('all-saved-checkpoint-geometry-audit', self.audit_saved_checkpoints)
            self.stage(GRAPHICS_STAGE, lambda: self.script(GRAPHICS_STAGE))
            self.stage(FINAL_STAGE, lambda: self.script(FINAL_STAGE))
            result = self.stage('final-independent-validation', lambda: self.validate(self.settings['time_steps'], final=True))
            self.summary['status'] = 'complete' if result['passed'] else 'validation_incomplete'
            return 0 if result['passed'] else 3
        except Exception as exc:
            self.summary.update(status='failed', stop_reason=type(exc).__name__ + ': ' + str(exc))
            return 1
        finally:
            self.summary.update(finished_utc=utc_now(),
                physical_accuracy='Teaching demonstration; no mesh/time convergence, biological realism or self-propulsion validation.')
            self.save_summary()
            print(json.dumps(self.summary, ensure_ascii=False, indent=2, default=str), flush=True)
        # No exit/disconnect/kill: keep the dedicated Fluent GUI available.


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--asset-root', help='Packaged fish assets or development project/scripts directory')
    parser.add_argument('--fluent-exe', help='Installed official Fluent launcher')
    parser.add_argument('--product-version', default=BASELINE_VERSION)
    parser.add_argument('--run-root', help='ASCII directory; each actual replay creates a unique subdirectory')
    parser.add_argument('--mesh-python', default=sys.executable, help='Separate interpreter with Gmsh and NumPy')
    parser.add_argument('--attach-server-info', help='Explicitly authorized dedicated session only; its state will be replaced with a new mesh')
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--plan', action='store_true', help='No SDK imports, file writes or solver operations')
    modes.add_argument('--check-only', action='store_true', help='Read assets, dependency metadata and installation/process state only')
    args = parser.parse_args(argv)
    if args.plan:
        print(json.dumps(plan(args), ensure_ascii=False, indent=2))
        return 0
    checks = inspect(args)
    print(json.dumps(checks, ensure_ascii=False, indent=2), flush=True)
    if args.check_only:
        # Existing sessions are a launch guard, not a broken environment.
        return 0 if checks['preflight_passed'] else 2
    if not checks['ready']:
        return 2
    return Replay(args, checks).execute()


if __name__ == '__main__':
    raise SystemExit(main())
