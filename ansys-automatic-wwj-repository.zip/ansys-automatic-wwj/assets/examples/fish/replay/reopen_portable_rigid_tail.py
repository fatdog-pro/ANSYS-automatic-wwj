"""Prepare/reopen a complete rigid-tail native result in a NEW Fluent process.

Research helper only. Default --check-only is offline. --execute copies a closed,
finished result and launches one new 261/3D/double/1-core GUI process. The caller
must first save and close the prior dedicated process to release its license.
Never initialize, solve, preview motion, reset CG, rebind boundaries, or edit time.
This validates relocation/reopen identity, not the original convergence quality.
"""
from __future__ import annotations
import argparse
import dataclasses
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import sys
import traceback
import subprocess

LIBRARY = 'libfish_rigid_tail_motion'
FUNCTION = 'fish_rigid_forebody_heave'
SOURCE = 'fish_rigid_forebody_motion.c'
RIGID = ('body_water', 'fish_drive', 'fish_eyes')
REPORTS = ('drive-y', 'tail-y-mean', 'tail-y-max', 'tail-y-min', 'tail-displacement',
           'force-x', 'force-y', 'mass-net', 'mass-inlet', 'mass-outlet')
CLOCKS = ('flow-time', 'time-step', 'physical-time-step', 'physical-time-step-m1')
CORE_FIELDS = {'SV_U', 'SV_V', 'SV_W', 'SV_P', 'SV_DENSITY', 'SV_DVOLUME_DT', 'SV_FLUX', 'SV_GRID_FLUX'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', 'utf-8')


def read_json(path):
    return json.loads(Path(path).read_text('utf-8-sig'))


def require(checks, message):
    failed = [key for key, value in checks.items() if value is not True]
    if failed:
        raise RuntimeError(message + ': ' + ', '.join(failed))


def sexpr(text, name):
    start = text.find('(' + name + ' ')
    if start < 0 or text.find('(' + name + ' ', start+1) >= 0:
        raise ValueError('Missing/ambiguous saved setting: ' + name)
    depth, quoted, escaped = 0, False, False
    for i in range(start, len(text)):
        c = text[i]
        if quoted:
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == '"':
                quoted = False
        elif c == '"':
            quoted = True
        elif c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0:
                return text[start:i+1]
    raise ValueError('Incomplete saved setting: ' + name)


def case_dependencies(path):
    import h5py
    with h5py.File(path, 'r') as f:
        rp = f['settings/Rampant Variables'][0].decode()
    libraries = re.findall(r'"([^"\n]+)"', sexpr(rp, 'udf/libname'))
    hooks = re.findall(r'\(udf "([^"\n]+)"\)', rp)
    compiled = sexpr(rp, 'udf/compile/files')
    checks = {'only_owned_formal_library': libraries == [LIBRARY],
              'exactly_three_formal_motion_hooks': hooks == [FUNCTION + '::' + LIBRARY]*3,
              'no_unused_probe_library_dependency': 'libfish_motion_probe' not in compiled,
              'compiled_source_basename_present': SOURCE in compiled}
    require(checks, 'Saved case does not have the intended self-contained UDF dependency set')
    return {'checks': checks, 'libraries': libraries, 'hooks': hooks, 'compile_setting': compiled}


def physical_fingerprint(case, data):
    """Hash native numeric mesh, core flow/history, and FE restart arrays only."""
    import h5py
    import numpy as np
    fingerprints = {}
    for label, path in (('case', case), ('data', data)):
        before = (path.stat().st_size, path.stat().st_mtime_ns)
        with h5py.File(path, 'r') as f:
            def visit(name, obj):
                if not isinstance(obj, h5py.Dataset):
                    return
                selected = (label == 'case' and name.startswith('meshes/')) or (label == 'data' and name.startswith('special/structure-'))
                if label == 'data' and name.startswith('results/1/phase-1/'):
                    selected = selected or any(part in CORE_FIELDS or part.endswith('_M1') for part in name.split('/'))
                if selected and obj.dtype.kind in 'biufc':
                    value = obj[:]
                    if not np.isfinite(value).all():
                        raise ValueError('Nonfinite saved physical field: ' + name)
                    attrs = {k: np.asarray(v).tolist() for k,v in obj.attrs.items()}
                    fingerprints[label+'/'+name] = {'shape': list(value.shape), 'dtype': str(value.dtype),
                        'sha256': hashlib.sha256(value.tobytes()).hexdigest(), 'attrs': attrs}
            f.visititems(visit)
            if label == 'data':
                variables = f['settings/Data Variables'][0].decode()
                clocks = {}
                for key in CLOCKS:
                    values = re.findall(r'\(' + re.escape(key) + r'\s+([-+\d.eEdD]+)\)', variables)
                    if len(values) != 1:
                        raise ValueError('Missing/ambiguous saved native clock: ' + key)
                    clocks[key] = float(values[0].replace('D','e').replace('d','e'))
                if not all(math.isfinite(x) for x in clocks.values()):
                    raise ValueError('Nonfinite native clock')
                iterations = f['results/residuals/phase-1/continuity/iterations'][:]
                if not iterations.size:
                    raise ValueError('Final data has no native iteration history')
                iteration = int(iterations[-1])
        if before != (path.stat().st_size, path.stat().st_mtime_ns):
            raise ValueError('Input changed during read: ' + str(path))
    if not any(k.startswith('case/meshes/') for k in fingerprints) or not any(k.startswith('data/special/structure-') for k in fingerprints):
        raise ValueError('Incomplete native mesh/FE fingerprint')
    return {'clocks': clocks, 'iteration': iteration, 'physical_datasets': fingerprints}


def report_numbers(raw):
    out = {}
    for item in ([raw] if isinstance(raw, dict) else raw):
        for key, value in item.items():
            if key not in REPORTS:
                continue
            if key in out:
                raise ValueError('Duplicate native report ' + key)
            while isinstance(value, (list, tuple)):
                if not value:
                    raise ValueError('Empty native report ' + key)
                value = value[0]
            out[key] = float(value)
    if set(out) != set(REPORTS) or not all(math.isfinite(v) for v in out.values()):
        raise ValueError('Expected ten finite distinct native reports')
    return out


def native_snapshot(solver):
    s = solver.settings
    return {'clocks': {name: solver.rp_vars(name) for name in CLOCKS},
        'iteration': int(solver.scheme.eval('(get-current-iteration)')),
        'flow_time_high_level': s.solution.run_calculation.transient_controls.flow_time.get_state(),
        'reports': report_numbers(s.solution.report_definitions.compute(report_defs=list(REPORTS))),
        'dynamic_mesh': s.setup.dynamic_mesh.get_state(),
        'boundary_structure': {name:s.setup.boundary_conditions.wall[name].structure.get_state()
                               for name in ('tail_water-shadow','tail_root')},
        'solid_names': s.setup.cell_zone_conditions.solid.get_object_names(),
        'fluid_names': s.setup.cell_zone_conditions.fluid.get_object_names(),
        'structure':s.setup.models.structure.get_state(),
        'loaded_libraries': s.setup.user_defined.unload.udf_library_name.allowed_values()}


def snapshot_checks(actual, expected_setup, expected_reports, expected_fingerprint):
    dynamic = actual['dynamic_mesh']['dynamic_zones']
    expected_dynamic = expected_setup['dynamic_mesh']['dynamic_zones']
    by_zone = {v['zone']:v for v in dynamic.values()}
    expected_by_zone = {v['zone']:v for v in expected_dynamic.values()}
    checks = {'four_native_clocks_unchanged': actual['clocks'] == expected_fingerprint['clocks'],
        'native_iteration_unchanged':actual['iteration'] == expected_fingerprint['iteration'],
        'high_level_time_unchanged': math.isclose(actual['flow_time_high_level'], expected_fingerprint['clocks']['flow-time'],abs_tol=1e-10,rel_tol=0),
        'ten_reports_preserved': all(math.isclose(actual['reports'][n],expected_reports[n],abs_tol=1e-10,rel_tol=1e-7) for n in REPORTS),
        'only_formal_library_loaded': set(actual['loaded_libraries']) == {LIBRARY},
        'exact_dynamic_zone_state_including_CG': by_zone == expected_by_zone,
        'tail_FE_boundaries_unchanged':actual['boundary_structure'] == expected_setup['boundary_structure'],
        'structure_model_unchanged':actual['structure'] == expected_setup['structure'],
        'only_elastic_tail_solid':actual['solid_names'] == ['soft_tail'],
        'only_water_fluid':actual['fluid_names'] == ['water'],
        'three_formal_rigid_bindings': all(by_zone.get(n,{}).get('type') == 'rigid-body'
            and by_zone[n].get('motion',{}).get('motion_def') == FUNCTION+'::'+LIBRARY for n in RIGID),
        'tail_still_intrinsic_fsi':by_zone.get('tail_water',{}).get('type') == 'intrinsic-fsi'}
    return checks



def local_process_snapshot():
    command="Get-CimInstance Win32_Process -Filter \"Name='cx2610.exe' OR Name='fl2610.exe'\" | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath | ConvertTo-Json -Compress"
    value=subprocess.run(['powershell.exe','-NoProfile','-Command',command],
        capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    if value.returncode!=0 or value.stderr.strip():
        raise RuntimeError('Cannot read native Windows process identity')
    rows=json.loads(value.stdout) if value.stdout.strip() else []
    rows=[rows] if isinstance(rows,dict) else rows
    return {int(p['ProcessId']):{'process_id':int(p['ProcessId']),
        'parent_process_id':int(p['ParentProcessId']),'name':p['Name'],
        'executable_path':p['ExecutablePath']} for p in rows}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for key in ('source-run','output','fluent-path'):
        ap.add_argument('--'+key,required=True)
    ap.add_argument('--allow-native-autocompile',action='store_true',help='Accept Fluent rebuilding the unchanged owned C during native read; preserve all physical-state checks')
    ap.add_argument('--execute',action='store_true')
    ap.add_argument('--check-only',action='store_true')
    ap.add_argument('--rebuild-owned-library',action='store_true',help='After an accepted first load, rebuild only this own library from the relocated absolute C path and recheck identity')
    a=ap.parse_args()
    if a.execute and a.check_only:
        ap.error('Choose --execute or --check-only')
    run=Path(a.source_run).resolve(strict=True)
    out=Path(a.output).resolve()
    fluent=Path(a.fluent_path).resolve(strict=True)
    if out.exists() or not str(out).isascii() or out == run or run in out.parents:
        ap.error('Use a new ASCII output outside the original run')
    files=['fish-final.cas.h5','fish-final.dat.h5',SOURCE,
        f'{LIBRARY}/src/{SOURCE}',f'{LIBRARY}/win64/3ddp_host/libudf.dll',f'{LIBRARY}/win64/3ddp_node/libudf.dll',
        'records/final_actual_setup.json','records/final_values.json','records/native_reopen.json',
        'replay_config.json','replay_summary.json']
    missing=[n for n in files if not (run/n).is_file() or (run/n).stat().st_size == 0]
    if missing:
        print(json.dumps({'ready':False,'backend_contacted':False,'missing_or_empty_final_inputs':missing}));return 2
    hashes={n:sha(run/n) for n in files}
    setup=read_json(run/'records/final_actual_setup.json')
    values=read_json(run/'records/final_values.json')
    config=read_json(run/'replay_config.json')
    summary=read_json(run/'replay_summary.json')
    require({'completed_source_run':summary.get('status') == 'complete',
        'expected_20_steps':config.get('time_steps') == 20,'expected_dt':config.get('dt_s') == .025,
        'matching_own_C_copies':hashes[SOURCE] == hashes[f'{LIBRARY}/src/{SOURCE}'],
        'source_hash_matches_native_setup':setup['rigid_forebody_motion_setup']['source_sha256'] == hashes[SOURCE]},'Final source preconditions')
    dependencies=case_dependencies(run/'fish-final.cas.h5')
    fingerprint=physical_fingerprint(run/'fish-final.cas.h5',run/'fish-final.dat.h5')
    require({'native_step_20':fingerprint['clocks']['time-step'] == 20,
             'native_time_1_5':math.isclose(fingerprint['clocks']['flow-time'],0.5,rel_tol=0,abs_tol=1e-10)},'Final native time')
    plan={'ready':True,'backend_contacted':False,'source_run':str(run),'output':str(out),
        'files_sha256':hashes,'case_udf_dependencies':dependencies,'expected_clocks':fingerprint['clocks'],
        'helper_source':{'filename':Path(__file__).name,'sha256':sha(Path(__file__))},
        'new_process':{'Fluent':'261','dimension':3,'precision':'double','processor_count':1,'ui_mode':'gui'},
        'rebuild_owned_library':a.rebuild_owned_library,
        'allow_native_autocompile':a.allow_native_autocompile,
        'scope':'Native result relocation/reopen identity only; does not replace solution acceptance or demonstrate another computer/platform',
        'single_license_precondition':'Caller must first save and gracefully close the prior dedicated solver; this helper never closes another session'}
    if not a.execute:
        print(json.dumps(plan,ensure_ascii=False,indent=2));return 0
    out.mkdir(parents=True,exist_ok=False)
    for name in files:
        target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(run/name,target)
        if sha(target) != hashes[name]:
            raise RuntimeError('Relocated bytes differ: '+name)
    write(out/'portable_input_manifest.json',plan)
    write(out/'source_physical_fingerprint.json',fingerprint)
    shutil.copy2(Path(__file__),out/plan['helper_source']['filename'])
    if sha(out/plan['helper_source']['filename']) != plan['helper_source']['sha256']:
        raise RuntimeError('The preserved reopen helper differs from its input manifest')
    import ansys.fluent.core as pf
    solver=None;active=False
    result={'passed':False,'backend_contacted':False,'scope':plan['scope'],'checks':{}}
    try:
        processes_before=local_process_snapshot()
        solver=pf.launch_fluent(fluent_path=str(fluent),product_version='261',dimension=3,
            precision='double',processor_count=1,mode='solver',ui_mode='gui',py=False,
            cwd=str(out),start_timeout=120,cleanup_on_exit=False,start_watchdog=False)
        result['backend_contacted']=True
        s=solver.settings
        processes_after=local_process_snapshot()
        fresh=[v for k,v in processes_after.items() if k not in processes_before]
        controllers=[p for p in fresh if p['name'].lower()=='cx2610.exe']
        hosts=[p for p in fresh if p['name'].lower()=='fl2610.exe']
        if len(controllers)!=1 or len(hosts)!=1:
            raise RuntimeError('Cannot uniquely identify this newly launched native controller and host')
        result['process']={'cortex':controllers[0],'solver':hosts[0]}
        result['process_identity_method']='Local Windows process inventory before/after launch; unique new native host/controller; no hostname-deserialization RPC'
        result['version']=str(solver.get_fluent_version())
        result['native_launch_mode'] = {
            'product_version':str(solver.application_runtime.get_product_version().value),
            'dimension':solver.application_runtime.get_dimension().value,
            'precision':solver.application_runtime.get_precision().value,
            'processor_count':int(solver.application_runtime.get_processor_count())}
        if result['native_launch_mode'] != {'product_version':'26.1.0','dimension':3,'precision':'double','processor_count':1}:
            raise RuntimeError('Actual native application mode differs from Fluent261/3D/double/1-core')
        result['fresh_loaded_libraries']=s.setup.user_defined.unload.udf_library_name.allowed_values()
        if result['fresh_loaded_libraries']:
            raise RuntimeError('New process already has UDF libraries; refuse cached-library evidence')
        if int(solver.application_runtime.get_processor_count()) != 1:
            raise RuntimeError('Expected exactly one compute process')
        solver.chdir(out.as_posix())
        s.file.start_transcript(file_name=(out/'portable-reopen.trn').as_posix());active=True
        s.file.read_case_data(file_name=(out/'fish-final.cas.h5').as_posix())
        observed=native_snapshot(solver);write(out/'native_relocated_load.json',observed)
        checks=snapshot_checks(observed,setup,values['reports'],fingerprint)
        result['checks'].update(checks);require(checks,'Relocated native readback')
        # Optional rebuild updates only our UDF compilation metadata/library,
        # never hook/CG state. Explicit list-form unload is the official API.
        if a.rebuild_owned_library:
            s.setup.user_defined.unload(udf_library_name=[LIBRARY])
            s.setup.user_defined.compiled_udf(library_name=LIBRARY,
                source_files=[(out/SOURCE).as_posix()],header_files=[],use_built_in_compiler=True)
            s.setup.user_defined.load(udf_library_name=LIBRARY)
            rebuilt=native_snapshot(solver);write(out/'native_after_owned_rebuild.json',rebuilt)
            check=snapshot_checks(rebuilt,setup,values['reports'],fingerprint)
            result['owned_rebuild_checks']=check;require(check,'Owned-source rebuild changed native state')
        readback=out/'portable-readback.cas.h5'
        s.file.write_case_data(file_name=readback.as_posix())
        actual_fingerprint=physical_fingerprint(readback,out/'portable-readback.dat.h5')
        write(out/'readback_physical_fingerprint.json',actual_fingerprint)
        result['checks']['saved_physical_mesh_flow_FE_histories_exact']=actual_fingerprint == fingerprint
        result['readback_udf_dependencies']=case_dependencies(readback)
        s.results.scene['fish-moving-geometry'].display()
        # Leave the verified fresh GUI able to show the actual solved sequence.
        # Animation files remain source-run assets here; the release packager
        # separately relocates all 20 HSF files and rewrites CXA references.
        animation_file=run/'animations/fish-swim.cxa'
        animation_text=animation_file.read_text('utf-8-sig')
        frame_count=re.search(r'^FRAMES:\s*(\d+)\s*$',animation_text,re.M)
        sequence_match=re.search(r'^NAME:\s*(.*?)\s*$',animation_text,re.M)
        if frame_count is None or int(frame_count.group(1)) != 20 or sequence_match is None:
            raise RuntimeError('Expected the completed 20-frame native source animation')
        p=s.results.animations.playback
        p.read_animation_file(animation_file_name=animation_file.as_posix())
        names=list(dict.fromkeys(p.current_animation.allowed_values()))
        sequence=sequence_match.group(1)
        if names.count(sequence) != 1:
            raise RuntimeError('Cannot identify the native source animation sequence')
        p.current_animation=sequence
        s.results.graphics.views.restore_view(view_name='fish-oblique')
        p.view_mode(view_name='current-view')
        speed=p.play.speed.default_value()
        if speed is None:
            lower,upper=p.play.speed.min(),p.play.speed.max()
            if lower is None or upper is None:
                raise RuntimeError('Native playback speed bounds are unavailable')
            speed=(int(lower)+int(upper))//2
        p.play(player='>',start_frame=1,end_frame=20,increment=1,
               playback_mode='play-once',speed=int(speed))
        result['checks']['native_source_animation_loaded_and_played']=p.current_animation.get_state()==sequence
        result['animation']={'frames':20,'source':str(animation_file),
            'mode':'play-once','scope':'Source-run CXA loaded and finite native playback returned; screen not inspected'}
        final=native_snapshot(solver);write(out/'native_after_display.json',final)
        result['display_checks']=snapshot_checks(final,setup,values['reports'],fingerprint)
        s.file.stop_transcript();active=False
        trn=(out/'portable-reopen.trn').read_text('utf-8',errors='replace')
        opened=re.findall(r'Opening library\s+"([^"]+)"',trn)
        normalized=[Path(p.replace('\\\\','\\')).resolve() for p in opened]
        result['opened_library_messages']=opened
        result['checks']['observed_load_from_relocated_own_library']=bool(normalized) and all(p == out/LIBRARY for p in normalized)
        result['checks']['no_native_runtime_errors']=not bool(re.search(r'(?im)^\s*(?:Error\s*:|Error Object\s*:)|floating point exception|incorrect cg motion UDF',trn))
        result['checks']['same_machine_relocation_only']=True
        result['checks']['original_inputs_unchanged']=all(sha(run/n)==hashes[n] for n in files)
        result['checks']['executed_helper_snapshot_unchanged']=(sha(Path(__file__)) == plan['helper_source']['sha256']
            and sha(out/plan['helper_source']['filename']) == plan['helper_source']['sha256'])
        result['checks']['relocated_case_data_C_unchanged']=all(sha(out/n)==hashes[n] for n in ('fish-final.cas.h5','fish-final.dat.h5',SOURCE))
        result['relocated_dll_sha256']={n:sha(out/n) for n in files if n.endswith('.dll')}
        if a.allow_native_autocompile:
            result['checks']['owned_C_unchanged_after_native_autocompile']=all(sha(out/n)==hashes[n] for n in (SOURCE,f'{LIBRARY}/src/{SOURCE}'))
            result['checks']['native_builtin_compiled_only_owned_source']=('Compiler and linker: Clang (builtin)' in trn and set(re.findall(r"C sources: \['([^']+)'\]",trn))=={SOURCE})
            result['native_autocompile_observed']=True
        elif not a.rebuild_owned_library:
            result['checks']['copied_DLLs_not_rebuilt_implicitly']=all(sha(out/n)==hashes[n] for n in files if n.endswith('.dll'))
            result['checks']['no_compile_in_relocation_only_mode']='Compiler and linker:' not in trn
        require(result['checks'],'Portable reopen verification')
        require(result['display_checks'],'Display changed native physical state')
        result['passed']=True
    except Exception as exc:
        result['error']=repr(exc);result['traceback']=traceback.format_exc()
    finally:
        if solver is not None and active:
            try:solver.settings.file.stop_transcript()
            except Exception as exc:result['transcript_stop_error']=repr(exc)
        result['session_left_open']=solver is not None
        write(out/'portable_reopen_validation.json',result)
        # Do not exit/disconnect or restart another session; leave native GUI open.
    print(json.dumps({'passed':result['passed'],'evidence':str(out/'portable_reopen_validation.json')},ensure_ascii=False))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
