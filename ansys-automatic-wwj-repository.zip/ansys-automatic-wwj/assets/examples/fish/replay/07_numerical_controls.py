"""Restore the original control schedule without advancing physical time.

The refined geometry still requires its own completed-run validation.
"""
s = solver.settings
s.solution.methods.p_v_coupling.flow_scheme = 'Coupled'
s.solution.controls.p_v_controls.flow_courant_number = 50
s.solution.controls.p_v_controls.explicit_pressure_under_relaxation = 0.75
s.solution.controls.p_v_controls.explicit_momentum_under_relaxation = 0.75
s.solution.controls.advanced.multi_grid.mg_controls['pressure-coupled'].termination_criteria = 0.001
s.solution.controls.advanced.multi_grid.amg_controls.coupled_parameters.fixed_cycle_parameters.max_cycle = 30
structure_urf = (replay_settings['structure_under_relaxation'] if step_index == 1
                 else replay_settings['structure_under_relaxation_after_first'])
s.solution.controls.under_relaxation['structure'] = structure_urf
s.setup.dynamic_mesh.options.implicit_update = {
    'enabled': True, 'update_interval': 1,
    'relaxation_factor': replay_settings['implicit_mesh_relaxation'],
    'residual_criterion': replay_settings['implicit_mesh_residual_criterion'],
}
s.solution.run_calculation.parameters.time_step_size = replay_settings['dt_s']
s.solution.run_calculation.parameters.profile_update_interval = 1
s.solution.run_calculation.parameters.max_iter_per_time_step = replay_settings['max_iterations_per_step']
for name in s.solution.monitor.residual.equations.get_object_names():
    s.solution.monitor.residual.equations[name].absolute_criteria = 1e-3 if name == 'continuity' else 1e-4
numerical_control_record = {
    'step': step_index, 'dt_s': replay_settings['dt_s'], 'scheme': 'Coupled',
    'expected_structure_urf': structure_urf,
    'actual_structure_urf': s.solution.controls.under_relaxation['structure'].get_state(),
    'actual_implicit_mesh_update': s.setup.dynamic_mesh.options.implicit_update.get_state(),
    'expected_implicit_mesh_relaxation': replay_settings['implicit_mesh_relaxation'],
    'expected_implicit_mesh_residual_criterion': replay_settings['implicit_mesh_residual_criterion'],
}
record(f'numerical-controls-{step_index:04d}', numerical_control_record)
print('NUMERICAL_CONTROLS', numerical_control_record)

_cycles_now = solver.rp_vars('smooth-mesh/niter')
_smoothing_now = s.setup.dynamic_mesh.methods.smoothing.get_state()
record(f'mesh-controls-{step_index:04d}', {'skew_smoothing_cycles': _cycles_now,
    'smoothing': _smoothing_now})
if _cycles_now != 0 or _smoothing_now['method'] != 'diffusion':
    raise RuntimeError('Required zero skew cycles / diffusion state changed before physical step')
