/* Fluent 261 prescribed forebody translation, SI units.
 * The q function and interval-average velocity are unchanged from the native
 * two-step CG motion probe. Mixed rigid/elastic implicit FSI still requires
 * actual saved-node and tail-root seam verification after every solved step.
 * No persistent accumulator: repeated calls at a time return identical values.
 */
#include "udf.h"
#include <math.h>

static real prescribed_y(real t)
{
    if (t <= 0.0) return 0.0;
    return 0.001 * sin(12.56637061435917295385 * t)
                 * (1.0 - exp(-t / 0.5));
}

DEFINE_CG_MOTION(fish_rigid_forebody_heave, dt, vel, omega, time, dtime)
{
    NV_S(vel, =, 0.0);
    NV_S(omega, =, 0.0);
    if (dtime <= 0.0) {
        Message("FISH_RIGID_CG_INVALID_DT zone=%d time=%.17g dtime=%.17g\n",
                THREAD_ID(DT_THREAD(dt)), time, dtime);
        return;
    }
    vel[1] = (prescribed_y(time) - prescribed_y(time - dtime)) / dtime;
    Message("FISH_RIGID_CG_CALL zone=%d time=%.17g dtime=%.17g flow_time=%.17g vy=%.17g target_y=%.17g\n",
            THREAD_ID(DT_THREAD(dt)), time, dtime, CURRENT_TIME,
            vel[1], prescribed_y(time));
}
