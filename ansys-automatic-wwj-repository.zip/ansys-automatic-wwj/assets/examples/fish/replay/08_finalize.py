"""Save/reopen/inspect the solved fish case and play its native animation once.

Executed by replay_fluent_fish.py in its stage namespace. This script never
advances time. Evidence is computed from observations in the current run.
Saved checkpoints are audited separately; this script verifies the final native
configuration, save/reopen and finite animation playback.
"""
import math
import re
import time
import hashlib
import csv

FINAL_MODEL = 'realistic-fish-rigid-forebody-flexible-tail'
FINAL_COUNTS = {'water': 26638, 'soft_tail': 5030}
FINAL_RIGID_SURFACES = {'body_water', 'fish_drive', 'fish_eyes'}


def final_position_error(value):
    return (not isinstance(value, bool) and isinstance(value, (int, float))
            and math.isfinite(value) and 0 <= value <= 1e-7)


def final_rigid_tail_checkpoint_matches(item):
    """Recheck the new observable kinematic fields, not just a stored pass flag."""
    coupled = item.get('fluid_solid_interface_coordinate_comparison', {})
    rigid = item.get('rigid_surface_coordinate_comparison', {})
    root, seam = item.get('tail_root_constraint', {}), item.get('body_tail_perimeter_seam', {})
    return bool(item.get('model') == FINAL_MODEL
        and item.get('active_cell_counts') == FINAL_COUNTS
        and item.get('drive_report_surface') == 'tail_root'
        and item.get('interface_coordinate_consistency_passed') is True
        and item.get('interface_coordinate_tolerance_m') == 1e-7
        and set(coupled) == {'tail_water'}
        and all(s.get('interface_coordinate_consistency_passed') is True
                and s.get('interface_coordinate_tolerance_m') == 1e-7
                and final_position_error(s.get('max_fluid_coordinate_vs_solved_solid_error_m')) for s in coupled.values())
        and set(rigid) == FINAL_RIGID_SURFACES
        and all(s.get('passed') is True and s.get('coordinate_tolerance_m') == 1e-7
                and final_position_error(s.get('max_actual_coordinate_vs_prescribed_error_m')) for s in rigid.values())
        and root.get('passed') is True and root.get('faces') == 94 and root.get('vertices') == 60
        and root.get('coordinate_tolerance_m') == 1e-7
        and final_position_error(root.get('max_FE_displacement_vs_prescribed_error_m'))
        and seam.get('passed') is True and seam.get('vertices') == 24
        and seam.get('coordinate_tolerance_m') == 1e-7
        and final_position_error(seam.get('max_rigid_coordinate_vs_solved_tail_root_error_m')))


def final_geometry_manifest(audit, identity_path, selected_mesh):
    identity = json.loads(identity_path.read_text(encoding='utf-8-sig'))
    observed = {}
    for key in ['source_mesh', 'output_mesh', 'id_mapping', 'tail_root_topology',
                'active_validation', 'source_quality_record', 'source_unsplit_mesh', 'source_eye_split_record']:
        entry = identity['files'][key]
        relative = Path(entry['path'])
        if relative.is_absolute():
            raise ValueError('Geometry identity paths must be relative to the explicit manifest.')
        path = (identity_path.parent / relative).resolve(strict=True)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != entry['sha256']:
            raise ValueError('Geometry identity hash mismatch: ' + key)
        observed[key] = {'path': str(path), 'sha256': actual}
    canonical = audit.get('canonical_reference_identity', {})
    cells = canonical.get('native_initial_tetrahedra', {})
    surfaces = canonical.get('native_initial_surface_triangles', {})
    source_quality = json.loads(Path(observed['source_quality_record']['path']).read_text(encoding='utf-8-sig'))
    source_mesh = source_quality.get('mesh', {})
    split = json.loads(Path(observed['source_eye_split_record']['path']).read_text(encoding='utf-8-sig'))
    active = json.loads(Path(observed['active_validation']['path']).read_text(encoding='utf-8-sig'))
    checks = {
        'new_hdf_schema_and_model': audit.get('schema_version') == 5 and audit.get('model') == FINAL_MODEL,
        'actual_selected_mesh_is_manifest_output': Path(observed['output_mesh']['path']) == selected_mesh.resolve(),
        'manifest_matches_independent_hdf_audit': canonical.get('status') == 'passed'
            and canonical.get('manifest_sha256') == hashlib.sha256(identity_path.read_bytes()).hexdigest()
            and bool(canonical.get('manifest')) and Path(canonical['manifest']).resolve() == identity_path.resolve(),
        'source_id_maps_and_current_files_match': canonical.get('source_to_active_ids_verified') is True
            and canonical.get('files') == {k:observed[k] for k in ['source_mesh','output_mesh','id_mapping']},
        'source_generated_mesh_quality_gates_preserved': source_mesh.get('quality_gate_passed') is True
            and source_mesh.get('gmsh_minSICN_min',0) >= .08
            and source_quality.get('fluent_quality_gate',{}).get('passed') is True
            and source_mesh.get('min_fluent_orthogonal_quality',0) >= .001,
        'fresh_eye_partition_hash_chain_matches': split.get('source_sha256') == observed['source_unsplit_mesh']['sha256']
            and split.get('output_sha256') == observed['source_mesh']['sha256']
            and all(split.get(k) is True for k in ['node_section_unchanged','original_face_connectivity_and_adjacency_preserved','volume_zones_unchanged']),
        'active_export_quality_gates_preserved': active.get('mode') == 'water-tail'
            and active.get('checks',{}).get('all_initial_OQ_strictly_greater_0_01') is True
            and active.get('checks',{}).get('all_source_SICN_at_least_0_1_inherited') is True,
        'canonical_two_zone_tetrahedra_verified': set(cells) == set(FINAL_COUNTS)
            and all(cells[name].get('cells') == count and cells[name].get('all_four_vertex_coordinates_exact') is True
                    for name,count in FINAL_COUNTS.items()),
        'canonical_named_surface_triangles_verified': set(surfaces) == FINAL_RIGID_SURFACES | {'tail_water','tail_water-shadow','tail_root'}
            and all(s.get('all_three_vertex_coordinates_exact') is True and s.get('triangles',0) > 0 for s in surfaces.values())
            and surfaces.get('tail_root',{}).get('triangles') == 94,
    }
    return {'checks': checks, 'manifest': str(identity_path), 'actual_files': observed,
            'canonical_reference_identity': canonical}


def final_rigid_motion_bindings(dm, motion_record):
    zones = list(dm.get('dynamic_zones', {}).values())
    by_name = {z.get('zone'):z for z in zones}
    bindings = motion_record.get('bindings', {})
    checks = {'exactly_three_recorded_rigid_bindings': set(bindings) == FINAL_RIGID_SURFACES,
        'no_duplicate_physical_dynamic_zones': len(zones) == len(by_name),
        'exactly_seven_expected_dynamic_zones': set(by_name) == FINAL_RIGID_SURFACES | {'tail_water','inlet','outlet','farfield'},
        'expected_compiled_motion_function': motion_record.get('udf_function') == 'fish_rigid_forebody_heave'
            and motion_record.get('library_name') == 'libfish_rigid_tail_motion',
        'one_native_process': motion_record.get('actual_processor_count') == 1,
        'six_dof_disabled': dm.get('options', {}).get('six_dof', {}).get('enabled') is False,
        'outside_boundaries_stationary': all(by_name.get(n,{}).get('type') == 'stationary' for n in ['inlet','outlet','farfield']),
        'tail_root_not_a_fluid_dynamic_zone': 'tail_root' not in by_name}
    for label in ['source', 'staged_source']:
        path = Path(motion_record.get(label+'_path',''))
        checks[label+'_C_bytes_match_compiled_record'] = (path.is_file()
            and path.name == 'fish_rigid_forebody_motion.c'
            and hashlib.sha256(path.read_bytes()).hexdigest() == motion_record.get(label+'_sha256'))
    checks['source_and_staged_C_identical'] = (bool(motion_record.get('source_sha256'))
        and motion_record.get('source_sha256') == motion_record.get('staged_source_sha256'))
    for name in sorted(FINAL_RIGID_SURFACES):
        saved = bindings.get(name, {})
        selected = saved.get('selected_binding')
        current = by_name.get(name, {})
        motion = current.get('motion', {})
        checks[name+'_actual_compiled_binding_matches'] = (current.get('type') == 'rigid-body'
            and isinstance(selected,str) and selected.split('::')[0] == 'fish_rigid_forebody_heave'
            and selected in saved.get('allowed_values', []) and motion.get('motion_def') == selected
            and motion.get('exclude_motion_bc') is False and motion.get('relative_motion',{}).get('enabled') is False)
    return {'status':final_status(checks),'checks':checks,
            'scope':'Current native UDF binding and source identity; actual coordinates must pass every saved-step HDF audit.'}


def final_status(checks):
    return 'passed' if checks and all(value is True for value in checks.values()) else 'failed'


def final_scalar(value):
    while isinstance(value, (list, tuple)):
        if not value:
            raise ValueError('Empty scalar report.')
        value = value[0]
    number = float(value)
    if not math.isfinite(number):
        raise ValueError('Nonfinite scalar report.')
    return number


def final_report_values(raw, expected):
    items = [raw] if isinstance(raw, dict) else raw
    result = {}
    for item in items:
        if isinstance(item, dict):
            for name, value in item.items():
                if name in expected:
                    result[name] = final_scalar(value)
    if set(result) != set(expected):
        raise ValueError('Missing report values: ' + ', '.join(sorted(set(expected) - set(result))))
    return result


def final_close(value, expected, atol=1e-10, rtol=1e-7):
    try:
        return math.isfinite(float(value)) and math.isclose(float(value), expected, abs_tol=atol, rel_tol=rtol)
    except (TypeError, ValueError):
        return False


def final_write_evidence():
    record('fsi_evidence', final_evidence)


def final_stabilization_matches(state, enabled, scale):
    if state.get('enabled') is not enabled:
        return False
    if not enabled:
        return True
    parameters = state.get('parameters', {})
    return (parameters.get('method') == 'coefficient-based'
            and final_close(parameters.get('scale'), scale))


def final_numerical_schedule(records_dir):
    samples, failures = [], []
    corrector = replay_settings.get('structure_corrector_under_relaxation')
    previous_end = 0
    for step in range(1, int(replay_settings['time_steps']) + 1):
        expected_urf = (replay_settings['structure_under_relaxation'] if step == 1
                        else replay_settings['structure_under_relaxation_after_first'])
        name = f'numerical-controls-{step:04d}.json'
        try:
            value = json.loads((records_dir / name).read_text(encoding='utf-8-sig'))
            mesh_control = json.loads((records_dir / f'mesh-controls-{step:04d}.json').read_text(encoding='utf-8-sig'))
            implicit = value.get('actual_implicit_mesh_update', {})
            checks = {
                'step_identity': value.get('step') == step,
                'zero_skew_cycles': mesh_control.get('skew_smoothing_cycles') == 0,
                'diffusion_smoothing': mesh_control.get('smoothing', {}).get('method') == 'diffusion',
                'structure_predictor_urf': final_close(value.get('actual_structure_urf'), expected_urf),
                'declared_predictor_urf': final_close(value.get('expected_structure_urf'), expected_urf),
                'implicit_update_enabled': implicit.get('enabled') is True,
                'implicit_update_interval': implicit.get('update_interval') == 1,
                'implicit_mesh_relaxation': final_close(implicit.get('relaxation_factor'), replay_settings['implicit_mesh_relaxation']),
                'implicit_mesh_residual_criterion': final_close(implicit.get('residual_criterion'), replay_settings['implicit_mesh_residual_criterion'], atol=1e-15),
            }
            sample = {'step': step, 'record': name, 'expected_structure_urf': expected_urf,
                      'actual_structure_urf': value.get('actual_structure_urf'), 'checks': checks}
            if corrector is not None:
                event_name = f'structure-corrector-{step:04d}.json'
                event_value = json.loads((records_dir / event_name).read_text(encoding='utf-8-sig'))
                # Recompute every event check; never trust its stored passed flag.
                event_check = check_structure_corrector_record(event_value,step,replay_settings)
                checks['all_corrector_event_records_valid'] = event_check['passed']
                checks['global_iteration_continuity_between_steps'] = event_value.get('starting_iteration') == previous_end
                with (records_dir / f'validation-step-{step:04d}' / 'step_residuals.csv').open(encoding='utf-8-sig',newline='') as stream:
                    residual_rows = list(csv.DictReader(stream))
                current_rows = [row for row in residual_rows if int(row['step']) == step]
                checks['native_transcript_terminal_iteration_matches'] = (len(current_rows) == 1
                    and int(current_rows[0]['final_iteration']) == event_value.get('ending_iteration')
                    and final_close(float(current_rows[0]['flow_time_s']),step*replay_settings['dt_s']))
                previous_end = event_value.get('ending_iteration')
                sample.update(corrector_record=event_name,corrector_validation=event_check,
                              starting_iteration=event_value.get('starting_iteration'),
                              ending_iteration=previous_end,new_iteration_count=event_value.get('new_iteration_count'),
                              carryover_count=event_value.get('carryover_count'))
            if not all(checks.values()):
                failures.append({'step': step, 'record': name, 'checks': checks})
            samples.append(sample)
        except (OSError, ValueError, TypeError, AttributeError, KeyError) as error:
            failures.append({'step': step, 'record': name, 'error': str(error)})
    checks = {'all_expected_step_records_present': len(samples) == int(replay_settings['time_steps']),
              'all_recorded_native_controls_match': not failures}
    return {'status': final_status(checks), 'checks': checks, 'samples': samples,
            'failures': failures, 'corrector_enabled': corrector is not None,
            'source': 'Predictor native readbacks before every physical step; when enabled, every synchronous IterationEnded corrector/carryover event and native transcript terminal iteration.'}


def final_native_mesh_quality(records_dir, completed_steps):
    """Inspect native quality records without touching or advancing the solver."""
    samples, failures = [], []
    expected = list(range(completed_steps + 1))
    for step in expected:
        name = f'mesh-quality-{step:04d}.json'
        try:
            value = json.loads((records_dir / name).read_text(encoding='utf-8-sig'))
            fields = ['minimum_orthogonal_quality', 'maximum_aspect_ratio',
                      'minimum_orthogonal_quality_threshold']
            if not all(isinstance(value.get(k), (int, float)) and not isinstance(value[k], bool)
                       and math.isfinite(value[k]) for k in fields):
                raise ValueError('Invalid native mesh-quality values')
            quality, aspect, threshold = [value[k] for k in fields]
            if not (value.get('status') == 'passed' and threshold == .001
                    and threshold <= quality <= 1 and aspect >= 1):
                raise ValueError('Native orthogonal quality must be >= 0.001 for the fast teaching profile and aspect ratio >= 1')
            samples.append({'step': step, 'record': name, 'minimum_orthogonal_quality': quality,
                            'maximum_aspect_ratio': aspect})
        except (OSError, ValueError, TypeError, AttributeError) as error:
            failures.append({'step': step, 'record': name, 'error': str(error)})
    checks = {'all_expected_records_present_and_passed': [row['step'] for row in samples] == expected,
              'no_invalid_or_failed_records': not failures}
    result = {'status': final_status(checks), 'checks': checks, 'expected_steps': expected,
              'checked_steps': [row['step'] for row in samples], 'sample_count': len(samples),
              'minimum_orthogonal_quality_threshold': .001, 'samples': samples, 'failures': failures,
              'source': 'Native Fluent mesh.quality records at initial mesh and each completed step',
              'scope': 'Initial mesh and saved completed steps; unsaved nonlinear iterations are not checked.'}
    if samples:
        worst = min(samples, key=lambda row: row['minimum_orthogonal_quality'])
        result.update(minimum_orthogonal_quality=worst['minimum_orthogonal_quality'],
                      minimum_orthogonal_quality_step=worst['step'],
                      maximum_aspect_ratio=max(row['maximum_aspect_ratio'] for row in samples))
    return result


def finalize_fish():
    s = solver.settings
    case = run_path / 'fish-final.cas.h5'
    data = run_path / 'fish-final.dat.h5'
    report_names = ['drive-y', 'tail-y-mean', 'tail-y-max', 'tail-y-min',
                    'tail-displacement', 'force-x', 'force-y',
                    'mass-net', 'mass-inlet', 'mass-outlet']
    wetted = ['tail_water-shadow']
    fluid_interfaces = ['body_water', 'tail_water', 'fish_drive', 'fish_eyes']
    drive_name = 'tail_root'
    expected_expression = '0.001 [m]*sin(12.566370614359172 [s^-1]*t)*(1-exp(-t/0.5 [s]))'

    # Read the live configuration, not constants claimed by the setup scripts.
    setup = {'general': s.setup.general.get_state(),
             'structure': s.setup.models.structure.get_state(),
             'viscous': s.setup.models.viscous.get_state(),
             'solid_materials': s.setup.materials.solid.get_state(),
             'fluid_materials': s.setup.materials.fluid.get_state(),
             'solid_zones': s.setup.cell_zone_conditions.solid.get_state(),
             'fluid_zones': s.setup.cell_zone_conditions.fluid.get_state(),
             'boundary_structure': {name: s.setup.boundary_conditions.wall[name].structure.get_state()
                                    for name in wetted + [drive_name]},
             'inlet': s.setup.boundary_conditions.velocity_inlet['inlet'].get_state(),
             'outlet': s.setup.boundary_conditions.pressure_outlet['outlet'].get_state(),
             'dynamic_mesh': s.setup.dynamic_mesh.get_state(),
             'methods': s.solution.methods.get_state(),
             'controls': s.solution.controls.get_state(),
             'run_calculation': s.solution.run_calculation.get_state(),
              'force_reports': {'force-x': s.solution.report_definitions.drag['force-x'].get_state(),
                                'force-y': s.solution.report_definitions.lift['force-y'].get_state()},
              'drive_report': s.solution.report_definitions.surface['drive-y'].get_state(),
              'animation': s.solution.calculation_activity.solution_animations['fish-swim'].get_state(),
              'moving_scene': s.results.scene['fish-moving-geometry'].get_state(),
              'rigid_forebody_mesh': s.results.graphics.mesh['fish-rigid-forebody'].get_state(),
              'tail_contour': s.results.graphics.contour['fish-displacement'].get_state()}
    dm = setup['dynamic_mesh']
    dynamic_types = {item.get('zone'): item.get('type') for item in dm.get('dynamic_zones', {}).values()}
    stabilization_states = {item.get('zone'): item.get('solver', {}).get('stabilization', {})
                            for item in dm.get('dynamic_zones', {}).values()}
    bc = setup['boundary_structure']
    drive = bc[drive_name]
    solid_names = s.setup.cell_zone_conditions.solid.get_object_names()
    fluid_names = s.setup.cell_zone_conditions.fluid.get_object_names()
    wall_names = s.setup.boundary_conditions.wall.get_object_names()
    interior_names = s.setup.boundary_conditions.interior.get_object_names()
    material = s.setup.materials.solid['tail-elastic']
    material_values = {'density': material.density.value.get_state(),
                       'youngs_modulus': material.struct_youngs_modulus.value.get_state(),
                       'poisson_ratio': material.struct_poisson_ratio.value.get_state()}
    numerical_schedule = final_numerical_schedule(run_path / 'records')
    final_expected_urf = (replay_settings['structure_under_relaxation'] if int(replay_settings['time_steps']) == 1
                          else replay_settings['structure_under_relaxation_after_first'])
    if replay_settings.get('structure_corrector_under_relaxation') is not None:
        final_expected_urf = replay_settings['structure_corrector_under_relaxation']
    final_actual_urf = s.solution.controls.under_relaxation['structure'].get_state()
    motion_setup = json.loads((state_dir / 'rigid_forebody_motion_setup.json').read_text(encoding='utf-8-sig'))
    motion_bindings = final_rigid_motion_bindings(dm,motion_setup)
    setup.update(material_values=material_values, native_solid_names=solid_names, native_fluid_names=fluid_names,
                 native_wall_names=wall_names, native_interior_names=interior_names,
                 numerical_schedule=numerical_schedule, final_structure_under_relaxation=final_actual_urf,
                 rigid_forebody_motion_setup=motion_setup, rigid_forebody_binding_verification=motion_bindings,
                 expected_solution_stabilization_enabled=replay_settings['solution_stabilization_enabled'])
    record('final_actual_setup', setup)
    fsi_checks = {
        'nonlinear_structural_solver_enabled': setup['structure'].get('model') == 'nonlinear-elasticity',
        'viscous_fsi_force_enabled': setup['structure'].get('expert', {}).get('include_viscous_fsi_force') is True,
        'operating_pressure_fsi_force_disabled': setup['structure'].get('expert', {}).get('include_pop_in_fsi_force') is False,
        'tail_backward_euler': setup['structure'].get('controls', {}).get('unsteady_damping_rayleigh') == 'Backward Euler',
        'tail_wetted_interface_intrinsic_fsi_xyz': all(bc[name].get(axis + '_disp_boundary_condition') == 'Intrinsic FSI'
                                                      for name in wetted for axis in 'xyz'),
        'tail_root_prescribed_displacement_xyz': all(drive.get(axis + '_disp_boundary_condition') == 'Node ' + axis.upper() + '-Displacement'
                                                for axis in 'xyz'),
        'tail_root_xz_zero': all(final_close(drive.get(axis + '_disp_boundary_value', {}).get('value'), 0.0) for axis in 'xz'),
        'tail_root_y_expected_expression': re.sub(r'\s+', '', str(drive.get('y_disp_boundary_value', {}).get('value'))) == re.sub(r'\s+', '', expected_expression),
        'dynamic_mesh_enabled': dm.get('enabled') is True,
        'implicit_mesh_update_enabled': dm.get('options', {}).get('implicit_update', {}).get('enabled') is True,
        'only_tail_fluid_interface_uses_intrinsic_fsi': {name for name,kind in dynamic_types.items() if kind == 'intrinsic-fsi'} == {'tail_water'},
        'all_three_forebody_surfaces_are_rigid': {name for name,kind in dynamic_types.items() if kind == 'rigid-body'} == FINAL_RIGID_SURFACES,
        'native_forebody_UDF_bindings_and_source_verified': motion_bindings['status'] == 'passed',
        'tail_fsi_stabilization_settings_match':
            final_stabilization_matches(stabilization_states.get('tail_water', {}),
                                        replay_settings['solution_stabilization_enabled'],
                                        replay_settings['solution_stabilization_scale']),
        'native_structure_control_schedule_matches': numerical_schedule['status'] == 'passed',
        'final_structure_urf_matches_schedule': final_close(final_actual_urf, final_expected_urf),
        'both_force_reports_include_all_four_interfaces': all(set(setup['force_reports'][name].get('zones', [])) == set(fluid_interfaces) for name in ['force-x', 'force-y']),
        'exactly_water_and_one_elastic_tail_zone': set(solid_names) == {'soft_tail'} and set(fluid_names) == {'water'},
        'tail_uses_elastic_material': s.setup.cell_zone_conditions.solid['soft_tail'].general.material.get_state() == 'tail-elastic',
        'drive_report_uses_complete_tail_root_FE': setup['drive_report'].get('report_type') == 'surface-vertexavg'
            and setup['drive_report'].get('field') == 'y-displacement' and setup['drive_report'].get('surface_names') == ['tail_root'],
        'animation_uses_complete_moving_scene': setup['animation'].get('animate_on') == 'fish-moving-geometry',
        'scene_contains_forebody_and_tail_graphics': {item.get('name') for item in setup['moving_scene'].get('graphics_objects',{}).values()}
            == {'fish-rigid-forebody','fish-displacement'},
        'rigid_mesh_displays_three_forebody_surfaces': set(setup['rigid_forebody_mesh'].get('surfaces_list', [])) == FINAL_RIGID_SURFACES,
        'displacement_contour_is_tail_only': setup['tail_contour'].get('surfaces_list') == ['tail_water-shadow']
            and setup['tail_contour'].get('field') == 'total-displacement' and setup['tail_contour'].get('deformation') is False,
        'material_values_match': all(final_close(material_values[name], value) for name, value in [('density', 1000), ('youngs_modulus', 2e6), ('poisson_ratio', .35)]),
    }
    final_evidence['fsi_configuration'] = {'status': final_status(fsi_checks), 'checks': fsi_checks,
        'source': 'live Fluent settings', 'configuration_record': 'final_actual_setup.json',
        'material_values': material_values, 'dynamic_zone_types': dynamic_types,
        'numerical_schedule': numerical_schedule,
        'rigid_forebody_binding_verification': motion_bindings,
        'solution_stabilization_enabled': replay_settings['solution_stabilization_enabled'],
        'scope': 'Prescribed rigid forebody and matching full-section tail-root translation; only the elastic tail has Fluent intrinsic two-way FSI. No free swimming or forebody elasticity.'}
    selected_mesh_path = Path(mesh_path).resolve()
    audit = globals().get('checkpoint_audit', {})
    identity_path = geometry_dir / 'mesh_identity.json'
    geometry_identity = final_geometry_manifest(audit,identity_path,selected_mesh_path)
    topology_checks = dict(geometry_identity['checks'])
    topology_checks.update({
        'exactly_one_native_solid_and_one_fluid_zone': set(solid_names) == {'soft_tail'} and set(fluid_names) == {'water'},
        'all_four_fluid_wet_walls_exist': set(fluid_interfaces) <= set(wall_names),
        'one_tail_shadow_and_complete_root_exist': {'tail_water-shadow','tail_root'} <= set(wall_names),
        'rigid_surfaces_have_no_structural_shadows': not any(name+'-shadow' in wall_names for name in FINAL_RIGID_SURFACES),
        'old_body_tail_interior_absent': 'body_tail' not in interior_names,
        'new_expected_cell_counts': audit.get('expected_cell_counts') == FINAL_COUNTS,
    })
    final_evidence['fluid_solid_topology'] = {'status': final_status(topology_checks),
        'checks': topology_checks, 'source': 'Current geometry manifest, source-ID and native initial tetrahedron/triangle audit, and live zone names',
        'model':FINAL_MODEL,'active_cell_counts':FINAL_COUNTS,'geometry_identity':geometry_identity,
        'selected_mesh_path':str(selected_mesh_path),'native_solid_names':solid_names,'native_fluid_names':fluid_names,
        'native_wall_names':wall_names,'native_interior_names':interior_names}
    final_write_evidence()

    before_time = float(s.solution.run_calculation.transient_controls.flow_time.get_state())
    before_raw = s.solution.report_definitions.compute(report_defs=report_names)
    before = final_report_values(before_raw, report_names)
    record('final_values', {'flow_time_s': before_time, 'reports': before, 'raw': before_raw})
    s.file.write_case_data(file_name=case.as_posix())
    if not all(path.is_file() and path.stat().st_size > 0 for path in [case, data]):
        raise RuntimeError('Final native case/data pair was not written.')
    s.file.read_case_data(file_name=case.as_posix())
    reopened_skew_cycles = solver.rp_vars('smooth-mesh/niter')
    record('reopened_mesh_controls', {'skew_smoothing_cycles': reopened_skew_cycles,
        'smoothing': s.setup.dynamic_mesh.methods.smoothing.get_state()})
    after_time = float(s.solution.run_calculation.transient_controls.flow_time.get_state())
    after_raw = s.solution.report_definitions.compute(report_defs=report_names)
    after = final_report_values(after_raw, report_names)
    differences = {name: abs(after[name] - before[name]) for name in report_names}
    report_checks = {name: final_close(after[name], before[name]) for name in report_names}
    expected_time = float(replay_settings['dt_s']) * int(replay_settings['time_steps'])
    reopen_checks = {'native_files_nonempty': all(path.is_file() and path.stat().st_size > 0 for path in [case, data]),
                     'zero_skew_cycles_preserved': reopened_skew_cycles == 0,
                     'flow_time_preserved': final_close(after_time, before_time, rtol=0),
                     'requested_end_time_reached': final_close(after_time, expected_time, rtol=0),
                     'all_report_values_preserved': all(report_checks.values())}
    reopen_record = {'checks': reopen_checks, 'case': str(case), 'data': str(data),
        'before_time_s': before_time, 'after_time_s': after_time, 'expected_time_s': expected_time,
        'before': before, 'after': after, 'absolute_differences': differences,
        'report_checks': report_checks, 'report_tolerance': {'absolute': 1e-10, 'relative': 1e-7},
        'time_absolute_tolerance_s': 1e-10}
    record('native_reopen', reopen_record)
    final_evidence['native_reopen'] = {'status': 'unknown' if all(reopen_checks.values()) else 'failed', **reopen_record,
                                     'animation': {'status': 'unknown', 'reason': 'Playback not attempted yet'}}
    final_write_evidence()

    # Read only bytes appended by this final check, never a stale initial check.
    transcript = run_path / 'fish-transcript.trn'
    offset = transcript.stat().st_size
    s.mesh.check()
    deadline = time.monotonic() + 5.0
    added = ''
    while True:
        with transcript.open('rb') as stream:
            stream.seek(offset)
            added = stream.read().decode('utf-8', errors='replace')
        if re.search(r'Checking mesh[^\r\n]*\s+Done\.', added, re.I) or time.monotonic() >= deadline:
            break
        time.sleep(.1)
    (state_dir / 'final_mesh_check.txt').write_text(added, encoding='utf-8')
    volumes = re.findall(r'minimum volume\s*\(m3\)\s*:\s*([-+0-9.eE]+)', added, re.I)
    minimum = float(volumes[-1]) if volumes else None
    mesh_checks = {'fresh_check_has_positive_minimum_volume': minimum is not None and math.isfinite(minimum) and minimum > 0,
                   'fresh_check_finished': bool(re.search(r'Checking mesh[^\r\n]*\s+Done\.', added, re.I)),
                   'fresh_check_has_no_error_or_warning': not bool(re.search(r'\b(?:error|warning)\s*:', added, re.I))}
    audit = globals().get('checkpoint_audit', {})
    audit_results = audit.get('results', [])
    expected_steps = list(range(1, int(replay_settings['time_steps']) + 1))
    audit_checks = {
        'rigid_tail_schema_and_model': audit.get('schema_version') == 5 and audit.get('model') == FINAL_MODEL,
        'same_run_directory': bool(audit.get('run_dir')) and Path(audit['run_dir']).resolve() == run_path.resolve(),
        'requested_all_completed_steps': audit.get('requested_steps') == expected_steps,
        'observed_all_completed_steps': [item.get('step') for item in audit_results] == expected_steps,
        'no_checkpoint_read_or_mapping_failures': audit.get('failures') == [],
        'all_checkpoint_geometric_checks_passed': audit.get('all_requested_checkpoint_geometry_checks_passed') is True,
        'each_mapping_and_geometry_verified': bool(audit_results) and all(
            item.get('mapping_verified') is True and item.get('geometric_checks_passed') is True
            for item in audit_results),
        'fixed_interface_position_tolerance': audit.get('interface_coordinate_tolerance_m') == 1e-7,
        'audit_requires_all_four_wet_surfaces': set(audit.get('required_fluid_interfaces', [])) == set(fluid_interfaces),
        'audit_classifies_tail_and_three_rigid_surfaces': audit.get('required_coupled_interfaces') == ['tail_water']
            and set(audit.get('required_rigid_surfaces',[])) == FINAL_RIGID_SURFACES
            and audit.get('required_root_surface') == 'tail_root',
        'canonical_initial_mesh_identity_verified': all(geometry_identity['checks'].values()),
        'all_interface_position_checks_passed': audit.get('all_requested_interface_coordinate_checks_passed') is True,
        'each_tail_rigid_root_and_seam_within_position_tolerance': bool(audit_results)
            and all(final_rigid_tail_checkpoint_matches(item) for item in audit_results),
    }
    all_saved_steps = {'status': final_status(audit_checks), 'checks': audit_checks,
        'audit_file': globals().get('checkpoint_audit_path'),
        'checked_steps': [item.get('step') for item in audit_results],
        'interface_coordinate_tolerance_m': 1e-7,
        'interface_tolerance_scope': 'Numerical interface-position consistency, not experimental or physical accuracy.',
        'scope': 'All saved completed time-step checkpoints; unsaved nonlinear iterations are not inspected.',
        'source': 'Independent HDF case/data inspection with native ID/reference-coordinate mapping and native report crosschecks'}
    if audit_results:
        all_saved_steps.update(
            minimum_fluid_volume_m3=min(item['fluid_min_volume_m3'] for item in audit_results),
            minimum_solid_deformation_J=min(item['solid_min_deformation_J'] for item in audit_results),
            maximum_abs_principal_engineering_strain=max(item['solid_max_abs_principal_engineering_strain'] for item in audit_results),
            maximum_interface_coordinate_error_m=max(
                surface['max_fluid_coordinate_vs_solved_solid_error_m']
                for item in audit_results for surface in item['fluid_solid_interface_coordinate_comparison'].values()),
            maximum_rigid_coordinate_error_m=max(surface['max_actual_coordinate_vs_prescribed_error_m']
                for item in audit_results for surface in item['rigid_surface_coordinate_comparison'].values()),
            maximum_tail_root_constraint_error_m=max(item['tail_root_constraint']['max_FE_displacement_vs_prescribed_error_m'] for item in audit_results),
            maximum_body_tail_seam_error_m=max(item['body_tail_perimeter_seam']['max_rigid_coordinate_vs_solved_tail_root_error_m'] for item in audit_results))
    mesh_checks['all_saved_completed_steps_independently_verified'] = all_saved_steps['status'] == 'passed'
    native_quality = final_native_mesh_quality(state_dir, int(replay_settings['time_steps']))
    mesh_checks['native_quality_passed_at_initial_mesh_and_every_completed_step'] = native_quality['status'] == 'passed'
    final_evidence['dynamic_mesh_quality'] = {'status': final_status(mesh_checks), 'checks': mesh_checks,
        'scope': 'initial and all completed-step native quality checks, final native mesh check, and independent saved-step geometry checks',
        'flow_time_s': after_time, 'minimum_cell_volume_m3': minimum,
        'transcript_byte_offset': offset, 'transcript_new_bytes': transcript.stat().st_size - offset,
        'source': 'final_mesh_check.txt', 'all_saved_steps': all_saved_steps,
        'native_quality_history': native_quality,
        'ale_mass_balance_diagnostic': audit.get('ale_mass_balance_diagnostic', {'status': 'unknown', 'acceptance_gate': False}),
        'all_saved_time_steps_verified': all_saved_steps['status'] == 'passed' and native_quality['status'] == 'passed',
        'all_nonlinear_iteration_meshes_verified': False,
        'limitation': 'Checks cover saved completed steps and the final native mesh. They do not establish unsaved nonlinear-iteration quality or mesh/time independence.'}
    final_write_evidence()

    cxa = run_path / 'animations' / 'fish-swim.cxa'
    sequence = cxa.read_text(encoding='utf-8-sig')
    count_match = re.search(r'^FRAMES:\s*(\d+)\s*$', sequence, re.M)
    name_match = re.search(r'^NAME:\s*(.*?)\s*$', sequence, re.M)
    frame_refs = re.findall(r'^Frame\s+(\d+)\s+\d+\s+(.+?\.hsf)\s+\d+\s*$', sequence, re.M | re.I)
    frame_count = int(count_match.group(1)) if count_match else 0
    frames = [cxa.parent / reference.strip('"') for _, reference in frame_refs]
    if not (frame_count > 0 and len(frame_refs) == frame_count and
            [int(index) for index, _ in frame_refs] == list(range(frame_count)) and
            all(path.is_file() and path.stat().st_size > 0 for path in frames)):
        raise RuntimeError('Native animation has missing, empty, or inconsistent frames.')
    p = s.results.animations.playback
    p.read_animation_file(animation_file_name=cxa.as_posix())
    # Reading a case and then its CXA may list the same sequence label twice.
    available = list(dict.fromkeys(p.current_animation.allowed_values()))
    sequence_name = name_match.group(1) if name_match else cxa.stem
    exact = [name for name in available if name == sequence_name]
    matching = exact or [name for name in available if sequence_name in name]
    if len(matching) != 1:
        raise RuntimeError('Could not identify the loaded native animation: ' + repr(available))
    p.current_animation = matching[0]
    # Use one readable camera even when the reference source sequence contains
    # early overview frames. Newly generated frames also use fish-oblique.
    s.results.scene['fish-moving-geometry'].display()
    s.results.graphics.views.restore_view(view_name='fish-oblique')
    p.view_mode(view_name='current-view')
    speed_info = {'min': p.play.speed.min(), 'max': p.play.speed.max(),
                  'default': p.play.speed.default_value()}
    speed = speed_info['default']
    if speed is None:
        if speed_info['min'] is None or speed_info['max'] is None:
            raise RuntimeError('Native playback exposes neither a speed default nor complete bounds.')
        speed = (int(speed_info['min']) + int(speed_info['max'])) // 2
    speed = int(speed)
    if ((speed_info['min'] is not None and speed < speed_info['min']) or
            (speed_info['max'] is not None and speed > speed_info['max'])):
        raise RuntimeError('Native playback speed is outside observed bounds.')
    p.play(player='>', start_frame=1, end_frame=frame_count, increment=1,
           playback_mode='play-once', speed=speed)
    animation_checks = {'all_referenced_frames_nonempty': all(path.is_file() and path.stat().st_size > 0 for path in frames),
                        'observed_frame_count_matches_completed_steps': frame_count == int(replay_settings['time_steps']),
                        'loaded_sequence_selected': p.current_animation.get_state() == matching[0],
                        'finite_native_play_command_returned': True}
    animation = {'status': final_status(animation_checks), 'checks': animation_checks,
        'cxa': str(cxa), 'actual_frames': frame_count, 'frame_files': [str(path) for path in frames],
        'available_sequences': available, 'selected_sequence': matching[0],
        'speed_observed': speed_info, 'speed_used': speed, 'mode': 'play-once',
        'scope': 'Native API load and finite playback command; no screen inspection or infinite playback test.'}
    record('native_animation', animation)
    reopen_checks['native_animation_load_and_playback'] = animation['status'] == 'passed'
    final_evidence['native_reopen'].update(status=final_status(reopen_checks), checks=reopen_checks, animation=animation)
    final_write_evidence()
    failed = [name for name, item in final_evidence.items() if item.get('status') != 'passed']
    if failed:
        raise RuntimeError('Final observed evidence did not pass: ' + ', '.join(failed))
    print('FISH_NATIVE_FINALIZATION_VERIFIED', after_time, after, flush=True)


final_evidence = {name: {'status': 'unknown', 'reason': 'Not observed yet'} for name in [
    'fsi_configuration', 'fluid_solid_topology', 'dynamic_mesh_quality', 'native_reopen']}
final_write_evidence()
try:
    finalize_fish()
except Exception as final_error:
    for final_item in final_evidence.values():
        if final_item['status'] == 'unknown':
            final_item['reason'] = 'Finalization stopped before this check: ' + type(final_error).__name__ + ': ' + str(final_error)
    final_write_evidence()
    record('finalization_error', {'type': type(final_error).__name__, 'message': str(final_error)})
    raise
