# 精细鱼体瞬态 FSI 资源

> **仓库版说明：** 本目录保留代码相关记录及轻量预览。下文所述已求解原生工程、Case/Data、HSF、CAD/网格缓存和全部 Mechanical GIF 位于 [Release 完整包](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases)；新运行会重新生成结果。验收记录是作者历史实测，本次打包未重新求解。

作者：抖音 萌猪过河。验收日期：2026-09-18。本目录只保留精细鱼基线：31,668 单元，20 步 / 0.5 s；飞机资源在独立目录保留。

模型是来流中的精细刚性前身规定平移和柔性尾部响应；前身无结构单元，不是全鱼弹性或自由游泳。仅柔性尾采用 Fluent standalone intrinsic FSI，流体有限体积与内置结构有限元双向耦合，没有调用 Mechanical 或 System Coupling。 本次完整入口自行启动 1 进程的专用 Fluent GUI 会话，重新生成几何和网格、从时间 0 初始化并计算 20 步、验收、保存重开及原生播放均通过。显式 attach 到已有会话的分支未在本版另做完整 20 步实测；豆包客户端未实测。 本机并行新启动尚未验证成功；本例使用单进程。

- `replay/`：几何生成器 `generate_realistic_fish.py`、`mesh_export.py`、离线质量检查器 `fluent_quality.py`、`split_eye_zone.py`、阶段代码、执行器、验收器和 [requirements.txt](replay/requirements.txt)。从新几何开始完整重算，入口命令见 [主 README](../../../README.md#运行精细鱼体瞬态流固耦合示例)。
- `geometry/`：新 CAD/源网格和原始 [mesh_validation.json](geometry/mesh_validation.json) 保留；实际求解网格为 `active-tail/fish_water_tail.msh`。[八项几何身份](geometry/mesh_identity.json) 引用源眼区网格、活动网格、编号映射、尾根接缝及质量记录，均使用包内相对路径。
- `replay/fish_rigid_forebody_motion.c` 和 `rigid_tail_motion.py`：刚体前身的原生 UDF 源码及编译/绑定流程。`results/libfish_rigid_tail_motion` 仅保留本例正式库的源 C 与 host/node DLL，与 final Case/Data 同目录。[UDF 迁移边界](records/udf-portability.json) 绑定同机新目录新进程的原生重开证据，未承诺跨电脑/平台；fresh 重跑会在目标机器编译。读取已有结果时不初始化或重新求解。
- [飞机保留身份](records/aircraft-preservation.json)：既有飞机资源和入口的逐文件 hash，供迁移后独立核对。
- [初始 Case（完整版）](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases) / [Data（完整版）](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases)，[最终 Case（完整版）](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases) / [Data（完整版）](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases)：原生状态，保持配对读取。
- [fish-swim.cxa（完整版）](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases) 与同目录 20 个 HSF：原生显示回放。迁移后显式 Read 此 CXA，不能依赖 Case 内来源电脑的存储路径。
- [validation.json](records/validation.json)、[fsi_evidence.json](records/fsi_evidence.json)、[checkpoint-audit.json](records/checkpoint-audit.json)、[replay_summary.json](records/replay_summary.json)：数值、双向耦合、全部保存步和完整入口证据。
- `records/checkpoint-audit-0001.json` 至 `checkpoint-audit-0020.json`：每步通过后、下一步开始前生成的保存场检查；打包核对同次运行、参考初态及 Case/Data 哈希，汇总保留全部 20 步。
- [mesh-quality-0000.json](records/mesh-quality-0000.json) 至 [mesh-quality-0020.json](records/mesh-quality-0020.json)：初始及全部完成步的 21 份 Fluent 原生质量记录；最低正交质量 0.00322893，固定门槛 ≥ 0.001，最大报告长宽比 71.4294。
- 每个物理时间步的首个实际新迭代使用结构松弛系数 1；该轮结束后通过官方同步 `IterationEnded` 回调切换到 0.3，本步其余轮只读核对。新时间层至多出现一次上一迭代编号的边界重放事件，保持系数 1、不计作新迭代；每步仍只调用一次原生 `dual_time_iterate`。20 份 `records/structure-corrector-NNNN.json` 全部验收，并与原生残差终止编号逐步核对。
- [实际设置](records/final_actual_setup.json)、[保存重开](records/native_reopen.json)、[原生播放](records/native_animation.json)：实际观测记录。
- [运动/受力](records/motion_history.csv) 和 [残差](records/step_residuals.csv)：20 步原始采样。可选 `replay/plot_fish_history.py` 使用 Matplotlib；默认求解不依赖作图。

完整 20 份中间 Case/Data 留在来源运行目录，不随本包分发；重新计算将在新 `checkpoints/` 目录生成。最终 Data 和 HSF 显示帧不能恢复所有中间数值场。详细参数、实测数值和限制见 [精细鱼固定流程](../../../references/fish-fsi.md)。本版按用户要求采用快速教学预览：较粗网格、20 步一个周期；原生低正交质量警告保留在记录中，明确采用 0.001 而非标准 0.01 的网格门槛。结果只用于流程和运动展示，不作工程定量结论。 这是层流、粗四面体网格的教学演示；局部薄鳍可能只有一层厚度单元，未做边界层膨胀、网格/时间步独立性、周期稳定或生物实验验证，不能据此预测真实鱼推进性能。原生网格质量检查覆盖初始网格及全部 20 个完成步，几何和界面检查覆盖全部保存完成步，不覆盖未保存的内部迭代。Gmsh SICN 不能替代 Fluent 原生正交质量检查，质量门槛也不等于网格独立性。刚体运动 UDF 随包提供 C 源码；新运行需用目标 Fluent 内置编译器重新编译。随包仅含本例正式库的两个 Windows DLL；已实测同机新目录、新 Fluent 261 单进程读取时自动用内置编译器重新编译未改动的 C 源码，再加载结果，时钟、十项报告、网格/流场/FE 历史及刚体状态保持一致，没有初始化或求解。这不证明跨电脑或平台兼容；跨电脑可先使用独立 CXA/HSF 观察结果。
