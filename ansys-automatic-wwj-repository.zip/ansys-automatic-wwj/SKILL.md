---
name: ansys-automatic-wwj
description: 作者：抖音 萌猪过河。Fluent＋Mechanical 已实测：飞机绕流、全身柔性鱼双向流固耦合、机械臂支架静力与六阶模态。鱼例自动输出原生工程、云图、曲线、数值摘要、GIF 和 MP4，并在对话展示；鱼循环尚未闭合，其他模块持续更新。
---

# ANSYS automatic wwj

## 分发形态：仓库源码版

保留全部重跑代码，默认按固定路线从新几何/时间 0 求解。大型已求解缓存不随仓库提供；资产 manifest 只校验此版实际包含的文件。历史验收 JSON 中的路径和哈希是来源证据，不代表文件已随本包提供。

用户明确要求打开作者已有原生结果时，到 [Releases](https://github.com/fatdog-pro/ANSYS-automatic-wwj/releases) 下载 Assets 中的 `ansys-automatic-wwj.zip`，不要使用自动生成的 Source code 代替。完整版单独解压，避免与仓库版的 manifest 混合。若未发布附件，说明缺失。

飞机重跑入口已允许仅校验源码资产；`open_fluent_aircraft.py` 仍要求缓存 Case/Data，仓库版调用它会说明应下载完整版。全身柔性鱼和 Mechanical 保留原来的新建及导出路线。安装及分发区别见 [README](README.md)。

**更新进度：Fluent 已实测，新增 Mechanical 支架静力与六阶模态实测。** 已实测飞机绕流和精细鱼体瞬态双向 FSI。精细刚身柔尾分支完整重跑 20 步并验收通过；轻量全身柔性分支完整重跑 28 步并验收通过。两者均新启动专用 GUI、1 进程、从新几何和时间 0 开始；显式 attach 分支未在本版另做完整实测。后续逐步更新其他 Ansys 模块；跨产品路线及历史探索不代表全部模块完成当前版本质量验证。

这是跨产品路由与执行 skill。各产品使用自己的求解器和接口；安装了 skill 不等于安装或授权了全部 Ansys。当前包含 41 条产品/应用注册项，并有未列产品的扩展流程。

用户偏好：**仅通过 MCP / 官方 API / 原生脚本执行，不做屏幕识别、OCR、点击或键盘模拟；默认交付原生工程，尽可能把结果显示在 Ansys 窗口并保持打开。**

**默认 Fluent 示例按已经跑通的代码路线完整重跑三维飞机绕流。** 使用 [Fluent 固定流程](references/fluent.md) 的 `scripts/replay_fluent_aircraft.py`，一次执行建模、网格、设置、求解、验证和原生展示。不要重新研究或零散拼凑这个固定示例的接口；按阶段日志观察，失败时报告具体阶段。内置旧 Case/Data 仅供对照或用户明确要求的快速预览，不能代替新求解。

**鱼游动默认使用下方轻量全身柔性分支。** 用户明确选择精细刚性前身＋柔性鱼尾时，使用本段旧分支。

**刚性前身＋柔性鱼尾示例**使用 [精细鱼 FSI 固定流程](references/fish-fsi.md) 的 `scripts/replay_fluent_fish.py`。重新生成曲面鱼身、鱼鳍、眼部及鳃盖，再保留原水/尾网格并去掉前身结构单元；从时间 0 求解 20 步。三个前身湿面按 UDF 规定平移，尾湿面是双向 FSI，四面均参与水动力报告。初始及每个完成步均须通过 Fluent 原生正交质量 ≥ 0.001 的检查，不能用 Gmsh SICN 代替。使用原生 Case/Data、HSF 动画和逐步记录验收，不以缓存替代新求解。模型是来流中的精细刚性前身规定平移和柔性尾部响应；前身无结构单元，不是全鱼弹性或自由游泳。仅柔性尾采用 Fluent standalone intrinsic FSI，流体有限体积与内置结构有限元双向耦合，没有调用 Mechanical 或 System Coupling。 用户明确要求其他产品或自由游泳时不能用本例替代。

**刚身柔尾分支采用快速教学预览。** 本机实测完整建模至原生展示约 21.4605 分钟，其中 20 步求解和逐步验收约 17.4779 分钟；硬件不同会改变耗时。默认不回到旧的 75 步细网格长算例。执行时用前几步实测时间估算余量，若明显偏离教学演示时长，应先诊断和调整方案，不直接让用户等待数小时。低网格质量警告、较宽残差阈值和定量使用限制见 [鱼体说明](references/fish-fsi.md)。

**内置全身柔性鱼快速版**：保留鱼身主动弯曲、全湿面双向 FSI 和 0.70 秒 / 28 步，本机完整入口实测 **20.2 分钟**，含原生动画和重开验收；此基线不含后新增的对话媒体导出，该阶段另测约 42 秒。半小时任务使用 [全身柔性鱼路线](references/fish-fullbody-fsi.md) 的 `replay_halfhour_fish.py`。循环尚未闭合；身体弯曲任务不得用刚性鱼身替代。

全身柔性鱼属于本 `ANSYS automatic wwj` skill 的内置示例，继续使用 `$ansys-automatic-wwj` 调用，无需另装技能。执行代码位于 [scripts/fish_fullbody](scripts/fish_fullbody/)，已验收原生结果及动画见 [内置结果说明](assets/examples/fish-fullbody/README.md)。后续鱼模型与循环改进继续更新本 skill。

**Mechanical 展示示例**使用 [机械臂支架固定路线](references/mechanical-bracket.md)：新建带安装孔、减重孔、加强筋和轴承座的单体支架，实际计算静力及六阶模态，验证反力、导出原生动画、保存并重开工程。此例已分阶段实测；动画为放大的归一化振型，不是瞬态振动或真实振幅。

## 入口与选路

1. 用户指定的产品优先，例如 CFX 任务必须走 CFX，不能用 Fluent 结果代替。用户只描述物理问题时，按下表选择；只有选择影响结果且无法推断时才澄清。
2. 先使用已连接的官方产品 MCP。没有对应工具时，使用本包 MCP 桥的 `product_info` / `inventory` 和 Python SDK 作业；Codex 有终端时也可用指定解释器直接执行。桥不替代官方 SDK。
3. 阅读对应分支，检查产品版本、实际可执行文件、SDK 导入、许可证、会话身份和现有工程。只读库存**不启动 Ansys、不取许可证**；文件存在或包元数据存在均不代表已接入。
4. 继续完成用户已授权的任务；不要把例行连接、保存、新建专用工程变成重复确认。涉及未保存现有项目替换或关闭时，先保存并核对所属会话；有歧义才问用户。

| 任务 | 首选产品与必读参考 |
|---|---|
| 静力、模态、振动、屈曲、结构瞬态、热分析 | Mechanical；展示例读 [支架静力＋模态](references/mechanical-bracket.md)，其他任务读 [机械与热分析](references/mechanical.md) |
| 流动、传热、多相、燃烧；明确 CFX | Fluent 或指定的 CFX；[Fluent 已验证流程](references/fluent.md)、[产品路线](references/product-routes.md) |
| 精细鱼体、柔性鱼尾、瞬态双向流固耦合示例 | Fluent standalone intrinsic FSI；[鱼体固定流程](references/fish-fsi.md) |
| 全身柔性鱼、鱼身主动弯曲、完整摆动周期 | Fluent standalone intrinsic FSI；[内置全身柔性鱼流程](references/fish-fullbody-fsi.md)，当前 0.70 s 结果尚未闭合 |
| 高频/低频电磁、电子散热、电路 | AEDT 的 HFSS / Maxwell / Icepak / Q3D / Circuit 等；[产品路线](references/product-routes.md) |
| 光子、照明、镜头 | 分别 Lumerical / SPEOS / OpticStudio，不可互换；[产品路线](references/product-routes.md) |
| DEM、显式冲击、复材、多体、电机、优化、耦合 | Rocky / LS-DYNA / ACP / Motion / Motor-CAD / optiSLang / System Coupling；[产品路线](references/product-routes.md) |
| CAD、网格、材料服务、后处理、其他产品 | [产品路线](references/product-routes.md)；只做该工具实际支持的工作，不把后处理或 CAD 当成求解 |

## 环境与执行

- 当前电脑和迁移配置见 [MCP 接入与迁移](references/mcp-and-migration.md)。库存使用 `scripts/inventory.py`；注册表为 `assets/products.json`。
- 用 MCP 桥运行外部 SDK 脚本时读 [作业接口](references/bridge.md)。`eligible_for_script` 仅表示能提交脚本；之后还要实际导入 SDK、连接应用、检查分析许可。
- 精确版本接口以安装包代码、类型信息及对应官方文档为准。禁止凭相近产品猜造方法名。文档旧例程和当前 API 冲突时先检查版本。
- 缺 SDK 时按该产品官方安装文档配置独立环境，仅安装当前任务所需依赖。缺产品、许可或明确不开放 API 时报告缺项并保存已完成工作。不要试图绕过限制。
- 当前 Student OpticStudio 禁用 ZOS-API/ZPL；当前 Discovery 的独显要求未满足。这是产品/硬件边界，不能改为屏幕自动化规避。
- `adapter_required` 的产品需要查当前版本官方脚本/CLI，编写、验证一个限定该产品的适配器后再执行；不要擅自改成已有 SDK 的别的产品。新适配器扩展方法在 [产品路线](references/product-routes.md) 末尾。

## 仿真闭环

- 明确几何、单位、材料、物理假设、边界条件、网格及输出。教学演示可采用合理小模型并说明数值；不要为缺省教学参数反复停下。
- 新演示在专用目录与专用会话中创建；附着现有会话时先读取工程路径和分析树，按用户指示修改。不要调用通用 clear-all、close-all 或 kill-all。
- 对用户希望看到的过程：通过原生 API 依次显示几何、网格、载荷、结果，记录阶段日志。计算较快时阶段可能一闪而过，保存脚本/中间工程供重放，不用额外 GUI 操控。
- 检查实际求解状态、求解日志、收敛、守恒/反力、数量级和单位。进程退出码 0、MCP 外层成功、结果对象存在、漂亮云图都不能单独证明求解成功。
- 保存原生工程及所有伴随结果/资源，记录路径。安全条件满足时在新会话或保存后的当前会话重开并读回结果；若未重开，明确写“未验证重开”。
- 用原生结果激活、相机及显示 API 展示结果。服务型接口可能只能保存再由原生查看器打开，应如实说明。图像导出可用于报告；HTML/Python 图不冒充 Ansys 原生窗口。
- 用户要保留窗口时不要在 finally 或工具结束时调用 exit/disconnect/shutdown；这些方法在现有 Mechanical/Fluent MCP 可能直接退出应用。逐产品验证会话生命周期。

## 状态与交付

每个产品/分析独立记：版本、installed、SDK import、license、connected、setup、solve、native reopen、GUI state、证据路径和限制。没有观察到的状态写 unknown。

当前公开示例还包括 2026-09-20 Mechanical 支架静力与六阶模态，来源证据见 [支架固定路线](references/mechanical-bracket.md)。既有 Fluent 示例的来源证据是 Fluent 三维飞机 SST 绕流与精细鱼体 intrinsic FSI（20 步、0.5 s）。鱼例已完成整个新启动专用 GUI重跑入口、逐步数值验收、全部保存步 HDF 检查、Case/Data 重开读值和原生动画读取/有限播放。Mechanical 静力悬臂梁与稳态导热属于 2026-09-15 本机历史探索，不能据此扩展当前发布范围。接收者必须独立验收自己的运行；详见 [已验证范围](references/verified-baseline.md) 与 [交付边界](references/delivery-validation.md)。

求解验收后默认完成对应分析的结果导出：带单位的主要数值与验证摘要、原生工程和配套文件、关键云图/曲线、数值表。瞬态或模态分析提供该分支已支持的原生动画及可播放媒体。最终回复直接嵌入本次结果图和动图，并附原生工程、MP4、CSV等文件链接；客户端不支持内嵌时明确说明并给文件。全身柔性鱼使用已接入完整入口的 `export_deliverables.py`；不要只交一个结果文件夹让用户自己寻找动画。其他模块输出与其真实可用结果和已验证接口对应。

最终回答给出主要物理结果、原生文件、窗口状态及实质限制。用户只要运行算例时，不倾倒整个安装目录或产品清单。
