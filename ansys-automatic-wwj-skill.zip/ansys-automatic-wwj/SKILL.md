---
name: ansys-automatic-wwj
description: 作者：抖音 萌猪过河。目前更新至 Fluent，已完成飞机流体仿真示例实测。通过 MCP、官方 API 或原生脚本执行建模、网格、求解、验证和原生展示；后续将逐步更新其他 Ansys 模块，并持续实测、改进各模块质量。
---

# ANSYS automatic wwj

**更新进度：目前更新至 Fluent。** 当前公开版本以已实测的飞机流体仿真示例为基础；后续将逐步更新其他 Ansys 模块，持续补充真实算例、验证执行流程与结果质量。下方的跨产品路线及历史探索记录不代表所有模块都已完成当前版本的质量验证。

这是跨产品路由与执行 skill。各产品使用自己的求解器和接口；安装了 skill 不等于安装或授权了全部 Ansys。当前包含 41 条产品/应用注册项，并有未列产品的扩展流程。

用户偏好：**仅通过 MCP / 官方 API / 原生脚本执行，不做屏幕识别、OCR、点击或键盘模拟；默认交付原生工程，尽可能把结果显示在 Ansys 窗口并保持打开。**

**默认 Fluent 示例按已经跑通的代码路线完整重跑三维飞机绕流。** 使用 [Fluent 固定流程](references/fluent.md) 的 `scripts/replay_fluent_aircraft.py`，一次执行建模、网格、设置、求解、验证和原生展示。不要重新研究或零散拼凑这个固定示例的接口；按阶段日志观察，失败时报告具体阶段。内置旧 Case/Data 仅供对照或用户明确要求的快速预览，不能代替新求解。

## 入口与选路

1. 用户指定的产品优先，例如 CFX 任务必须走 CFX，不能用 Fluent 结果代替。用户只描述物理问题时，按下表选择；只有选择影响结果且无法推断时才澄清。
2. 先使用已连接的官方产品 MCP。没有对应工具时，使用本包 MCP 桥的 `product_info` / `inventory` 和 Python SDK 作业；Codex 有终端时也可用指定解释器直接执行。桥不替代官方 SDK。
3. 阅读对应分支，检查产品版本、实际可执行文件、SDK 导入、许可证、会话身份和现有工程。只读库存**不启动 Ansys、不取许可证**；文件存在或包元数据存在均不代表已接入。
4. 继续完成用户已授权的任务；不要把例行连接、保存、新建专用工程变成重复确认。涉及未保存现有项目替换或关闭时，先保存并核对所属会话；有歧义才问用户。

| 任务 | 首选产品与必读参考 |
|---|---|
| 静力、模态、振动、屈曲、结构瞬态、热分析 | Mechanical；[机械与热分析](references/mechanical.md) |
| 流动、传热、多相、燃烧；明确 CFX | Fluent 或指定的 CFX；[Fluent 已验证流程](references/fluent.md)、[产品路线](references/product-routes.md) |
| 高频/低频电磁、电子散热、电路 | AEDT 的 HFSS / Maxwell / Icepak / Q3D / Circuit 等；[产品路线](references/product-routes.md) |
| 光子、照明、镜头 | 分别 Lumerical / SPEOS / OpticStudio，不可互换；[产品路线](references/product-routes.md) |
| DEM、显式冲击、复材、多体、电机、优化、耦合 | Rocky / LS-DYNA / ACP / Motion / Motor-CAD / optiSLang / System Coupling；[产品路线](references/product-routes.md) |
| CAD、网格、材料服务、后处理、其他产品 | [产品路线](references/product-routes.md)；只做该工具实际支持的工作，不把后处理或 CAD 当成求解 |

## 环境与执行

- 当前电脑和迁移配置见 [MCP 接入与迁移](references/mcp-and-migration.md)。库存使用 `scripts/inventory.py`；注册表为 `assets/products.json`。
- 用 MCP 桥运行外部 SDK 脚本时读 [作业接口](references/bridge.md)。`eligible_for_script` 仅表示能提交脚本；之后还要实际导入 SDK、连接应用、检查分析许可。
- 精确版本接口以安装包代码、类型信息及对应官方文档为准。禁止凭相近产品猜造方法名。文档旧例程和当前 API 冲突时先检查版本。
- 缺 SDK 时按该产品官方安装文档配置独立环境，仅安装当前任务所需依赖。缺产品、许可或明确不开放 API 时报告缺项并保存已完成工作。不要试图绕过限制。
- 当前 Student OpticStudio 禁用 ZOS-API/ZPL；当前 Discovery 的独显要求未满足。这是产品/硬件边界，不能改为屏幕自动化规避。
- `adapter_required` 的产品需要查当前版本官方脚本/CLI，编写、验证一个限定该产品的适配器后再执行；不要擅自改成已有 SDK 的别的产品。新适配器扩展方法在 [产品路线](references/product-routes.md) 末尾。

## 仿真闭环

- 明确几何、单位、材料、物理假设、边界条件、网格及输出。教学演示可采用合理小模型并说明数值；不要为缺省教学参数反复停下。
- 新演示在专用目录与专用会话中创建；附着现有会话时先读取工程路径和分析树，按用户指示修改。不要调用通用 clear-all、close-all 或 kill-all。
- 对用户希望看到的过程：通过原生 API 依次显示几何、网格、载荷、结果，记录阶段日志。计算较快时阶段可能一闪而过，保存脚本/中间工程供重放，不用额外 GUI 操控。
- 检查实际求解状态、求解日志、收敛、守恒/反力、数量级和单位。进程退出码 0、MCP 外层成功、结果对象存在、漂亮云图都不能单独证明求解成功。
- 保存原生工程及所有伴随结果/资源，记录路径。安全条件满足时在新会话或保存后的当前会话重开并读回结果；若未重开，明确写“未验证重开”。
- 用原生结果激活、相机及显示 API 展示结果。服务型接口可能只能保存再由原生查看器打开，应如实说明。图像导出可用于报告；HTML/Python 图不冒充 Ansys 原生窗口。
- 用户要保留窗口时不要在 finally 或工具结束时调用 exit/disconnect/shutdown；这些方法在现有 Mechanical/Fluent MCP 可能直接退出应用。逐产品验证会话生命周期。

## 状态与交付

每个产品/分析独立记：版本、installed、SDK import、license、connected、setup、solve、native reopen、GUI state、证据路径和限制。没有观察到的状态写 unknown。

本机已完成的证据是 Fluent 三维飞机 SST 绕流、Mechanical 静力悬臂梁与稳态导热。飞机 Case/Data、几何、云图、真实收敛历史及验收记录已随本 skill 提供；源机器的求解与重开证据不等于接收者机器已验证。其他分析不继承“通过”。详见 [已验证范围](references/verified-baseline.md)。

最终回答给出主要物理结果、原生文件、窗口状态及实质限制。用户只要运行算例时，不倾倒整个安装目录或产品清单。

