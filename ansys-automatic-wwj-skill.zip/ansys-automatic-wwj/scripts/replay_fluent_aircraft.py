"""Rebuild and solve the aircraft demonstration using its fixed verified route.

The bundled solution is a reference only. This runner generates a new mesh,
initializes and solves new fields, validates actual monitor records, and leaves
the native Fluent GUI open. It never falls back to the bundled case/data.
"""
from __future__ import annotations

import argparse
import contextlib
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import uuid

_opener_spec = importlib.util.spec_from_file_location(
    "aircraft_reference_opener", Path(__file__).resolve().with_name("open_fluent_aircraft.py")
)
opener = importlib.util.module_from_spec(_opener_spec)
_opener_spec.loader.exec_module(opener)


SCRIPT_DIR = opener.ASSETS / "replay"
INITIAL_STAGES = (
    ("01_load_mesh.py", "Read and check the newly generated 3D mesh"),
    ("02_setup.py", "Set air, boundaries, SST and report definitions"),
    ("03_initialize.py", "Initialize new solution fields"),
    ("04_iterate.py", "First-order SIMPLE: up to 50 iterations"),
    ("05_second_order.py", "Switch to second-order schemes"),
    ("04_iterate.py", "Second-order SIMPLE: up to 50 more iterations"),
    ("06_display.py", "Display native pressure contour"),
    ("08_coupled.py", "Use coupled solver and global pseudo-time"),
    ("09_iterate_coupled.py", "Coupled: up to 30 more iterations"),
    ("09_iterate_coupled.py", "Coupled: up to 30 more iterations"),
    ("10_flow_graphics.py", "Create native velocity and streamline graphics"),
    ("11_accelerate.py", "Apply the verified pseudo-time scale adjustment"),
    ("09_iterate_coupled.py", "Coupled: up to 30 more iterations"),
    ("15_turbulence_controls.py", "Apply verified turbulence linear-solver controls"),
)
REFINEMENT_PHASES = (
    (None, "13_continue.py", "Turbulence controls; cumulative ceiling 290"),
    ("17_pressure_accuracy.py", "13_continue.py", "Pressure accuracy; cumulative ceiling 390"),
    ("19_linear_refinement.py", "13_continue.py", "Linear refinement; cumulative ceiling 490"),
    ("20_pseudo_stabilize.py", "13_continue.py", "Pseudo-time stabilization; cumulative ceiling 590"),
    ("21_chord_pseudo.py", "13_continue.py", "Chord length scale; cumulative ceiling 690"),
    (None, "13_continue.py", "Final fixed continuation; cumulative ceiling 790"),
)
FINAL_STAGES = ("22_final_exports.py", "18_save_reopen.py")
REQUIRED_SCRIPTS = sorted({
    *(name for name, _ in INITIAL_STAGES),
    *(name for phase in REFINEMENT_PHASES for name in phase[:2] if name),
    *FINAL_STAGES, "12_final_values.py", "16_wing_section.py",
    "generate_aircraft_mesh.py", "validate_solution.py", "plot_convergence.py", "requirements.txt",
})
MAX_ITERATIONS = 790


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    temporary.replace(path)


def plan() -> dict:
    return {
        "mode": "plan", "solver_launched": False, "geometry_generated": False,
        "route": "Fixed aircraft route validated with Fluent 26.1.0, PyFluent 0.42.1 and Gmsh 4.15.2",
        "geometry": {"script": "generate_aircraft_mesh.py", "output": "<new run>/geometry"},
        "initial_stages": [{"script": name, "purpose": purpose} for name, purpose in INITIAL_STAGES],
        "refinement_phases": [
            {"control_script": control, "iteration_script": iteration, "purpose": purpose,
             "after_phase": "Validate this run's actual progress and mesh; stop numerical stages when acceptance passes"}
            for control, iteration, purpose in REFINEMENT_PHASES
        ],
        "maximum_requested_iterations": MAX_ITERATIONS,
        "iteration_note": "Ceilings describe the fixed route, not completed iteration counts. The actual monitor history determines completion.",
        "final_stages": [*FINAL_STAGES, "validate_solution.py with explicit current-run paths", "plot_convergence.py --root <new run>"],
        "failure_policy": "Stop the numerical route at its first failed stage. Do not retry, explore new controls, loosen thresholds, or load bundled solution fields. Attempt fixed final export/validation where possible.",
        "gui_policy": "Refuse a new Fluent session while one already exists. Leave any session created by this run open.",
        "reference_policy": "Source-machine values are reference comparisons only; current numerical acceptance uses current histories and mesh.",
        "script_directory": str(SCRIPT_DIR),
    }


def dependency_metadata(python: str, packages: tuple[str, ...]) -> dict:
    """Inspect installed metadata in a chosen interpreter, without importing SDKs."""
    code = (
        "import importlib.metadata as m,json,sys\n"
        "d={'python':sys.executable,'python_version':list(sys.version_info[:3]),'packages':{}}\n"
        "for name in sys.argv[1:]:\n"
        " try:d['packages'][name]={'version':m.version(name),'installed':True}\n"
        " except m.PackageNotFoundError:d['packages'][name]={'version':None,'installed':False}\n"
        "print(json.dumps(d))\n"
    )
    extra = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
    result = subprocess.run(
        [python, "-c", code, *packages], text=True, capture_output=True,
        encoding="utf-8", errors="replace", timeout=30, check=True,
        env=dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8"), **extra,
    )
    return json.loads(result.stdout)


def inspect(args: argparse.Namespace) -> dict:
    result = {"mode": "check-only" if args.check_only else "geometry-only" if args.geometry_only else "replay",
              "solver_launched": False, "geometry_generated": False, "errors": [], "warnings": []}
    try:
        result["assets"] = opener.verify_assets()
        manifest = json.loads((opener.ASSETS / "manifest.json").read_text(encoding="utf-8-sig"))
        entries = {item["path"] for item in manifest["files"]}
        missing = [name for name in REQUIRED_SCRIPTS if "replay/" + name not in entries or not (SCRIPT_DIR / name).is_file()]
        if missing:
            raise ValueError("Replay scripts missing from verified manifest: " + ", ".join(missing))
        result["verified_replay_files"] = len(REQUIRED_SCRIPTS)
        result["run_root"] = str(opener.choose_run_root(args.run_root))
        result["reference_version"] = opener.expected_results()["version"]
    except (OSError, ValueError, TypeError, KeyError) as exc:
        result["errors"].append("Assets/runtime path: " + str(exc))
    try:
        result["mesh_dependencies"] = dependency_metadata(args.mesh_python, ("gmsh", "numpy"))
        for name, package in result["mesh_dependencies"]["packages"].items():
            if not package["installed"]:
                result["errors"].append("Mesh Python is missing " + name)
        version = result["mesh_dependencies"]["packages"]["gmsh"]["version"]
        if version and version != "4.15.2":
            result["warnings"].append("Gmsh differs from verified 4.15.2; regenerated geometry/mesh must pass current checks.")
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        result["errors"].append("Mesh dependency metadata: " + str(exc))
    if not args.geometry_only:
        try:
            result["solver_dependencies"] = dependency_metadata(sys.executable, ("ansys-fluent-core", "numpy", "matplotlib"))
            for name, package in result["solver_dependencies"]["packages"].items():
                if not package["installed"]:
                    result["errors"].append("Replay Python is missing " + name)
            version = result["solver_dependencies"]["packages"]["ansys-fluent-core"]["version"]
            if version and version != "0.42.1":
                result["warnings"].append("PyFluent differs from verified 0.42.1; API failures stop this fixed route without retries.")
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            result["errors"].append("Solver dependency metadata: " + str(exc))
        try:
            result["fluent"] = opener.locate_fluent(args)
            executable = result["fluent"]["path"]
            if not executable or not Path(executable).is_file():
                result["errors"].append("Fluent executable not found; use --fluent-exe or official installation environment variables.")
            if result["fluent"]["product_version"] != "26.1.0":
                result["warnings"].append("Only Fluent 26.1.0 is validated for this fixed route. Other versions can stop at incompatible API calls.")
            result["existing_fluent_processes"] = opener.existing_fluent_processes()
            if result["existing_fluent_processes"]:
                result["errors"].append("Fluent is already running. This runner will not create another session or modify the current project.")
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:
            result["errors"].append("Fluent installation/process check: " + str(exc))
    result["ready"] = not result["errors"]
    result["dependency_check"] = "Metadata only: no SDK imports, geometry generation, solver launch or license checkout."
    return result


class Tee:
    def __init__(self, terminal, log):
        self.terminal, self.log = terminal, log

    def write(self, message):
        self.terminal.write(message)
        if not self.log.closed:
            self.log.write(message)
        return len(message)

    def flush(self):
        self.terminal.flush()
        if not self.log.closed:
            self.log.flush()

    def __getattr__(self, name):
        return getattr(self.terminal, name)


class Replay:
    def __init__(self, args: argparse.Namespace, checks: dict):
        self.args, self.checks = args, checks
        self.run_dir = Path(checks["run_root"]) / (
            "aircraft-replay-" + datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:10]
        )
        self.run_dir.mkdir(parents=True, exist_ok=False)
        self.state_dir = self.run_dir / "records"
        self.geometry_dir = self.run_dir / "geometry"
        self.results_dir = self.run_dir / "results"
        for directory in (self.state_dir, self.geometry_dir, self.results_dir, self.state_dir / "stages"):
            directory.mkdir()
        self.stages = []
        self.namespace = {}
        self.validation = None
        self.summary = {
            "schema_version": 1, "status": "running", "started_utc": utc_now(),
            "runtime_directory": str(self.run_dir), "recomputed": False,
            "bundled_solution_loaded": False, "maximum_requested_iterations": MAX_ITERATIONS,
            "actual_iterations": None, "geometry_generated": False, "solver_launched": False,
            "gui_left_open": False, "numerical_route_completed": False,
            "numerical_acceptance": False, "native_reopen_passed": False,
            "checks": checks, "stages": self.stages, "failures": [],
        }
        self.save_summary()

    def save_summary(self):
        write_json(self.run_dir / "replay_summary.json", self.summary)

    def record(self, name, data):
        if not name or Path(name).name != name or any(char in name for char in ("/", "\\", ":")):
            raise ValueError("Unsafe record name: " + str(name))
        write_json(self.state_dir / (name + ".json"), data)

    def stage(self, name, action):
        index = len(self.stages) + 1
        item = {"index": index, "name": name, "status": "running", "started_utc": utc_now()}
        self.stages.append(item)
        record_path = self.state_dir / "stages" / f"{index:02d}_{Path(name).stem}.json"
        log_path = record_path.with_suffix(".log")
        item["log"] = str(log_path)
        write_json(record_path, item)
        self.save_summary()
        print("REPLAY_STAGE_START", index, name, flush=True)
        started = time.monotonic()
        try:
            with log_path.open("w", encoding="utf-8") as log:
                with contextlib.redirect_stdout(Tee(sys.stdout, log)), contextlib.redirect_stderr(Tee(sys.stderr, log)):
                    value = action()
            item["status"] = "passed"
            return value
        except Exception as exc:
            item["status"] = "failed"
            item["error"] = type(exc).__name__ + ": " + str(exc)
            item["traceback"] = traceback.format_exc()
            self.summary["failures"].append({"stage": name, "error": item["error"]})
            raise
        finally:
            item["finished_utc"] = utc_now()
            item["elapsed_seconds"] = time.monotonic() - started
            write_json(record_path, item)
            self.save_summary()
            print("REPLAY_STAGE_" + item["status"].upper(), index, name, flush=True)

    def subprocess(self, arguments):
        extra = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        with subprocess.Popen(
            arguments, cwd=str(self.run_dir), stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
            env=dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8"), **extra,
        ) as process:
            for line in process.stdout:
                print(line, end="", flush=True)
            returncode = process.wait()
        if returncode:
            raise RuntimeError("Subprocess exited with status " + str(returncode) + ": " + str(arguments[1]))

    def generate_geometry(self):
        self.subprocess([self.args.mesh_python, str(SCRIPT_DIR / "generate_aircraft_mesh.py"),
                         "--output", str(self.geometry_dir)])
        mesh = json.loads((self.geometry_dir / "mesh_validation.json").read_text(encoding="utf-8"))
        if not mesh.get("mesh", {}).get("passed") or not (self.geometry_dir / "aircraft_fluent.msh").is_file():
            raise RuntimeError("Newly generated geometry/mesh did not pass its own validation.")
        self.summary["geometry_generated"] = True
        self.summary["generated_mesh"] = {"cells": mesh["mesh"].get("cells"), "nodes": mesh["mesh"].get("nodes"),
                                          "gmsh_version": mesh.get("gmsh_version")}
        self.record("mesh_generation_validation", mesh)

    def launch(self):
        import ansys.fluent.core as pyfluent

        existing = opener.existing_fluent_processes()
        if existing:
            raise RuntimeError("A Fluent session appeared before launch; no new session started: " + str(existing))
        fluent = self.checks["fluent"]
        solver = pyfluent.launch_fluent(
            fluent_path=fluent["path"], product_version=fluent["product_version"],
            dimension=3, precision="double", processor_count=1, mode="solver", ui_mode="gui", py=False,
            cwd=str(self.run_dir), start_timeout=300, cleanup_on_exit=False, start_watchdog=False,
        )
        self.summary.update(solver_launched=True, gui_left_open=True,
                            fluent_version=str(solver.get_fluent_version()))
        self.namespace = {"solver": solver, "run_dir": self.run_dir, "state_dir": self.state_dir,
                          "geometry_dir": self.geometry_dir, "script_dir": SCRIPT_DIR,
                          "record": self.record, "Path": Path, "json": json,
                          "__name__": "__aircraft_replay_stage__"}
        specification = importlib.util.spec_from_file_location("aircraft_replay_validator", SCRIPT_DIR / "validate_solution.py")
        validator = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(validator)
        self.validate = validator.validate

    def run_script(self, name):
        path = SCRIPT_DIR / name
        self.namespace["__file__"] = str(path)
        def execute():
            exec(compile(path.read_text(encoding="utf-8-sig"), str(path), "exec"), self.namespace)
            if name in ("04_iterate.py", "09_iterate_coupled.py", "13_continue.py"):
                progress = self.read_progress()
                if progress is None or self.summary["actual_iterations"] is None:
                    raise RuntimeError("Iteration stage did not produce an actual monitor record.")
                self.summary["recomputed"] = self.summary["actual_iterations"] > 0
                if self.summary["actual_iterations"] > MAX_ITERATIONS:
                    raise RuntimeError("Actual monitor iteration exceeds the fixed route limit; stop without further iteration.")
                self.save_summary()
        self.stage(name, execute)

    def read_progress(self):
        path = self.state_dir / "progress.json"
        if not path.is_file():
            return None
        progress = json.loads(path.read_text(encoding="utf-8-sig"))
        labels = progress.get("histories", {}).get("residual", {}).get("iteration", [])
        if labels:
            self.summary["actual_iterations"] = int(labels[-1])
        return progress

    def check_numerical_acceptance(self):
        progress = self.read_progress()
        if progress is None:
            raise RuntimeError("Current run has no actual progress record; cannot validate.")
        mesh = json.loads((self.geometry_dir / "mesh_validation.json").read_text(encoding="utf-8-sig"))
        self.validation = self.validate(progress, mesh)
        label = "acceptance_after_" + str(self.summary["actual_iterations"])
        self.record(label, self.validation)
        self.summary["numerical_acceptance"] = bool(self.validation["steady_convergence"]["passed"])
        self.summary["acceptance_blockers"] = self.validation["steady_convergence"].get("blockers", [])
        self.save_summary()
        print("CURRENT_RUN_ACCEPTANCE", self.summary["actual_iterations"], self.summary["numerical_acceptance"], flush=True)
        return self.summary["numerical_acceptance"]

    def numerical_route(self):
        for name, _ in INITIAL_STAGES:
            self.run_script(name)
        for control, iteration, _ in REFINEMENT_PHASES:
            if control:
                self.run_script(control)
            self.run_script(iteration)
            accepted = self.stage("validate_current_solution", self.check_numerical_acceptance)
            if accepted:
                break
        self.summary["numerical_route_completed"] = True
        self.save_summary()

    def finalize(self):
        # These are the fixed delivery stages, not retries of failed numerical work.
        for name in FINAL_STAGES:
            try:
                self.run_script(name)
            except Exception:
                pass  # Detailed failure already persisted; keep collecting independent evidence.
        try:
            self.stage("validate_solution_cli", lambda: self.subprocess([
                sys.executable, str(SCRIPT_DIR / "validate_solution.py"),
                "--progress", str(self.state_dir / "progress.json"),
                "--mesh", str(self.geometry_dir / "mesh_validation.json"),
                "--output", str(self.results_dir / "validation.json"),
            ]))
            self.validation = json.loads((self.results_dir / "validation.json").read_text(encoding="utf-8-sig"))
            self.summary["numerical_acceptance"] = bool(self.validation["steady_convergence"]["passed"])
            self.summary["actual_iterations"] = self.validation.get("iteration")
            self.summary["acceptance_blockers"] = self.validation["steady_convergence"].get("blockers", [])
        except Exception:
            pass
        try:
            self.stage("plot_convergence", lambda: self.subprocess([
                sys.executable, str(SCRIPT_DIR / "plot_convergence.py"), "--root", str(self.run_dir),
            ]))
        except Exception:
            pass
        reopen = self.state_dir / "reopen_verification.json"
        if reopen.is_file():
            reopened = json.loads(reopen.read_text(encoding="utf-8-sig"))
            self.summary["native_reopen_passed"] = bool(reopened.get("passed"))
            self.summary["native_reopen_record"] = str(reopen)
        progress = self.read_progress()  # Read the preserved file; never query reset histories after reopen.
        if progress:
            actual = {name: pair[0] for item in progress["force_reports_raw"] for name, pair in item.items()}
            expected = opener.expected_results()
            self.summary["source_reference_comparison"] = {
                "used_for_acceptance": False,
                "meaning": "A different mesh/runtime can change these values. Numerical acceptance uses this run's histories and conservation checks.",
                "source_iterations": expected.get("source_iterations"),
                "forces": {name: {"actual": actual.get(name), "source_reference": value,
                                   "difference": actual[name] - value if name in actual else None}
                           for name, value in expected["forces"].items()},
            }
            self.summary["recomputed"] = bool(self.summary["actual_iterations"] and self.summary["actual_iterations"] > 0)
        self.summary["native_files"] = {name: str(self.run_dir / name) for name in ("aircraft.cas.h5", "aircraft.dat.h5")
                                        if (self.run_dir / name).is_file()}
        self.summary["mesh_accuracy"] = "Not validated: coarse tetrahedra, no prism inflation or grid-independence study."

    def execute(self) -> int:
        try:
            self.stage("generate_aircraft_mesh", self.generate_geometry)
            if self.args.geometry_only:
                self.summary["status"] = "geometry_complete"
                return 0
            self.stage("launch_fluent", self.launch)
            try:
                self.numerical_route()
            except Exception as exc:
                self.summary["numerical_stop_reason"] = type(exc).__name__ + ": " + str(exc)
            self.finalize()
            passed = (self.summary["numerical_route_completed"] and self.summary["numerical_acceptance"]
                      and self.summary["native_reopen_passed"] and not self.summary["failures"])
            self.summary["status"] = "complete" if passed else "failed" if self.summary["failures"] else "not_converged"
            return 0 if passed else 3
        except Exception as exc:
            self.summary["status"] = "failed"
            self.summary["error"] = type(exc).__name__ + ": " + str(exc)
            return 1
        finally:
            self.summary["finished_utc"] = utc_now()
            self.save_summary()
            print(json.dumps(self.summary, ensure_ascii=False, indent=2, default=str), flush=True)
        # No solver shutdown: the GUI remains available for inspection.


def main(argv: list[str] | None = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fluent-exe", help="Installed Fluent launcher; otherwise use official installation environment variables")
    parser.add_argument("--product-version", help="Ansys version, baseline 26.1.0")
    parser.add_argument("--run-root", help="ASCII directory for a unique new replay; default ASCII system temp")
    parser.add_argument("--mesh-python", default=sys.executable, help="Python with gmsh 4.15.2 and numpy; default current interpreter")
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--plan", action="store_true", help="Print the fixed route without SDK import, launch, generation or file writes")
    modes.add_argument("--check-only", action="store_true", help="Validate asset hashes and dependency metadata without any simulation")
    modes.add_argument("--geometry-only", action="store_true", help="Generate and validate new geometry/mesh without starting Ansys")
    args = parser.parse_args(argv)
    if args.plan:
        print(json.dumps(plan(), ensure_ascii=False, indent=2))
        return 0
    checks = inspect(args)
    print(json.dumps(checks, ensure_ascii=False, indent=2), flush=True)
    if checks["errors"]:
        return 2
    if args.check_only:
        return 0
    return Replay(args, checks).execute()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({"error": type(error).__name__ + ": " + str(error)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
