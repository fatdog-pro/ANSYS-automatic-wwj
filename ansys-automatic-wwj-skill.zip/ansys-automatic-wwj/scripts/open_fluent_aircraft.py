"""Open the bundled, already-solved aircraft case in Fluent through PyFluent.

This reader never generates a mesh, initializes a solution, or runs iterations.
Use --check-only for read-only checks or --prepare-only to copy verified native
files without importing PyFluent or launching Ansys. The GUI is left open.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import uuid


SKILL_ROOT = Path(__file__).resolve().parents[1]
ASSETS = SKILL_ROOT / "assets" / "examples" / "aircraft"
BASELINE_VERSION = "26.1.0"
NATIVE_FILES = ("results/aircraft.cas.h5", "results/aircraft.dat.h5")
REQUIRED_FILES = (*NATIVE_FILES, "expected.json")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_assets() -> dict:
    """Check every manifest entry, including native files and expected reports."""
    manifest = json.loads((ASSETS / "manifest.json").read_text(encoding="utf-8-sig"))
    if manifest.get("schema_version") != 1 or not isinstance(manifest.get("files"), list):
        raise ValueError("Unsupported or malformed aircraft manifest.")
    seen = set()
    total_bytes = 0
    for item in manifest["files"]:
        relative = item.get("path", "")
        pure = PurePosixPath(relative)
        if (not relative or pure.is_absolute() or ".." in pure.parts
                or "\\" in relative or ":" in relative or relative in seen):
            raise ValueError("Unsafe or duplicate manifest path: " + repr(relative))
        path = (ASSETS / relative).resolve()
        if not path.is_relative_to(ASSETS.resolve()):
            raise ValueError("Manifest entry escapes the aircraft asset directory.")
        if not path.is_file() or path.stat().st_size != item.get("bytes"):
            raise ValueError("Missing asset or incorrect byte count: " + relative)
        if sha256(path) != item.get("sha256"):
            raise ValueError("Asset SHA-256 mismatch: " + relative)
        seen.add(relative)
        total_bytes += path.stat().st_size
    missing = set(REQUIRED_FILES) - seen
    if missing:
        raise ValueError("Manifest omits required assets: " + ", ".join(sorted(missing)))
    return {
        "verified": True, "manifest": str(ASSETS / "manifest.json"),
        "verified_files": len(seen), "verified_bytes": total_bytes,
        "manifest_sha256": sha256(ASSETS / "manifest.json"),
    }


def expected_results() -> dict:
    expected = json.loads((ASSETS / "expected.json").read_text(encoding="utf-8-sig"))
    forces = expected["forces"]
    if set(forces) != {"drag-n", "lift-n", "cd", "cl"}:
        raise ValueError("Expected report definitions are incomplete.")
    if any(not isinstance(value, (int, float)) or not math.isfinite(value)
           for value in forces.values()):
        raise ValueError("Expected force values must be finite numbers.")
    tolerance = expected["numerical_tolerance"]
    for name in ("relative", "absolute"):
        value = tolerance[name]
        if not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError("Invalid numerical tolerance: " + name)
    normalize_version(expected["version"])
    return expected


def normalize_version(value: str) -> str:
    if re.fullmatch(r"\d{3}", value):
        value = value[:2] + "." + value[2] + ".0"
    elif re.fullmatch(r"\d{2}\.\d", value):
        value += ".0"
    if not re.fullmatch(r"\d{2}\.\d\.\d+", value):
        raise ValueError("Use an Ansys version such as 26.1.0 or 261.")
    return value


def inferred_version(path: str) -> str | None:
    match = re.search(r"(?:^|[\\/])v(\d{3})(?:[\\/]|$)", path, re.IGNORECASE)
    return normalize_version(match.group(1)) if match else None


def locate_fluent(args: argparse.Namespace) -> dict:
    """Read-only discovery using locally verified official launcher conventions.

    PyFluent 0.42.1 implements the same AWP_ROOTnnn/fluent/ntbin/win64
    and PYFLUENT_FLUENT_ROOT/ntbin/win64 layouts in its launcher modules.
    No SDK import or license checkout is needed to inspect those paths.
    """
    requested = normalize_version(args.product_version) if args.product_version else None
    if args.fluent_exe:
        executable = Path(args.fluent_exe).expanduser().resolve()
        version = requested or inferred_version(str(executable)) or BASELINE_VERSION
        return {"path": str(executable), "product_version": version, "source": "--fluent-exe"}
    version = requested or BASELINE_VERSION
    code = "".join(version.split(".")[:2])
    candidates = []
    if os.environ.get("AWP_ROOT" + code):
        candidates.append((Path(os.environ["AWP_ROOT" + code]) / "fluent", version, "AWP_ROOT" + code))
    if os.environ.get("PYFLUENT_FLUENT_ROOT"):
        root = Path(os.environ["PYFLUENT_FLUENT_ROOT"])
        derived = inferred_version(str(root))
        if not requested or not derived or derived == requested:
            candidates.append((root, requested or derived or version, "PYFLUENT_FLUENT_ROOT"))
    if not requested:
        for key in sorted(os.environ, reverse=True):
            match = re.fullmatch(r"AWP_ROOT(\d{3})", key)
            if match and int(match.group(1)) >= 261 and key != "AWP_ROOT" + code:
                candidates.append((Path(os.environ[key]) / "fluent", normalize_version(match.group(1)), key))
    for root, candidate_version, source in candidates:
        executable = (root / "ntbin" / "win64" / "fluent.exe").expanduser().resolve()
        if executable.is_file():
            return {"path": str(executable), "product_version": candidate_version, "source": source}
    return {
        "path": None, "product_version": version, "source": "not_found",
        "hint": "Supply --fluent-exe or configure the official AWP_ROOTnnn installation environment variable.",
    }


def existing_fluent_processes() -> list[dict]:
    """Read Windows tasklist CSV; never stop a process or connect to a session."""
    if os.name != "nt":
        raise RuntimeError("Opening this example is supported on Windows only.")
    tasklist = Path(os.environ.get("WINDIR", "")) / "System32" / "tasklist.exe"
    if not tasklist.is_file():
        raise RuntimeError("Windows tasklist.exe was not found; process check is unavailable.")
    result = subprocess.run(
        [str(tasklist), "/FO", "CSV", "/NH"], capture_output=True,
        text=True, errors="replace", check=False, timeout=30,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )
    if result.returncode:
        detail = result.stderr.strip() or result.stdout.strip() or f"exit status {result.returncode}"
        raise RuntimeError("Windows process check failed: " + detail[:1000])
    matches = []
    rows = list(csv.reader(result.stdout.splitlines()))
    if not rows or not any(len(row) >= 2 and row[1].isdigit() for row in rows):
        raise RuntimeError("Windows process output could not be validated.")
    for row in rows:
        if row and re.fullmatch(r"(?:fl\d{4}|fluent)\.exe", row[0], re.IGNORECASE):
            if len(row) < 2 or not row[1].isdigit():
                raise RuntimeError("Could not reliably read an existing Fluent PID.")
            matches.append({"image": row[0], "pid": int(row[1])})
    return matches


def choose_run_root(argument: str | None) -> Path:
    if argument:
        root = Path(argument).expanduser().resolve()
    else:
        temporary = Path(tempfile.gettempdir()).resolve()
        if not str(temporary).isascii() and os.name == "nt":
            # A short existing Windows path can avoid a non-ASCII user profile.
            import ctypes
            buffer = ctypes.create_unicode_buffer(32768)
            length = ctypes.windll.kernel32.GetShortPathNameW(str(temporary), buffer, len(buffer))
            if 0 < length < len(buffer):
                temporary = Path(buffer.value)
        root = temporary / "ansys-automatic-wwj" / "fluent-runs"
    if not str(root).isascii():
        raise ValueError("Choose an ASCII-only --run-root on this computer.")
    if root.exists() and not root.is_dir():
        raise ValueError("--run-root is not a directory.")
    return root


def prepare_files(run_root: Path, asset_check: dict) -> dict:
    run_dir = run_root / (
        "aircraft-open-" + datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:10]
    )
    run_dir.mkdir(parents=True, exist_ok=False)
    copied = []
    for relative in NATIVE_FILES:
        source = ASSETS / relative
        destination = run_dir / source.name
        shutil.copy2(source, destination)
        if sha256(source) != sha256(destination):
            raise RuntimeError("Runtime copy failed its SHA-256 check: " + source.name)
        copied.append({"path": str(destination), "sha256": sha256(destination), "bytes": destination.stat().st_size})
    summary = {
        "prepared": True, "runtime_directory": str(run_dir), "files": copied,
        "asset_check": asset_check, "solver_launched": False, "iterations_run": 0,
        "meaning": "Verified native files copied only; no solver, SDK import, or new simulation.",
    }
    write_json(run_dir / "prepare_summary.json", summary)
    return summary


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def compare_reports(raw: object, expected: dict) -> dict:
    # Verified settings API result: [{"drag-n": [value, "N"]}, ...].
    if not isinstance(raw, list):
        raise ValueError("Unexpected force-report return type: " + type(raw).__name__)
    actual = {}
    for entry in raw:
        if not isinstance(entry, dict):
            raise ValueError("Malformed Fluent report entry.")
        for name, value in entry.items():
            if name in expected["forces"]:
                if name in actual or not isinstance(value, (list, tuple)) or len(value) < 2:
                    raise ValueError("Malformed or duplicate report: " + name)
                actual[name] = {"value": float(value[0]), "unit": str(value[1])}
    if set(actual) != set(expected["forces"]):
        raise ValueError("Fluent did not return every required force/coefficient report.")
    tolerance = expected["numerical_tolerance"]
    comparisons = {}
    for name, value in expected["forces"].items():
        measured = actual[name]["value"]
        expected_unit = "N" if name.endswith("-n") else ""
        passed = (math.isfinite(measured) and actual[name]["unit"] == expected_unit
                  and math.isclose(measured, value, rel_tol=tolerance["relative"], abs_tol=tolerance["absolute"]))
        comparisons[name] = {**actual[name], "expected": value, "passed": passed}
    return {"passed": all(item["passed"] for item in comparisons.values()),
            "tolerance": tolerance, "reports": comparisons}


def open_native(args: argparse.Namespace, checks: dict, expected: dict) -> int:
    import ansys.fluent.core as pyfluent

    # Prevent a second session even if one appeared after the first check/import.
    current = existing_fluent_processes()
    if current:
        raise RuntimeError("Fluent is already running; no new session started: " + str(current))
    prepared = prepare_files(Path(checks["run_root"]), checks["assets"])
    run_dir = Path(prepared["runtime_directory"])
    summary = {
        "opened": False, "recomputed": False, "iterations_run": 0,
        "source_solve_iterations": expected.get("source_iterations"),
        "meaning": "Opening a previously solved case; force reports are read from stored solution fields.",
        "opened_at_utc": datetime.now(timezone.utc).isoformat(),
        "runtime_directory": str(run_dir), "view": args.view,
        "assets": checks["assets"], "requested_product_version": checks["fluent"]["product_version"],
    }
    try:
        solver = pyfluent.launch_fluent(
            fluent_path=checks["fluent"]["path"], product_version=checks["fluent"]["product_version"],
            dimension=3, precision="double", processor_count=1, mode="solver",
            ui_mode="gui", py=False, cwd=str(run_dir), start_timeout=300,
            cleanup_on_exit=False, start_watchdog=False,
        )
        summary["gui_left_open"] = True
        summary["fluent_version"] = str(solver.get_fluent_version())
        solver.settings.file.read_case_data(file_name=str(run_dir / "aircraft.cas.h5"))
        # The source case contains a source-machine report-file path. Redirect
        # this output in memory so later user-driven iteration uses this run.
        reports = solver.settings.solution.monitor.report_files
        if "aero-history" not in reports.get_object_names():
            raise RuntimeError("Saved case is missing the required aero-history report file.")
        reports["aero-history"].file_name = str(run_dir / "aero-history.out")
        summary["aero_history_file"] = reports["aero-history"].file_name.get_state()
        if Path(summary["aero_history_file"]).resolve() != (run_dir / "aero-history.out").resolve():
            raise RuntimeError("Report output path did not update correctly.")
        graphics = solver.settings.results.graphics
        if args.view == "pressure":
            name = "aircraft-pressure"
            objects = graphics.contour
        else:
            name = "aircraft-streamline-scene" if args.view == "streamlines" else "wing-velocity-scene"
            objects = solver.settings.results.scene
        if name not in objects.get_object_names():
            raise RuntimeError("Saved case is missing the required graphical object: " + name)
        # Only display preferences change; physical model and solution stay intact.
        effects = solver.preferences.Graphics.GraphicsEffects
        display_changes = {}
        for option in ("GridPlaneEnabled", "ReflectionsEnabled", "ShadowMapEnabled", "SimpleShadowsEnabled"):
            setting = getattr(effects, option)
            display_changes[option] = {"before": setting.get_state(), "after": False}
            setting.set_state(False)
        summary["display_preferences_changed"] = display_changes
        objects[name].display()
        camera = graphics.views.camera
        camera.projection = "orthographic"
        camera.position = [-8.0, -10.0, 6.0]
        camera.target = [0.0, 0.0, 0.0]
        camera.up_vector = [0.0, 0.0, 1.0]
        camera.field = [8.6, 6.45]
        raw = solver.settings.solution.report_definitions.compute(report_defs=list(expected["forces"]))
        summary["force_readback"] = compare_reports(raw, expected)
        summary["native_object"] = name
        summary["opened"] = True
        summary["case"] = str(run_dir / "aircraft.cas.h5")
        summary["data"] = str(run_dir / "aircraft.dat.h5")
        summary["native_files_overwritten"] = False
        summary["report_path_note"] = "Report output was redirected in the open session; saving manually preserves that change. Bundled and copied native files were not overwritten."
        write_json(run_dir / "open_summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
        return 0 if summary["force_readback"]["passed"] else 3
    except Exception as exc:
        summary["error"] = type(exc).__name__ + ": " + str(exc)
        write_json(run_dir / "open_summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
        return 1
    # Intentionally no solver shutdown: leave any successfully launched GUI open.


def main(argv: list[str] | None = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fluent-exe", help="Installed Fluent launcher path; otherwise use official installation environment variables")
    parser.add_argument("--product-version", help="Ansys version, e.g. 26.1.0; default: prefer the verified 26.1.0 baseline")
    parser.add_argument("--run-root", help="ASCII directory for a unique native-file copy; default: an ASCII system temp path")
    parser.add_argument("--view", choices=("pressure", "streamlines", "velocity"), default="pressure")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check-only", action="store_true", help="Verify assets and read configuration/dependency metadata; never launch")
    mode.add_argument("--prepare-only", action="store_true", help="Verify assets and copy case/data; no SDK import or solver required")
    args = parser.parse_args(argv)
    checks = {"mode": "prepare-only" if args.prepare_only else "check-only" if args.check_only else "open",
              "solver_launched": False, "iterations_run": 0, "errors": []}
    try:
        checks["assets"] = verify_assets()
        expected = expected_results()
        checks["run_root"] = str(choose_run_root(args.run_root))
    except (OSError, ValueError, TypeError, KeyError) as exc:
        checks["errors"].append(str(exc))
        print(json.dumps(checks, ensure_ascii=False, indent=2))
        return 2
    if args.prepare_only:
        prepared = prepare_files(Path(checks["run_root"]), checks["assets"])
        print(json.dumps(prepared, ensure_ascii=False, indent=2))
        return 0
    try:
        checks["fluent"] = locate_fluent(args)
        path = checks["fluent"]["path"]
        if not path or not Path(path).is_file():
            checks["errors"].append("Fluent executable was not found; provide --fluent-exe for this computer.")
        current_version = tuple(map(int, checks["fluent"]["product_version"].split(".")))
        source_version = tuple(map(int, expected["version"].split(".")))
        if current_version < source_version:
            checks["errors"].append("Native files were saved by " + expected["version"] + "; opening in an older Fluent is unsupported.")
        checks["same_version_as_source"] = current_version == source_version
        if current_version != source_version:
            checks["compatibility_note"] = "This Fluent version differs from the verified baseline; opening and force readback must be checked locally."
    except (OSError, ValueError) as exc:
        checks["errors"].append(str(exc))
    try:
        checks["pyfluent_package_version"] = metadata.version("ansys-fluent-core")
    except metadata.PackageNotFoundError:
        checks["pyfluent_package_version"] = None
        checks["errors"].append("PyFluent is missing in this Python environment. Use a Python environment with ansys-fluent-core installed.")
    checks["dependency_check"] = "Distribution metadata only; the SDK is imported only when opening."
    checks["python"] = sys.executable
    try:
        checks["existing_fluent_processes"] = existing_fluent_processes()
        if checks["existing_fluent_processes"]:
            checks["errors"].append("Fluent is already running. Save and close that session before using this opener; no session was changed.")
    except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
        checks["existing_fluent_processes"] = None
        checks["errors"].append(str(exc))
    checks["ready_to_open"] = not checks["errors"]
    checks["source_solve_iterations"] = expected.get("source_iterations")
    checks["license_check"] = "Not performed; a local compatible Fluent installation and license are needed only to open the native GUI."
    print(json.dumps(checks, ensure_ascii=False, indent=2), flush=True)
    if checks["errors"]:
        return 2
    if args.check_only:
        return 0
    return open_native(args, checks, expected)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({"error": type(error).__name__ + ": " + str(error)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
