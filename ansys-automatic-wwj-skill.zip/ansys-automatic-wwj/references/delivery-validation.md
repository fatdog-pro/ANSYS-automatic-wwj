# 此版本交付验证

日期：2026-09-15。产品安装为本机 Ansys Student 2026 R1；该记录不随迁移自动成立。

## 库存

实际运行 `scripts/inventory.py`，41 条产品/应用注册项：

| 前置状态 | 数量 | 含义 |
|---|---:|---|
| eligible_for_script | 2 | Mechanical、Fluent，已有 Python SDK 元数据 |
| blocked_missing_sdk | 27 | 当前配置的环境缺相应官方 SDK；也可能缺独立产品 |
| blocked_student_api | 1 | OpticStudio Student 禁止编程接口 |
| blocked_no_python_route | 11 | 需产品原生脚本/CLI 的适配器，不能冒充已实现 |

26 项找到了候选程序文件。这可能包括共享组件或辅助程序，不能报告为 26 个已安装且可运行的独立求解器。

库存没有 SDK import、许可证签出或 Ansys 启动。完整本机库存保存在包外 `inventory-20260915.json`，仅用于本机排查。产品历史真实验证见 verified-baseline.md。

## 新代码

- `quick_validate.py`：技能格式通过；UTF-8 中文入口与 UI 元数据已检查。
- `test_bridge.py`：11 项测试，10 通过；Windows 当前账户不能创建符号链接，相关 1 项跳过。
- 实际 Python helper 成功与异常退出、错误 hash、产品/会话声明、路径穿越、缺 SDK、Student API 禁用、配置解释器、有界日志及 bundled API 路径均测试。
- FastMCP 实际 stdio 工具发现与 product_info 调用通过，6 工具可见；Mechanical 0.13.2 / Fluent 0.42.1 读取正确，zemax 别名返回 opticstudio 并阻断 Student API。
- 初版通道网格生成器已替换为三维飞机建模/网格代码及完整重跑路线。打包更新本身不等于再次执行了一轮求解。
- 独立代理使用五种真实请求做 forward-test：CFX 精确选路、Student OpticStudio API、现有 Mechanical 添加模态并保留窗口、豆包迁移边界、helper completed 的含义。均未发现严重误导；适配器扩展步骤已补充。
- 安装位置的真实 stdio 端到端检查通过：发现6工具，读取3产品状态，再通过 write_script/start_job 实际导入 Mechanical SDK，helper 正常结束并读取日志；没有启动求解器。已打开的 Mechanical 进程仍响应，工程标题正确。
- 本机适配器配置分支检查通过：缺路径阻断、存在路径仍标 configured_unverified、已知 Student API 禁用仍优先阻断。

以上桥与库存记录来自初版技能验证，不表示此后所有版本自动通过。飞机示例本身的源机求解/重开记录见 verified-baseline.md，打开器的打包验证另列下文。豆包客户端导入、其他产品求解和未授权产品的 API 仍未验证。

## 飞机固定重跑路线的打包验证

- 默认入口 `replay_fluent_aircraft.py`，原实际成功脚本按固定顺序执行，最多请求790步；当前运行独立验收，旧结果仅作参考。另有显式预览入口 `open_fluent_aircraft.py`。
- 技能格式、脚本语法、无SDK的 `--plan` 与 MCP `runpy` 入口通过；完整 manifest 校验包含46个资产，其中24个为重放脚本/依赖文件。
- 只读预检正确识别 Python3.12.14、PyFluent0.42.1、Gmsh4.15.2 与已有Fluent会话，未启动第二实例。受限工具环境曾因系统拒绝 tasklist 而停止；正常主机权限下成功识别已有进程。进程检查错误现在保留具体stderr原因。
- 独立代理在新的中文目录中实际执行复制出的几何/网格生成脚本：24.68秒，59947四面体、11734节点；CAD体积与基线一致，正体积、面邻接、壁面闭合、体积一致性通过。
- 网格计数相对源运行略有变化，因此新图表使用当前网格元数据；源机升阻力只作对照，不能要求新运行逐位相同或代替其验收。
- 日志转发器已测试关闭阶段日志后的异步write/flush，避免后台输出持有旧流导致异常。
- 本轮更新没有重新启动Ansys或再做一轮CFD求解；新入口的整个求解到重开流程尚未在本轮整轮实测。它调用的是源运行已逐段成功的代码；实际重跑必须以目标机的新记录判断成功。
