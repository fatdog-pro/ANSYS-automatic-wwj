# Codex 与豆包本地 MCP 配置

本包无需屏幕操控。SKILL.md 提供选路与流程；MCP/SDK 提供执行能力，两部分都要配置。

## 本机配置

- Ansys Student 2026 R1：`E:/ANSYSStudent/v261`。
- Mechanical/通用桥 Python：`D:/AnsysMCP/.venv/Scripts/python.exe`。
- Fluent Python：`D:/FluentMCP/.venv/Scripts/python.exe`。
- 本 skill 安装在 `C:/Users/15063/.codex/skills/ansys-automatic-wwj`。
- `assets/runtime.local.json` 保存产品根目录、Python 环境、项目根目录、edition 提示。用 `--config <path>` 或 `ANSYS_UNIFIED_CONFIG` 指定另一个配置。
- 默认通用环境只已有 Mechanical SDK；其他 SDK 按任务配置。SDK 升级前检查各版本 Python 兼容性，避免污染已验证环境。可以在 python_runtimes 新增环境并调整产品 runtime。

`assets/mcp.local.json` 是当前电脑的通用 mcpServers JSON。客户端若提供表单，分别填写 command、args、env；不要假定每个客户端支持直接导入该 JSON。

### 官方 Mechanical MCP

command 为 Mechanical Python，args：

```json
["-m", "ansys.mechanical.mcp", "--static-tools", "--transport-mode", "wnua"]
```

env：`AWP_ROOT261=E:/ANSYSStudent/v261`、`PYMECHANICAL_TRANSPORT_MODE=wnua`、`PYTHONUTF8=1`、`PYTHONIOENCODING=utf-8`。启动超时建议 120 秒，求解工具超时按任务设置 600–900 秒。

### 官方 Fluent MCP + 本机兼容启动器

默认 Fluent 示例的已验证重跑脚本、基准 Case/Data 与图形已内置在 `assets/examples/aircraft/`，迁移时复制**整个 skill 文件夹**。不要只复制 SKILL.md，也不需另找作者的 D 盘项目。按 [Fluent 固定流程](fluent.md) 配置接收者的解释器、Gmsh/PyFluent 依赖与 Ansys 位置，运行 `scripts/replay_fluent_aircraft.py` 一次完成全部阶段，不让 agent 重新摸索算法或接口。脚本按自身位置找资源，新结果写入本机独立目录。仅明确预览时使用 `scripts/open_fluent_aircraft.py`。

使用 Fluent Python 执行本包 `scripts/fluent_mcp_compat.py`。启动器仅为官方 launch_fluent 增加 `py=False` 默认值，解决本机中文主机名下的 Fluent 内嵌 Python 编码问题；外部 PyFluent API 仍正常使用。不修改 Ansys 安装文件。

### 本包统一桥

使用带 `fastmcp` 的 Python（本机 Mechanical 和 Fluent 环境均已存在）：
```json
["C:/Users/15063/.codex/skills/ansys-automatic-wwj/scripts/bridge.py",
 "--config", "C:/Users/15063/.codex/skills/ansys-automatic-wwj/assets/runtime.local.json"]
```

这是本包扩展桥，负责库存与外部 SDK 作业；没有对应官方 SDK/许可时会返回缺项。

## 迁移到豆包电脑版

桥的已验证运行组合为 Python 3.12、`fastmcp==4.0.3`。在目标机新建独立环境后，使用该环境的 `python -m pip install fastmcp==4.0.3`；官方产品 SDK 按所需路线另装。已有环境不应无故覆盖或重建。本机官方包版本为 `ansys-mechanical-core==0.13.2`、`ansys-mechanical-mcp==0.2.0`，Fluent 独立环境为 `ansys-fluent-core==0.42.1`、`ansys-fluent-mcp==0.4.0`；迁移到其他 Ansys 版本时重新核对兼容性。

用户确认其豆包电脑版有技能或 MCP 设置；本次没有实际操作或验证豆包。

1. 复制整个 ansys-automatic-wwj 文件夹。若其技能功能接受 SKILL.md 文件夹，按客户端要求导入；若只接受文本指令，把入口及所需参考加入技能知识，并保留本地桥文件。不要声称任何客户端都能原样导入 Codex skill。
2. 目标机器安装目标 Ansys 产品及合法许可，准备匹配版本的 Python、官方 SDK、MCP。目录同名不等于版本/许可兼容。
3. 更新 runtime.local.json 中所有本机路径、edition 和硬件说明；不要把另一台机器的 Student 限制提示误当实时发现。
4. 更新 mcp.local.json 的 command/args/env 路径，在客户端本地 stdio MCP 设置添加所需服务。先用统一桥的 product_info 验证工具可调用。
5. 只读检查现有工程，然后运行专用小算例：真实求解状态、物理量、原生保存/重开、窗口保留均通过才标“豆包已接入验证”。

不同 MCP 客户端通常启动不同服务器进程；豆包不会自动继承 Codex 的现有会话。附着必须明确核对对应产品、端口和工程，避免重复打开同一文件的可写副本。

## 扩展官方 MCP

官方目录已有 Mechanical、MAPDL、Fluent、CFX、AEDT、Lumerical MCP；只安装当前任务所需的服务，先查各包当前参数和 Python 要求。包名与官方入口见 products.researched.json / product-routes.md。不要把所有包一次性装进一个环境。

迁移或修复只改当前任务有关配置，保留已有 MCP 服务和用户设置。不打包 Python 虚拟环境、Ansys 程序、许可证文件或连接口令。
