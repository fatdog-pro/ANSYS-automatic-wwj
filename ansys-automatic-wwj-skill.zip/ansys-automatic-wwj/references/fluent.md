# Fluent：按已验证代码完整重跑飞机示例

目标是省去接收者 agent 的重复思考和接口试错，**仍然在接收者电脑实际执行建模、网格、求解、验证和展示**。默认入口是 `scripts/replay_fluent_aircraft.py`；旧 Case/Data 是对照和可选预览，不是默认交付的新结果。固定工况为简化飞机、20 m/s、5°迎角，详细阶段见 [飞机算例说明](aircraft-example.md)。

## 固定执行流程

1. 从 skill 自身位置定位 `assets/examples/aircraft/replay/`，校验 manifest。这里是来源运行中真实成功的脚本，已将作者盘符换成执行器传入的目录变量；不要重新发明网格算法、猜 settings 属性或另拼一套代码。
2. 用 `--check-only` 检查资产、Python 依赖、Fluent 安装和当前会话，不启动求解器。缺项只处理具体环境问题。目标基线是 Python 3.12、Fluent 2026 R1（26.1.0）、PyFluent 0.42.1、Gmsh 4.15.2；完整依赖版本在 `replay/requirements.txt`。
3. 在唯一 ASCII 工作目录中启动一次执行器。它重新生成飞机 CAD 和流体网格，经网格拓扑检查后启动专用 Fluent 3D 双精度 GUI，按固定顺序设置、初始化、迭代、显示、保存并重开核对。
4. 执行期间只依据阶段日志和本次 `records/progress.json` 更新进度，不再临时调整物理模型、放宽残差标准或重复提交运行任务。脚本已经包含原先用过的 SIMPLE→Coupled、伪时间及线性求解精度控制顺序。
5. 固定路线最多推进至约 790 步；每个末段批次依据本次实际数据验收，达标即结束数值阶段并导出。源机在第 747 步达到目标，接收者不保证恰好同一步。若达到路线边界仍未通过，保存结果并明确“未收敛”；不能加载旧解冒充成功或继续无限尝试新路线。
6. 从本次运行目录的 `replay_summary.json`、`results/validation.json`、`records/reopen_verification.json` 读取状态和新数值。`completed`/exit0、旧图或源记录不能代替本次求解验收。保留新 Fluent 窗口。

在 skill 根目录内，使用已配好依赖的 Python：

```powershell
python scripts/replay_fluent_aircraft.py --plan
python scripts/replay_fluent_aircraft.py --check-only
python scripts/replay_fluent_aircraft.py
```

`--plan` 只显示固定阶段；`--geometry-only` 仅重新生成并验证几何/网格，不启动 Ansys。打开器支持 `--fluent-exe`、`--product-version`、`--run-root`；`--mesh-python` 可指定独立 Gmsh 环境。未指定时使用当前 Python 生成网格，运行目录默认选 ASCII 临时路径；若用户名导致路径不适用，指定本机可写的 ASCII 目录。

需要安装缺失依赖时，在独立 Python 3.12 环境中执行 `python -m pip install -r assets/examples/aircraft/replay/requirements.txt`，或者沿用已满足依赖的分离环境。不要无故覆盖用户已有环境。Ansys 程序与许可证仍需由接收者实际安装；skill 不包含 Ansys 安装程序或授权。

## 已有会话与失败边界

执行器发现已有 Fluent 会话时不启动第二个实例，也不关闭/替换用户工程。先核对会话身份和保存状态；若用户希望复用已打开会话，由代理说明并取得所需的项目替换授权后按相同路线适配，不能静默覆盖。技能打包/只读验证不需要关闭当前窗口。

任一建模、接口、网格或求解阶段异常时记录具体阶段并停止自动路线，不自动重试整个工程。保留已生成文件与已启动 GUI，定位该版本/环境的具体差异后再修复；不要把“固定路线”解释为忽略错误。旧版 Fluent 读取或脚本兼容性未验证；其他版本必须另核对接口与结果。

## MCP 客户端的一次提交

已有终端时直接运行入口。只有 MCP 的客户端使用 [通用桥](bridge.md) 的 `write_script` / `start_job`，先完成 [目标机配置](mcp-and-migration.md)。提交一个短入口，调用包内执行器，避免把二十多个阶段分别交给 agent 逐次推导。

```python
# ansys-product: fluent
# ansys-session: dedicated-keep-open
import runpy
from pathlib import Path
# SKILL_ROOT、PROJECT_DIR 和可选的软件/网格Python路径由本机配置确定
entry = runpy.run_path(str(SKILL_ROOT / 'scripts' / 'replay_fluent_aircraft.py'))
raise SystemExit(entry['main'](['--run-root', str(PROJECT_DIR)]))
```

`SKILL_ROOT` 是目标机已安装的 skill 目录，`PROJECT_DIR` 是桥配置允许的 ASCII 项目目录；写成真实值后提交。运行过程中查询 `job_status` / `read_job_log` 即可。作业尚在运行时不要重复 start_job。会话专属状态和失败原因以执行器写出的本机记录为准。

## 只在明确要求预览时读取旧结果

用户说“只看已有结果、不重新算”时才使用 `scripts/open_fluent_aircraft.py --view pressure|streamlines|velocity`。它校验并复制旧 Case/Data、重定向报告路径、显示原生图形、回读升阻力，本次 `iterations_run=0`。`--prepare-only` 只复制原生文件，无需 SDK；手动打开时保留 `.cas.h5` 与 `.dat.h5` 在同一目录。

必须说清这是来源运行的已保存场。用户要求 30 m/s、新迎角或新几何时，应在明确修改后的项目中重新求解与验收；默认执行器固定为 20 m/s、5°，不能直接把旧数据换个标签。

## 保留的已验证接口要点

- 原生压力为 `results.graphics.contour['aircraft-pressure']`，流线场景为 `results.scene['aircraft-streamline-scene']`，速度切面为 `results.scene['wing-velocity-scene']`。
- 增强图形组合用 `scene.graphics_objects.add(name=已有图形对象)`；旧 `draw_mesh` / `display_states.use_active` 在来源环境不活动，成功脚本已使用正确接口。
- 力报告返回 `[数值, 单位]`，第二项不是迭代号。`report_definitions.compute` 对现有场积分，不求解流动；真实求解仍通过固定脚本的 `iterate` 完成。
- `py=False` 关闭 Fluent 内嵌 Python 控制台，外部 PyFluent 继续工作；用于已验证的中文主机名兼容路径，不修改软件安装文件。
- GUI 参数为 `ui_mode='gui', cleanup_on_exit=False, start_watchdog=False`；不用会自动关闭求解器的上下文管理器，不在结束时调用 `exit/disconnect/close`。
- 迭代数读实际 monitor history，不用 `rp_vars('sol/iterations')`。源 GUI 会话的 transcript 文件曾为空，执行器保留真正的 API 回读、CSV 和阶段日志。
- 数值收敛、整体质量守恒和气动精度不同。近壁网格粗、没有网格独立性，不能用成功重跑声称真实飞机性能已验证。
