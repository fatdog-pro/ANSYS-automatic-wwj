# Ansys 产品路由与接口覆盖（官方文档核查）

核查日期：2026-09-15。用途：统一 `ansys-automatic-wwj` skill 的产品分流参考。**本表记录文档支持；不代表本机已安装、许可证可用、已连接或已求解。** 本机状态必须由探测结果和实际算例分别给出。

## 必须保留的边界

- “全部模块”应实现为统一入口、按产品选择接口和显式报告缺项；不能声称一个 Mechanical MCP 可以控制全部 Ansys 产品。
- GUI 可见、API 可调用、实际完成求解是三个独立状态。保存原生项目并在正确产品里重新打开，也是有效交付方式。
- 只通过官方 MCP、Python/.NET API、原生脚本或已核查 CLI 操作；不使用屏幕识别、鼠标键盘模拟。API 返回结果和导出的科学图像可以用于验证。
- 模块没有当前版本的可靠接口时，标记 `needs_adapter`；许可证明确不支持接口时，标记 `license_api_unavailable`。不以另一个产品的计算冒充该模块已运行。

## 优先路由矩阵

| 产品 / 分析族 | 官方程序入口 | 原生交付及重开 | 可见窗口边界 | 验证条件 / 官方依据 |
|---|---|---|---|---|
| Mechanical：静力、瞬态结构、稳态/瞬态热、模态、谐响应、屈曲等 | `ansys-mechanical-mcp` → PyMechanical `launch_mechanical` / `run_python_script` → Mechanical ACT 数据模型 | `.mechdb` + 配套结果目录，或 `.mechpz`；Workbench 集成另保存 `.wbpj/.wbpz` | PyMechanical 支持非 batch 启动；在已连接 Mechanical 内通过 ACT 选择和激活结果 | 每个分析类型仍需查询本机 `Model` 能力、创建分析、网格、求解、原生重开；不能因静力通过就把全部分析标为通过。[PyMechanical MCP](https://github.com/ansys/pymechanical-mcp)；[Mechanical standalone 边界](https://mechanical.docs.pyansys.com/version/stable/kil/mechanical.html)；[原生导入格式](https://ansyshelp.ansys.com/public/Views/Secured/corp/v251/en/wb2_help/wb2h_importing_files.html) |
| Mechanical Explicit Dynamics / Autodyn / Mechanical LS-DYNA | 首选当前安装版本的 Mechanical ACT 或 Workbench journal；独立 Autodyn/LS-DYNA 另路由 | Mechanical 工程；Autodyn `.ad`；LS-DYNA `.k/.key` 和结果目录 | Mechanical 内对应分析可见不等于独立产品 GUI 已连接 | Explicit Dynamics、Autodyn、LS-DYNA 不是同一个后端。先确认模板、求解器安装和授权，再实测对应 API。[Student 分析系统清单](https://ansys.synopsys.com/academic/students/ansys-student)；[导入格式](https://ansyshelp.ansys.com/public/Views/Secured/corp/v251/en/wb2_help/wb2h_importing_files.html) |
| Mechanical APDL | `ansys-mapdl-mcp` / PyMAPDL `launch_mapdl(mode="grpc")`；APDL 输入脚本 | `.db` / `.cdb`、`.rst`（结构）或相应热结果、可重放 `.inp` | `mapdl.open_gui(include_result=True)` 保存当前数据库并在 MAPDL GUI 打开；这与 gRPC 会话中的实时同步显示应区别说明 | 当前 Windows 推荐 gRPC；console 模式限 Linux。Student 会自动选 SMP，仍应控制核数。[launch_mapdl](https://mapdl.docs.pyansys.com/version/stable/api/_autosummary/ansys.mapdl.core.launcher.launch_mapdl.html)；[open_gui](https://mapdl.docs.pyansys.com/version/stable/api/_autosummary/ansys.mapdl.core.Mapdl.open_gui.html) |
| Fluent：流动、传热、多相、燃烧等 | `ansys-fluent-mcp` → PyFluent `launch_fluent`；settings / meshing API；必要时官方 TUI/journal | `.cas.h5` + `.dat.h5`；网格与 journal | `ui_mode="gui"`；通过原生 graphics settings 显示网格和云图 | 各物理模型有单独设置和许可证约束。本机已有 `py=False` 的中文主机名兼容路径，不修改安装源文件。[PyFluent](https://github.com/ansys/pyfluent)；[launcher](https://fluent.docs.pyansys.com/version/stable/api/launcher/launcher.html) |
| CFX / CFD-Post | **已有官方** `ansys-cfx-mcp`；PyCFX `PreProcessing.from_install()`、`Solver.from_install()`、`PostProcessing.from_install()`；版本匹配 CCL/session/CLI 后备 | `.cfx`、`.def`、`.res`，后处理 `.cst`；多配置有 `.mdef/.mres` 和配套目录 | CFX-Pre、Solver Manager、CFD-Post 是不同窗口/会话；需查询当前 PyCFX 启动参数，不能把 Fluent `ui_mode` 参数照搬 | PyCFX 支持 CFX **2025 R2 SP3 及以后**。官方 MCP 可启动/附着三类工作流。[PyCFX](https://github.com/ansys/pycfx)；[PyCFX MCP](https://github.com/ansys/pycfx-mcp)；[原生文件](https://ansyshelp.ansys.com/public/Views/Secured/corp/v252/en/cfx_intr/cfxANSYANSYFile.html) |
| AEDT：HFSS / HFSS 3D Layout、Maxwell 2D/3D、Q3D/Q2D、Icepak、Circuit、Twin Builder、RMxprt、EMIT | `ansys-aedt-mcp` / PyAEDT `ansys.aedt.core` 中各 Application 类 | `.aedt` 与配套结果；PCB 工作流按实际设计包含 EDB 等依赖 | `non_graphical=False`；可在可见 Desktop 中控制设计、求解与原生场图/报告 | AEDT Student 是单独下载，Workbench Student 的存在不能证明 AEDT 安装；Student 不保证所有 PyAEDT Application 都授权。AEDT 的 `Mechanical` 类也不等同于 Workbench Mechanical。[PyAEDT API 列表和启动](https://aedt.docs.pyansys.com/version/stable/API/index.html)；[PyAnsys MCP 包清单](https://docs.pyansys.com/version/dev/getting-started/install.html) |
| Lumerical：FDTD、MODE、Multiphysics、INTERCONNECT | `ansys-lumerical-mcp` / `ansys-lumerical-core`；随产品提供的 `lumapi`；LSF 脚本 | FDTD `.fsp`；其他应用用该产品 API 保存项目并记录实际格式及依赖 | `FDTD(hide=False)` 等启动 CAD/GUI；`hide=True` 是隐藏模式 | 需独立安装和合法产品许可；逆设计 `lumopt2` 还要求 Lumerical 2026 R1.2+。不能将 SPEOS 或 Zemax 的安装等同于 Lumerical。[PyLumerical](https://lumerical.docs.pyansys.com/version/stable/)；[GUI 入门](https://lumerical.docs.pyansys.com/version/stable/getting_started/index.html)；[MCP 清单](https://docs.pyansys.com/version/dev/getting-started/install.html) |
| SPEOS | PySpeos `launcher.launch_local_speos_rpc_server` / `Speos` / `Project` → `SimulationDirect` 等；SpaceClaim/SPEOS 插件脚本需单独适配 | Speos 原生场景/仿真文件与依赖、`.xmp/.xm3` 结果；保存时使用实际版本 `SceneLink.save_file` / simulation export API | RPC 是服务；不能许诺同步控制 SPEOS 建模 GUI。Windows 官方 `open_result_in_viewer` 可将结果在原生查看器打开 | 服务需要 SPEOS 许可；Student 有几何/三角形限制，禁 GPU 和 Live Preview。不是“安装 PySpeos 就获得完整 SPEOS”。[结果查看器](https://speos.docs.pyansys.com/version/stable/examples/workflow/open-result.html)；[服务许可](https://speos.docs.pyansys.com/version/stable/getting_started/faq.html)；[接口索引](https://speos.docs.pyansys.com/version/stable/genindex.html) |
| Zemax OpticStudio | 支持编程的许可：ZOS-API（Python.NET / C# / C++ / MATLAB），或 ZPL；**Student 禁止该路由** | 通过 `TheSystem` 保存原生镜头项目和依赖；实际版本通常 `.zos` / 旧 `.zmx`，必须在本机 API 文档确认 | ZOS-API Interactive 可连接已开的实例；Standalone 是后台计算，不是可见交互模式 | **当前 Student 明确不支持 ZPL、ZOS-API、User Defined DLLs**，标记 `license_api_unavailable`，不尝试绕过。商业/支持接口的许可才可启用适配器。[Student 限制](https://ansys.synopsys.com/academic/students/ansys-student)；[ZOS-API 模式](https://optics.ansys.com/hc/en-us/articles/42661773562899-Sample-code-for-ZOS-API-users)；[Python.NET](https://optics.ansys.com/hc/en-us/articles/42661747915539-ZOS-API-using-Python-NET) |
| LS-DYNA 独立求解 | 当前 PyDYNA `Deck` / `keywords` 生成输入；版本匹配 LS-DYNA CLI 提交；DPF 后处理；或 Mechanical LS-DYNA | `.k/.key` 输入、`d3plot`、binout 等实际产生结果；在 LS-PrePost 或 Mechanical 支持的导入流程重开 | 求解器 CLI 本身无完整建模 GUI；PyDYNA `deck.plot()` 是预览，不能冒充 Ansys 原生窗口。LS-PrePost 的脚本/CLI 应按安装版单独核查 | **PyDYNA 0.11 起删 core.pre/core.run，core.solvers 废弃**；官方旧 example 仍引用 `core.run.run_dyna`，不能盲用。LS-DYNA Student 是单独产品。[当前首页警告](https://dyna.docs.pyansys.com/version/stable/)；[Deck 与原生输出](https://dyna.docs.pyansys.com/version/stable/getting-started/example.html) |
| Rocky / DEM / SPH | PyRocky `launch_rocky(headless=False)` → `RockyClient.api`（PrePost Scripting） | `api.SaveProject("...rocky")` 与结果依赖 | 原生 UI 可见；PyRocky 不能自动处理确认/错误模态框，应避免触发或停下让用户处理 | PyRocky 要求 Rocky 2024 R2+；Student 的可用脚本和模块有裁剪。[启动与附着](https://rocky.docs.pyansys.com/version/stable/getting_started/index.html)；[保存与GUI已知限制](https://rocky.docs.pyansys.com/version/stable/user_guide/index.html) |
| Discovery / SpaceClaim / Geometry | PyAnsys Geometry `launch_modeler_with_discovery`、`launch_modeler_with_spaceclaim`、Geometry service；Discovery/SpaceClaim 自身脚本接口另查 | Geometry Design 原生保存/导出；`.scdocx` 等取决于后端与许可 | SpaceClaim `hidden=False`；Discovery 可启动建模后端；纯 Geometry Service 是服务 | **Geometry API 是 CAD 建模，不覆盖 Discovery 全部物理求解**。Student 禁几何导出；原生项目保存与中性CAD导出分开检查。Discovery 的 GPU要求须探测，不能本机 Intel UHD 直接标支持。[本地后端](https://geometry.docs.pyansys.com/version/stable/getting_started/local/index.html)；[launcher 参数](https://geometry.docs.pyansys.com/version/stable/api/ansys/geometry/core/connection/launcher/index.html) |
| ACP Pre/Post / 复材 | PyACP `launch_acp` → 模型铺层 / 导出；求解交给 Mechanical/MAPDL；DPF Composites 后处理 | `model.save("...acph5")`、结构输入和求解结果 | 官方说明为保存 `.acph5` 后 ACP GUI 打开/重载；不是同步 GUI 控制承诺 | 复材定义、结构求解、失效后处理分别验证。ACP API 客户端成功不代表结构 solver 已通过。[保存](https://acp.docs.pyansys.com/version/stable/user_guide/howto/file_management.html)；[GUI 工作流](https://acp.docs.pyansys.com/version/stable/user_guide/howto/view_model_in_acp_gui.html) |
| System Coupling | PySystemCoupling `ansys.systemcoupling.core.launch()` / `connect()`；原生 Python commands；Workbench integration | **整个耦合工作目录**：`SyC/Settings.h5`、restart、participant 输入/结果；`.scp/.sci` 仅用于填充参与者/设置，不是完整工程 | GUI、CLI、Workbench 均有入口；PySystemCoupling 会话不自动等于可见 GUI，需用匹配版本保存/打开工作目录或脚本入口 | 每个参与者先独立通过，再验证映射、耦合收敛、守恒；本机许可/内存要能同时承担参与者。[API 启动](https://systemcoupling.docs.pyansys.com/version/stable/api/core/launching.html)；[GUI 命令入口](https://ansyshelp.ansys.com/public/Views/Secured/corp/v261/en/sysc_ug/sysc_userinterfaces_gui_menus.html)；[完整导出目录](https://ansyshelp.ansys.com/public/Views/Secured/corp/v251/en/sysc_ug/sysc_workbench_workflows_advanced_exportsetup.html) |
| Motion | 原生 Motion API 外部 `.dll` 或 `.dfjnl` journal；Motion Postprocessor Python.NET `VM.Post.API.OutputReader`；Mechanical Motion 分支独立核查 | 原生工程及所有依赖文件（按已安装版 Publish/Save 格式），`.dfjnl` 重放；后处理 `.dfr` | API/journal 可供 Motion 自身执行；目前未核实可安全外部启动并附着全部前处理的统一 Python 参数，因此应标 `needs_adapter` | 后处理 API 只读曲线不等于完整建模/求解接口；不可发明 `ansys-motion-core`。2026 Student 含 Motion但有模型规模限制。[原生API与journal](https://ansyshelp.ansys.com/public/Views/Secured/corp/v252/en/motion_pre/File_Menu.html)；[Post API](https://ansyshelp.ansys.com/public/Views/Secured/corp/v251/en/motion_post/postprocessor_api_py.html) |
| Motor-CAD | PyMotorCAD `MotorCAD()`；`get/set_variable`、电磁/热/机械求解接口 | `save_to_file("...mot")` + 各分析结果目录；保存结果 API 另调用 | `set_visible(True)`、`display_screen("scripting")`；原生界面可见 | 可见 UI 不会逐步刷新每次参数更改；官方建议在 scripting 页设置变量。Motor-CAD 是单独产品/许可。[GUI 行为](https://motorcad.docs.pyansys.com/version/stable/user_guide/Motor-CAD_setup.html)；[MOT 保存](https://motorcad.docs.pyansys.com/version/stable/methods/_autosummary_General/ansys.motorcad.core.motorcad_methods.MotorCAD.save_to_file.html) |
| optiSLang / DesignXplorer | PyOptiSLang `Optislang(batch=False)`；项目 nodes、Python 脚本、参数研究；Workbench DesignXplorer journal 另路由 | `.opf` 和完整工作目录；`application.save_as` | `batch=False` 原生 GUI；若用户要保持打开，显式管理 dispose/shutdown 生命周期 | 它调度其他 solver；项目完成不等于所有设计点求解成功，要逐点记录响应、失败与可行性。[启动 API](https://optislang.docs.pyansys.com/version/stable/api/_autosummary/ansys.optislang.core.optislang.Optislang.html)；[GUI/保存官方速查](https://optislang.docs.pyansys.com/version/stable/_static/cheat_sheet.pdf) |
| GRANTA MI / 材料数据 | PyGranta 服务客户端；MI Scripting Toolkit、JobQueue、RecordLists、BoM Analytics | MI 服务器记录 ID、查询/导入导出文件与来源；无通用“solver case” | 这是材料数据服务，不是独立CAE求解窗口；GUI/网页展示与仿真软件交付分开 | 不能把 Workbench Engineering Data 与 GRANTA MI 数据服务授权混同；使用已有 MI endpoint 与合法访问凭据。[官方开发者接口](https://developer.synopsys.com/docs/granta-mi)；[PyGranta](https://github.com/ansys/pygranta) |

## Student 2026 R1 路由前置检查

依据同一官方 [Student 下载/限制页](https://ansys.synopsys.com/academic/students/ansys-student)：

- Workbench Student 列有 Mechanical、MAPDL、CFX、Fluent、ACP、Autodyn、Discovery、SPEOS、optiSLang、Rocky、System Coupling、SpaceClaim、Motion（2026 R1）、OpticStudio 等。**列入套装不证明本机该组件安装完整**。
- AEDT Student、LS-DYNA Student 是另列的下载；不要因 E 盘有 Workbench Student 就自动启用。
- 结构限制 128K nodes/elements，流体 1M cells/nodes，通常最多 4 CPU cores；各专门产品限额另查。应使用小算例按实际 license response 验证。
- OpticStudio Student 不支持编程功能，是当前“不用屏幕操作却跑全部模块”目标的明确产品边界。

## 拓展到本表外产品

套装还包含 EnSight、TurboGrid、Chemkin-Pro、Forte、Polyflow、FENSAP-ICE、Aqwa、DesignModeler、Meshing 等。统一 skill 应保留通用回退：识别产品 → 本机版本/可执行文件 → 官方当前 API 或脚本/CLI 文档 → 建模/求解/保存/重开适配器 → 小算例验证。未核实前标为 `needs_adapter`。

PyAnsys 官方目录已列 PyEnSight、PyTurboGrid、PyChemkin、PyPrimeMesh、PyWorkbench 等，供继续选路。**目录存在不表示某产品所有功能都可经 Python 覆盖**。来源：[PyAnsys 官方目录](https://docs.pyansys.com/version/stable/)。

## 建议状态字段

### 将 needs_adapter 接到本包桥

`adapter_required` 当前会被桥明确阻断；写一个 .py 文件不会自动启用。扩展时按以下实际配置接通：

1. 在独立目录编写外部 CPython 适配器，内部只调用该产品已核实的官方 API、原生 journal 或 CLI。若调用 CLI，用绝对程序路径、参数列表、`shell=False`；记录返回码和产品结果状态。此适配器不是 Ansys 官方 SDK，名称和说明要区分。
2. 用用户授权的专用小工程验证建模/求解/原生保存，并检查窗口生命周期；若暂时只能做后处理，注册范围就只写后处理。没有实际求解证据时仍保留未验证状态。
3. 为该产品在 `assets/products.json` 保留精确 `id`，将 `execution_kind` 设为 `local_python_adapter`，`python_package` 设为 null，`python_import` 写适配器的实际模块名，`runtime` 指向已配置解释器。保留 `student_api_blocked`，不得用适配器绕过已知许可限制。
4. 在 `runtime.local.json` 的 `bundled_api_paths.<product_id>` 中登记适配器目录（此字段也用于本机自有适配器）；桥只会把该路径加到该作业的 PYTHONPATH。示例为 `"aqwa": ["D:/AnsysAdapters/aqwa"]`，需替换为真实已创建的路径。
5. 重新 product_info；此时 `configured_unverified` 仍只表示路径存在。先运行仅 import 和读取版本的脚本，再运行目标算例，核对真实结果。脚本使用匹配产品 ID 与会话声明，按 write_script → start_job → job_status/read_job_log 提交。
6. 更新该产品的 evidence 与验证记录，运行桥测试；新增产品仍需加入注册表。客户端没有本地文件配置能力时，这一步需要在本机编辑/部署完成，不能靠给模型一段提示词替代。

当前没有预置这些未核实产品的完整适配器，因此不能把它们标成开箱即用。所有 SDK 的可用方法也随版本而变化，接通一个产品不代表它的全部模型、求解器与许可均通过。

每个产品独立记录：`documented_route`、`installed`、`python_dependency_ready`、`license_checked`、`connected`、`setup_verified`、`solve_verified`、`native_reopen_verified`、`gui_visible_verified`、`limitations`、`evidence_paths`。缺少证据保持 `unknown`，不能从相邻字段推断。

本次仅完成官方文档核查，没有安装依赖或启动求解器。
